#!/usr/bin/env python3
"""
web_search.py — FinanceAGI Autonomous Web Search Module
Pure httpx implementation — NO external packages needed beyond what's already installed.
Works on Termux/Android with zero additional installs.

Uses DuckDuckGo HTML search (scrapes the response) + DuckDuckGo Instant Answer API.
Both are free, no key, no rate limit.

The agent searches automatically in 5 situations:
  1. MORNING BRIEF   — 9:00 AM daily → Nifty outlook + key levels
  2. LOSING STREAK   — 3+ consecutive losses → why is market moving
  3. WEEKLY IMPROVE  — Sunday → strategy research
  4. INSTRUMENT MOVE — MCX move >1.5% → why is it moving
  5. POST EVENT      — after high-impact event fires
"""

import asyncio, json, logging, re, sqlite3, time, html
from datetime import datetime, timezone, timedelta
from pathlib import Path

try:  # IMPORT-FIX
    import httpx
except ImportError:
    httpx = None  # graceful degradation — web search disabled

log  = logging.getLogger("agi.search")
IST  = timezone(timedelta(hours=5, minutes=30))
BASE = Path(__file__).resolve().parent
DB   = str(BASE / "data" / "v10.db")

ENV = {}
ef  = BASE / ".env"
if ef.exists():
    for ln in ef.read_text().splitlines():
        ln = ln.strip()
        if ln and not ln.startswith("#") and "=" in ln:
            k, v = ln.split("=", 1); ENV[k.strip()] = v.strip()

ANTHROPIC_KEY = ENV.get("ANTHROPIC_API_KEY", "")
OLLAMA_HOST   = ENV.get("OLLAMA_HOST",  "http://localhost:11434")
OLLAMA_MODEL  = ENV.get("OLLAMA_MODEL", "qwen2.5:3b")

# ── DB helpers ────────────────────────────────────────────────────────────────

def _db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def _save(key: str, value):
    try:
        c = _db()
        c.execute("INSERT OR REPLACE INTO config(key,val) VALUES(?,?)",
                  (f"search_{key}", json.dumps(value)))
        c.commit(); c.close()
    except Exception: pass

def _load(key: str):
    try:
        c = _db()
        row = c.execute("SELECT val FROM config WHERE key=?", (f"search_{key}",)).fetchone()
        c.close()
        return json.loads(row["val"]) if row else None
    except Exception:
        return None

# ═══════════════════════ SEARCH ENGINE ═══════════════════════

class WebSearcher:
    """
    Pure httpx DuckDuckGo search — no extra packages needed.

    Method 1: DuckDuckGo Instant Answer API (ddg.gg/?q=...&format=json)
              Fast, structured, but only returns summaries.

    Method 2: DuckDuckGo HTML scrape (html.duckduckgo.com)
              Full search results. Parses snippets from HTML.

    Both work on Termux with just httpx.
    """

    MAX_DAILY = 20
    CACHE_TTL = 7200   # 2 hours
    MIN_GAP   = 5.0    # seconds between searches

    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 13; Samsung Galaxy) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-IN,en;q=0.9",
    }

    def __init__(self):
        self._count   = 0
        self._day     = None
        self._cache   = {}
        self._last    = 0.0

    def _reset(self):
        today = datetime.now(IST).date()
        if today != self._day:
            self._count = 0
            self._day   = today

    def _cached(self, q: str):
        k = str(hash(q.lower().strip()))
        c = self._cache.get(k)
        if c and time.time() - c["ts"] < self.CACHE_TTL:
            return c["r"]
        return None

    def _cache_set(self, q: str, r: list):
        self._cache[str(hash(q.lower().strip()))] = {"r": r, "ts": time.time()}

    async def search(self, query: str, max_results: int = 5) -> list:
        """Search DuckDuckGo. Returns list of {title, url, body}."""
        self._reset()

        cached = self._cached(query)
        if cached is not None:
            log.info(f"  [SEARCH] Cache: {query[:50]}")
            return cached

        if self._count >= self.MAX_DAILY:
            log.info(f"  [SEARCH] Daily limit ({self.MAX_DAILY}) reached")
            return []

        gap = self.MIN_GAP - (time.time() - self._last)
        if gap > 0:
            await asyncio.sleep(gap)

        log.info(f"  [SEARCH] '{query[:60]}' (#{self._count+1}/{self.MAX_DAILY})")

        # Try HTML scrape first (more results), fall back to instant API
        results = await self._html_search(query, max_results)
        if not results:
            results = await self._instant_search(query)

        self._count += 1
        self._last   = time.time()
        self._cache_set(query, results)
        return results

    async def _html_search(self, query: str, max_results: int) -> list:
        """Scrape DuckDuckGo HTML results."""
        try:
            async with httpx.AsyncClient(timeout=12, follow_redirects=True) as client:
                r = await client.get(
                    "https://html.duckduckgo.com/html/",
                    params={"q": query, "kl": "in-en", "s": "0"},
                    headers=self.HEADERS,
                )
                if r.status_code != 200:
                    return []
                return self._parse_html(r.text, max_results)
        except Exception as e:
            log.debug(f"  [SEARCH] HTML search error: {e}")
            return []

    def _parse_html(self, html_text: str, max_results: int) -> list:
        """Extract results from DuckDuckGo HTML response."""
        results = []
        # DDG HTML structure: <a class="result__a" href="...">title</a>
        #                     <a class="result__snippet">snippet</a>
        title_pat   = re.compile(r'class="result__a"[^>]*>(.*?)</a>', re.DOTALL)
        snippet_pat = re.compile(r'class="result__snippet"[^>]*>(.*?)</a>', re.DOTALL)
        url_pat     = re.compile(r'class="result__url"[^>]*>(.*?)</span>', re.DOTALL)

        titles   = title_pat.findall(html_text)
        snippets = snippet_pat.findall(html_text)
        urls     = url_pat.findall(html_text)

        for i in range(min(max_results, len(titles))):
            title   = self._clean(titles[i])
            body    = self._clean(snippets[i]) if i < len(snippets) else ""
            url     = self._clean(urls[i])     if i < len(urls)     else ""
            if title and body:
                results.append({"title": title, "url": url, "body": body})

        return results

    async def _instant_search(self, query: str) -> list:
        """DuckDuckGo Instant Answer API — returns summary if available."""
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                r = await client.get(
                    "https://api.duckduckgo.com/",
                    params={"q": query, "format": "json", "no_html": "1",
                            "no_redirect": "1", "skip_disambig": "1"},
                    headers={"User-Agent": self.HEADERS["User-Agent"]},
                )
                data = r.json()
                results = []
                abstract = data.get("AbstractText","")
                if abstract:
                    results.append({
                        "title": data.get("Heading", query),
                        "url":   data.get("AbstractURL",""),
                        "body":  abstract[:300],
                    })
                for topic in data.get("RelatedTopics", [])[:4]:
                    text = topic.get("Text","")
                    url  = topic.get("FirstURL","")
                    if text:
                        results.append({"title": text[:60], "url": url, "body": text[:200]})
                return results
        except Exception as e:
            log.debug(f"  [SEARCH] Instant API error: {e}")
            return []

    @staticmethod
    def _clean(text: str) -> str:
        text = re.sub(r"<[^>]+>", "", text)
        text = html.unescape(text)
        text = re.sub(r"\s+", " ", text).strip()
        return text[:300]

    def to_text(self, results: list) -> str:
        if not results:
            return "No results."
        lines = []
        for i, r in enumerate(results, 1):
            lines.append(f"{i}. {r['title']}")
            if r["body"]:
                lines.append(f"   {r['body']}")
        return "\n".join(lines)

searcher = WebSearcher()

# ═══════════════════════ KEY LEVEL EXTRACTOR ═══════════════════════

class KeyLevelExtractor:
    """Extract support/resistance levels and sentiment from search text."""

    SUPPORT_RE    = re.compile(r"support\s+(?:at|near|around)?\s*(\d{4,6}(?:\.\d+)?)|(\d{4,6}(?:\.\d+)?)\s+support", re.I)
    RESIST_RE     = re.compile(r"resistance\s+(?:at|near|around)?\s*(\d{4,6}(?:\.\d+)?)|(\d{4,6}(?:\.\d+)?)\s+resistance", re.I)
    TARGET_RE     = re.compile(r"target\s+(?:of|at|around)?\s*(\d{4,6}(?:\.\d+)?)", re.I)
    BULL_WORDS    = {"bullish","buy","upside","positive","rally","gains","strong","surge","breakout"}
    BEAR_WORDS    = {"bearish","sell","downside","negative","fall","weak","decline","drop","crash"}

    def extract(self, text: str, spot: float = 23000) -> dict:
        def _levels(pattern):
            vals = []
            for m in pattern.finditer(text):
                raw = m.group(1) or m.group(2) if m.lastindex >= 2 else m.group(1)
                try:
                    v = float(raw)
                    if spot * 0.80 <= v <= spot * 1.20:
                        vals.append(v)
                except Exception:  # BUG-EXCEPT-4 FIX: was bare except
                    pass
            return sorted(set(vals))

        tl = text.lower()
        bull = sum(tl.count(w) for w in self.BULL_WORDS)
        bear = sum(tl.count(w) for w in self.BEAR_WORDS)
        sentiment = "bullish" if bull > bear + 2 else "bearish" if bear > bull + 2 else "neutral"

        return {
            "support":    _levels(self.SUPPORT_RE),
            "resistance": _levels(self.RESIST_RE),
            "targets":    _levels(self.TARGET_RE),
            "sentiment":  sentiment,
        }

level_extractor = KeyLevelExtractor()

# ═══════════════════════ MARKET BRIEF ═══════════════════════

class MarketBrief:
    """Daily market brief built from web searches."""

    def __init__(self):
        self.date       = None
        self.sentiment  = "neutral"
        self.support    = []
        self.resistance = []
        self.headlines  = []
        self.summary    = ""
        self.bias_score = 0.0

    def update(self, results: list, spot: float = 23000):
        text = " ".join(r["body"] for r in results)
        self.headlines  = [r["title"] for r in results[:5]]
        levels          = level_extractor.extract(text, spot)
        self.support    = levels["support"]
        self.resistance = levels["resistance"]
        self.sentiment  = levels["sentiment"]
        self.date       = datetime.now(IST).date()
        self.bias_score = +0.08 if self.sentiment == "bullish" else -0.08 if self.sentiment == "bearish" else 0.0
        self.summary    = f"sentiment={self.sentiment} support={self.support[:2]} resist={self.resistance[:2]}"
        log.info(f"  [SEARCH] Brief: {self.summary}")
        _save("market_brief", {
            "date": str(self.date), "sentiment": self.sentiment,
            "support": self.support, "resistance": self.resistance,
            "headlines": self.headlines, "bias": self.bias_score,
        })

    def level_bias(self, spot: float, opt_type: str) -> float:
        near_sup = any(abs(spot - s) / max(1,s) * 100 <= 0.3 for s in self.support)
        near_res = any(abs(spot - r) / max(1,r) * 100 <= 0.3 for r in self.resistance)
        if near_sup: return +0.08 if opt_type == "CE" else -0.04
        if near_res: return +0.08 if opt_type == "PE" else -0.04
        return self.bias_score

market_brief = MarketBrief()

# ═══════════════════════ LLM INSIGHT ═══════════════════════

def _ask_llm(search_text: str, context: str) -> str:
    """Send search results to Claude/Ollama for insights. Synchronous."""
    prompt = (
        f"Context: {context}\n\nSearch results:\n{search_text}\n\n"
        "Give 2-3 specific insights for an NSE intraday options bot: "
        "key price levels, market bias, risks. Under 80 words. Direct."
    )
    if ANTHROPIC_KEY:
        try:
            r = httpx.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": ANTHROPIC_KEY,
                         "anthropic-version": "2023-06-01",
                         "content-type": "application/json"},
                json={"model": "claude-haiku-4-5-20251001", "max_tokens": 150,
                      "messages": [{"role": "user", "content": prompt}]},
                timeout=15,
            )
            return r.json().get("content", [{}])[0].get("text", "")
        except Exception: pass
    try:
        import urllib.request
        data = json.dumps({"model": OLLAMA_MODEL, "prompt": prompt,
                           "stream": False, "options": {"num_predict": 120}}).encode()
        req  = urllib.request.Request(
            f"{OLLAMA_HOST}/api/generate", data=data,
            headers={"Content-Type": "application/json"}, method="POST"
        )
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read()).get("response", "")
    except Exception:
        return ""

# ═══════════════════════ QUERY BUILDERS ═══════════════════════

def _morning_queries() -> list:
    d = datetime.now(IST).strftime("%d %B %Y")
    return [
        f"Nifty 50 support resistance levels today {d}",
        f"Bank Nifty outlook {d}",
    ]

def _streak_queries(losses: int, trades: list) -> list:
    d = datetime.now(IST).strftime("%d %B %Y")
    uls = list(set(t.get("underlying","") for t in trades[-3:] if t.get("underlying","")))
    q = [f"Nifty 50 market direction {d}"]
    if uls: q.append(f"{uls[0]} outlook today India")
    return q[:2]

def _weekly_queries() -> list:
    return [
        "best NSE Nifty intraday options strategy 2026",
        "MCX crude oil natural gas trading strategy India profit",
    ]

def _instrument_queries(symbol: str, event: str) -> list:
    d = datetime.now(IST).strftime("%d %B %Y")
    return [f"{symbol} price {event} reason India {d}"]

# ═══════════════════════ AUTONOMOUS SEARCHER ═══════════════════════

class AutonomousSearcher:
    def __init__(self):
        self._morning_done   = None
        self._weekly_done    = None
        self._last_streak    = 0.0
        self._last_instr     = {}

    async def run_morning_brief(self, spots: list):
        now   = datetime.now(IST)
        today = now.date()
        if self._morning_done == today: return
        if not (now.weekday() < 5 and now.hour == 9 and now.minute <= 15): return
        self._morning_done = today
        log.info("  [SEARCH] Morning brief...")
        all_r = []
        for q in _morning_queries():
            r = await searcher.search(q, 4)
            all_r.extend(r)
            if r: await asyncio.sleep(4)
        if not all_r: return
        market_brief.update(all_r, spots[-1] if spots else 23000)
        txt     = searcher.to_text(all_r)
        insight = await asyncio.get_event_loop().run_in_executor(
            None, lambda: _ask_llm(txt, f"Morning brief {today}")
        )
        if insight:
            log.info(f"  [SEARCH] Morning: {insight[:180]}")
            _save("morning_insight", {"date": str(today), "insight": insight,
                                       "brief": market_brief.summary})

    async def run_losing_streak(self, losses: int, trades: list, spots: list):
        if losses < 3: return
        if time.time() - self._last_streak < 3600: return
        self._last_streak = time.time()
        log.info(f"  [SEARCH] {losses} losses — searching market context")
        all_r = []
        for q in _streak_queries(losses, trades):
            r = await searcher.search(q, 3)
            all_r.extend(r)
            if r: await asyncio.sleep(4)
        if not all_r: return
        market_brief.update(all_r, spots[-1] if spots else 23000)
        txt     = searcher.to_text(all_r)
        insight = await asyncio.get_event_loop().run_in_executor(
            None, lambda: _ask_llm(txt, f"After {losses} consecutive losses")
        )
        if insight:
            log.info(f"  [SEARCH] Streak insight: {insight[:180]}")
            _save("streak_insight", {"ts": datetime.now(IST).isoformat(),
                                      "losses": losses, "insight": insight})

    async def run_weekly(self):
        now  = datetime.now(IST)
        week = now.isocalendar()[1]
        if self._weekly_done == week: return
        if not (now.weekday() == 6 and 10 <= now.hour <= 12): return
        self._weekly_done = week
        log.info("  [SEARCH] Weekly strategy search...")
        all_r = []
        for q in _weekly_queries():
            r = await searcher.search(q, 3)
            all_r.extend(r)
            if r: await asyncio.sleep(5)
        if not all_r: return
        txt     = searcher.to_text(all_r)
        insight = await asyncio.get_event_loop().run_in_executor(
            None, lambda: _ask_llm(txt, "Weekly NSE strategy review")
        )
        if insight:
            log.info(f"  [SEARCH] Weekly: {insight[:200]}")
            _save("weekly_insight", {"week": week, "year": now.year, "insight": insight})

    async def run_instrument(self, symbol: str, move_pct: float, spots: list):
        last = self._last_instr.get(symbol, 0)
        if time.time() - last < 1800: return
        if abs(move_pct) < 1.5: return
        self._last_instr[symbol] = time.time()
        event = "rising" if move_pct > 0 else "falling"
        log.info(f"  [SEARCH] {symbol} {move_pct:+.1f}% — searching reason")
        results = await searcher.search(_instrument_queries(symbol, event)[0], 3)
        if not results: return
        txt     = searcher.to_text(results)
        insight = await asyncio.get_event_loop().run_in_executor(
            None, lambda: _ask_llm(txt, f"{symbol} moved {move_pct:+.1f}%")
        )
        if insight:
            log.info(f"  [SEARCH] {symbol}: {insight[:150]}")
            _save(f"instr_{symbol.lower()}", {"ts": datetime.now(IST).isoformat(),
                                               "move": move_pct, "insight": insight})

auto_searcher = AutonomousSearcher()

# ═══════════════════════ BACKGROUND LOOP ═══════════════════════

async def run_search_loop(spots_ref: list, ls_ref: list, trades_ref: list):
    """Background coroutine. Add to asyncio.gather in run()."""
    log.info("  [SEARCH] Web search loop started (pure httpx — no extra packages needed)")
    while True:
        try:
            await asyncio.sleep(30)
            spots  = spots_ref[0]  if spots_ref  else []
            ls     = ls_ref[0]     if ls_ref     else 0
            trades = trades_ref[0] if trades_ref else []
            await auto_searcher.run_morning_brief(spots)
            await auto_searcher.run_losing_streak(ls, trades, spots)
            await auto_searcher.run_weekly()
        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error(f"  [SEARCH] Loop error: {e}")
            await asyncio.sleep(60)

# ═══════════════════════ PUBLIC API ═══════════════════════

def get_search_bias(spot: float, opt_type: str) -> float:
    """Score bias from web market brief. Returns 0 if brief is stale."""
    if market_brief.date != datetime.now(IST).date():
        return 0.0
    return market_brief.level_bias(spot, opt_type)

def get_morning_insight() -> str:
    data = _load("morning_insight")
    if not data: return ""
    if data.get("date") != str(datetime.now(IST).date()): return ""
    return data.get("insight", "")
