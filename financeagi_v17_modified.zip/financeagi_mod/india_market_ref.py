#!/usr/bin/env python3
"""
india_market_ref.py — Indian Market Reference Data for FinanceAGI (2021–2026)
==============================================================================
Sourced from NSE circulars, SEBI reports, broker margin calculators, and
financial data platforms as of March 2026.

DO NOT CHANGE — ONLY ADD.

Usage:
    from india_market_ref import (
        get_lot_size, get_stt_rate, get_vix_regime,
        scale_premium_for_vix, MARKET_REF, FNO_STOCKS,
        INTRADAY_STOCKS, MCX_COMMODITIES, STRATEGY_WIN_RATES,
        REGULATORY_TIMELINE, calc_charges_accurate,
    )
"""

from datetime import date, datetime
from typing import Union

# ══════════════════════════════════════════════════════════════════════════════
# NIFTY 50 LOT SIZE HISTORY
# Source: NSE circulars FAOP64625, Stocko bulletin Oct 2025
# ══════════════════════════════════════════════════════════════════════════════
NIFTY_LOT_HISTORY = [
    # (effective_from, effective_to_inclusive, lot_size)
    (date(2021,  1,  1), date(2024, 11, 19), 25),
    (date(2024, 11, 20), date(2025, 10, 27), 75),
    (date(2025, 10, 28), date(2099, 12, 31), 65),   # current as of Mar 2026
]

# ══════════════════════════════════════════════════════════════════════════════
# BANKNIFTY LOT SIZE HISTORY
# Source: NSE circulars, Dhan lot-size page, Sahi blog Apr 2025, Stocko Oct 2025
# ══════════════════════════════════════════════════════════════════════════════
BANKNIFTY_LOT_HISTORY = [
    (date(2021,  1,  1), date(2024, 11, 19), 15),
    (date(2024, 11, 20), date(2025,  3, 31), 30),
    (date(2025,  4,  1), date(2025, 10, 27), 35),
    (date(2025, 10, 28), date(2099, 12, 31), 30),   # current as of Mar 2026
]

def get_lot_size(symbol: str, trade_date: Union[date, datetime, str]) -> int:
    """
    Return the correct lot size for NIFTY or BANKNIFTY on a given date.
    For all other symbols, returns the lot size from FNO_STOCKS dict.

    Args:
        symbol:     'NIFTY', 'BANKNIFTY', or any FNO stock symbol (e.g. 'RELIANCE')
        trade_date: date / datetime / ISO string (YYYY-MM-DD)

    Returns:
        int lot size

    Examples:
        get_lot_size('NIFTY', date(2024, 11, 1))   → 25
        get_lot_size('NIFTY', date(2025, 1, 1))    → 75
        get_lot_size('NIFTY', date(2026, 3, 1))    → 65
        get_lot_size('BANKNIFTY', date(2025, 5, 1))→ 35
        get_lot_size('RELIANCE', date(2026, 3, 1)) → 500
    """
    if isinstance(trade_date, str):
        trade_date = date.fromisoformat(trade_date[:10])
    elif isinstance(trade_date, datetime):
        trade_date = trade_date.date()

    sym_upper = symbol.upper()

    if sym_upper in ("NIFTY", "NIFTY50"):
        for (from_d, to_d, lot) in NIFTY_LOT_HISTORY:
            if from_d <= trade_date <= to_d:
                return lot
        return 25  # fallback pre-2021

    if sym_upper in ("BANKNIFTY", "BANK NIFTY"):
        for (from_d, to_d, lot) in BANKNIFTY_LOT_HISTORY:
            if from_d <= trade_date <= to_d:
                return lot
        return 15  # fallback pre-2021

    # FNO stocks — static (lot sizes as of March 2026, post-SEBI revision)
    stock_lots = {s["symbol"]: s["lot_size"] for s in FNO_STOCKS}
    if sym_upper in stock_lots:
        return stock_lots[sym_upper]

    return 1  # fallback for unknown symbols


# ══════════════════════════════════════════════════════════════════════════════
# STT (Securities Transaction Tax) RATE HISTORY — OPTIONS
# Source: Bajaj Finserv, Cleartax, Budget 2024
# ══════════════════════════════════════════════════════════════════════════════
STT_OPTIONS_HISTORY = [
    # (effective_from, rate_on_sell_premium)
    # STT on options is charged on sell side only, on premium value
    (date(2021,  1,  1), date(2026,  3, 31), 0.0010),   # 0.10% until Mar 31 2026
    (date(2026,  4,  1), date(2099, 12, 31), 0.0015),   # 0.15% from Apr 1 2026
]

STT_FUTURES_HISTORY = [
    # (effective_from, rate_on_turnover)
    (date(2021,  1,  1), date(2026,  3, 31), 0.000200),  # 0.02% until Mar 31 2026
    (date(2026,  4,  1), date(2099, 12, 31), 0.000500),  # 0.05% from Apr 1 2026
]

def get_stt_rate(trade_date: Union[date, datetime, str],
                 instrument: str = "option") -> float:
    """
    Return the correct STT rate for a given trade date.

    Args:
        trade_date:  date / datetime / ISO string
        instrument:  'option' or 'future'

    Returns:
        float rate (e.g. 0.001 = 0.10%)
    """
    if isinstance(trade_date, str):
        trade_date = date.fromisoformat(trade_date[:10])
    elif isinstance(trade_date, datetime):
        trade_date = trade_date.date()

    history = STT_OPTIONS_HISTORY if instrument == "option" else STT_FUTURES_HISTORY
    for (from_d, to_d, rate) in history:
        if from_d <= trade_date <= to_d:
            return rate
    return 0.001  # safe fallback


def calc_charges_accurate(buy_price: float, sell_price: float,
                           qty: int, trade_date: Union[date, datetime, str],
                           instrument: str = "option") -> tuple:
    """
    Accurate charge calculation respecting STT history.
    Replaces the hardcoded calc_charges() in backtest_inject.py for historical work.

    Returns:
        (total_charges, gross_pnl, net_pnl)  — all in ₹
    """
    stt_rate  = get_stt_rate(trade_date, instrument)
    buy_val   = buy_price  * qty
    sell_val  = sell_price * qty
    turnover  = buy_val + sell_val

    brokerage = 40.0
    stt       = sell_val  * stt_rate         # STT on sell side only (options)
    exchange  = turnover  * 0.000495         # NSE transaction charge
    sebi      = turnover  * 0.000001
    ipft      = turnover  * 0.000001
    stamp     = buy_val   * 0.00003
    gst       = (brokerage + exchange + sebi + ipft) * 0.18
    total     = brokerage + stt + exchange + gst + sebi + stamp + ipft

    gross     = (sell_price - buy_price) * qty
    return round(total, 2), round(gross, 2), round(gross - total, 2)


# ══════════════════════════════════════════════════════════════════════════════
# INDIA VIX REGIME CLASSIFICATION
# Source: CEIC Data, NSE historical VIX; Long-term median 16.16 (2012–2026)
# ══════════════════════════════════════════════════════════════════════════════
VIX_REGIMES = [
    # (label, vix_min_inclusive, vix_max_exclusive, premium_multiplier, description)
    ("ultra_low",  0.0,  11.0, 0.70, "Option premiums cheap; sellers' paradise"),
    ("low",       11.0,  14.0, 0.85, "Sellers' market, low IV crush risk"),
    ("normal",    14.0,  18.0, 1.00, "Baseline premium environment (median 16.16)"),
    ("elevated",  18.0,  22.0, 1.35, "Corrections/events; buyers have edge"),
    ("high",      22.0,  30.0, 1.70, "Fear spike; major risk-off move"),
    ("crisis",    30.0, 999.0, 2.50, "Rare; ATH 83.61 on Mar 24 2020"),
]

VIX_HISTORICAL_BY_YEAR = {
    # year: (avg_low, avg_high, notable_events)
    2021: (12, 28, "COVID Delta spike Apr-May"),
    2022: (13, 30, "Russia-Ukraine Feb-Mar spike"),
    2023: (10, 16, "Calm year, declining vol"),
    2024: (9.5, 23, "Election spike Jun 4 to 23; record low 9.15 Dec 26"),
    2025: (9.15, 21, "Record low Dec 26 2025; correction spike"),
    2026: (12, 21, "Sharp correction Jan-Mar; VIX 14→21 in two sessions"),
}

def get_vix_regime(vix: float) -> dict:
    """
    Classify a VIX value into a regime.

    Returns dict with keys: label, premium_multiplier, description
    """
    for (label, vmin, vmax, mult, desc) in VIX_REGIMES:
        if vmin <= vix < vmax:
            return {"label": label, "premium_multiplier": mult, "description": desc}
    return {"label": "normal", "premium_multiplier": 1.0, "description": "fallback"}


def scale_premium_for_vix(base_premium: float, vix: float) -> float:
    """
    Scale a base option premium by VIX regime multiplier.

    The reference baseline is VIX ~14–18 (multiplier=1.0).
    At VIX=25 premiums are ~2× a VIX=12 environment.

    Args:
        base_premium: premium at normal VIX (14–18 range)
        vix:          current India VIX value

    Returns:
        float scaled premium
    """
    regime = get_vix_regime(vix)
    return round(base_premium * regime["premium_multiplier"], 2)


# ══════════════════════════════════════════════════════════════════════════════
# NIFTY WEEKLY OPTION PREMIUM GUIDE
# Points at ~23,000–24,000 index level; scale proportionally for other levels
# Source: NSE historical option chains, broker data
# ══════════════════════════════════════════════════════════════════════════════
NIFTY_WEEKLY_PREMIUMS = {
    # otm_points: {dte: (min_premium, max_premium)}
    # Multiply by VIX regime multiplier from scale_premium_for_vix()
    0:   {5: (120, 180), 3: (70, 120), 1: (30, 60),  0: (10, 30)},   # ATM
    100: {5: (60, 100),  3: (35, 65),  1: (10, 30),  0: (2,  12)},
    200: {5: (25, 50),   3: (12, 30),  1: (3,  10),  0: (0.5, 3)},
    300: {5: (8,  25),   3: (4,  15),  1: (1,  5),   0: (0.05, 1)},
}

NIFTY_STRIKE_INTERVAL = 50          # points
BANKNIFTY_STRIKE_INTERVAL = 100     # points

# ══════════════════════════════════════════════════════════════════════════════
# EXPIRY SCHEDULE HISTORY
# Source: NSE circulars, Zerodha Z-Connect, Geojit notifications
# ══════════════════════════════════════════════════════════════════════════════
EXPIRY_SCHEDULE = {
    # (symbol, period_start, period_end): (frequency, day_of_week)
    # day_of_week: 'thursday', 'tuesday', 'last_tuesday_monthly', None=discontinued
    ("NIFTY",     date(2021,  1,  1), date(2025,  4,  3)): ("weekly",  "thursday"),
    ("NIFTY",     date(2025,  4,  4), date(2099, 12, 31)): ("weekly",  "tuesday"),
    ("BANKNIFTY", date(2021,  1,  1), date(2024, 11, 19)): ("weekly",  "wednesday"),
    ("BANKNIFTY", date(2024, 11, 20), date(2025,  4,  3)): ("monthly", "last_thursday"),
    ("BANKNIFTY", date(2025,  4,  4), date(2099, 12, 31)): ("monthly", "last_tuesday"),
    # FINNIFTY and MIDCAPNIFTY weeklies also discontinued Nov 20 2024
    ("FINNIFTY",  date(2021,  1,  1), date(2024, 11, 19)): ("weekly",  "tuesday"),
    ("FINNIFTY",  date(2024, 11, 20), date(2099, 12, 31)): ("monthly", "last_tuesday"),
}


# ══════════════════════════════════════════════════════════════════════════════
# NIFTY 50 HISTORICAL PRICE TABLE
# Source: Wikipedia/NSE historical data
# ══════════════════════════════════════════════════════════════════════════════
NIFTY_YEARLY = [
    # (year, low, high, year_end, annual_return_pct)
    (2021, 13600, 18600, 17354, 24.0),
    (2022, 15183, 18887, 18105,  4.3),
    (2023, 16828, 21800, 21731, 20.0),
    (2024, 21280, 26277, 23644,  8.8),
    (2025, 21744, 26200, 26000, 10.0),
    # 2026 Jan–Mar: ATH 26,373 (Jan 5), current ~23,100
    (2026, 23000, 26373, 23100, None),
]

NIFTY_ATH = 26373   # January 5, 2026
NIFTY_CURRENT_MAR2026 = 23100   # approx March 2026

# ══════════════════════════════════════════════════════════════════════════════
# BANKNIFTY HISTORICAL PRICE TABLE
# Source: Enrich Money, NSE data
# ══════════════════════════════════════════════════════════════════════════════
BANKNIFTY_YEARLY = [
    # (year, low, high, year_end)
    (2021, 29300, 41830, 35500),
    (2022, 32155, 44150, 43050),
    (2023, 38600, 48636, 48500),
    (2024, 44250, 54467, 51066),
    (2025, 46000, 55000, 54000),
    (2026, 49000, 55500, 53400),   # current Mar 2026
]

BANKNIFTY_ATH = 54467   # September 2024
BANKNIFTY_CURRENT_MAR2026 = 53400


# ══════════════════════════════════════════════════════════════════════════════
# 25 FNO STOCKS — PRICES AND LOT SIZES AS OF MARCH 2026
# Source: NSE, Dhan lot-size page; prices after ~12% correction from ATH
# Notes:
#   - IRCTC removed from F&O effective February 25, 2026
#   - TATAMOTORS demerged Oct 2025; F&O symbol is now TMPV (passenger vehicles)
# ══════════════════════════════════════════════════════════════════════════════
FNO_STOCKS = [
    # symbol, price_mar2026, lot_size, contract_value_lakh, iv_band
    {"symbol": "RELIANCE",   "price": 1414,  "lot_size": 500,  "contract_lakh": 7.07,  "iv_band": (14, 22)},
    {"symbol": "TCS",        "price": 2373,  "lot_size": 175,  "contract_lakh": 4.15,  "iv_band": (12, 20)},
    {"symbol": "HDFCBANK",   "price": 781,   "lot_size": 550,  "contract_lakh": 4.30,  "iv_band": (12, 18)},
    {"symbol": "INFY",       "price": 1241,  "lot_size": 400,  "contract_lakh": 4.96,  "iv_band": (14, 22)},
    {"symbol": "ICICIBANK",  "price": 1264,  "lot_size": 700,  "contract_lakh": 8.85,  "iv_band": (14, 20)},
    {"symbol": "SBIN",       "price": 1069,  "lot_size": 750,  "contract_lakh": 8.02,  "iv_band": (16, 24)},
    {"symbol": "BHARTIARTL", "price": 1840,  "lot_size": 475,  "contract_lakh": 8.74,  "iv_band": (16, 26)},
    {"symbol": "ITC",        "price": 299,   "lot_size": 1600, "contract_lakh": 4.78,  "iv_band": (12, 18)},
    {"symbol": "KOTAKBANK",  "price": 375,   "lot_size": 2000, "contract_lakh": 7.50,  "iv_band": (14, 20)},
    {"symbol": "LT",         "price": 3435,  "lot_size": 175,  "contract_lakh": 6.01,  "iv_band": (16, 24)},
    {"symbol": "TMPV",       "price": 314,   "lot_size": 800,  "contract_lakh": 2.51,  "iv_band": (20, 35),
     "note": "ex-TATAMOTORS; demerged Oct 2025, F&O symbol TMPV (passenger vehicles)"},
    {"symbol": "MARUTI",     "price": 12500, "lot_size": 50,   "contract_lakh": 6.25,  "iv_band": (14, 22)},
    {"symbol": "BAJFINANCE", "price": 866,   "lot_size": 750,  "contract_lakh": 6.50,  "iv_band": (18, 28)},
    {"symbol": "AXISBANK",   "price": 1120,  "lot_size": 625,  "contract_lakh": 7.00,  "iv_band": (16, 24)},
    {"symbol": "WIPRO",      "price": 192,   "lot_size": 3000, "contract_lakh": 5.76,  "iv_band": (16, 24)},
    {"symbol": "HCLTECH",    "price": 1580,  "lot_size": 350,  "contract_lakh": 5.53,  "iv_band": (14, 22)},
    {"symbol": "ADANIENT",   "price": 2200,  "lot_size": 309,  "contract_lakh": 6.80,  "iv_band": (28, 45)},
    {"symbol": "TATASTEEL",  "price": 198,   "lot_size": 5500, "contract_lakh": 10.89, "iv_band": (22, 35)},
    {"symbol": "POWERGRID",  "price": 257,   "lot_size": 1900, "contract_lakh": 4.88,  "iv_band": (12, 18)},
    {"symbol": "NTPC",       "price": 381,   "lot_size": 1500, "contract_lakh": 5.72,  "iv_band": (14, 22)},
    {"symbol": "BHEL",       "price": 235,   "lot_size": 2625, "contract_lakh": 6.17,  "iv_band": (24, 38)},
    {"symbol": "PNB",        "price": 100,   "lot_size": 8000, "contract_lakh": 8.00,  "iv_band": (22, 35)},
    {"symbol": "BANKBARODA", "price": 255,   "lot_size": 2925, "contract_lakh": 7.46,  "iv_band": (18, 28)},
    {"symbol": "IDFCFIRSTB", "price": 63,    "lot_size": 9275, "contract_lakh": 5.84,  "iv_band": (22, 38)},
    # IRCTC: removed from F&O effective Feb 25, 2026
    {"symbol": "IRCTC",      "price": 700,   "lot_size": None, "contract_lakh": None,  "iv_band": None,
     "note": "REMOVED from F&O effective February 25, 2026 (SEBI eligibility norms)",
     "fo_removed_date": date(2026, 2, 25)},
]

# ATM monthly option premium range for FNO stocks: 1.5–4% of stock price at ~20 DTE
# Higher-vol (ADANIENT, BHEL, TATASTEEL, PNB): 3–4%
# Stable large-caps (HDFCBANK, ITC, POWERGRID): 1.5–2%
FNO_ATM_MONTHLY_PREMIUM_PCT = (1.5, 4.0)   # percent of stock price at ~20 DTE

def is_fo_eligible(symbol: str, trade_date: Union[date, datetime, str]) -> bool:
    """Return False if a stock has been removed from F&O by the given date."""
    if isinstance(trade_date, str):
        trade_date = date.fromisoformat(trade_date[:10])
    elif isinstance(trade_date, datetime):
        trade_date = trade_date.date()

    for s in FNO_STOCKS:
        if s["symbol"] == symbol.upper():
            removed = s.get("fo_removed_date")
            if removed and trade_date >= removed:
                return False
            return True
    return True   # unknown symbol — assume eligible


# ══════════════════════════════════════════════════════════════════════════════
# 11 INTRADAY EQUITY STOCKS — PRICES AS OF MARCH 2026
# Dominated by PSU and infrastructure names; high retail intraday volume
# ══════════════════════════════════════════════════════════════════════════════
INTRADAY_STOCKS = [
    # symbol, price_range_mar2026, 52w_range, notes
    {"symbol": "IRFC",   "price_range": (95,  97),  "52w": (95,  149), "notes": "Railway finance, ~4% dividend yield"},
    {"symbol": "NHPC",   "price_range": (74,  77),  "52w": (72,   92), "notes": "Hydro power, ~4.4% yield"},
    {"symbol": "SUZLON", "price_range": (41,  42),  "52w": (38,   74), "notes": "Wind energy, –44% from 52w high"},
    {"symbol": "RVNL",   "price_range": (262, 280), "52w": (261, 448), "notes": "Railway infra, P/E ~45"},
    {"symbol": "HFCL",   "price_range": (68,  72),  "52w": (60,   94), "notes": "Telecom infra"},
    {"symbol": "NBCC",   "price_range": (83,  87),  "52w": (75,  131), "notes": "Construction PSU"},
    {"symbol": "JPPOWER","price_range": (14,  14),  "52w": (13,   28), "notes": "Penny stock; true sub-₹20 name"},
    {"symbol": "HUDCO",  "price_range": (172, 180), "52w": (167, 254), "notes": "Housing finance PSU"},
    {"symbol": "IOC",    "price_range": (145, 145), "52w": (None, None),"notes": "Oil marketing, defensive"},
    {"symbol": "PFC",    "price_range": (407, 435), "52w": (330, 444), "notes": "Power finance, P/E ~6, 3.8% yield"},
    {"symbol": "RECLTD", "price_range": (335, 354), "52w": (331, 450), "notes": "Power finance, 6.9% yield"},
]

# ₹40–100 cluster (JPPOWER, IRFC, NHPC, SUZLON, HFCL, NBCC) = highest retail
# intraday volume relative to market cap. PFC and RECLTD higher-priced but heavy volume.
PENNY_STOCK_THRESHOLD = 20   # stocks below this are "penny stocks" in Indian context


# ══════════════════════════════════════════════════════════════════════════════
# MCX COMMODITY FUTURES — SPECIFICATIONS AS OF MARCH 20, 2026
# Source: Zerodha margin calculator, 5paisa GOLDPETAL page
# ══════════════════════════════════════════════════════════════════════════════
MCX_COMMODITIES = {
    "GOLDPETAL": {
        "lot_size":         1,           # 1 gram
        "price_mar2026":    14850,       # ₹/gram
        "contract_value":   14850,       # ₹ per lot
        "nrml_margin":      2160,        # ₹ (NRML / overnight)
        "margin_pct":       14.5,        # %
        "tick_size":        1,           # ₹/gram
        "pnl_per_tick":     1,           # ₹
        "price_range_2025_2026": (7000, 15300),  # ₹/gram
        "notes": "Lowest capital requirement among MCX contracts; gold rally 2025–2026",
    },
    "CRUDEOILM": {
        "lot_size":         10,          # barrels
        "price_mar2026":    8999,        # ₹/barrel
        "contract_value":   89990,       # ₹ per lot
        "nrml_margin":      31700,       # ₹
        "margin_pct":       35.0,        # % — highest among these 3
        "tick_size":        1,           # ₹/barrel
        "pnl_per_tick":     10,          # ₹
        "price_range_2025_2026": (4500, 9000),  # ₹/barrel
        "notes": "Highest margin % reflecting crude oil volatility; driven by global price + USD/INR",
    },
    "NATGASMINI": {
        "lot_size":         250,         # mmBtu
        "price_mar2026":    295,         # ₹/mmBtu
        "contract_value":   73750,       # ₹ per lot
        "nrml_margin":      22000,       # ₹
        "margin_pct":       30.0,        # %
        "tick_size":        0.10,        # ₹/mmBtu
        "pnl_per_tick":     25,          # ₹
        "price_range_2025_2026": (150, 350),    # ₹/mmBtu
        "notes": "Extremely volatile; tendency for violent intraday swings",
    },
}

# MIS (intraday) margins are typically 30–50% lower than NRML
MCX_MIS_MARGIN_FACTOR = 0.5   # approximate; varies by broker


# ══════════════════════════════════════════════════════════════════════════════
# SEBI STUDY: 93% RETAIL F&O TRADERS LOSE MONEY (Sep 2024)
# Period: FY22–FY24 (three years)
# ══════════════════════════════════════════════════════════════════════════════
SEBI_STUDY_2024 = {
    "period":                  "FY2022–FY2024",
    "loss_rate_pct":           93.0,            # % of individual traders with net losses
    "profitable_pct":          7.2,             # % with any profit
    "profitable_over_1lakh_pct": 1.0,           # % earning >₹1 lakh after costs
    "aggregate_net_losses_crore": 181000,        # ₹1.81 lakh crore
    "fpi_algo_profit_share_pct": 97.0,           # % of FPI profits from algo trading
    "prop_trader_algo_profit_share_pct": 96.0,  # % of prop trader profits from algo
    "avg_transaction_cost_per_trader": 26000,   # ₹/year
    "transaction_cost_as_pct_gross_loss": 27.0, # %
}

# For realistic synthetic data: no more than 7.2% of simulated accounts
# should show net profitability over a multi-year period.
MAX_REALISTIC_WIN_RATE_ANNUAL = 7.2   # % for account-level profitability


# ══════════════════════════════════════════════════════════════════════════════
# STRATEGY WIN RATES — FOR SYNTHETIC P&L MODELING
# Source: backtests, broker research, Medium/trader blogs, Zerodha Varsity
# ══════════════════════════════════════════════════════════════════════════════
STRATEGY_WIN_RATES = {
    "short_straddle_intraday": {
        "win_rate":    (60, 69),      # % range
        "avg_win_inr": (4000, 8000),  # ₹ per trade
        "avg_loss_inr":(8000, 15000), # ₹ per trade (negatively skewed)
        "risk_reward":  0.5,          # avg_win / avg_loss (< 1 = negative skew)
        "notes": "SL at 25–30% per leg; max drawdown ₹17,000+/lot on BANKNIFTY",
        "best_vix_regime": "normal",  # 14–18
    },
    "short_strangle": {
        "win_rate":    (65, 70),
        "avg_win_inr": (3000, 6000),
        "avg_loss_inr":(6000, 12000),
        "risk_reward":  0.5,
        "notes": "Transaction costs severely erode edge; backtests show costs eat gross profit",
        "best_vix_regime": "low",
    },
    "iron_condor": {
        "win_rate":    (65, 75),
        "avg_win_inr": (3000, 4500),
        "avg_loss_inr":(2000, 3000),
        "risk_reward":  1.5,          # defined risk; better skew
        "notes": "Historically cost-inefficient in Indian markets; better in ultra-low VIX",
        "best_vix_regime": "ultra_low",
    },
    "directional_option_buy": {
        "win_rate":    (30, 45),
        "avg_win_inr": (2500, 5000),
        "avg_loss_inr":(3000, 6000),
        "risk_reward":  0.8,
        "notes": "Theta headwind brutal; ATM weekly decay 9–10%/day at 5 DTE",
        "best_vix_regime": "elevated",   # need big moves to overcome theta
    },
    "momentum_scalping": {
        "win_rate":    (50, 55),
        "avg_win_inr": (500, 1500),
        "avg_loss_inr":(500, 1200),
        "risk_reward":  1.0,
        "notes": "Bid-ask spread eats 20–30% of 10-pt target; need 20–50 pt moves for profit",
        "best_vix_regime": "normal",
    },
    "mean_reversion": {
        "win_rate":    (60, 70),
        "avg_win_inr": (800, 2000),
        "avg_loss_inr":(2000, 5000),
        "risk_reward":  0.5,
        "notes": "Works on ~60–70% sideways days; small profit per trade",
        "best_vix_regime": "low",
    },
}

# Theta decay reference (ATM weekly options, NIFTY)
THETA_DECAY_REFERENCE = {
    "daily_decay_pct_at_5dte":   (9, 10),    # % of premium per day at 5 DTE
    "expiry_day_premium_loss_pct":(40, 60),  # % premium lost on expiry day (no major move)
    "overnight_theta_pct_of_daily": 78,      # % of daily theta that decays overnight
}


# ══════════════════════════════════════════════════════════════════════════════
# TRANSACTION COST REFERENCE
# Source: Angel One, Cleartax, NSE transaction charge schedule
# ══════════════════════════════════════════════════════════════════════════════
TRANSACTION_COST_REF = {
    "round_trip_1_nifty_lot_pre_apr2026": {
        "brokerage":   40.0,   # ₹ flat (₹20 × 2 orders, discount broker)
        "stt":         11.0,   # ₹ approx (0.10% on sell premium ~₹110 lot value)
        "exchange":    (7, 8), # ₹ (NSE transaction charge)
        "gst":         (8, 9), # ₹ (18% on brokerage + exchange)
        "total_range": (55, 70),
    },
    "breakeven_premium_move_per_unit": 1,   # ₹ just to cover costs
    "annual_avg_per_trader_inr": 26000,     # ₹/year (SEBI study FY22–FY24)
    "scalp_friction": {
        "target_5pt_gross":    325,  # ₹ (5 pts × 65 lots)
        "cost_pct_of_gross":   (17, 20),   # % friction on small scalp
    },
}


# ══════════════════════════════════════════════════════════════════════════════
# KEY REGULATORY TIMELINE
# Source: NSE circulars, Zerodha Z-Connect, SEBI notifications
# ══════════════════════════════════════════════════════════════════════════════
REGULATORY_TIMELINE = [
    {
        "date":   date(2024, 11, 20),
        "change": "SEBI ₹15L minimum contract value mandate",
        "impact": [
            "NIFTY lot size: 25 → 75",
            "BANKNIFTY lot size: 15 → 30",
            "One weekly expiry per exchange (NSE retains NIFTY only)",
            "BANKNIFTY/FINNIFTY/MIDCAPNIFTY weekly expiries discontinued",
            "2% ELM (Extreme Loss Margin) on short options on expiry day",
        ],
    },
    {
        "date":   date(2025,  2, 10),
        "change": "Calendar spread margin benefit removed on expiry day",
        "impact": ["Changed hedging economics for multi-leg strategies on expiry"],
    },
    {
        "date":   date(2025,  4,  4),
        "change": "Expiry day shifted Thursday → Tuesday",
        "impact": ["NIFTY weekly and all monthly expiries now on Tuesday"],
    },
    {
        "date":   date(2025, 10, 28),
        "change": "Lot size revision (SEBI review)",
        "impact": [
            "NIFTY lot size: 75 → 65",
            "BANKNIFTY lot size: 35 → 30",
        ],
    },
    {
        "date":   date(2026,  2, 25),
        "change": "IRCTC removed from F&O",
        "impact": ["IRCTC no longer available for derivatives trading (SEBI eligibility norms)"],
    },
    {
        "date":   date(2026,  4,  1),
        "change": "STT rate hike",
        "impact": [
            "Options STT: 0.10% → 0.15% (50% increase)",
            "Futures STT: 0.02% → 0.05% (150% increase)",
        ],
    },
]


# ══════════════════════════════════════════════════════════════════════════════
# MASTER REFERENCE DICT — convenient single-import access
# ══════════════════════════════════════════════════════════════════════════════
MARKET_REF = {
    "nifty": {
        "lot_history":       NIFTY_LOT_HISTORY,
        "yearly":            NIFTY_YEARLY,
        "ath":               NIFTY_ATH,
        "current_mar2026":   NIFTY_CURRENT_MAR2026,
        "strike_interval":   NIFTY_STRIKE_INTERVAL,
        "weekly_premiums":   NIFTY_WEEKLY_PREMIUMS,
    },
    "banknifty": {
        "lot_history":       BANKNIFTY_LOT_HISTORY,
        "yearly":            BANKNIFTY_YEARLY,
        "ath":               BANKNIFTY_ATH,
        "current_mar2026":   BANKNIFTY_CURRENT_MAR2026,
        "strike_interval":   BANKNIFTY_STRIKE_INTERVAL,
    },
    "vix": {
        "long_term_median":  16.16,
        "ath":               83.61,   # Mar 24 2020
        "record_low":        9.15,    # Dec 26 2025
        "regimes":           VIX_REGIMES,
        "historical":        VIX_HISTORICAL_BY_YEAR,
    },
    "fno_stocks":            FNO_STOCKS,
    "intraday_stocks":       INTRADAY_STOCKS,
    "mcx":                   MCX_COMMODITIES,
    "sebi_study":            SEBI_STUDY_2024,
    "strategy_win_rates":    STRATEGY_WIN_RATES,
    "theta_decay":           THETA_DECAY_REFERENCE,
    "transaction_costs":     TRANSACTION_COST_REF,
    "regulatory_timeline":   REGULATORY_TIMELINE,
    "stt_options_history":   STT_OPTIONS_HISTORY,
    "stt_futures_history":   STT_FUTURES_HISTORY,
    "expiry_schedule":       EXPIRY_SCHEDULE,
}


# ══════════════════════════════════════════════════════════════════════════════
# QUICK SANITY CHECK (run: python3 india_market_ref.py)
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("=== india_market_ref.py — sanity check ===\n")

    tests = [
        ("NIFTY",     "2024-06-01",  25),
        ("NIFTY",     "2024-12-01",  75),
        ("NIFTY",     "2026-01-01",  65),
        ("BANKNIFTY", "2024-11-01",  15),
        ("BANKNIFTY", "2025-01-01",  30),
        ("BANKNIFTY", "2025-06-01",  35),
        ("BANKNIFTY", "2026-03-01",  30),
        ("RELIANCE",  "2026-03-01", 500),
    ]
    all_ok = True
    for sym, dt, expected in tests:
        got = get_lot_size(sym, dt)
        status = "✓" if got == expected else "✗ FAIL"
        print(f"  {status}  get_lot_size('{sym}', '{dt}') = {got}  (expected {expected})")
        if got != expected:
            all_ok = False

    print()
    stt_tests = [
        ("2026-03-31", "option", 0.001),
        ("2026-04-01", "option", 0.0015),
        ("2026-04-01", "future", 0.0005),
    ]
    for dt, inst, expected in stt_tests:
        got = get_stt_rate(dt, inst)
        status = "✓" if abs(got - expected) < 1e-8 else "✗ FAIL"
        print(f"  {status}  get_stt_rate('{dt}', '{inst}') = {got}  (expected {expected})")
        if abs(got - expected) >= 1e-8:
            all_ok = False

    print()
    vix_tests = [
        (10.5, "ultra_low", 0.70),
        (13.0, "low",       0.85),
        (16.0, "normal",    1.00),
        (20.0, "elevated",  1.35),
        (25.0, "high",      1.70),
        (35.0, "crisis",    2.50),
    ]
    for vix, expected_label, expected_mult in vix_tests:
        r = get_vix_regime(vix)
        ok_l = r["label"] == expected_label
        ok_m = abs(r["premium_multiplier"] - expected_mult) < 1e-6
        status = "✓" if (ok_l and ok_m) else "✗ FAIL"
        print(f"  {status}  VIX={vix:5.1f} → {r['label']:10s} mult={r['premium_multiplier']}")

    print()
    print(f"  scale_premium_for_vix(150, 25.0) = {scale_premium_for_vix(150, 25.0):.1f}  (expected 255.0)")
    print(f"  scale_premium_for_vix(150, 12.0) = {scale_premium_for_vix(150, 12.0):.1f}  (expected 127.5)")

    print()
    print(f"  IRCTC F&O eligible on 2026-02-24: {is_fo_eligible('IRCTC', '2026-02-24')}  (expected True)")
    print(f"  IRCTC F&O eligible on 2026-02-25: {is_fo_eligible('IRCTC', '2026-02-25')}  (expected False)")

    print()
    ch, gross, net = calc_charges_accurate(100.0, 115.0, 65, "2026-03-15", "option")
    print(f"  calc_charges_accurate(100, 115, 65, 2026-03-15): charges=₹{ch} gross=₹{gross} net=₹{net}")
    ch2, gross2, net2 = calc_charges_accurate(100.0, 115.0, 65, "2026-04-05", "option")
    print(f"  calc_charges_accurate(100, 115, 65, 2026-04-05): charges=₹{ch2} gross=₹{gross2} net=₹{net2}")
    print(f"  (STT diff pre/post Apr 2026: ₹{ch2-ch:.2f} higher charges)")

    print()
    print(f"  MCX GOLDPETAL margin: ₹{MCX_COMMODITIES['GOLDPETAL']['nrml_margin']}")
    print(f"  MCX CRUDEOILM margin: ₹{MCX_COMMODITIES['CRUDEOILM']['nrml_margin']}")
    print(f"  FNO stocks loaded: {len([s for s in FNO_STOCKS if s['lot_size'] is not None])} active")

    print()
    if all_ok:
        print("All core tests passed ✓")
    else:
        print("Some tests FAILED — check above ✗")
