"""
equity_intraday.py — Equity Intraday (MIS) Trading Module for FinanceAGI
Scans affordable stocks, uses MIS leverage (up to 5x), scalps 0.3-1% moves.

Capital-adaptive:
  ₹500-2K  → Penny stocks under ₹30 (IRFC, NHPC, PNB, SUZLON)
  ₹2K-10K  → Mid-range stocks ₹30-200 (BHEL, BANKBARODA, TATASTEEL)
  ₹10K+    → All stocks including large caps with MIS leverage

Uses Upstox APIs:
  - /v2/market-quote/ohlc for OHLC + volume data
  - /v2/market-quote/ltp for batch LTP (up to 500 keys)
  - /v3/order/place with product="I" (MIS intraday)

Charges for equity intraday:
  - Brokerage: ₹20 per order (buy+sell = ₹40)
  - STT: 0.025% on sell side only
  - Exchange: 0.00297% both sides (NSE)
  - GST: 18% on (brokerage + exchange + SEBI)
  - SEBI: ₹10/crore both sides
  - Stamp duty: 0.003% on buy side
  - NO DP charges (intraday, no delivery)
"""

import asyncio, json, logging, time, math, random
from datetime import datetime, timezone, timedelta

log = logging.getLogger("agi.equity")
IST = timezone(timedelta(hours=5, minutes=30))

# ═══════════════════════ EQUITY FEATURES ═══════════════════════

# Feature names for the equity NN scorer (must match agent.py's inline array)
EQ_FEATURES = [
    "day_change_pct",    # intraday change %  (÷10 for scaling)
    "range_pct",         # day range as %     (÷5)
    "range_position",    # 0=at low, 1=at high
    "vol_ratio",         # volume vs avg ratio
    "direction_sign",    # +1 BUY, -1 SELL
    "scanner_score",     # scanner score      (÷10)
]

# ═══════════════════════ STOCK UNIVERSE ═══════════════════════

# Affordable liquid stocks for intraday scalping
# Categorized by price range for capital-adaptive selection

EQUITY_STOCKS = {
    # Penny / Ultra-cheap (₹5-30) — good for ₹500-2K capital
    "IRFC":       {"key": "NSE_EQ|INE053F01010", "tier": "penny"},
    "NHPC":       {"key": "NSE_EQ|INE848E01016", "tier": "penny"},
    "SUZLON":     {"key": "NSE_EQ|INE040H01021", "tier": "penny"},
    "RVNL":       {"key": "NSE_EQ|INE415G01027", "tier": "penny"},
    "HFCL":       {"key": "NSE_EQ|INE548C01032", "tier": "penny"},
    "NBCC":       {"key": "NSE_EQ|INE095N01031", "tier": "penny"},
    "JPPOWER":    {"key": "NSE_EQ|INE351F01018", "tier": "penny"},
    "HUDCO":      {"key": "NSE_EQ|INE031A01017", "tier": "penny"},

    # Low-mid (₹30-100) — good for ₹2K-5K capital
    "PNB":        {"key": "NSE_EQ|INE160A01022", "tier": "low"},
    "BANKBARODA": {"key": "NSE_EQ|INE028A01039", "tier": "low"},
    "IOC":        {"key": "NSE_EQ|INE242A01010", "tier": "low"},
    "BHEL":       {"key": "NSE_EQ|INE257A01026", "tier": "low"},
    "PFC":        {"key": "NSE_EQ|INE134E01011", "tier": "low"},
    "RECLTD":     {"key": "NSE_EQ|INE020B01018", "tier": "low"},
    "IDFCFIRSTB": {"key": "NSE_EQ|INE092T01019", "tier": "low"},
    "NTPC":       {"key": "NSE_EQ|INE733E01010", "tier": "low"},

    # Mid (₹100-500) — good for ₹5K-15K capital
    "TATASTEEL":  {"key": "NSE_EQ|INE081A01020", "tier": "mid"},
    "SBIN":       {"key": "NSE_EQ|INE062A01020", "tier": "mid"},
    "POWERGRID":  {"key": "NSE_EQ|INE752E01010", "tier": "mid"},
    "ADANIENT":   {"key": "NSE_EQ|INE423A01024", "tier": "mid"},
    "ITC":        {"key": "NSE_EQ|INE154A01025", "tier": "mid"},
    "AXISBANK":   {"key": "NSE_EQ|INE238A01034", "tier": "mid"},
    "WIPRO":      {"key": "NSE_EQ|INE075A01022", "tier": "mid"},
    "IRCTC":      {"key": "NSE_EQ|INE335Y01020", "tier": "mid"},

    # High (₹500+) — need ₹10K+ capital, benefits from MIS leverage
    "HDFCBANK":   {"key": "NSE_EQ|INE040A01034", "tier": "high"},
    "ICICIBANK":  {"key": "NSE_EQ|INE090A01021", "tier": "high"},
    "RELIANCE":   {"key": "NSE_EQ|INE002A01018", "tier": "high"},
    "INFY":       {"key": "NSE_EQ|INE009A01021", "tier": "high"},
    "TCS":        {"key": "NSE_EQ|INE467B01029", "tier": "high"},
    "BHARTIARTL": {"key": "NSE_EQ|INE397D01024", "tier": "high"},
}

# MIS leverage estimate per tier (conservative estimates)
MIS_LEVERAGE = {
    "penny": 3,    # Lower leverage for volatile penny stocks
    "low": 4,
    "mid": 5,
    "high": 5,
}

# ═══════════════════════ CHARGES ═══════════════════════

class EquityIntradayCharges:
    """
    Upstox Equity Intraday (MIS) charges.
    Cheaper than options because:
      - STT is only 0.025% (vs 0.0625% for options)
      - No lot size constraint (buy 1 share or 1000)
      - No DP charges (intraday = no delivery)
    """

    @staticmethod
    def calculate(buy_price, sell_price, qty):
        buy_val = buy_price * qty
        sell_val = sell_price * qty
        turnover = buy_val + sell_val

        brokerage = min(40, turnover * 0.001)  # ₹20/order x 2, or 0.05% whichever lower
        stt = sell_val * 0.00025              # 0.025% sell side only (intraday)
        exchange = turnover * 0.0000297       # 0.00297% NSE
        sebi = turnover * 0.000001            # ₹10/crore
        stamp = buy_val * 0.00003             # 0.003% buy side
        gst = (brokerage + exchange + sebi) * 0.18

        total = brokerage + stt + exchange + gst + sebi + stamp
        gross = (sell_price - buy_price) * qty

        return {
            "total_charges": round(total, 2),
            "gross_pnl": round(gross, 2),
            "net_pnl": round(gross - total, 2),
            "breakeven_pct": round(total / max(1, buy_val) * 100, 3),
            "brokerage": round(brokerage, 2),
            "stt": round(stt, 2),
        }

    @staticmethod
    def breakeven_pct(buy_price, qty):
        # Bug #12 fix: calculate() caps brokerage on turnover (buy_val + sell_val),
        # but the old breakeven_pct() only used buy_val — producing a different cap
        # threshold and making pre-trade and post-trade charge estimates inconsistent.
        # Approximate turnover as 2 × buy_val (sell ≈ buy for BE calculation).
        buy_val  = buy_price * qty
        turnover = buy_val * 2                          # sell_val ≈ buy_val at breakeven
        brokerage = min(40, turnover * 0.001)           # matches calculate() exactly
        stt       = buy_val * 0.00025                   # STT on sell side
        exchange  = turnover * 0.0000297                # exchange both sides
        stamp     = buy_val * 0.00003                   # stamp on buy side
        sebi      = turnover * 0.000001
        gst       = (brokerage + exchange + sebi) * 0.18
        total     = brokerage + stt + exchange + stamp + sebi + gst
        return round(total / max(1, buy_val) * 100, 3)

eq_charges = EquityIntradayCharges()

# ═══════════════════════ STOCK SCANNER ═══════════════════════

_eq_scan_idx = 0

def get_scan_batch(cash, batch_size=8, ltp_snapshot: dict = None):
    """
    Get stocks affordable with current capital + MIS leverage.
    BUG-I fix: accepts an optional ltp_snapshot dict {instrument_key: last_price}
    fetched by scan_stocks() so affordability uses real prices, not stale tier estimates.
    Falls back to tier estimates only when ltp_snapshot is not available.
    """
    affordable = []

    for name, info in EQUITY_STOCKS.items():
        leverage = MIS_LEVERAGE.get(info["tier"], 3)
        buying_power = cash * leverage
        key = info["key"]

        # Use real LTP if available, else fall back to tier estimate
        if ltp_snapshot and key in ltp_snapshot:
            est_price = ltp_snapshot[key]
        else:
            est_price = {"penny": 25, "low": 70, "mid": 250, "high": 1500}.get(info["tier"], 100)

        # Need at least 10 shares to make meaningful trades
        max_price = buying_power / 10
        if est_price <= max_price:
            affordable.append((name, info))

    if not affordable:
        # Fallback to penny stocks
        affordable = [(n, i) for n, i in EQUITY_STOCKS.items() if i["tier"] == "penny"]

    # Rotate through affordable stocks
    random.shuffle(affordable)
    batch = affordable[:batch_size]
    return batch


async def scan_stocks(broker, cash, batch_size=8):
    """
    Fetch LTP + OHLC for a batch of stocks and score them.
    Returns list of tradeable stock opportunities.
    BUG-I fix: do a lightweight batch LTP pre-fetch for ALL stocks first so
    get_scan_batch() uses real prices instead of stale tier estimates.
    """
    # Pre-fetch LTP for all stocks to build real affordability snapshot
    all_keys = ",".join(info["key"] for info in EQUITY_STOCKS.values())
    ltp_snapshot = {}
    try:
        prefetch = await broker._get(f"/v2/market-quote/ltp?instrument_key={all_keys}")
        for v in prefetch.get("data", {}).values():
            key = v.get("instrument_token", "")
            lp  = v.get("last_price", 0)
            if key and lp > 0:
                ltp_snapshot[key] = lp
    except Exception as e:
        log.warning(f"  EQ pre-fetch LTP failed: {e} — using tier estimates")

    batch = get_scan_batch(cash, batch_size, ltp_snapshot=ltp_snapshot)
    if not batch:
        return []

    # Build comma-separated instrument keys for batch LTP + OHLC
    keys = ",".join(info["key"] for _, info in batch)

    try:
        # Batch LTP (up to 500 in one call)
        ltp_data = await broker._get(f"/v2/market-quote/ltp?instrument_key={keys}")
        # OHLC data
        ohlc_data = await broker._get(f"/v2/market-quote/ohlc?instrument_key={keys}&interval=1d")
    except Exception as e:
        log.error(f"  EQ scan error: {e}")
        return []

    opportunities = []
    ltp_map = ltp_data.get("data", {})
    ohlc_map = ohlc_data.get("data", {})

    for name, info in batch:
        key = info["key"]
        tier = info["tier"]
        leverage = MIS_LEVERAGE.get(tier, 3)

        # Find data (Upstox returns keys like "NSE_EQ:NHPC")
        ltp_entry = None
        ohlc_entry = None
        for k, v in ltp_map.items():
            if v.get("instrument_token") == key:
                ltp_entry = v; break
        for k, v in ohlc_map.items():
            if v.get("instrument_token") == key:
                ohlc_entry = v; break

        if not ltp_entry:
            continue

        ltp = ltp_entry.get("last_price", 0)
        if ltp <= 0:
            continue

        # Calculate how many shares we can buy with MIS
        buying_power = cash * leverage
        max_shares = int(buying_power / ltp)
        if max_shares < 5:  # Need at least 5 shares
            continue

        # Use sensible quantity (don't use all capital on one stock)
        trade_shares = min(max_shares, int(cash * 0.6 * leverage / ltp))
        trade_shares = max(5, trade_shares)

        # OHLC data for momentum scoring
        ohlc = ohlc_entry.get("ohlc", {}) if ohlc_entry else {}
        day_open = ohlc.get("open", ltp)
        day_high = ohlc.get("high", ltp)
        day_low = ohlc.get("low", ltp)
        prev_close = ohlc_entry.get("last_price", ltp) if ohlc_entry else ltp

        # Calculate signals
        day_range = day_high - day_low if day_high > day_low else 0.01
        day_change_pct = ((ltp - day_open) / max(0.01, day_open)) * 100
        range_position = (ltp - day_low) / max(0.01, day_range)  # 0=at low, 1=at high
        volatility = (day_range / max(0.01, ltp)) * 100  # Day range as %

        # Charges check
        be_pct = eq_charges.breakeven_pct(ltp, trade_shares)
        margin_needed = ltp * trade_shares / leverage

        # Score the opportunity
        # Good scalp = decent volatility, not at extremes, low charges relative to range
        score = 0
        if volatility > 0.5: score += 1  # Need some movement
        if volatility > 1.0: score += 1
        if 0.3 < range_position < 0.7: score += 1  # Not at day extremes
        if be_pct < 0.15: score += 2  # Low charges
        elif be_pct < 0.3: score += 1
        if abs(day_change_pct) > 0.3: score += 1  # Stock is moving today

        # Direction bias
        direction = "BUY" if day_change_pct > 0.1 or range_position < 0.4 else "SELL"
        # MIS allows short selling too
        if direction == "SELL" and range_position > 0.6:
            score += 1  # Good short setup

        if score < 2:
            continue

        opportunities.append({
            "name": name,
            "key": key,
            "tier": tier,
            "ltp": ltp,
            "qty": trade_shares,
            "leverage": leverage,
            "margin_needed": round(margin_needed, 2),
            "direction": direction,
            "score": score,
            "day_change_pct": round(day_change_pct, 2),
            "volatility": round(volatility, 2),
            "range_position": round(range_position, 2),
            "breakeven_pct": be_pct,
            "day_open": day_open,
            "day_high": day_high,
            "day_low": day_low,
            "asset": "equity",
            "target_pct":    0.5 if score <= 3 else 0.8,
            "sl_pct":        0.3 if score <= 3 else 0.4,
            "max_hold_min":  15,
            "range_pct":     round(volatility, 2),
        })

    # Sort by score
    opportunities.sort(key=lambda x: x["score"], reverse=True)
    return opportunities


# ═══════════════════════ TRADE EXECUTION ═══════════════════════

async def buy_equity(broker, stock, paper=True):
    """Place MIS buy order for equity intraday."""
    if paper:
        return {"status": "success", "data": {"order_ids": [f"P-EQ-{int(time.time())}"]}}

    return await broker._post("/v3/order/place", {
        "quantity": stock["qty"],
        "product": "I",           # MIS intraday
        "validity": "DAY",
        "price": 0,
        "instrument_token": stock["key"],
        "order_type": "MARKET",
        "transaction_type": stock["direction"],  # BUY or SELL
        "disclosed_quantity": 0,
        "trigger_price": 0,
        "is_amo": False,
        "slice": True,
    })


async def exit_equity(broker, key, qty, entry_direction, paper=True):
    """Exit equity position (reverse the direction)."""
    exit_dir = "SELL" if entry_direction == "BUY" else "BUY"

    if paper:
        return {"status": "success", "data": {"order_ids": [f"P-EQ-X-{int(time.time())}"]}}

    return await broker._post("/v3/order/place", {
        "quantity": qty,
        "product": "I",
        "validity": "DAY",
        "price": 0,
        "instrument_token": key,
        "order_type": "MARKET",
        "transaction_type": exit_dir,
        "disclosed_quantity": 0,
        "trigger_price": 0,
        "is_amo": False,
        "slice": True,
    })


# ═══════════════════════ EQUITY STRATEGIES ═══════════════════════

class EquityScalpStrategy:
    """Simple momentum scalp for equity intraday."""

    def __init__(self, name="EqScalp", target_pct=0.5, sl_pct=0.3, max_hold_min=20):
        self.name = name
        self.target_pct = target_pct
        self.sl_pct = sl_pct
        self.max_hold_min = max_hold_min
        self.trades = 0
        self.wins = 0

    @property
    def wr(self):
        return round(self.wins / max(1, self.trades) * 100, 1)

    def should_exit(self, entry_price, current_price, direction, hold_minutes, peak_pnl_pct):
        """Check if we should exit."""
        if direction == "BUY":
            pnl_pct = ((current_price - entry_price) / entry_price) * 100
        else:
            pnl_pct = ((entry_price - current_price) / entry_price) * 100

        # Target hit
        if pnl_pct >= self.target_pct:
            return "TARGET", pnl_pct

        # Stop loss
        if pnl_pct <= -self.sl_pct:
            return "STOPLOSS", pnl_pct

        # Trailing stop (if we had > 0.3% profit and it's dropping)
        if peak_pnl_pct > 0.3 and pnl_pct < peak_pnl_pct * 0.5:
            return "TRAIL_SL", pnl_pct

        # Timeout
        if hold_minutes >= self.max_hold_min:
            return "TIMEOUT", pnl_pct

        return None, pnl_pct


# Default equity strategies
EQ_STRATEGIES = [
    EquityScalpStrategy("EqMomentum", target_pct=0.6, sl_pct=0.3, max_hold_min=15),
    EquityScalpStrategy("EqQuickScalp", target_pct=0.3, sl_pct=0.2, max_hold_min=8),
    EquityScalpStrategy("EqSwing", target_pct=1.0, sl_pct=0.5, max_hold_min=30),
]


# ═══════════════════════ INFO ═══════════════════════

def describe_equity(cash):
    """Show what's available for given capital."""
    lines = [f"Equity Intraday (MIS) — Capital: ₹{cash:,.0f}"]
    affordable = get_scan_batch(cash, 30)
    by_tier = {}
    for name, info in affordable:
        tier = info["tier"]
        by_tier.setdefault(tier, []).append(name)

    for tier in ["penny", "low", "mid", "high"]:
        stocks = by_tier.get(tier, [])
        lev = MIS_LEVERAGE.get(tier, 3)
        if stocks:
            lines.append(f"  {tier.upper()} ({lev}x leverage): {', '.join(stocks[:6])}{'...' if len(stocks) > 6 else ''}")

    # Charges comparison
    lines.append(f"\n  Charges example (₹50 stock x 100 shares):")
    ch = eq_charges.calculate(50, 50.30, 100)  # 0.6% move
    lines.append(f"    0.6% move: gross=₹{ch['gross_pnl']} charges=₹{ch['total_charges']:.0f} net=₹{ch['net_pnl']:.0f} BE={ch['breakeven_pct']:.2f}%")

    ch2 = eq_charges.calculate(50, 50.50, 100)  # 1% move
    lines.append(f"    1.0% move: gross=₹{ch2['gross_pnl']} charges=₹{ch2['total_charges']:.0f} net=₹{ch2['net_pnl']:.0f}")

    lines.append(f"\n  vs Options (₹5 premium x 50 lot):")
    lines.append(f"    Breakeven ~8-10% move needed (₹40+ brokerage dominates)")
    lines.append(f"    Equity intraday breakeven: ~0.1-0.2% move needed")

    return "\n".join(lines)


if __name__ == "__main__":
    print(describe_equity(1000))
    print()
    print(describe_equity(10000))
