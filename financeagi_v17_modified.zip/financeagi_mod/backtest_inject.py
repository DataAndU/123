#!/usr/bin/env python3
"""
backtest_inject.py — FinanceAGI Historical Backtester + DB Injector
Reads NSE options CSV data, simulates FinanceAGI's scanner + strategy logic,
generates synthetic trade records, and injects them into v10.db so the NN
and RL wake up pre-trained instead of starting from zero.

Usage:
    python3 backtest_inject.py                        # dry run (print only)
    python3 backtest_inject.py --inject               # inject into DB
    python3 backtest_inject.py --inject --reset-db    # wipe DB first then inject

Input files (place in same folder or pass paths):
    OPTIDX_NIFTY_PE_*.csv
    OPTIDX_NIFTY_CE_*.csv

Produces:
    - Synthetic trades in data/v10.db  (features_json filled for NN training)
    - Printed summary of backtest P&L, win rate, strategy breakdown
"""

import argparse, json, math, os, random, re, sqlite3, sys
from datetime import datetime, timezone, timedelta, date as date_type
from pathlib import Path
import pandas as pd
import numpy as np

# ── Indian Market Reference Data (2021–2026) ──────────────────────────────────
# Added: historically-correct lot sizes, STT history, VIX regime scaling,
#        FNO stock universe, MCX specs, regulatory timeline.
# DO NOT CHANGE existing logic — this only adds capabilities.
from india_market_ref import (
    get_lot_size,
    get_stt_rate,
    get_vix_regime,
    scale_premium_for_vix,
    calc_charges_accurate,
    is_fo_eligible,
    MARKET_REF,
    FNO_STOCKS,
    INTRADAY_STOCKS,
    MCX_COMMODITIES,
    STRATEGY_WIN_RATES,
    REGULATORY_TIMELINE,
    NIFTY_LOT_HISTORY,
    BANKNIFTY_LOT_HISTORY,
)

BASE = Path(__file__).resolve().parent
DB   = str(BASE / "data" / "v10.db")
IST  = timezone(timedelta(hours=5, minutes=30))

# ── Match FinanceAGI feature vector exactly ──────────────────────────────────
FEAT_NAMES = [
    "delta","gamma_x10k","theta","iv","log_volume","log_oi",
    "otm_pct","spot_mv","sin_hour","cos_hour",
    "ltp_div10","cost_frac","dte_norm",
    "iv_rank","vol_oi_ratio","gamma_dollar_div1k","theta_pct","moneyness_m1",
    "log_prem","spread_ratio",
]
FEAT_DIM = len(FEAT_NAMES)

# ── Seed strategies (same as agent.py) ───────────────────────────────────────
SEED_STRATS = [
    {"name":"MomentumCE","option_type":"CE","delta_min":0.15,"delta_max":0.35,"otm_min":1,"otm_max":5,"target_pct":5,"sl_pct":7,"max_hold_min":15,"vol_min":5000000},
    {"name":"MomentumPE","option_type":"PE","delta_min":0.15,"delta_max":0.35,"otm_min":1,"otm_max":5,"target_pct":5,"sl_pct":7,"max_hold_min":15,"vol_min":5000000},
    {"name":"QuickScalp","option_type":"BOTH","delta_min":0.20,"delta_max":0.45,"otm_min":0.5,"otm_max":3,"target_pct":3,"sl_pct":4,"max_hold_min":8,"vol_min":10000000},
    {"name":"SwingCE","option_type":"CE","delta_min":0.10,"delta_max":0.30,"otm_min":2,"otm_max":6,"target_pct":10,"sl_pct":8,"max_hold_min":30,"vol_min":1000000},
    {"name":"FadeBear","option_type":"PE","delta_min":0.10,"delta_max":0.25,"otm_min":1,"otm_max":5,"target_pct":4,"sl_pct":5,"max_hold_min":20,"vol_min":1000000},
    {"name":"StockCE","option_type":"CE","delta_min":0.15,"delta_max":0.40,"otm_min":1,"otm_max":5,"target_pct":6,"sl_pct":8,"max_hold_min":20,"vol_min":500000},
    {"name":"StockPE","option_type":"PE","delta_min":0.15,"delta_max":0.40,"otm_min":1,"otm_max":5,"target_pct":6,"sl_pct":8,"max_hold_min":20,"vol_min":500000},
]

# ── Lot-size resolver (uses india_market_ref history) ────────────────────────
def resolve_lot(symbol: str, trade_date) -> int:
    """
    Return historically-correct lot size for NIFTY, BANKNIFTY, or any FNO stock.
    Wraps get_lot_size() from india_market_ref so backtest uses real lot sizes.

    Falls back to the --lot CLI arg if symbol is unrecognised.
    """
    sym = symbol.upper().replace(" ", "")
    # Strip strike and type suffix if present (e.g. 'NIFTY 23000 CE' → 'NIFTY')
    for token in ["NIFTY", "BANKNIFTY"]:
        if sym.startswith(token):
            sym = token
            break
    try:
        lot = get_lot_size(sym, trade_date)
        return lot if lot and lot > 0 else 65   # safe default
    except Exception:
        return 65


def vix_scaled_premium(base_premium: float, vix: float) -> float:
    """
    Scale a base option premium by current VIX regime.
    Uses india_market_ref.scale_premium_for_vix().
    Baseline (mult=1.0) is normal VIX 14–18.
    """
    return scale_premium_for_vix(base_premium, vix)


def log_regulatory_context(trade_date) -> str:
    """
    Return a short string describing regulatory environment on a given date.
    Useful for annotating synthetic trade records.
    """
    if isinstance(trade_date, str):
        from datetime import date as _d
        trade_date = _d.fromisoformat(trade_date[:10])

    notes = []
    # Lot size regime
    nifty_lot = resolve_lot("NIFTY", trade_date)
    notes.append(f"NIFTY_lot={nifty_lot}")

    # STT regime
    stt = get_stt_rate(trade_date, "option")
    notes.append(f"STT_opt={stt*100:.3f}%")

    # BANKNIFTY weekly status
    from datetime import date as _d
    if trade_date >= _d(2024, 11, 20):
        notes.append("BN_monthly_only")
    else:
        notes.append("BN_weekly")

    # Expiry day
    from datetime import date as _d
    if trade_date >= _d(2025, 4, 4):
        notes.append("expiry=Tuesday")
    else:
        notes.append("expiry=Thursday")

    return "|".join(notes)


# ── Charges (matches agent.py exactly) ───────────────────────────────────────
def calc_charges(buy_price, sell_price, qty):
    buy_val  = buy_price * qty
    sell_val = sell_price * qty
    turnover = buy_val + sell_val
    brokerage = 40
    stt       = sell_val * 0.000625
    exchange  = turnover * 0.000495
    sebi      = turnover * 0.000001
    ipft      = turnover * 0.000001
    stamp     = buy_val  * 0.00003
    gst       = (brokerage + exchange + sebi + ipft) * 0.18
    total     = brokerage + stt + exchange + gst + sebi + stamp + ipft
    gross     = (sell_price - buy_price) * qty
    return round(total, 2), round(gross, 2), round(gross - total, 2)

# ── Approximate delta from moneyness + DTE ───────────────────────────────────
def approx_delta(spot, strike, dte, opt_type, iv_pct=20):
    """Black-Scholes-like delta approximation (no scipy needed)."""
    if spot <= 0 or strike <= 0 or dte <= 0:
        return 0.5 if opt_type == "CE" else -0.5
    T   = dte / 365.0
    vol = iv_pct / 100.0
    try:
        d1 = (math.log(spot / strike) + 0.5 * vol**2 * T) / (vol * math.sqrt(T))
        # Approximation of N(d1) using logistic function
        nd1 = 1 / (1 + math.exp(-1.7 * d1))
        if opt_type == "CE":
            return round(nd1, 3)
        else:
            return round(-(1 - nd1), 3)
    except Exception:
        return 0.3 if opt_type == "CE" else -0.3

def approx_iv(ltp, spot, strike, dte, opt_type):
    """Very rough IV approximation from premium."""
    if dte <= 0 or ltp <= 0 or spot <= 0:
        return 20.0
    T   = max(dte / 365.0, 1/365)
    otm = abs(spot - strike) / spot
    # Simple rule: higher OTM + lower premium = lower IV estimate
    iv_raw = (ltp / spot) / math.sqrt(T) * 10
    return round(max(8, min(80, iv_raw * 100)), 1)

def approx_theta(ltp, dte):
    """Theta ≈ premium / DTE (linear decay approximation)."""
    if dte <= 0:
        return ltp
    return round(ltp / max(1, dte), 3)

def approx_gamma(delta, spot, dte, iv_pct=20):
    """Gamma ≈ N'(d1)/(S*σ*√T)."""
    if spot <= 0 or dte <= 0:
        return 0.001
    T   = max(dte / 365.0, 1/365)
    vol = iv_pct / 100.0
    # N'(x) ≈ 0.4 at peak (ATM)
    abs_d = abs(delta)
    nd1_prime = abs_d * (1 - abs_d) * 4  # rough bell approximation
    gamma = nd1_prime / max(0.01, spot * vol * math.sqrt(T))
    return round(gamma, 6)

# ── Feature vector ────────────────────────────────────────────────────────────
def build_features(row, cash=10000, lot=50, hour=10):
    spot   = row["spot"]
    strike = row["strike"]
    ltp    = row["ltp"]
    dte    = row["dte"]
    oi     = max(1, row["oi"])
    vol    = max(1, row["volume"])
    opt_type = row["type"]

    otm_pct  = abs(spot - strike) / max(1, spot) * 100
    iv       = approx_iv(ltp, spot, strike, dte, opt_type)
    delta    = approx_delta(spot, strike, dte, opt_type, iv)
    gamma    = approx_gamma(delta, spot, dte, iv)
    theta    = approx_theta(ltp, dte)

    magnitude = 10 ** (len(str(int(spot))) - 2)
    magnitude = max(1, magnitude)
    sm = ((spot - round(spot / magnitude) * magnitude) / max(1, spot)) * 100

    dte_norm      = min(dte / 30.0, 1.0)
    iv_rank       = min(iv / 50.0, 1.0)
    vol_oi_ratio  = math.log(vol / max(1, oi) + 1)
    gamma_dollar  = abs(gamma) * spot
    theta_pct     = theta / max(0.01, ltp) * 100
    moneyness     = strike / max(1, spot)
    log_prem      = math.log(ltp + 1)
    spread_ratio  = min(abs(gamma) * iv / max(0.01, ltp), 1.0)

    f = np.array([
        abs(delta),
        abs(gamma) * 10000,
        abs(theta),
        iv,
        math.log(vol + 1),
        math.log(oi + 1),
        otm_pct,
        sm,
        math.sin(2 * math.pi * hour / 24),
        math.cos(2 * math.pi * hour / 24),
        ltp / 10,
        (ltp * lot) / max(1, cash),
        dte_norm,
        iv_rank,
        vol_oi_ratio,
        gamma_dollar / 1000,
        theta_pct,
        moneyness - 1.0,
        log_prem,
        spread_ratio,
    ], dtype=np.float64)[:FEAT_DIM]

    return f, abs(delta), abs(gamma), abs(theta), iv

# ── Simulate one trade ────────────────────────────────────────────────────────
def simulate_trade(entry_row, day_rows, strat, lot=50, capital=10000):
    """
    Given an entry option row and the rest of that day's data for the same
    strike+expiry, simulate holding until target/SL/timeout.

    Returns a trade dict or None if no exit found.
    """
    entry_ltp  = entry_row["ltp"]
    entry_time = entry_row["hour"]
    opt_type   = entry_row["type"]
    strike     = entry_row["strike"]
    expiry     = entry_row["expiry"]
    spot_entry = entry_row["spot"]

    target_pct = strat["target_pct"]
    sl_pct     = strat["sl_pct"]
    max_hold   = strat["max_hold_min"]

    target_price = entry_ltp * (1 + target_pct / 100)
    sl_price     = entry_ltp * (1 - sl_pct / 100)

    # Simulate intraday price path using High/Low range
    # We don't have tick data — use High as best case, Low as worst case
    # Assign direction of move based on day trend
    entry_high = entry_row.get("high", entry_ltp)
    entry_low  = entry_row.get("low", entry_ltp)
    entry_close= entry_row.get("close", entry_ltp)

    # Estimate exit price
    exit_ltp    = None
    exit_reason = None

    # Check if target was hit during the day (High reached target)
    if entry_high >= target_price:
        exit_ltp    = target_price
        exit_reason = "TARGET"
    # Check if SL was hit (Low hit SL)
    elif entry_low <= sl_price:
        exit_ltp    = sl_price
        exit_reason = "STOPLOSS"
    # Timeout — exit at close
    else:
        exit_ltp    = entry_close
        exit_reason = "TIMEOUT"

    if exit_ltp is None or exit_ltp <= 0:
        return None

    charges, gross, net = calc_charges(entry_ltp, exit_ltp, lot)
    pnl_pct = (exit_ltp - entry_ltp) / max(0.01, entry_ltp) * 100
    won     = net > 0

    dte = entry_row["dte"]
    f, delta, gamma, theta, iv = build_features(entry_row, cash=capital, lot=lot, hour=entry_time)

    # Simulate hold time (rough)
    hold_min = max_hold if exit_reason == "TIMEOUT" else random.randint(5, max_hold)

    ts = entry_row["date"].replace(hour=entry_time, minute=random.randint(0,30))

    return {
        "ts":            ts.isoformat(),
        "symbol":        f"NIFTY {strike} {opt_type}",
        "strike":        strike,
        "otype":         opt_type,
        "asset":         "option",
        "underlying":    "Nifty 50",
        "expiry":        expiry.strftime("%Y-%m-%d"),
        "strategy":      strat["name"],
        "entry_price":   round(entry_ltp, 2),
        "entry_delta":   round(delta, 3),
        "entry_gamma":   round(gamma, 6),
        "entry_theta":   round(theta, 3),
        "entry_iv":      round(iv, 1),
        "entry_volume":  int(entry_row["volume"]),
        "entry_oi":      int(entry_row["oi"]),
        "entry_otm":     round(entry_row["otm_pct"], 2),
        "entry_spot":    round(spot_entry, 2),
        "entry_hour":    entry_time,
        "lot":           lot,
        "cost":          round(entry_ltp * lot, 2),
        "capital_pct":   round(entry_ltp * lot / max(1, capital) * 100, 1),
        "exit_price":    round(exit_ltp, 2),
        "exit_reason":   exit_reason,
        "hold_sec":      hold_min * 60,
        "pnl":           round(gross, 2),
        "pnl_pct":       round(pnl_pct, 2),
        "won":           1 if won else 0,
        "nn_prob":       round(random.uniform(0.4, 0.8), 3),
        "rl_state":      f"h{entry_time}_iv{int(iv//10)*10}",
        "rl_action":     random.randint(0, 6),
        "features_json": json.dumps(f.tolist()),
        "strat_gen":     0,
        "peak_pnl":      round(max(pnl_pct, 0), 2),
        "partial":       0,
        "charges":       round(charges, 2),
        "net_pnl":       round(net, 2),
    }

# ── Strategy filter (mirrors Strat.matches in agent.py) ──────────────────────
def strat_matches(row, strat):
    opt_type = row["type"]
    if strat["option_type"] != "BOTH" and opt_type != strat["option_type"]:
        return False
    delta = abs(row.get("delta_approx", 0.3))
    if delta < strat["delta_min"] or delta > strat["delta_max"]:
        return False
    otm = row["otm_pct"]
    if otm < strat.get("otm_min", 0) or otm > strat.get("otm_max", 10):
        return False
    vol = row["volume"]
    if vol < strat.get("vol_min", 0):
        return False
    dte = row["dte"]
    if dte <= 0 or dte > 30:  # nearest expiry only
        return False
    return True

# ── Main backtest ─────────────────────────────────────────────────────────────
def run_backtest(capital=10000, lot=50, max_trades_per_day=3, verbose=True):
    print("Loading CSV files...")
    pe = pd.read_csv("/mnt/user-data/uploads/OPTIDX_NIFTY_PE_20-Dec-2025_TO_20-Mar-2026.csv")
    ce = pd.read_csv("/mnt/user-data/uploads/OPTIDX_NIFTY_CE_20-Dec-2025_TO_20-Mar-2026.csv")
    pe.columns = [c.strip() for c in pe.columns]
    ce.columns = [c.strip() for c in ce.columns]

    df = pd.concat([pe, ce], ignore_index=True)
    df['Date']   = pd.to_datetime(df['Date'],   dayfirst=True)
    df['Expiry'] = pd.to_datetime(df['Expiry'], dayfirst=True)

    for col in ['Open','High','Low','Close','LTP','No. of contracts','Open Int','Change in OI','Underlying Value']:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    # Filter to rows with actual trading data
    df = df.dropna(subset=['Open','High','Low','Close','LTP','Underlying Value']).copy()
    df = df[df['LTP'] > 0.5]  # skip zero/sub-penny options
    df = df[df['No. of contracts'] > 10]  # skip illiquid

    # Rename for convenience
    df = df.rename(columns={
        'Date': 'date', 'Expiry': 'expiry', 'Option type': 'type',
        'Strike Price': 'strike', 'Open': 'open', 'High': 'high',
        'Low': 'low', 'Close': 'close', 'LTP': 'ltp',
        'No. of contracts': 'contracts', 'Open Int': 'oi',
        'Change in OI': 'change_oi', 'Underlying Value': 'spot',
        'Turnover * in  \u20b9 Lakhs': 'turnover',
        'Premium Turnover ** in   \u20b9 Lakhs': 'prem_turnover',
    })

    df['dte']     = (df['expiry'] - df['date']).dt.days
    df['otm_pct'] = abs(df['spot'] - df['strike']) / df['spot'] * 100
    df['volume']  = df['contracts'] * lot * 50  # approximate volume in units

    # Approximate delta
    df['delta_approx'] = df.apply(
        lambda r: abs(approx_delta(r['spot'], r['strike'], r['dte'], r['type'])), axis=1
    )

    # Entry time: simulate morning entry between 9:30–11:00
    random.seed(42)

    all_trades  = []
    trading_days = sorted(df['date'].unique())
    total_pnl   = 0
    wins = losses = 0

    print(f"Processing {len(trading_days)} trading days, {len(df)} liquid option rows...")

    for day in trading_days:
        day_df = df[df['date'] == day].copy()
        day_trades = 0

        # ── Resolve historically-correct lot size for this date ───────────────
        # Uses india_market_ref.get_lot_size() instead of fixed --lot arg.
        # The user-supplied --lot arg is kept as a fallback only.
        day_lot = resolve_lot("NIFTY", day.date() if hasattr(day, 'date') else day)
        if day_lot <= 0:
            day_lot = lot   # fallback to CLI arg

        # Regulatory context string (annotates each trade)
        reg_ctx = log_regulatory_context(day.date() if hasattr(day, 'date') else day)

        # Direction bias: compute day trend from spot vs prev day
        spot_today = day_df['spot'].iloc[0] if len(day_df) > 0 else 23000
        day_open   = day_df['open'].mean()
        day_change = (spot_today - day_open) / max(1, day_open) * 100 if day_open > 0 else 0

        # Prefer CE in uptrend, PE in downtrend
        if day_change > 0.3:
            preferred_type = "CE"
        elif day_change < -0.3:
            preferred_type = "PE"
        else:
            preferred_type = "BOTH"

        for strat in SEED_STRATS:
            if day_trades >= max_trades_per_day:
                break

            # Filter options matching this strategy
            candidates = day_df[day_df.apply(lambda r: strat_matches(r, strat), axis=1)].copy()

            # Apply direction bias
            if preferred_type != "BOTH":
                dir_filtered = candidates[candidates['type'] == preferred_type]
                if len(dir_filtered) > 0:
                    candidates = dir_filtered

            if candidates.empty:
                continue

            # Sort by OI (liquidity) and pick best
            candidates = candidates.sort_values('oi', ascending=False)
            entry_row  = candidates.iloc[0].to_dict()
            entry_row['hour'] = random.randint(9, 11)

            trade = simulate_trade(entry_row, day_df, strat, lot=day_lot, capital=capital)
            if trade is None:
                continue

            # Attach regulatory context and accurate charges for this date
            trade["reg_context"] = reg_ctx
            trade["lot"] = day_lot   # override with historically-correct lot

            # Recompute charges with accurate STT for this date
            try:
                trade_date_obj = entry_row["date"].date() if hasattr(entry_row["date"], 'date') else entry_row["date"]
                acc_charges, acc_gross, acc_net = calc_charges_accurate(
                    trade["entry_price"], trade["exit_price"], day_lot, trade_date_obj, "option"
                )
                trade["charges"]  = acc_charges
                trade["net_pnl"]  = acc_net
                trade["pnl"]      = acc_gross
            except Exception:
                pass   # fall back to simulate_trade's calc_charges() result

            all_trades.append(trade)
            day_trades += 1
            total_pnl += trade['net_pnl']
            if trade['won']:
                wins += 1
            else:
                losses += 1

            if verbose:
                ic = "✓" if trade['won'] else "✗"
                print(f"  {ic} {trade['ts'][:10]} {strat['name']:15s} "
                      f"{trade['otype']} {trade['strike']:>8.0f} "
                      f"@ ₹{trade['entry_price']:>7.1f} → ₹{trade['exit_price']:>7.1f} "
                      f"{trade['pnl_pct']:+.1f}% net=₹{trade['net_pnl']:+.0f} [{trade['exit_reason']}]")

    total = wins + losses
    wr    = round(wins / max(1, total) * 100, 1)
    print(f"\n{'='*60}")
    print(f"BACKTEST SUMMARY")
    print(f"  Period:     {trading_days[0].strftime('%d-%b-%Y')} → {trading_days[-1].strftime('%d-%b-%Y')}")
    print(f"  Trades:     {total} ({wins}W / {losses}L)")
    print(f"  Win Rate:   {wr}%")
    print(f"  Net P&L:    ₹{total_pnl:+,.0f}")
    print(f"  Avg/trade:  ₹{total_pnl/max(1,total):+.0f}")
    print(f"\nBy Strategy:")
    strat_stats = {}
    for t in all_trades:
        s = t['strategy']
        strat_stats.setdefault(s, {"t":0,"w":0,"pnl":0})
        strat_stats[s]["t"] += 1
        strat_stats[s]["w"] += t["won"]
        strat_stats[s]["pnl"] += t["net_pnl"]
    for s, st in sorted(strat_stats.items(), key=lambda x: -x[1]["pnl"]):
        wr_s = round(st["w"]/max(1,st["t"])*100,1)
        print(f"  {s:20s} {st['t']:3d}T {wr_s:5.1f}%WR ₹{st['pnl']:+,.0f}")
    print(f"{'='*60}")

    return all_trades

# ── DB injection ──────────────────────────────────────────────────────────────
def inject_into_db(trades, reset_db=False):
    (BASE / "data").mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(DB)
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS trades(id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, symbol TEXT, strike REAL, otype TEXT, asset TEXT,
        underlying TEXT, expiry TEXT, strategy TEXT,
        entry_price REAL, entry_delta REAL, entry_gamma REAL,
        entry_theta REAL, entry_iv REAL, entry_volume INTEGER,
        entry_oi INTEGER, entry_otm REAL, entry_spot REAL,
        entry_hour INTEGER, lot INTEGER, cost REAL, capital_pct REAL,
        exit_price REAL, exit_reason TEXT, hold_sec INTEGER,
        pnl REAL, pnl_pct REAL, won INTEGER, nn_prob REAL,
        rl_state TEXT, rl_action INTEGER, features_json TEXT,
        strat_gen INTEGER, peak_pnl REAL, partial INTEGER DEFAULT 0,
        charges REAL, net_pnl REAL,
        reg_context TEXT DEFAULT NULL);
    CREATE TABLE IF NOT EXISTS auth(id INTEGER PRIMARY KEY, provider TEXT, token TEXT);
    CREATE TABLE IF NOT EXISTS spots(ts TEXT, spot REAL, iv REAL);
    CREATE TABLE IF NOT EXISTS config(key TEXT PRIMARY KEY, val TEXT);
    """)

    if reset_db:
        conn.execute("DELETE FROM trades")
        conn.execute("DELETE FROM config")
        conn.commit()
        print("DB reset.")

    existing = conn.execute("SELECT COUNT(*) FROM trades").fetchone()[0]

    cols = [
        "ts","symbol","strike","otype","asset","underlying","expiry","strategy",
        "entry_price","entry_delta","entry_gamma","entry_theta","entry_iv",
        "entry_volume","entry_oi","entry_otm","entry_spot","entry_hour",
        "lot","cost","capital_pct","exit_price","exit_reason","hold_sec",
        "pnl","pnl_pct","won","nn_prob","rl_state","rl_action",
        "features_json","strat_gen","peak_pnl","partial","charges","net_pnl",
        "reg_context",
    ]
    placeholders = ",".join(f":{c}" for c in cols)
    sql = f"INSERT INTO trades({','.join(cols)}) VALUES({placeholders})"

    inserted = 0
    for t in trades:
        try:
            conn.execute(sql, {c: t.get(c, None) for c in cols})
            inserted += 1
        except Exception as e:
            print(f"  Insert error: {e}")

    conn.commit()
    conn.close()

    print(f"\nDB injection complete.")
    print(f"  Existing trades before: {existing}")
    print(f"  Inserted:               {inserted}")
    print(f"  Total in DB now:        {existing + inserted}")
    print(f"\nThe NN will retrain on {existing + inserted} trades at next startup.")
    print(f"RL will have pre-loaded state-action history.")

# ── CLI ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="FinanceAGI Backtester + DB Injector")
    parser.add_argument("--inject",    action="store_true", help="Inject trades into DB")
    parser.add_argument("--reset-db",  action="store_true", help="Wipe DB before injecting")
    parser.add_argument("--capital",   type=float, default=10000, help="Simulated capital (default 10000)")
    parser.add_argument("--lot",       type=int,   default=50,    help="Lot size (default 50)")
    parser.add_argument("--max-per-day", type=int, default=3,     help="Max trades per day (default 3)")
    parser.add_argument("--quiet",     action="store_true", help="Suppress per-trade output")
    args = parser.parse_args()

    trades = run_backtest(
        capital=args.capital,
        lot=args.lot,
        max_trades_per_day=args.max_per_day,
        verbose=not args.quiet,
    )

    if args.inject:
        inject_into_db(trades, reset_db=args.reset_db)
    else:
        print("\nDry run — use --inject to write to DB")
        print(f"Generated {len(trades)} synthetic trade records ready to inject.")
