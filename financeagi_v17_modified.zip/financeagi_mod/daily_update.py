#!/usr/bin/env python3
"""
daily_update.py — FinanceAGI v13.1 Daily AI Update
Runs automatically at 6 AM via PM2 cron.

Flow:
  1. Gather all trade stats + feature importance from DB
  2. Ask Claude API (primary) or Qwen/Ollama (fallback) for analysis
  3. Auto-apply safe parameter suggestions
  4. Track whether last week's suggestions improved things
  5. Send full daily Telegram report
"""

import json, os, sqlite3, time, urllib.request, urllib.error  # IMPORT-FIX
try:
    import httpx
except ImportError:
    httpx = None  # graceful degradation — Claude API calls use urllib fallback
from datetime import datetime, timezone, timedelta
from pathlib import Path

BASE = Path(__file__).resolve().parent
IST  = timezone(timedelta(hours=5, minutes=30))
DB   = str(BASE / "data" / "v10.db")
LOG  = BASE / "logs" / "llm_update.log"

ENV = {}
ef  = BASE / ".env"
if ef.exists():
    for ln in ef.read_text().splitlines():
        ln = ln.strip()
        if ln and not ln.startswith("#") and "=" in ln:
            k, v = ln.split("=", 1); ENV[k.strip()] = v.strip()

ANTHROPIC_KEY = ENV.get("ANTHROPIC_API_KEY", "")
OLLAMA_HOST   = ENV.get("OLLAMA_HOST",  "http://localhost:11434")
OLLAMA_MODEL  = ENV.get("OLLAMA_MODEL", "qwen2.5:3b")
TG_TOKEN      = ENV.get("TG_BOT_TOKEN", ENV.get("TELEGRAM_TOKEN", ""))
TG_CHAT       = ENV.get("TG_CHAT_ID",   ENV.get("TELEGRAM_CHAT_ID", ""))

# ── Logging ──────────────────────────────────────────────────────────────────

def log(msg):
    ts   = datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with open(LOG, "a") as f: f.write(line + "\n")
    except Exception:
        pass

def tg(msg: str):
    if not TG_TOKEN or not TG_CHAT:
        return
    try:
        import urllib.request, urllib.parse
        data = json.dumps({"chat_id": TG_CHAT, "text": msg, "parse_mode": "HTML"}).encode()
        req  = urllib.request.Request(
            f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
            data=data, headers={"Content-Type": "application/json"}, method="POST"
        )
        urllib.request.urlopen(req, timeout=8)
    except Exception as e:
        log(f"Telegram error: {e}")

# ── DB helpers ────────────────────────────────────────────────────────────────

def get_db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def _load_web_insights(c=None) -> dict:
    """Load latest web search insights from DB."""
    try:
        close_c = c is None
        if c is None:
            c = get_db()
        keys = ["search_morning_insight", "search_streak_insight",
                "search_weekly_insight", "search_market_brief"]
        result = {}
        for key in keys:
            row = c.execute("SELECT val FROM config WHERE key=?", (key,)).fetchone()
            if row:
                try:
                    result[key.replace("search_","")] = json.loads(row["val"])
                except Exception:
                    pass
        if close_c:
            c.close()
        return result
    except Exception:
        return {}

def gather_stats() -> dict:
    """Comprehensive stats for LLM analysis."""
    try:
        c = get_db()

        # All-time
        r = c.execute("""
            SELECT COUNT(*) t, COALESCE(SUM(won),0) w,
                   COALESCE(SUM(pnl),0) p, COALESCE(SUM(net_pnl),0) np,
                   COALESCE(SUM(charges),0) ch
            FROM trades
        """).fetchone()

        # Last 7 days
        week_ago = (datetime.now(IST) - timedelta(days=7)).strftime("%Y-%m-%d")
        r7 = c.execute("""
            SELECT COUNT(*) t, COALESCE(SUM(won),0) w,
                   COALESCE(SUM(net_pnl),0) np
            FROM trades WHERE ts >= ?
        """, (week_ago,)).fetchone()

        # Yesterday
        yesterday = (datetime.now(IST) - timedelta(days=1)).strftime("%Y-%m-%d")
        ry = c.execute("""
            SELECT COUNT(*) t, COALESCE(SUM(won),0) w,
                   COALESCE(SUM(net_pnl),0) np,
                   COALESCE(SUM(pnl),0) gross
            FROM trades WHERE ts >= ? AND ts < ?
        """, (yesterday, datetime.now(IST).strftime("%Y-%m-%d"))).fetchone()

        # Strategy breakdown (all time)
        strats = c.execute("""
            SELECT strategy, COUNT(*) t, SUM(won) w, SUM(net_pnl) np,
                   AVG(pnl_pct) avg_pnl, AVG(hold_sec)/60 avg_hold_min
            FROM trades GROUP BY strategy ORDER BY np DESC
        """).fetchall()

        # Exit reason breakdown
        exits = c.execute("""
            SELECT exit_reason, COUNT(*) n, AVG(pnl_pct) avg_pnl, AVG(net_pnl) avg_net
            FROM trades GROUP BY exit_reason ORDER BY n DESC
        """).fetchall()

        # Hour of day performance
        hours = c.execute("""
            SELECT entry_hour, COUNT(*) t, SUM(won) w, AVG(net_pnl) avg_net
            FROM trades GROUP BY entry_hour ORDER BY avg_net DESC
        """).fetchall()

        # Asset breakdown
        assets = c.execute("""
            SELECT asset, COUNT(*) t, SUM(won) w, SUM(net_pnl) np
            FROM trades GROUP BY asset ORDER BY np DESC
        """).fetchall()

        # Feature importance (from background tracker)
        feat_imp = {}
        fi_row = c.execute("SELECT val FROM config WHERE key='feat_importance'").fetchone()
        if fi_row:
            try: feat_imp = json.loads(fi_row["val"])
            except Exception:  # BUG-EXCEPT-4 FIX: was bare except
                pass

        # Previous suggestions (to track if they worked)
        prev_sugg = {}
        ps_row = c.execute("SELECT val FROM config WHERE key='last_suggestions'").fetchone()
        if ps_row:
            try: prev_sugg = json.loads(ps_row["val"])
            except Exception:  # BUG-EXCEPT-4 FIX: was bare except
                pass

        c.close()

        total = r["t"]; wins = int(r["w"])
        return {
            "all_time": {
                "trades": total, "wins": wins,
                "win_rate_pct": round(wins / max(1, total) * 100, 1),
                "gross_pnl": round(r["p"] or 0, 2),
                "net_pnl":   round(r["np"] or 0, 2),
                "charges":   round(r["ch"] or 0, 2),
            },
            "last_7_days": {
                "trades": r7["t"], "wins": int(r7["w"]),
                "win_rate_pct": round(int(r7["w"]) / max(1, r7["t"]) * 100, 1),
                "net_pnl": round(r7["np"] or 0, 2),
            },
            "yesterday": {
                "trades": ry["t"], "wins": int(ry["w"]),
                "win_rate_pct": round(int(ry["w"]) / max(1, ry["t"]) * 100, 1),
                "net_pnl": round(ry["np"] or 0, 2),
                "gross_pnl": round(ry["gross"] or 0, 2),
            },
            "by_strategy": [
                {"name": s["strategy"], "trades": s["t"],
                 "win_rate": round((s["w"] or 0) / max(1, s["t"]) * 100, 1),
                 "net_pnl": round(s["np"] or 0, 2),
                 "avg_pnl_pct": round(s["avg_pnl"] or 0, 2),
                 "avg_hold_min": round(s["avg_hold_min"] or 0, 1)}
                for s in strats
            ],
            "exit_reasons": [
                {"reason": e["exit_reason"], "count": e["n"],
                 "avg_pnl_pct": round(e["avg_pnl"] or 0, 2),
                 "avg_net": round(e["avg_net"] or 0, 2)}
                for e in exits
            ],
            "best_hours": [
                {"hour": h["entry_hour"], "trades": h["t"],
                 "win_rate": round((h["w"] or 0) / max(1, h["t"]) * 100, 1),
                 "avg_net_per_trade": round(h["avg_net"] or 0, 2)}
                for h in hours[:5]
            ],
            "by_asset": [
                {"asset": a["asset"], "trades": a["t"],
                 "win_rate": round((a["w"] or 0) / max(1, a["t"]) * 100, 1),
                 "net_pnl": round(a["np"] or 0, 2)}
                for a in assets
            ],
            "top_features": sorted(feat_imp.items(), key=lambda x: -x[1])[:8] if feat_imp else [],
            "previous_suggestions": prev_sugg,
            "web_insights": _load_web_insights(c),
        }
    except Exception as e:
        log(f"Stats error: {e}")
        return {}

# ── LLM calls ─────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are an expert algorithmic trading system optimizer for Indian NSE/MCX markets.
You analyze trading bot performance data and suggest precise, data-driven improvements.
You understand NSE options (CE/PE), equity intraday MIS, and MCX commodity futures.
You always respond in valid JSON only — no markdown, no explanation outside the JSON."""

USER_PROMPT_TEMPLATE = """Analyze this FinanceAGI trading system performance and suggest improvements:

{stats_json}

The system trades:
- NSE Options (single-leg CE/PE buys on Nifty, BankNifty, FNO stocks)
- Equity intraday MIS (long/short)
- MCX commodity futures (GOLDPETAL, CRUDEOILM, NATGASMINI)

Key parameters to optimize:
- target_pct (2-20): exit when option gains this %
- stoploss_pct (2-20): exit when option loses this %
- max_hold_min (3-60): max minutes to hold
- nn_thr (0.3-0.8): minimum NN probability to enter trade
- kelly (0.05-0.4): Kelly fraction for position sizing
- trail_on (0.5-5): activate trailing stop after this % gain
- trail_dist (0.5-3): trailing stop distance %
- partial_at (1-8): take 50% partial profit at this % gain

Based on the data, provide exactly this JSON:
{
  "parameter_changes": [
    {"param": "target_pct", "suggested": 7.5, "reason": "..."}
  ],
  "strategy_actions": [
    {"strategy": "StratName", "action": "boost|kill|keep", "reason": "..."}
  ],
  "best_trading_hours": [9, 10, 14],
  "regime_insight": "One sentence about current market regime pattern",
  "improvement_insight": "One sentence: did last week suggestions help?",
  "urgency": "high|medium|low",
  "confidence": 0.7
}"""

def ask_claude(stats: dict) -> dict:
    """Primary: use Claude API for analysis."""
    if not ANTHROPIC_KEY:
        return {}
    if httpx is None:
        log("  Claude API skipped: httpx not installed")
        return {}
    try:
        stats_json = json.dumps(stats, indent=2)
        resp = httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-haiku-4-5-20251001",
                "max_tokens": 1000,
                "system": SYSTEM_PROMPT,
                "messages": [{"role": "user", "content": USER_PROMPT_TEMPLATE.format(stats_json=stats_json)}],
            },
            timeout=30,
        )
        text = resp.json().get("content", [{}])[0].get("text", "")
        # Strip markdown fences if present
        text = text.strip()
        if "```" in text:
            for part in text.split("```"):
                part = part.strip().lstrip("json").strip()
                if part.startswith("{"):
                    text = part; break
        return json.loads(text)
    except Exception as e:
        log(f"Claude API error: {e}")
        return {}

def ask_ollama(stats: dict) -> dict:
    """Fallback: use local Ollama."""
    try:
        stats_json = json.dumps(stats, indent=2)
        payload = json.dumps({
            "model": OLLAMA_MODEL,
            "prompt": SYSTEM_PROMPT + "\n\n" + USER_PROMPT_TEMPLATE.format(stats_json=stats_json),
            "stream": False,
            "options": {"temperature": 0.2, "num_predict": 800}
        }).encode()
        req = urllib.request.Request(
            f"{OLLAMA_HOST}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=120) as r:
            text = json.loads(r.read().decode()).get("response", "")
        text = text.strip()
        if "```" in text:
            for part in text.split("```"):
                part = part.strip().lstrip("json").strip()
                if part.startswith("{"):
                    text = part; break
        return json.loads(text)
    except Exception as e:
        log(f"Ollama error: {e}")
        return {}

def ask_qwen(stats: dict) -> dict:
    """Call Qwen 2.5 via qwen_engine.qwen_tasks for daily analysis."""
    try:
        from qwen_engine import qwen_tasks as _qt
        if not _qt.q.is_available():
            return {}
        log("  Qwen 2.5 available — running daily_param_tune")
        result = _qt.daily_param_tune(stats)
        if result:
            log(f"  ✓ Qwen 2.5 responded (insight: {result.get('regime_insight','')[:60]})")
        return result
    except Exception as e:
        log(f"  Qwen error: {e}")
        return {}

def get_suggestions(stats: dict) -> tuple:
    """Try Qwen 2.5 first (local, fast), then Claude API, then Ollama raw."""
    log("  Trying Qwen 2.5 (local)...")
    result = ask_qwen(stats)
    if result:
        return result, "qwen2.5"
    log("  Trying Claude API...")
    result = ask_claude(stats)
    if result:
        log("  ✓ Claude API responded")
        return result, "claude"
    log("  Trying Ollama (raw)...")
    result = ask_ollama(stats)
    if result:
        log("  ✓ Ollama responded")
        return result, "ollama"
    log("  ✗ All LLMs unavailable")
    return {}, "none"

# ── Apply suggestions ──────────────────────────────────────────────────────────

SAFE_PARAMS = {
    "target_pct":   (2.0, 20.0),
    "stoploss_pct": (2.0, 20.0),
    "max_hold_min": (3.0, 60.0),
    "nn_thr":       (0.3, 0.8),
    "kelly":        (0.05, 0.4),
    "trail_on":     (0.5, 5.0),
    "trail_dist":   (0.5, 3.0),
    "partial_at":   (1.0, 8.0),
}

def apply_suggestions(suggestions: dict, stats: dict, source: str):
    if not suggestions:
        return []

    c    = get_db()
    applied = []

    # Apply parameter changes
    for change in suggestions.get("parameter_changes", []):
        param = change.get("param", "")
        val   = change.get("suggested")
        if param not in SAFE_PARAMS or not isinstance(val, (int, float)):
            continue
        lo, hi = SAFE_PARAMS[param]
        safe   = round(max(lo, min(hi, float(val))), 3)
        try:
            c.execute("INSERT OR REPLACE INTO config(key,val) VALUES(?,?)",
                      (param, json.dumps(safe)))
            c.commit()
            log(f"  ✓ {param} = {safe}  ({change.get('reason','')})")
            applied.append(f"{param}={safe}")
        except Exception as e:
            log(f"  DB error {param}: {e}")

    # Nudge strategy DNA
    STRAT_PARAMS = {"target_pct", "stoploss_pct", "max_hold_min"}
    st_path = BASE / "data" / "strats.json"
    if st_path.exists():
        try:
            sd = json.load(open(st_path))
            # Get actual current means from strats.json (not from LLM hallucinations)
            actual_means = {}
            for p in STRAT_PARAMS:
                vals = [float(s[p]) for s in sd.get("alive", []) if p in s]
                if vals: actual_means[p] = sum(vals) / len(vals)

            for change in suggestions.get("parameter_changes", []):
                param = change.get("param", "")
                if param not in STRAT_PARAMS: continue
                suggested = change.get("suggested")
                if not isinstance(suggested, (int, float)): continue
                actual_cur = actual_means.get(param)
                if actual_cur is None: continue
                delta = float(suggested) - actual_cur

                for strat in sd.get("alive", []):
                    if param not in strat: continue
                    cur_v   = float(strat[param])
                    nudge   = max(-cur_v*0.3, min(cur_v*0.3, delta))  # ±30% cap
                    lo, hi  = SAFE_PARAMS[param]
                    strat[param] = round(max(lo, min(hi, cur_v + nudge)), 2)

            json.dump(sd, open(st_path, "w"), indent=1)
            log(f"  ✓ Strategy DNA nudged")
        except Exception as e:
            log(f"  strats.json nudge error: {e}")

    # Save suggestions for next run to track improvement
    c.execute("INSERT OR REPLACE INTO config(key,val) VALUES(?,?)",
              ("last_suggestions", json.dumps({
                  "ts": datetime.now(IST).isoformat(),
                  "source": source,
                  "applied": applied,
                  "suggestions": suggestions,
                  "stats_at_time": {
                      "wr": stats.get("all_time", {}).get("win_rate_pct", 0),
                      "net_pnl": stats.get("all_time", {}).get("net_pnl", 0),
                  }
              })))
    c.commit(); c.close()
    return applied

# ── Telegram daily report ──────────────────────────────────────────────────────

def send_daily_report(stats: dict, suggestions: dict, applied: list, source: str):
    if not TG_TOKEN or not TG_CHAT:
        return

    yd  = stats.get("yesterday", {})
    w7  = stats.get("last_7_days", {})
    all = stats.get("all_time", {})

    # Best and worst strategy
    by_strat = stats.get("by_strategy", [])
    best_s  = max(by_strat, key=lambda x: x["net_pnl"], default={})
    worst_s = min(by_strat, key=lambda x: x["win_rate"], default={})

    msg = (
        f"📊 <b>FinanceAGI Daily Report</b>\n"
        f"<i>{datetime.now(IST).strftime('%d %b %Y, %I:%M %p IST')}</i>\n\n"
        f"<b>Yesterday</b>\n"
        f"  Trades: {yd.get('trades',0)} | W/R: {yd.get('win_rate_pct',0)}%\n"
        f"  Net P&L: ₹{yd.get('net_pnl',0):+,.0f} (Gross: ₹{yd.get('gross_pnl',0):+,.0f})\n\n"
        f"<b>Last 7 Days</b>\n"
        f"  Trades: {w7.get('trades',0)} | W/R: {w7.get('win_rate_pct',0)}%\n"
        f"  Net P&L: ₹{w7.get('net_pnl',0):+,.0f}\n\n"
        f"<b>All Time</b>\n"
        f"  Trades: {all.get('trades',0)} | W/R: {all.get('win_rate_pct',0)}%\n"
        f"  Net P&L: ₹{all.get('net_pnl',0):+,.0f}\n\n"
    )

    if best_s:
        msg += f"🏆 Best: {best_s.get('name','?')} ({best_s.get('win_rate',0)}%WR ₹{best_s.get('net_pnl',0):+.0f})\n"
    if worst_s and worst_s != best_s:
        msg += f"⚠️ Worst: {worst_s.get('name','?')} ({worst_s.get('win_rate',0)}%WR)\n"

    if suggestions:
        regime = suggestions.get("regime_insight", "")
        if regime:
            msg += f"\n🧠 <b>AI Insight ({source})</b>\n{regime}\n"
        if applied:
            msg += f"\n⚙️ Auto-applied: {', '.join(applied)}\n"
        urgency = suggestions.get("urgency", "low")
        if urgency == "high":
            msg += "\n🚨 Urgency: HIGH — review logs!\n"

    msg += f"\n<i>AI via {source} | Restart agent to apply changes</i>"
    tg(msg)
    log("  Telegram report sent")

# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    log("=" * 55)
    log(f"  FinanceAGI v13.1 Daily AI Update — {datetime.now(IST).strftime('%d %b %Y')}")
    log("=" * 55)

    # 1. Gather stats
    log("Gathering stats...")
    stats = gather_stats()
    if not stats or stats.get("all_time", {}).get("trades", 0) == 0:
        log("No trades in DB yet — skipping AI update")
        tg("📊 FinanceAGI Daily: No trades recorded yet. Agent running.")
        return

    all_t = stats["all_time"]
    log(f"  All-time: {all_t['trades']}T {all_t['win_rate_pct']}%WR ₹{all_t['net_pnl']:+.0f}")
    log(f"  Yesterday: {stats['yesterday']['trades']}T ₹{stats['yesterday']['net_pnl']:+.0f}")

    # 2. Get AI suggestions
    log("\nRequesting AI analysis...")
    suggestions, source = get_suggestions(stats)

    if not suggestions:
        log("No AI suggestions — sending report without changes")
        send_daily_report(stats, {}, [], "none")
        return

    log(f"\nAI insight: {suggestions.get('regime_insight', 'N/A')}")
    log(f"Urgency: {suggestions.get('urgency', '?')} | Confidence: {suggestions.get('confidence', '?')}")

    # 3. Apply changes
    log("\nApplying suggestions...")
    applied = apply_suggestions(suggestions, stats, source)

    # 4. Send Telegram report
    send_daily_report(stats, suggestions, applied, source)

    # 5. Save full log
    out = BASE / "logs" / f"ai_update_{datetime.now(IST).strftime('%Y%m%d')}.json"
    out.write_text(json.dumps({"ts": datetime.now(IST).isoformat(),
                               "stats": stats, "suggestions": suggestions,
                               "applied": applied, "source": source}, indent=2))
    log(f"\nFull update saved: {out.name}")
    log("Daily update complete.")
    log("Restart agent to apply: pm2 restart financeagi-agent")

if __name__ == "__main__":
    main()
