# FinanceAGI v16 — Upgrade Guide
## Installing over an existing v15 (or earlier) deployment

This guide covers upgrading a **running** installation without losing your
trade history, `.env` credentials, or trained neural-net weights.

---

## What's new in v16

| File | Change |
|---|---|
| `agent.py` | Qwen engine wired in (regime gate, entry/exit commentary, startup ping) |
| `commodity_futures.py` | 8 named commodity strategies + 3 helper functions added |
| `daily_update.py` | Qwen 2.5 is now the **primary** daily analyser (not just fallback) |
| `strategy_inventor.py` | **NEW** — AI strategy creator, evaluator, and evolution engine |
| `qwen_engine.py` | **NEW** — First-class Qwen 2.5 client with 10 named tasks |

**Your `.env`, `data/v10.db`, `data/nn.pkl`, `data/rl.pkl`, and `data/strats.json`
are never touched by the upgrade. All learning and credentials are preserved.**

---

## Before you start

```bash
# Note your current install directory
INSTALL_DIR=/data/financeagi        # default; change if yours is different
# e.g. Termux: INSTALL_DIR=$HOME/financeagi

# Stop the agent (leave the dashboard running if you want)
pm2 stop financeagi-agent
```

---

## Step 1 — Upload and extract the v16 archive

```bash
# From your local machine
scp financeagi_v16_tar.gz user@your-vps:/tmp/

# On the VPS / Termux: extract to a temp location
cd /tmp
tar -xzf financeagi_v16_tar.gz
# This creates /tmp/financeagi_v16/
```

---

## Step 2 — Copy the new and changed files

Run this block exactly as shown. It copies only the changed `.py` files and
the new modules — it does **not** touch your `.env`, `data/`, or `logs/`.

```bash
INSTALL_DIR=/data/financeagi        # ← change if yours differs
SRC=/tmp/financeagi_v16

# Changed files
cp $SRC/agent.py              $INSTALL_DIR/
cp $SRC/commodity_futures.py  $INSTALL_DIR/
cp $SRC/daily_update.py       $INSTALL_DIR/

# New files (safe to copy even if already exist — they're additive)
cp $SRC/strategy_inventor.py  $INSTALL_DIR/
cp $SRC/qwen_engine.py        $INSTALL_DIR/

# Update the deploy guide
cp $SRC/DEPLOY.md             $INSTALL_DIR/
cp $SRC/UPGRADE_v16.md        $INSTALL_DIR/

echo "Files copied. Credentials and DB untouched."
ls -lh $INSTALL_DIR/*.py
```

---

## Step 3 — Install Ollama and Qwen 2.5 (if not already done)

Qwen 2.5 runs locally via Ollama. Skip this step if `ollama list` already
shows `qwen2.5:3b`.

### Ubuntu / Debian VPS

```bash
# Install Ollama (one-liner)
curl -fsSL https://ollama.ai/install.sh | sh

# Pull Qwen 2.5 3B (~2 GB download)
ollama pull qwen2.5:3b

# Verify it loaded
ollama list
# Should show: qwen2.5:3b   <hash>   1.9 GB

# Quick smoke test
ollama run qwen2.5:3b "Reply with the word OK only"
# Expected: OK
```

### Termux (Android)

```bash
# Termux needs the tur-repo for Ollama
pkg install tur-repo
pkg install ollama

# Pull the model (needs ~2 GB free storage)
ollama pull qwen2.5:3b

# Start Ollama as a background service
ollama serve &
```

### Check Ollama stays running on reboot (VPS only)

Ollama installs its own systemd service on Ubuntu. Verify:

```bash
systemctl status ollama
# Should show: active (running)
```

If not enabled:

```bash
sudo systemctl enable ollama
sudo systemctl start ollama
```

---

## Step 4 — Verify Qwen is reachable from the app

```bash
cd $INSTALL_DIR
python3 qwen_engine.py ping
```

Expected output:
```
Qwen ping: ✓ ONLINE
[QWEN] qwen2.5:3b@http://localhost:11434 | calls=0 errors=0 avg=0ms | available=True
```

If you see `✗ OFFLINE`:
- Check `ollama serve` is running: `curl http://localhost:11434/api/tags`
- Check the model name in `.env` matches exactly: `OLLAMA_MODEL=qwen2.5:3b`
- If running on a non-default port, set `OLLAMA_HOST=http://localhost:PORT`

---

## Step 5 — Update `.env` (add v16 settings)

Open your existing `.env` and add these lines at the bottom. Your existing
credentials and settings are untouched.

```bash
nano $INSTALL_DIR/.env
```

Add at the bottom:

```dotenv
# ── v16: Qwen 2.5 Engine ─────────────────────────────────────────────────────
OLLAMA_HOST=http://localhost:11434   # already set? leave it, no duplicate needed
OLLAMA_MODEL=qwen2.5:3b              # already set? leave it
QWEN_TIMEOUT=90                      # seconds to wait for Qwen response (default 90)
QWEN_MAX_TOKENS=512                  # max tokens per Qwen call (default 512)

# ── v16: Strategy Inventor ───────────────────────────────────────────────────
INVENTOR_MAX_STRATS=12               # max live commodity strategies at once
INVENTOR_KILL_WR=0.40                # kill strategy if WR drops below 40%
INVENTOR_MIN_TRADES=8                # minimum trades before kill is eligible

# ── v16: Strategy Invention via Claude (optional) ────────────────────────────
# If set, the StrategyInventor uses Claude to invent brand-new strategies.
# Your existing ANTHROPIC_API_KEY works — no new key needed.
# Leave blank to use only the 8 seed strategies + local evolution.
# ANTHROPIC_API_KEY=already_set_above   ← no need to duplicate
```

Save and exit (`Ctrl+X`, `Y`, `Enter` in nano).

---

## Step 6 — Verify strategy inventor boots

```bash
cd $INSTALL_DIR
python3 strategy_inventor.py status
```

Expected output (8 seed strategies loaded):
```
──────────────────────────────────────────────────────
NAME                   SIGNAL             DIR   ...
──────────────────────────────────────────────────────
CrudeGoldSpread        SPREAD_INTER       BOTH  ...
CrudeUSBreakout        US_MOMENTUM        BOTH  ...
EODFade                MEAN_REVERT        BOTH  ...
GoldMeanRev            MEAN_REVERT        BOTH  ...
MorningORB             BREAKOUT_VOL       BOTH  ...
NatGasEIA              INVENTORY_CRUDE    BOTH  ...
NatGasSeasonal         SEASONAL_NATGAS    BUY   ...
VIXGoldHedge           VIX_SPIKE_GOLD     BUY   ...
──────────────────────────────────────────────────────
[INVENTOR] 8 active strategies
```

---

## Step 7 — Test Qwen tasks

These are non-destructive read-only tests:

```bash
# Regime classification
python3 qwen_engine.py regime

# Example trade commentary
python3 qwen_engine.py commentary

# Free chat
python3 qwen_engine.py chat "What time does crude oil move the most on MCX?"

# Candle pattern on random data
python3 qwen_engine.py candles
```

All commands print `(Qwen offline)` gracefully if Ollama isn't running — the
agent handles this the same way and simply skips Qwen tasks without crashing.

---

## Step 8 — Restart the agent

```bash
cd $INSTALL_DIR
pm2 restart financeagi-agent

# Confirm it started cleanly
pm2 logs financeagi-agent --lines 40
```

Look for these lines in the startup log:

```
  Qwen 2.5: ONLINE
  [QWEN] Patched daily_update.ask_ollama → qwen_tasks.daily_param_tune
  [QWEN] Patched web_search._summarise_with_llm → qwen_tasks.summarise_news
  [INVENTOR] Loaded 8 strategies from invented_strategies.json
```

If Qwen is offline at startup, you'll see:
```
  Qwen 2.5: OFFLINE (will retry)
```
This is not an error — the agent continues normally and retries the ping
every 5 minutes.

---

## Step 9 — Verify the Telegram startup message

If Telegram is configured, the agent sends:

```
🚀 FinanceAGI v16 started
Mode: PAPER | Capital: ₹10,000
Strats: 14 | MCX: ON
Qwen 2.5: ONLINE
```

The `Qwen 2.5: ONLINE` line confirms the full integration is active.

---

## Enabling MCX + Strategy Inventor together

If you haven't enabled MCX yet but want to use the new commodity strategies:

```bash
# In .env:
ASSET_MODE=all
COMMODITY_ENABLED=true
ALLOC_COMMODITY=15000     # minimum ~₹7,000 for CRUDEOILM

pm2 restart financeagi-agent
```

Once MCX is enabled, `strategy_inventor.py` will automatically start tracking
performance per strategy and evolving them after every 10 trades.

To see live strategy performance at any time without stopping the agent:

```bash
python3 strategy_inventor.py status
```

To force-invent a new strategy via Claude now (requires `ANTHROPIC_API_KEY`):

```bash
python3 strategy_inventor.py invent
```

To run one evolution cycle (kill weak, breed top-2, mutate one) manually:

```bash
python3 strategy_inventor.py evolve
```

---

## Running the daily Qwen analysis manually

```bash
python3 daily_update.py
```

v16 call order: **Qwen 2.5 (local, fast) → Claude API → Ollama raw fallback**.
Qwen handles it in ~5–15 seconds locally. The output and DB writes are
identical to before — `apply_suggestions()` runs the same way regardless of
which model answered.

---

## Rollback if something goes wrong

Your original v15 files are untouched in the source archive. To revert any
single file:

```bash
# Example: revert agent.py to v15
tar -xzf /tmp/financeagi_v15_tar.gz --strip-components=1 \
    -C $INSTALL_DIR financeagi_v15/agent.py

pm2 restart financeagi-agent
```

The new files (`strategy_inventor.py`, `qwen_engine.py`) have no effect if
their imports fail — both are wrapped in `try/except` in `agent.py` and
degrade silently.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| `Qwen ping: ✗ OFFLINE` | Run `ollama serve` or `systemctl start ollama` |
| `qwen2.5:3b not found` | Run `ollama pull qwen2.5:3b` |
| `strategy_inventor not loaded` | Check `python3 strategy_inventor.py status` for the error |
| Qwen responses are slow (>30s) | Normal on first call (model load). Subsequent calls are 3–8s. |
| `invented_strategies.json` not created | Run `python3 strategy_inventor.py status` once to seed it |
| Agent crashes on import | Run `python3 agent.py` directly to see the full traceback |
| `OLLAMA_MODEL not found` | Check `ollama list` — model name must match exactly including tag |
| MCX trades not using strategies | Set `COMMODITY_ENABLED=true` and `ASSET_MODE=all` in `.env` |

---

## File summary — what changed vs v15

```
financeagi/
├── agent.py              ← UPDATED (Qwen wired in: 5 new hooks)
├── commodity_futures.py  ← UPDATED (8 named strategies + helpers added)
├── daily_update.py       ← UPDATED (Qwen is now primary LLM, not fallback)
├── strategy_inventor.py  ← NEW     (AI strategy creator + evolution engine)
├── qwen_engine.py        ← NEW     (Qwen 2.5 client with 10 named tasks)
├── UPGRADE_v16.md        ← NEW     (this file)
│
│   ── untouched ──────────────────────────────────────────────────
├── .env                  (your credentials — never modified by upgrade)
├── data/v10.db           (trade history — never modified by upgrade)
├── data/nn.pkl           (neural net weights — preserved)
├── data/strats.json      (options strategy DNA — preserved)
├── multileg.py           (no changes)
├── equity_intraday.py    (no changes)
├── alpha_signals.py      (no changes)
├── ensemble_scorer.py    (no changes)
├── regime_hmm.py         (no changes)
├── self_improve.py       (no changes)
└── web_search.py         (no changes; patched at runtime by qwen_engine)
```
