#!/usr/bin/env python3
"""
strategy_master.py — FinanceAGI v17: Unified Strategy Creation & Management Engine
====================================================================================

The Strategy Master orchestrates strategy invention, evolution, and lifecycle
management across ALL asset classes:
  - Options (NIFTY/BANKNIFTY/FNO stocks) via options_strategy_inventor
  - Equity Intraday (MIS) via equity_strategy_inventor
  - Commodity Futures (MCX) via strategy_inventor (existing)

Core Capabilities:
  ┌──────────────────────────────────────────────────────────────────────────┐
  │  INVENT    — LLM-powered strategy creation for any asset class         │
  │  CROSSOVER — Cross-pollinate ideas between asset classes               │
  │  LIFECYCLE — Unified birth → test → promote → mature → kill pipeline   │
  │  ALLOCATE  — Dynamic capital allocation across strategies              │
  │  REPORT    — Unified performance dashboard across all strategies        │
  │  SCHEDULE  — Automated invention/evolution cycles                      │
  └──────────────────────────────────────────────────────────────────────────┘

Cross-Asset Intelligence:
  The Strategy Master can transfer winning patterns across asset classes.
  E.g., a mean-reversion strategy working well for GOLDPETAL commodities
  can inspire an equity mean-reversion strategy for banking stocks, or
  a theta-harvesting options strategy for NIFTY.

Integration with agent.py:
  1. Import: `from strategy_master import master`
  2. In main loop: `await master.run_cycle(broker, market_context)`
  3. For picks: `strat, target = master.pick_best("options", chain, spot, cash)`
  4. Record:   `master.record_trade("options", strat_name, won, pnl_pct)`
  5. Status:   `master.full_report()`

Usage (standalone):
  python3 strategy_master.py                # Full dashboard
  python3 strategy_master.py invent         # Force invention all classes
  python3 strategy_master.py report         # Performance report
  python3 strategy_master.py evolve         # Evolution cycle all classes
  python3 strategy_master.py crossover      # Cross-asset learning
"""

import asyncio
import json
import logging
import math
import os
import sqlite3
import sys
import time
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

try:
    import httpx
    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False

log = logging.getLogger("agi.master")
IST = timezone(timedelta(hours=5, minutes=30))
BASE = Path(__file__).resolve().parent
DB   = str(BASE / "data" / "v10.db")
MASTER_STATE_FILE = BASE / "data" / "strategy_master_state.json"

# ── Load environment ───────────────────────────────────────────────────────────
def _env(key: str, default: str = "") -> str:
    ef = BASE / ".env"
    if ef.exists():
        for ln in ef.read_text().splitlines():
            ln = ln.strip()
            if ln and not ln.startswith("#") and "=" in ln:
                k, v = ln.split("=", 1)
                if k.strip() == key:
                    return v.strip()
    return os.environ.get(key, default)

ANTHROPIC_API_KEY = _env("ANTHROPIC_API_KEY")

# ── Import sub-inventors ───────────────────────────────────────────────────────
try:
    from options_strategy_inventor import options_inventor, opt_strat_db, opt_perf
    _OPT_INV = True
except Exception as e:
    log.warning(f"  [MASTER] options_strategy_inventor not loaded: {e}")
    options_inventor = None
    _OPT_INV = False

try:
    from equity_strategy_inventor import equity_inventor, eq_strat_db, eq_perf
    _EQ_INV = True
except Exception as e:
    log.warning(f"  [MASTER] equity_strategy_inventor not loaded: {e}")
    equity_inventor = None
    _EQ_INV = False

try:
    from strategy_inventor import inventor as commodity_inventor, strat_db as com_strat_db, perf_tracker as com_perf
    _COM_INV = True
except Exception as e:
    log.warning(f"  [MASTER] strategy_inventor (commodity) not loaded: {e}")
    commodity_inventor = None
    _COM_INV = False


# ═══════════════════════ LIFECYCLE STAGES ═══════════════════════════════════════

class StrategyLifecycle:
    """
    Manages strategy lifecycle stages:
      SEED      → Initial creation (generation 0)
      INVENTED  → LLM-created (generation 1+)
      TESTING   → Under probation (< min trades)
      PROMOTED  → Passed testing threshold
      MATURE    → Consistent performer (> 20 trades, WR > 50%)
      DECLINING → Performance dropping (WR decreasing trend)
      KILLED    → Deactivated (below kill threshold)
    """

    STAGES = ["SEED", "INVENTED", "TESTING", "PROMOTED", "MATURE", "DECLINING", "KILLED"]
    MIN_TEST_TRADES = 5
    PROMOTE_WR = 0.50
    MATURE_TRADES = 20
    MATURE_WR = 0.50

    @staticmethod
    def classify(strat: dict, perf_summary: dict) -> str:
        """Classify a strategy into its lifecycle stage."""
        if not strat.get("active", True):
            return "KILLED"

        n  = perf_summary.get("n", 0) or strat.get("trades", 0)
        wr = perf_summary.get("wr", 0.5)
        gen = strat.get("generation", 0)

        if n == 0:
            return "SEED" if gen == 0 else "INVENTED"

        if n < StrategyLifecycle.MIN_TEST_TRADES:
            return "TESTING"

        if n >= StrategyLifecycle.MATURE_TRADES and wr >= StrategyLifecycle.MATURE_WR:
            return "MATURE"

        if wr >= StrategyLifecycle.PROMOTE_WR:
            return "PROMOTED"

        return "DECLINING"


lifecycle = StrategyLifecycle()


# ═══════════════════════ CROSS-ASSET LEARNER ═══════════════════════════════════

class CrossAssetLearner:
    """
    Transfers winning patterns between asset classes.
    Analyzes what's working in one domain and suggests adaptations for others.
    """

    MODEL = "claude-sonnet-4-20250514"
    COOLDOWN_SEC = 600  # 10 minutes

    def __init__(self):
        self._last_call = 0.0

    async def suggest_crossover(self, winning_strategies: dict,
                                  market_context: dict) -> list[dict]:
        """
        Analyze winning strategies across asset classes and suggest
        cross-pollination opportunities.

        winning_strategies: {
            "options": [{"name": ..., "strategy_type": ..., "wr": ..., ...}],
            "equity":  [...],
            "commodity": [...]
        }

        Returns list of suggestion dicts with target_class and adaptation details.
        """
        if not ANTHROPIC_API_KEY or not _HAS_HTTPX:
            return self._rule_based_crossover(winning_strategies)

        if time.time() - self._last_call < self.COOLDOWN_SEC:
            return self._rule_based_crossover(winning_strategies)

        self._last_call = time.time()

        # Build context of winning strategies
        winners_text = ""
        for asset_class, strats in winning_strategies.items():
            if strats:
                winners_text += f"\n{asset_class.upper()} WINNERS:\n"
                for s in strats[:3]:
                    winners_text += (
                        f"  {s.get('name', '?')}: type={s.get('strategy_type', '?')} "
                        f"signal={s.get('signal_type', '?')} WR={s.get('wr', 0):.0%} "
                        f"sharpe={s.get('sharpe', 0):.2f} rationale={s.get('rationale', '')[:60]}\n"
                    )

        system_prompt = (
            "You are a cross-asset quant strategist. Analyze winning strategies from "
            "one asset class and suggest how their edge could be adapted to other classes. "
            "Return ONLY a JSON array of suggestions."
        )

        user_prompt = f"""
WINNING STRATEGIES ACROSS ASSET CLASSES:
{winners_text}

MARKET CONTEXT:
  VIX: {market_context.get("india_vix", "?")}
  NIFTY: {market_context.get("nifty", "?")}

For each winning pattern, suggest ONE adaptation to a DIFFERENT asset class.
E.g., if a commodity mean-reversion works well, suggest an equity or options version.

Return ONLY a JSON array (no fences):
[
  {{
    "source_class": "commodity/options/equity",
    "source_strategy": "StrategyName",
    "target_class": "options/equity/commodity",
    "suggested_name": "NewStrategyName",
    "adaptation": "1 sentence on how to adapt the edge",
    "strategy_type": "appropriate_type_for_target_class",
    "signal_type": "appropriate_signal",
    "key_params": {{"target_pct": 0.5, "stoploss_pct": 0.3}}
  }}
]
""".strip()

        try:
            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key":         ANTHROPIC_API_KEY,
                        "anthropic-version": "2023-06-01",
                        "content-type":      "application/json",
                    },
                    json={
                        "model": self.MODEL,
                        "max_tokens": 800,
                        "system": system_prompt,
                        "messages": [{"role": "user", "content": user_prompt}],
                    },
                )
                resp.raise_for_status()
                data = resp.json()

            raw = ""
            for block in data.get("content", []):
                if block.get("type") == "text":
                    raw += block.get("text", "")

            raw = raw.strip()
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]

            suggestions = json.loads(raw.strip())
            log.info(f"  [MASTER] Cross-asset learner: {len(suggestions)} suggestions")
            return suggestions if isinstance(suggestions, list) else []

        except Exception as e:
            log.error(f"  [MASTER] Cross-asset LLM failed: {e}")
            return self._rule_based_crossover(winning_strategies)

    def _rule_based_crossover(self, winning_strategies: dict) -> list[dict]:
        """Fallback rule-based cross-pollination when LLM unavailable."""
        suggestions = []

        # Pattern: commodity mean-revert winner → equity mean-revert
        for s in winning_strategies.get("commodity", []):
            if "mean" in s.get("signal_type", "").lower() or "revert" in s.get("name", "").lower():
                suggestions.append({
                    "source_class": "commodity",
                    "source_strategy": s.get("name", ""),
                    "target_class": "equity",
                    "suggested_name": f"EqAdapt_{s.get('name', 'MR')[:10]}",
                    "adaptation": f"Adapt {s.get('name', '')} mean-reversion to equity stocks",
                    "strategy_type": "mean_revert",
                    "signal_type": "RANGE_POSITION",
                    "key_params": {
                        "target_pct": min(s.get("target_pct", 1.0) * 0.5, 1.0),
                        "stoploss_pct": min(s.get("sl_pct", 0.6) * 0.5, 0.5),
                    }
                })

        # Pattern: options theta harvest winner → commodity credit strategy
        for s in winning_strategies.get("options", []):
            if "theta" in s.get("signal_type", "").lower() or "credit" in str(s.get("tags", [])):
                suggestions.append({
                    "source_class": "options",
                    "source_strategy": s.get("name", ""),
                    "target_class": "commodity",
                    "suggested_name": f"ComAdapt_{s.get('name', 'TH')[:10]}",
                    "adaptation": f"Adapt {s.get('name', '')} time-decay approach to commodity EOD scalps",
                    "strategy_type": "mean_revert",
                    "signal_type": "MEAN_REVERT",
                    "key_params": {
                        "target_pct": 0.5,
                        "sl_pct": 0.35,
                        "session": "eod",
                    }
                })

        # Pattern: equity momentum winner → options momentum
        for s in winning_strategies.get("equity", []):
            if "momentum" in s.get("strategy_type", "").lower():
                suggestions.append({
                    "source_class": "equity",
                    "source_strategy": s.get("name", ""),
                    "target_class": "options",
                    "suggested_name": f"OptAdapt_{s.get('name', 'MO')[:10]}",
                    "adaptation": f"Adapt {s.get('name', '')} momentum to options CE/PE buys",
                    "strategy_type": "single",
                    "signal_type": "MOMENTUM_LONG",
                    "key_params": {
                        "target_pct": s.get("target_pct", 0.5) * 10,
                        "stoploss_pct": s.get("stoploss_pct", 0.3) * 10,
                    }
                })

        return suggestions[:3]


cross_learner = CrossAssetLearner()


# ═══════════════════════ CAPITAL ALLOCATOR ═══════════════════════════════════════

class StrategyCapitalAllocator:
    """
    Dynamically allocate capital across strategies based on performance.
    Uses a modified Kelly criterion weighted by Sharpe ratio.
    """

    @staticmethod
    def allocate(strategies: list[dict], total_capital: float,
                 perf_summaries: dict) -> dict:
        """
        Allocate capital across strategies.

        Returns: {strategy_name: allocated_capital}
        """
        if not strategies:
            return {}

        # Score each strategy
        scores = {}
        for s in strategies:
            name = s["name"]
            perf = perf_summaries.get(name, {})
            wr = perf.get("wr", 0.5)
            sharpe = perf.get("sharpe", 0)
            n = perf.get("n", 0)

            # Confidence grows with trades
            confidence = min(n / 20, 1.0)

            # Score combines WR, Sharpe, and confidence
            score = (wr * 2.0 + max(sharpe, 0) * 1.0) * confidence
            # Minimum allocation for untested strategies
            score = max(score, 0.3 if n < 5 else 0.1)
            scores[name] = score

        # Normalize scores to allocations
        total_score = sum(scores.values())
        if total_score <= 0:
            # Equal allocation
            n = len(strategies)
            return {s["name"]: total_capital / n for s in strategies}

        allocations = {}
        for name, score in scores.items():
            pct = score / total_score
            # Cap any single strategy at 30% of capital
            pct = min(pct, 0.30)
            allocations[name] = round(total_capital * pct, 2)

        return allocations


allocator = StrategyCapitalAllocator()


# ═══════════════════════ UNIFIED REPORT ═══════════════════════════════════════

class UnifiedReporter:
    """Generates unified performance reports across all asset classes."""

    @staticmethod
    def full_report() -> str:
        lines = []
        lines.append("=" * 80)
        lines.append("  FINANCEAGI — STRATEGY MASTER REPORT")
        lines.append(f"  {datetime.now(IST).strftime('%Y-%m-%d %H:%M IST')}")
        lines.append("=" * 80)

        total_strategies = 0
        total_trades = 0
        total_wins = 0
        total_pnl = 0.0

        # ── Options ──
        if _OPT_INV:
            opt_active = options_inventor.active_strategies()
            total_strategies += len(opt_active)
            lines.append(f"\n{'─'*40}")
            lines.append(f"  OPTIONS ({len(opt_active)} active)")
            lines.append(f"{'─'*40}")

            type_dist = defaultdict(int)
            for s in opt_active:
                n = s.get("trades", 0)
                w = s.get("wins", 0)
                total_trades += n
                total_wins += w
                total_pnl += s.get("total_pnl", 0)
                type_dist[s.get("strategy_type", "?")] += 1
                stage = lifecycle.classify(s, opt_perf.summary(s["name"]))
                perf = opt_perf.summary(s["name"])
                wr = f"{perf['wr']:.0%}" if perf['n'] > 0 else "—"
                lines.append(
                    f"  {stage:10s} {s['name']:<22s} {s.get('strategy_type','?'):<14s} "
                    f"n={perf['n']:>3} WR={wr:>4s} S={perf['sharpe']:>5.2f}"
                )

            lines.append(f"  Types: {dict(type_dist)}")

        # ── Equity ──
        if _EQ_INV:
            eq_active = equity_inventor.active_strategies()
            total_strategies += len(eq_active)
            lines.append(f"\n{'─'*40}")
            lines.append(f"  EQUITY ({len(eq_active)} active)")
            lines.append(f"{'─'*40}")

            for s in eq_active:
                n = s.get("trades", 0)
                w = s.get("wins", 0)
                total_trades += n
                total_wins += w
                total_pnl += s.get("total_pnl", 0)
                stage = lifecycle.classify(s, eq_perf.summary(s["name"]))
                perf = eq_perf.summary(s["name"])
                wr = f"{perf['wr']:.0%}" if perf['n'] > 0 else "—"
                lines.append(
                    f"  {stage:10s} {s['name']:<22s} {s.get('strategy_type','?'):<16s} "
                    f"n={perf['n']:>3} WR={wr:>4s} S={perf['sharpe']:>5.2f}"
                )

        # ── Commodity ──
        if _COM_INV:
            com_active = commodity_inventor.active_strategies() if hasattr(commodity_inventor, 'active_strategies') else []
            total_strategies += len(com_active)
            lines.append(f"\n{'─'*40}")
            lines.append(f"  COMMODITY ({len(com_active)} active)")
            lines.append(f"{'─'*40}")

            for s in com_active:
                n = s.get("trades", 0)
                w = s.get("wins", 0)
                total_trades += n
                total_wins += w
                total_pnl += s.get("total_pnl", 0)
                # Use com_perf if available
                perf_data = {}
                if com_perf:
                    perf_data = com_perf.summary(s["name"])
                stage = lifecycle.classify(s, perf_data)
                wr_val = perf_data.get("wr", 0)
                n_val = perf_data.get("n", 0)
                wr = f"{wr_val:.0%}" if n_val > 0 else "—"
                lines.append(
                    f"  {stage:10s} {s['name']:<22s} {s.get('signal_type','?'):<18s} "
                    f"n={n_val:>3} WR={wr:>4s}"
                )

        # ── Summary ──
        overall_wr = round(total_wins / max(total_trades, 1) * 100, 1)
        lines.append(f"\n{'='*80}")
        lines.append(
            f"  TOTAL: {total_strategies} strategies | {total_trades} trades | "
            f"{overall_wr}% WR | P&L: {total_pnl:+.2f}%"
        )
        lines.append("=" * 80)

        return "\n".join(lines)


reporter = UnifiedReporter()


# ═══════════════════════ MASTER ORCHESTRATOR ══════════════════════════════════

class StrategyMaster:
    """
    Unified Strategy Creation & Management Engine.
    Orchestrates all three asset-class inventors + cross-asset learning.
    """

    def __init__(self):
        self._cycle_count = 0
        self._last_invention_cycle = 0.0
        self._last_evolution_cycle = 0.0
        self._last_crossover_cycle = 0.0
        self.INVENTION_INTERVAL = 3600     # 1 hour
        self.EVOLUTION_INTERVAL = 1800     # 30 min
        self.CROSSOVER_INTERVAL = 7200     # 2 hours
        self._state = self._load_state()

    def _load_state(self) -> dict:
        if MASTER_STATE_FILE.exists():
            try:
                return json.loads(MASTER_STATE_FILE.read_text())
            except Exception:
                pass
        return {
            "total_inventions": 0,
            "total_evolutions": 0,
            "total_crossovers": 0,
            "created_at": datetime.now(IST).isoformat(),
        }

    def _save_state(self):
        MASTER_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        MASTER_STATE_FILE.write_text(json.dumps(self._state, indent=2))

    async def run_cycle(self, market_context: dict):
        """
        Run one master cycle. Called periodically from agent.py main loop.
        Handles invention, evolution, and cross-asset learning on schedule.
        """
        self._cycle_count += 1
        now = time.time()

        # Evolution cycle (most frequent)
        if now - self._last_evolution_cycle > self.EVOLUTION_INTERVAL:
            self._run_all_evolutions()
            self._last_evolution_cycle = now

        # Invention cycle
        if now - self._last_invention_cycle > self.INVENTION_INTERVAL:
            await self._run_all_inventions(market_context)
            self._last_invention_cycle = now

        # Cross-asset learning (least frequent)
        if now - self._last_crossover_cycle > self.CROSSOVER_INTERVAL:
            await self._run_crossover(market_context)
            self._last_crossover_cycle = now

    async def _run_all_inventions(self, market_context: dict):
        """Attempt invention across all asset classes."""
        log.info("  [MASTER] Running invention cycle across all asset classes")

        if _OPT_INV:
            try:
                result = await options_inventor.maybe_invent(market_context)
                if result:
                    log.info(f"  [MASTER] Options invention: {result['name']}")
                    self._state["total_inventions"] = self._state.get("total_inventions", 0) + 1
            except Exception as e:
                log.error(f"  [MASTER] Options invention error: {e}")

        if _EQ_INV:
            try:
                result = await equity_inventor.maybe_invent(market_context)
                if result:
                    log.info(f"  [MASTER] Equity invention: {result['name']}")
                    self._state["total_inventions"] = self._state.get("total_inventions", 0) + 1
            except Exception as e:
                log.error(f"  [MASTER] Equity invention error: {e}")

        if _COM_INV and hasattr(commodity_inventor, 'maybe_invent'):
            try:
                result = await commodity_inventor.maybe_invent(market_context)
                if result:
                    log.info(f"  [MASTER] Commodity invention: {result['name']}")
                    self._state["total_inventions"] = self._state.get("total_inventions", 0) + 1
            except Exception as e:
                log.error(f"  [MASTER] Commodity invention error: {e}")

        self._save_state()

    def _run_all_evolutions(self):
        """Run evolution across all asset classes."""
        log.info("  [MASTER] Running evolution cycle across all asset classes")

        if _OPT_INV:
            try:
                from options_strategy_inventor import opt_evolution, opt_strat_db
                actions = opt_evolution.evolve(opt_strat_db.active())
                if actions:
                    log.info(f"  [MASTER] Options evolution: {len(actions)} actions")
            except Exception as e:
                log.error(f"  [MASTER] Options evolution error: {e}")

        if _EQ_INV:
            try:
                from equity_strategy_inventor import eq_evolution, eq_strat_db
                actions = eq_evolution.evolve(eq_strat_db.active())
                if actions:
                    log.info(f"  [MASTER] Equity evolution: {len(actions)} actions")
            except Exception as e:
                log.error(f"  [MASTER] Equity evolution error: {e}")

        if _COM_INV:
            try:
                from strategy_inventor import evolution_engine, strat_db
                actions = evolution_engine.evolve(strat_db.active())
                if actions:
                    log.info(f"  [MASTER] Commodity evolution: {len(actions)} actions")
            except Exception as e:
                log.error(f"  [MASTER] Commodity evolution error: {e}")

        self._state["total_evolutions"] = self._state.get("total_evolutions", 0) + 1
        self._save_state()

    async def _run_crossover(self, market_context: dict):
        """Run cross-asset learning cycle."""
        log.info("  [MASTER] Running cross-asset learning cycle")

        # Gather winners from each class
        winners = {"options": [], "equity": [], "commodity": []}

        if _OPT_INV:
            for s in options_inventor.active_strategies():
                perf = opt_perf.summary(s["name"])
                if perf["n"] >= 5 and perf["wr"] > 0.55:
                    winners["options"].append({**s, **perf})

        if _EQ_INV:
            for s in equity_inventor.active_strategies():
                perf = eq_perf.summary(s["name"])
                if perf["n"] >= 5 and perf["wr"] > 0.55:
                    winners["equity"].append({**s, **perf})

        if _COM_INV and hasattr(commodity_inventor, 'active_strategies'):
            for s in commodity_inventor.active_strategies():
                perf = com_perf.summary(s["name"]) if com_perf else {}
                if perf.get("n", 0) >= 5 and perf.get("wr", 0) > 0.55:
                    winners["commodity"].append({**s, **perf})

        # Only proceed if we have winners
        total_winners = sum(len(v) for v in winners.values())
        if total_winners < 2:
            log.info("  [MASTER] Not enough winning strategies for cross-asset learning")
            return

        suggestions = await cross_learner.suggest_crossover(winners, market_context)
        if suggestions:
            log.info(f"  [MASTER] Cross-asset suggestions: {len(suggestions)}")
            for sug in suggestions:
                log.info(
                    f"  [MASTER]   {sug.get('source_class', '?')} → {sug.get('target_class', '?')}: "
                    f"{sug.get('suggested_name', '?')} — {sug.get('adaptation', '')[:60]}"
                )
            self._state["total_crossovers"] = self._state.get("total_crossovers", 0) + 1
            self._save_state()

    def record_trade(self, asset_class: str, strategy_name: str, won: bool,
                     pnl_pct: float, extra: dict = None):
        """Record a trade to the appropriate sub-inventor."""
        if asset_class == "options" and _OPT_INV:
            options_inventor.record_trade(strategy_name, won, pnl_pct, extra)
        elif asset_class == "equity" and _EQ_INV:
            equity_inventor.record_trade(strategy_name, won, pnl_pct, extra)
        elif asset_class == "commodity" and _COM_INV:
            if hasattr(commodity_inventor, 'record_trade'):
                commodity_inventor.record_trade(strategy_name, won, pnl_pct)

    def pick_best(self, asset_class: str, *args, **kwargs):
        """Delegate pick to the appropriate sub-inventor."""
        if asset_class == "options" and _OPT_INV:
            return options_inventor.pick_strategy(*args, **kwargs)
        elif asset_class == "equity" and _EQ_INV:
            return equity_inventor.pick_strategy(*args, **kwargs)
        return None, None

    def allocate_capital(self, asset_class: str, total_capital: float) -> dict:
        """Allocate capital across strategies for an asset class."""
        if asset_class == "options" and _OPT_INV:
            strats = options_inventor.active_strategies()
            perfs = {s["name"]: opt_perf.summary(s["name"]) for s in strats}
            return allocator.allocate(strats, total_capital, perfs)
        elif asset_class == "equity" and _EQ_INV:
            strats = equity_inventor.active_strategies()
            perfs = {s["name"]: eq_perf.summary(s["name"]) for s in strats}
            return allocator.allocate(strats, total_capital, perfs)
        return {}

    def full_report(self) -> str:
        """Generate unified report."""
        report = reporter.full_report()
        report += f"\n\n  Master cycles: {self._cycle_count}"
        report += f"\n  Total inventions: {self._state.get('total_inventions', 0)}"
        report += f"\n  Total evolutions: {self._state.get('total_evolutions', 0)}"
        report += f"\n  Total crossovers: {self._state.get('total_crossovers', 0)}"
        return report

    def strategy_count(self) -> dict:
        """Count strategies across all classes."""
        counts = {}
        if _OPT_INV:
            counts["options"] = len(options_inventor.active_strategies())
        if _EQ_INV:
            counts["equity"] = len(equity_inventor.active_strategies())
        if _COM_INV and hasattr(commodity_inventor, 'active_strategies'):
            counts["commodity"] = len(commodity_inventor.active_strategies())
        counts["total"] = sum(counts.values())
        return counts

    def status_line(self) -> str:
        """One-line status for Telegram / logs."""
        c = self.strategy_count()
        return (
            f"[MASTER] Strategies: {c.get('total', 0)} "
            f"(opt={c.get('options', 0)} eq={c.get('equity', 0)} com={c.get('commodity', 0)}) | "
            f"Inv={self._state.get('total_inventions', 0)} Evo={self._state.get('total_evolutions', 0)} "
            f"XO={self._state.get('total_crossovers', 0)}"
        )


# ── Module-level singleton ──────────────────────────────────────────────────
master = StrategyMaster()


# ═══════════════════════ ASYNC LOOP FOR AGENT.PY ══════════════════════════════

async def run_strategy_master_loop(market_context_ref: list):
    """
    Background loop for strategy management.
    market_context_ref is a mutable list [context_dict] that agent.py updates.
    """
    log.info("  [MASTER] Strategy master loop started")
    while True:
        try:
            ctx = market_context_ref[0] if market_context_ref else {}
            await master.run_cycle(ctx)
        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error(f"  [MASTER] Cycle error: {e}")
        await asyncio.sleep(300)  # Run every 5 minutes


# ═══════════════════════ CLI ═══════════════════════════════════════════════════

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s", datefmt="%H:%M:%S",
                        handlers=[logging.StreamHandler()])

    cmd = sys.argv[1] if len(sys.argv) > 1 else "report"

    if cmd == "report":
        print(master.full_report())
        print(f"\n{master.status_line()}")

    elif cmd == "invent":
        print("Force-inventing across all asset classes...")
        ctx = {
            "spot_prices": {"NIFTY": 22450, "BANKNIFTY": 48200},
            "day_changes": {"NIFTY": +0.3, "BANKNIFTY": -0.1},
            "india_vix": 14.5,
            "pcr": 1.15,
            "nifty": 22450, "nifty_change": +0.3,
            "banknifty": 48200, "breadth": "positive",
            "regime": "RANGING",
        }
        asyncio.run(master._run_all_inventions(ctx))
        print("\nDone. Run 'python3 strategy_master.py report' to see results.")

    elif cmd == "evolve":
        print("Running evolution across all classes...")
        master._run_all_evolutions()
        print(master.full_report())

    elif cmd == "crossover":
        print("Running cross-asset learning...")
        ctx = {"india_vix": 14.5, "nifty": 22450}
        asyncio.run(master._run_crossover(ctx))

    elif cmd == "counts":
        c = master.strategy_count()
        print(json.dumps(c, indent=2))

    else:
        print(f"Unknown: {cmd}")
        print("Usage: python3 strategy_master.py [report|invent|evolve|crossover|counts]")
