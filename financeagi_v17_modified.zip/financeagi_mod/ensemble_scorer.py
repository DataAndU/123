#!/usr/bin/env python3
"""
ensemble_scorer.py — FinanceAGI v14 Upgrade: LightGBM + NN Ensemble

DROP-IN addition. Does NOT modify agent.py.
agent.py's v14_patch.py hooks this into the scoring pipeline.

Architecture:
  - LightGBM  (weight 0.50) — best on tabular data, <1ms inference on ARM
  - Existing NN (weight 0.35) — captures smooth nonlinearities
  - Rolling WR  (weight 0.15) — per-strategy recent win rate anchoring

Falls back gracefully to NN-only if lightgbm is not installed.

Install on Termux:
  pip install lightgbm --break-system-packages
  (or: pkg install tur-repo && pip install lightgbm)
"""

import json, logging, math, os, pickle, time
from pathlib import Path
from collections import deque

import numpy as np

log = logging.getLogger("agi.ensemble")
BASE = Path(__file__).resolve().parent
LGBM_MODEL_F = str(BASE / "data" / "lgbm_model.pkl")
LGBM_HISTORY_F = str(BASE / "data" / "lgbm_history.pkl")

# ── Try importing LightGBM ──────────────────────────────────────────────────
_HAS_LGBM = False
try:
    import lightgbm as lgb
    _HAS_LGBM = True
    log.info("  [ENSEMBLE] LightGBM available")
except ImportError:
    log.info("  [ENSEMBLE] LightGBM not installed — ensemble uses NN-only + rolling WR")


# ═══════════════════════ LIGHTGBM WRAPPER ═══════════════════════

class LGBMScorer:
    """
    Lightweight LightGBM binary classifier for trade win prediction.
    Trains on same (features_json, won) data as the NN.
    Retrains every N trades (incremental via init_model).
    """

    PARAMS = {
        "objective": "binary",
        "metric": "binary_logloss",
        "num_leaves": 31,
        "learning_rate": 0.05,
        "n_estimators": 200,
        "max_depth": 6,
        "min_child_samples": 10,
        "reg_alpha": 0.1,
        "reg_lambda": 0.1,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "verbose": -1,
        "n_jobs": 1,          # ARM-friendly
        "force_col_wise": True,
    }

    def __init__(self, feat_dim: int = 20):
        self.feat_dim = feat_dim
        self.model = None
        self.train_count = 0
        self.last_train_ts = 0
        self._feature_names = None

    def predict(self, features: np.ndarray) -> float:
        """Predict win probability. Returns 0.5 if model not trained."""
        if not _HAS_LGBM or self.model is None:
            return 0.5
        try:
            x = features.reshape(1, -1)[:, :self.feat_dim]
            p = self.model.predict(x, num_iteration=self.model.best_iteration or self.model.num_trees())[0]
            return float(np.clip(p, 0.01, 0.99))
        except Exception as e:
            log.debug(f"  [LGBM] predict error: {e}")
            return 0.5

    def train(self, X: np.ndarray, y: np.ndarray, feature_names: list = None):
        """Train or retrain LightGBM on full dataset."""
        if not _HAS_LGBM:
            return
        if X is None or len(X) < 15:
            log.info(f"  [LGBM] Need 15+ samples, have {len(X) if X is not None else 0}")
            return

        try:
            X = X[:, :self.feat_dim]
            y_flat = y.ravel()

            self._feature_names = feature_names or [f"f{i}" for i in range(X.shape[1])]

            # 80/20 split for early stopping
            split = max(10, int(len(X) * 0.8))
            X_tr, y_tr = X[:split], y_flat[:split]
            X_val, y_val = X[split:], y_flat[split:]

            dtrain = lgb.Dataset(X_tr, label=y_tr, feature_name=self._feature_names[:X.shape[1]])
            dval = lgb.Dataset(X_val, label=y_val, reference=dtrain)

            callbacks = [lgb.early_stopping(30, verbose=False), lgb.log_evaluation(0)]

            self.model = lgb.train(
                self.PARAMS,
                dtrain,
                valid_sets=[dval],
                num_boost_round=200,
                init_model=self.model,  # incremental if model exists
                callbacks=callbacks,
            )
            self.train_count = len(X)
            self.last_train_ts = time.time()
            log.info(f"  [LGBM] Trained on {len(X)} samples, trees={self.model.num_trees()}")
            self.save()

        except Exception as e:
            log.error(f"  [LGBM] Train error: {e}")

    def importance(self) -> dict:
        """Return feature importance dict."""
        if not _HAS_LGBM or self.model is None:
            return {}
        try:
            imp = self.model.feature_importance(importance_type="gain")
            names = self._feature_names or [f"f{i}" for i in range(len(imp))]
            total = max(1, imp.sum())
            return {n: round(float(v / total * 100), 1) for n, v in zip(names, imp)}
        except Exception:
            return {}

    def save(self):
        if not _HAS_LGBM or self.model is None:
            return
        try:
            pickle.dump({
                "model": self.model,
                "train_count": self.train_count,
                "feature_names": self._feature_names,
            }, open(LGBM_MODEL_F, "wb"))
        except Exception as e:
            log.debug(f"  [LGBM] Save error: {e}")

    def load(self):
        if not _HAS_LGBM or not os.path.exists(LGBM_MODEL_F):
            return False
        try:
            d = pickle.load(open(LGBM_MODEL_F, "rb"))
            self.model = d["model"]
            self.train_count = d.get("train_count", 0)
            self._feature_names = d.get("feature_names")
            log.info(f"  [LGBM] Loaded model ({self.train_count} samples, {self.model.num_trees()} trees)")
            return True
        except Exception as e:
            log.warning(f"  [LGBM] Load failed: {e}")
            return False


# ═══════════════════════ ROLLING WIN RATE ═══════════════════════

class RollingWR:
    """
    Per-strategy rolling win rate over last N trades.
    Provides an anchoring signal that adapts faster than the NN.
    """

    def __init__(self, window: int = 20):
        self.window = window
        self._data = {}  # strategy_name → deque of bools (win=True)

    def record(self, strategy: str, won: bool):
        if strategy not in self._data:
            self._data[strategy] = deque(maxlen=self.window)
        self._data[strategy].append(won)

    def wr(self, strategy: str) -> float:
        """Return rolling WR as probability [0, 1]. 0.5 if no data."""
        d = self._data.get(strategy)
        if not d or len(d) < 3:
            return 0.5
        return sum(d) / len(d)

    def save(self):
        try:
            pickle.dump({k: list(v) for k, v in self._data.items()}, open(LGBM_HISTORY_F, "wb"))
        except Exception:
            pass

    def load(self):
        if not os.path.exists(LGBM_HISTORY_F):
            return
        try:
            d = pickle.load(open(LGBM_HISTORY_F, "rb"))
            self._data = {k: deque(v, maxlen=self.window) for k, v in d.items()}
        except Exception:
            pass


# ═══════════════════════ ENSEMBLE SCORER ═══════════════════════

class EnsembleScorer:
    """
    Weighted ensemble: LightGBM + NN + Rolling WR.
    Adjusts weights automatically based on recent accuracy.

    Usage from v14_patch.py:
      ensemble = EnsembleScorer(feat_dim=FEAT_DIM)
      ensemble.load()
      # At scoring time:
      prob = ensemble.score(features, nn_prob, strategy_name)
      # After trade closes:
      ensemble.record_outcome(features, won, strategy_name)
    """

    def __init__(self, feat_dim: int = 20):
        self.lgbm = LGBMScorer(feat_dim)
        self.rolling = RollingWR()
        self.feat_dim = feat_dim
        # Adaptive weights — start with defaults, adjust by tracking accuracy
        self.w_lgbm = 0.50 if _HAS_LGBM else 0.0
        self.w_nn   = 0.85 if not _HAS_LGBM else 0.35
        self.w_rwr  = 0.15
        # Track recent predictions for weight adaptation
        self._lgbm_hits = deque(maxlen=50)  # (predicted > 0.5) == actual
        self._nn_hits   = deque(maxlen=50)
        self._retrain_every = 5  # retrain LGBM every N new trades
        self._new_since_train = 0

    def score(self, features: np.ndarray, nn_prob: float, strategy_name: str = "") -> float:
        """
        Compute ensemble probability.
        features: raw feature vector from feats()
        nn_prob: existing NN prediction from nn.predict()
        strategy_name: for rolling WR lookup
        """
        lgbm_p = self.lgbm.predict(features) if _HAS_LGBM else 0.5
        rwr_p  = self.rolling.wr(strategy_name)

        # Weighted blend
        p = (self.w_lgbm * lgbm_p +
             self.w_nn   * nn_prob +
             self.w_rwr  * rwr_p)

        return float(np.clip(p, 0.01, 0.99))

    def record_outcome(self, features: np.ndarray, won: bool, strategy_name: str):
        """Record trade outcome for weight adaptation and LGBM retraining."""
        self.rolling.record(strategy_name, won)
        self._new_since_train += 1

        # Track prediction accuracy for weight adaptation
        if _HAS_LGBM and self.lgbm.model is not None:
            lgbm_pred = self.lgbm.predict(features) > 0.5
            self._lgbm_hits.append(lgbm_pred == won)

    def retrain_if_needed(self, X: np.ndarray, y: np.ndarray, feature_names: list = None):
        """Call periodically to retrain LGBM."""
        if not _HAS_LGBM:
            return
        if self._new_since_train < self._retrain_every:
            return
        self._new_since_train = 0
        self.lgbm.train(X, y, feature_names)
        self._adapt_weights()

    def _adapt_weights(self):
        """Adjust ensemble weights based on recent accuracy."""
        if not _HAS_LGBM or len(self._lgbm_hits) < 10:
            return

        lgbm_acc = sum(self._lgbm_hits) / max(1, len(self._lgbm_hits))
        nn_acc   = sum(self._nn_hits) / max(1, len(self._nn_hits)) if len(self._nn_hits) >= 10 else 0.5

        # Proportional weight allocation (floor at 0.15 for each active model)
        total_acc = lgbm_acc + nn_acc + 0.5  # 0.5 anchor for rolling WR
        self.w_lgbm = max(0.15, lgbm_acc / total_acc)
        self.w_nn   = max(0.15, nn_acc / total_acc)
        self.w_rwr  = max(0.10, 0.5 / total_acc)

        # Renormalize
        total = self.w_lgbm + self.w_nn + self.w_rwr
        self.w_lgbm /= total; self.w_nn /= total; self.w_rwr /= total

        log.info(f"  [ENSEMBLE] Weights: LGBM={self.w_lgbm:.2f} NN={self.w_nn:.2f} RWR={self.w_rwr:.2f} "
                 f"(lgbm_acc={lgbm_acc:.0%} nn_acc={nn_acc:.0%})")

    def load(self):
        self.lgbm.load()
        self.rolling.load()

    def save(self):
        self.lgbm.save()
        self.rolling.save()

    def status_line(self) -> str:
        lgbm_s = f"LGBM:{self.lgbm.train_count}samples" if _HAS_LGBM and self.lgbm.model else "LGBM:off"
        return f"[ENSEMBLE] {lgbm_s} w=[{self.w_lgbm:.2f}/{self.w_nn:.2f}/{self.w_rwr:.2f}]"
