#!/usr/bin/env python3
"""
commodity_strategy_manager.py — FinanceAGI v16
AI-Powered Commodity Strategy Inventor & Manager

Two core capabilities:

1. STRATEGY INVENTOR
   Uses Claude (via Anthropic API) to:
   - Analyse recent trade performance by strategy
   - Invent new commodity strategies with full parameter sets
   - Mutate existing strategies (vary target/SL/hold/session)
   - Prune losing strategies automatically

2. STRATEGY MANAGER
   - Tracks per-strategy win rate, avg P&L, Sharpe, max drawdown
   - Promotes strategies with WR ≥ 60% and promotes to Live
   - Kills strategies with WR < 35% after min_trades
   - Exports strategy performance to DB and JSON
   - Generates daily strategy report via LLM

Usage:
    python3 commodity_strategy_manager.py status          # Live strategy table
    python3 commodity_strategy_manager.py invent          # Invent new strategies
    python3 commodity_strategy_manager.py prune           # Kill losers
    python3 commodity_strategy_manager.py evolve          # Full evolution cycle

Background usage (from agent.py):
    from commodity_strategy_manager import strat_mgr
    await strat_mgr.on_trade_closed(trade)    # Call after every MCX close
    await strat_mgr.run_evolution_cycle()     # Call every N trades
"""

import asyncio, json, logging, math, os, random, sqlite3, sys, time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from collections import defaultdict

log  = logging.getLogger("agi.strat_mgr")
IST  = timezone(timedelta(hours=5, minutes=30))
BASE = Path(__file__).resolve().parent
DB   = str(BASE / "data" / "v10.db")

ENV = {}
ef  = BASE / ".env"
if ef.exists():
    for ln in ef.read_text().splitlines():
        ln = ln.strip()
        if ln and not ln.startswith("#") and "=" in ln:
            k, v = ln.split("=", 1); ENV[k.strip()] = v.strip()

ANTHROPIC_API_KEY = ENV.get("ANTHROPIC_API_KEY", os.environ.get("ANTHROPIC_API_KEY", ""))
CLAUDE_MODEL      = "claude-sonnet-4-20250514"

# ── Thresholds ──────────────────────────────────────────────────────────────
MIN_TRADES_TO_JUDGE  = 8    # Need this many trades before killing/promoting
KILL_WIN_RATE        = 35   # Kill strategy if WR% < this after min_trades
PROMOTE_WIN_RATE     = 60   # Mark strategy as "proven" if WR% ≥ this
MAX_STRATEGIES       = 20   # Max total strategies in catalogue at once
MAX_INVENTED_PER_RUN = 3    # Invent up to 3 new strategies per evolution cycle
INVENT_EVERY_N_TRADES = 15  # Run invention every N closed commodity trades

# ── Asset classes for invention ──────────────────────────────────────────────
ASSET_CLASSES = ["precious_metal", "energy", "base_metal"]
ALL_SYMBOLS   = ["GOLDPETAL", "GOLD", "SILVER", "CRUDEOILM", "NATGASMINI",
                 "COPPER", "ALUMINIUM", "ZINC"]

# ═══════════════════════ DB HELPERS ═══════════════════════════════════════

def _init_db():
    """Ensure commodity strategy tables exist."""
    con = sqlite3.connect(DB)
    con.executescript("""
        CREATE TABLE IF NOT EXISTS commodity_strategies (
            id            TEXT PRIMARY KEY,
            name          TEXT,
            description   TEXT,
            params_json   TEXT,
            status        TEXT DEFAULT 'active',
            source        TEXT DEFAULT 'invented',
            created_at    INTEGER,
            updated_at    INTEGER
        );

        CREATE TABLE IF NOT EXISTS commodity_strat_stats (
            strategy_id   TEXT,
            date          TEXT,
            trades        INTEGER DEFAULT 0,
            wins          INTEGER DEFAULT 0,
            gross_pnl     REAL DEFAULT 0.0,
            net_pnl       REAL DEFAULT 0.0,
            max_dd        REAL DEFAULT 0.0,
            avg_hold_min  REAL DEFAULT 0.0,
            PRIMARY KEY (strategy_id, date)
        );

        CREATE TABLE IF NOT EXISTS commodity_strat_trades (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy_id   TEXT,
            symbol        TEXT,
            direction     TEXT,
            entry_price   REAL,
            exit_price    REAL,
            qty           INTEGER,
            gross_pnl     REAL,
            net_pnl       REAL,
            hold_min      REAL,
            won           INTEGER,
            ts            INTEGER
        );
    """)
    con.commit(); con.close()

def _save_strategy(strat_id: str, name: str, description: str, params: dict, source: str = "invented"):
    con = sqlite3.connect(DB)
    now = int(time.time())
    con.execute("""
        INSERT OR REPLACE INTO commodity_strategies
            (id, name, description, params_json, status, source, created_at, updated_at)
        VALUES (?, ?, ?, ?, 'active', ?, ?, ?)
    """, (strat_id, name, description, json.dumps(params), source, now, now))
    con.commit(); con.close()

def _update_strategy_status(strat_id: str, status: str):
    con = sqlite3.connect(DB)
    con.execute("UPDATE commodity_strategies SET status=?, updated_at=? WHERE id=?",
                (status, int(time.time()), strat_id))
    con.commit(); con.close()

def _record_trade(strat_id, symbol, direction, entry_price, exit_price, qty,
                  gross_pnl, net_pnl, hold_min, won):
    con  = sqlite3.connect(DB)
    date = datetime.now(IST).strftime("%Y-%m-%d")
    con.execute("""
        INSERT INTO commodity_strat_trades
            (strategy_id,symbol,direction,entry_price,exit_price,qty,
             gross_pnl,net_pnl,hold_min,won,ts)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
    """, (strat_id, symbol, direction, entry_price, exit_price, qty,
          gross_pnl, net_pnl, hold_min, won, int(time.time())))
    # Update daily stats
    con.execute("""
        INSERT INTO commodity_strat_stats (strategy_id, date, trades, wins, gross_pnl, net_pnl, avg_hold_min)
        VALUES (?, ?, 1, ?, ?, ?, ?)
        ON CONFLICT(strategy_id, date) DO UPDATE SET
            trades       = trades + 1,
            wins         = wins + excluded.wins,
            gross_pnl    = gross_pnl + excluded.gross_pnl,
            net_pnl      = net_pnl + excluded.net_pnl,
            avg_hold_min = (avg_hold_min * trades + excluded.avg_hold_min) / (trades + 1)
    """, (strat_id, date, int(won), gross_pnl, net_pnl, hold_min))
    con.commit(); con.close()

def _load_all_stats() -> dict:
    """
    Returns {strategy_id: {trades, wins, win_rate, net_pnl, ...}} aggregated.
    """
    con = sqlite3.connect(DB)
    rows = con.execute("""
        SELECT strategy_id,
               SUM(trades) as t,
               SUM(wins)   as w,
               SUM(net_pnl) as pnl,
               AVG(avg_hold_min) as hold
        FROM commodity_strat_stats
        GROUP BY strategy_id
    """).fetchall()
    con.close()
    result = {}
    for r in rows:
        sid, t, w, pnl, hold = r
        result[sid] = {
            "trades":   t or 0,
            "wins":     w or 0,
            "win_rate": round((w / t * 100) if t else 0, 1),
            "net_pnl":  round(pnl or 0, 2),
            "avg_hold": round(hold or 0, 1),
        }
    return result

def _load_all_strategies() -> list:
    con  = sqlite3.connect(DB)
    rows = con.execute(
        "SELECT id,name,description,params_json,status,source FROM commodity_strategies"
    ).fetchall()
    con.close()
    out = []
    for r in rows:
        sid, name, desc, pj, status, source = r
        try: params = json.loads(pj or "{}")
        except Exception:  # BUG-EXCEPT-4 FIX: was bare except
            params = {}
        out.append({"id": sid, "name": name, "description": desc,
                    "params": params, "status": status, "source": source})
    return out

# ═══════════════════════ ANTHROPIC CALLER ══════════════════════════════════

async def _call_claude(system: str, user: str, max_tokens: int = 1500) -> str:
    """Call Claude API. Returns text response."""
    if not ANTHROPIC_API_KEY:
        log.warning("  [STRAT_MGR] No ANTHROPIC_API_KEY — skipping LLM call")
        return ""
    import httpx
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key":         ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type":      "application/json",
            },
            json={
                "model":      CLAUDE_MODEL,
                "max_tokens": max_tokens,
                "system":     system,
                "messages":   [{"role": "user", "content": user}],
            },
        )
    data = r.json()
    if "content" not in data:
        log.error(f"  [STRAT_MGR] API error: {data}")
        return ""
    return "".join(b.get("text", "") for b in data["content"] if b.get("type") == "text")

# ═══════════════════════ STRATEGY INVENTOR ═════════════════════════════════

INVENT_SYSTEM = """
You are FinanceAGI's commodity strategy inventor for MCX (Multi Commodity Exchange, India).
You invent intraday MIS (Margin Intraday Square-off) futures trading strategies.
All strategies must:
  - Be executable within MCX hours: 9 AM - 11:30 PM IST
  - Use only price, volume, OHLC data available intraday (no option chain)
  - Target realistic 0.3%–2.0% intraday moves
  - Respect stop-loss and position sizing discipline

Supported symbols: GOLDPETAL, GOLD, SILVER, CRUDEOILM, NATGASMINI, COPPER, ALUMINIUM, ZINC

Output ONLY a JSON array of strategy objects. No other text.
Each strategy object must have exactly these fields:
{
  "id":              "UNIQUE_SNAKE_CASE_ID",
  "name":            "Short Strategy Name",
  "description":     "One-sentence plain-English description of the entry/exit logic",
  "preferred_assets":["SYMBOL1", "SYMBOL2"],
  "asset_class":     "precious_metal | energy | base_metal | mixed",
  "session":         "both | morning | us",
  "hold_min":        45,
  "target_pct":      0.8,
  "sl_pct":          0.5,
  "target_multiplier":1.0,
  "sl_multiplier":   1.0,
  "score_bonus":     1,
  "min_capital":     5000,
  "signal_type":     "TREND | MEAN_REVERT | BREAKOUT | EVENT | SEASONAL | SPREAD | VOLATILITY",
  "entry_condition": "Plain English: exact entry trigger",
  "exit_condition":  "Plain English: exact exit trigger",
  "risk_note":       "One key risk of this strategy"
}
"""

async def invent_strategies(performance_context: str = "", count: int = 3) -> list:
    """
    Use Claude to invent new commodity strategies.
    Returns list of strategy dicts ready for injection.
    """
    user_msg = f"""
Invent {count} NEW commodity futures trading strategies for MCX India.
Make them diverse across: signal types, asset classes, and sessions.
Avoid duplicating existing strategies.

{f'Recent performance context:{performance_context}' if performance_context else ''}

Existing strategy IDs to avoid duplicating:
TREND_FOLLOW, MEAN_REVERT, BREAKOUT_VOL, US_MOMENTUM, GOLD_HEDGE,
SPREAD_INTER, SEASONAL_NATGAS, INVENTORY_CRUDE, VIX_SPIKE_GOLD,
METAL_COMPLEX, CARRY_ROLL, VOLATILITY_CRUSH

Output a JSON array of {count} strategy objects. Only JSON, no other text.
"""
    log.info(f"  [INVENTOR] Calling Claude to invent {count} strategies...")
    raw = await _call_claude(INVENT_SYSTEM, user_msg, max_tokens=2000)
    if not raw:
        return []

    try:
        # Strip markdown fences if present
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = "\n".join(cleaned.split("\n")[1:])
        if cleaned.endswith("```"):
            cleaned = "\n".join(cleaned.split("\n")[:-1])
        strategies = json.loads(cleaned.strip())
        if not isinstance(strategies, list):
            strategies = [strategies]
        log.info(f"  [INVENTOR] Invented {len(strategies)} strategies")
        return strategies
    except Exception as e:
        log.error(f"  [INVENTOR] JSON parse failed: {e}\nRaw: {raw[:500]}")
        return []

async def mutate_strategy(strategy: dict) -> dict:
    """
    Mutate a strategy's parameters slightly to create a variant.
    Uses lightweight rule-based mutation (no API call) for speed.
    """
    mutant = json.loads(json.dumps(strategy))  # deep copy
    params = mutant.get("params", mutant)

    mutations = [
        ("target_pct",   lambda v: round(v * random.uniform(0.8, 1.3), 2)),
        ("sl_pct",        lambda v: round(v * random.uniform(0.8, 1.2), 2)),
        ("hold_min",      lambda v: int(v * random.uniform(0.7, 1.4))),
        ("score_bonus",   lambda v: max(0, v + random.choice([-1, 0, 0, 1]))),
    ]

    # Apply 1-3 random mutations
    for key, fn in random.sample(mutations, k=random.randint(1, 3)):
        if key in params:
            params[key] = fn(params[key])

    old_id   = mutant.get("id", "STRAT")
    mutant["id"]   = f"{old_id}_MUT_{int(time.time()) % 10000}"
    mutant["name"] = f"{mutant.get('name', old_id)} (Mutant)"
    mutant["source"] = "mutant"
    return mutant

# ═══════════════════════ STRATEGY MANAGER ══════════════════════════════════

class CommodityStrategyManager:
    """
    Central manager for MCX commodity strategies.
    Tracks performance, invents new ones, kills losers.
    """

    def __init__(self):
        _init_db()
        self.stats          = {}   # {strategy_id: {...}}
        self.strategies     = []   # full strategy list from DB
        self.trade_count    = 0    # total closed commodity trades
        self._last_invent_n = 0    # trade count when last invention ran
        self._refresh()

    def _refresh(self):
        """Reload stats and strategies from DB."""
        self.stats      = _load_all_stats()
        self.strategies = _load_all_strategies()

    def get_stats(self, strat_id: str) -> dict:
        return self.stats.get(strat_id, {"trades": 0, "wins": 0, "win_rate": 0, "net_pnl": 0})

    # ── Event hook called by agent on every MCX trade close ─────────────────

    def on_trade_closed_sync(self, trade: dict):
        """
        Record a closed commodity trade.
        trade = {
            strategy, symbol, direction,
            entry_price, exit_price, qty,
            gross_pnl, net_pnl, hold_min, won
        }
        """
        sid = trade.get("strategy", "TREND_FOLLOW")
        _record_trade(
            strat_id=sid,
            symbol=trade.get("symbol", ""),
            direction=trade.get("direction", "BUY"),
            entry_price=trade.get("entry_price", 0),
            exit_price=trade.get("exit_price", 0),
            qty=trade.get("qty", 1),
            gross_pnl=trade.get("gross_pnl", 0),
            net_pnl=trade.get("net_pnl", 0),
            hold_min=trade.get("hold_min", 0),
            won=int(trade.get("won", 0)),
        )
        self.trade_count += 1
        self._refresh()
        log.info(f"  [STRAT_MGR] Trade recorded: {sid} | won={trade.get('won')} | net=₹{trade.get('net_pnl', 0):.0f}")

    async def on_trade_closed(self, trade: dict):
        """Async wrapper for on_trade_closed_sync."""
        self.on_trade_closed_sync(trade)

    # ── Pruning: kill losing strategies ──────────────────────────────────────

    def prune_losers(self) -> list:
        """
        Kill strategies with win_rate < KILL_WIN_RATE after MIN_TRADES_TO_JUDGE.
        Returns list of killed strategy IDs.
        """
        killed = []
        for sid, s in self.stats.items():
            if s["trades"] >= MIN_TRADES_TO_JUDGE and s["win_rate"] < KILL_WIN_RATE:
                _update_strategy_status(sid, "killed")
                killed.append(sid)
                log.info(f"  [STRAT_MGR] Killed strategy {sid} (WR={s['win_rate']:.1f}%, trades={s['trades']})")
        self._refresh()
        return killed

    def promote_proven(self) -> list:
        """
        Mark high-performing strategies as 'proven'.
        Returns list of promoted strategy IDs.
        """
        promoted = []
        for sid, s in self.stats.items():
            if s["trades"] >= MIN_TRADES_TO_JUDGE and s["win_rate"] >= PROMOTE_WIN_RATE:
                _update_strategy_status(sid, "proven")
                promoted.append(sid)
                log.info(f"  [STRAT_MGR] Promoted {sid} to proven (WR={s['win_rate']:.1f}%, P&L=₹{s['net_pnl']:.0f})")
        self._refresh()
        return promoted

    # ── Invention cycle ──────────────────────────────────────────────────────

    async def run_invention_cycle(self, force: bool = False) -> list:
        """
        Invent new strategies if needed.
        Only runs if:
          - force=True, OR
          - trade_count has advanced by INVENT_EVERY_N_TRADES
        """
        if not force:
            trades_since = self.trade_count - self._last_invent_n
            if trades_since < INVENT_EVERY_N_TRADES:
                log.info(f"  [INVENTOR] Skipping — only {trades_since}/{INVENT_EVERY_N_TRADES} trades since last run")
                return []

        active_count = sum(1 for s in self.strategies if s.get("status") in ("active", "proven"))
        if active_count >= MAX_STRATEGIES:
            log.info(f"  [INVENTOR] Max strategies ({MAX_STRATEGIES}) reached — skipping invention")
            return []

        slots = min(MAX_INVENTED_PER_RUN, MAX_STRATEGIES - active_count)

        # Build performance context for the LLM
        perf_lines = []
        for sid, s in sorted(self.stats.items(), key=lambda x: -x[1]["net_pnl"])[:5]:
            perf_lines.append(f"  {sid}: WR={s['win_rate']}% trades={s['trades']} net=₹{s['net_pnl']:.0f}")
        perf_ctx = "\n".join(perf_lines) if perf_lines else "No completed trades yet."

        new_strats = await invent_strategies(performance_context=perf_ctx, count=slots)

        saved = []
        for s in new_strats:
            sid = s.get("id", f"INVENTED_{int(time.time())}")
            # Don't overwrite existing strategies
            existing_ids = {x["id"] for x in self.strategies}
            if sid in existing_ids:
                sid = sid + f"_V{int(time.time()) % 1000}"
            _save_strategy(
                strat_id=sid,
                name=s.get("name", sid),
                description=s.get("description", ""),
                params=s,
                source="invented",
            )
            saved.append(sid)
            log.info(f"  [INVENTOR] Saved new strategy: {sid} — {s.get('name', '')}")

        self._last_invent_n = self.trade_count
        self._refresh()
        return saved

    # ── Full evolution cycle ─────────────────────────────────────────────────

    async def run_evolution_cycle(self) -> dict:
        """
        Full evolution: prune losers → promote winners → invent new → mutate top.
        Returns summary dict.
        """
        log.info("  [STRAT_MGR] === Evolution Cycle Starting ===")
        killed   = self.prune_losers()
        promoted = self.promote_proven()
        invented = await self.run_invention_cycle(force=True)

        # Mutate top performer if we have room
        mutated = []
        active   = sum(1 for s in self.strategies if s.get("status") in ("active", "proven"))
        if active < MAX_STRATEGIES:
            top = sorted(self.stats.items(), key=lambda x: -x[1]["win_rate"])
            if top:
                top_sid  = top[0][0]
                top_strat = next((s for s in self.strategies if s["id"] == top_sid), None)
                if top_strat:
                    mutant = await mutate_strategy(top_strat.get("params", top_strat))
                    _save_strategy(mutant["id"], mutant.get("name", mutant["id"]),
                                   mutant.get("description", "Mutant variant"),
                                   mutant, source="mutant")
                    mutated.append(mutant["id"])
                    log.info(f"  [STRAT_MGR] Created mutant of {top_sid}: {mutant['id']}")

        self._refresh()
        summary = {
            "killed":   killed,
            "promoted": promoted,
            "invented": invented,
            "mutated":  mutated,
            "total_active": sum(1 for s in self.strategies if s["status"] in ("active", "proven")),
        }
        log.info(f"  [STRAT_MGR] Evolution done: {summary}")
        return summary

    # ── Reporting ─────────────────────────────────────────────────────────────

    def status_table(self) -> str:
        """
        Print a formatted strategy performance table.
        """
        self._refresh()
        lines = [
            "\n╔══════════════════════════════════════════════════════════════════════════╗",
            "║        COMMODITY STRATEGY MANAGER — LIVE STATUS                         ║",
            "╚══════════════════════════════════════════════════════════════════════════╝",
            f"  Total strategies: {len(self.strategies)} | "
            f"Active: {sum(1 for s in self.strategies if s['status'] == 'active')} | "
            f"Proven: {sum(1 for s in self.strategies if s['status'] == 'proven')} | "
            f"Killed: {sum(1 for s in self.strategies if s['status'] == 'killed')}",
            "",
            f"  {'ID':<28} {'Status':<8} {'Trades':>6} {'WR%':>6} {'NetP&L':>10} {'Source':<10}",
            "  " + "─" * 72,
        ]
        for s in sorted(self.strategies, key=lambda x: -(self.stats.get(x["id"], {}).get("net_pnl", 0))):
            sid    = s["id"]
            st     = self.stats.get(sid, {})
            status = s.get("status", "active")
            emoji  = {"active": "🔵", "proven": "🟢", "killed": "🔴", "paused": "⚪"}.get(status, "❓")
            line = (
                f"  {emoji} {sid:<26} {status:<8} "
                f"{st.get('trades', 0):>6} "
                f"{st.get('win_rate', 0):>5.1f}% "
                f"₹{st.get('net_pnl', 0):>9,.0f}  "
                f"{s.get('source', 'builtin'):<10}"
            )
            lines.append(line)

        lines.append("")
        lines.append(f"  Trade count (total MCX): {self.trade_count}")
        lines.append(f"  Next invention at trade: {self._last_invent_n + INVENT_EVERY_N_TRADES}")
        return "\n".join(lines)

    async def daily_report(self) -> str:
        """
        Generate a natural-language daily strategy summary via Claude.
        """
        self._refresh()
        perf_data = json.dumps({
            "strategies": {
                sid: stats for sid, stats in self.stats.items()
                if stats["trades"] > 0
            }
        }, indent=2)

        prompt = f"""
You are a quantitative analyst reviewing MCX commodity trading strategy performance.
Here is today's strategy performance data:
{perf_data}

Write a concise (3-5 sentence) daily report:
1. Which strategy performed best and why
2. Which is underperforming and what might be causing it
3. One actionable recommendation for tomorrow
"""
        report = await _call_claude(
            "You are a quantitative trading analyst. Be concise and data-driven.",
            prompt, max_tokens=400
        )
        return report or "No API key configured — daily report unavailable."

    # ── Integration: inject invented strategies into commodity_futures.py ────

    def get_active_strategy_ids(self) -> list:
        """Return list of active+proven strategy IDs for use in scanner."""
        return [s["id"] for s in self.strategies if s["status"] in ("active", "proven")]

    def enrich_opportunity(self, opp: dict) -> dict:
        """
        Merge invented strategy params into a scanner opportunity.
        Invented strategies override target/SL if they have better params.
        """
        sid = opp.get("strategy", "")
        strat = next((s for s in self.strategies if s["id"] == sid), None)
        if not strat:
            return opp
        params = strat.get("params", {})
        if "target_pct" in params:
            opp["target_pct"] = params["target_pct"] * params.get("target_multiplier", 1.0)
        if "sl_pct" in params:
            opp["sl_pct"] = params["sl_pct"] * params.get("sl_multiplier", 1.0)
        if "hold_min" in params:
            opp["max_hold_min"] = params["hold_min"]
        return opp

# ── Singleton ─────────────────────────────────────────────────────────────────
strat_mgr = CommodityStrategyManager()

# ═══════════════════════ SEED BUILT-IN STRATEGIES INTO DB ═════════════════

def seed_builtin_strategies():
    """
    Persist the 12 built-in strategies from STRATEGY_CATALOGUE into DB
    so they appear in reporting and can be tracked from day one.
    """
    try:
        from commodity_futures import STRATEGY_CATALOGUE
    except ImportError:
        log.warning("  [STRAT_MGR] commodity_futures not found — skipping seed")
        return
    existing = {s["id"] for s in _load_all_strategies()}
    for sid, s in STRATEGY_CATALOGUE.items():
        if sid not in existing:
            _save_strategy(sid, s["name"], s["description"], s, source="builtin")
            log.info(f"  [STRAT_MGR] Seeded builtin strategy: {sid}")

# ═══════════════════════ CLI ENTRY POINT ══════════════════════════════════

async def _main():
    seed_builtin_strategies()
    strat_mgr._refresh()

    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"

    if cmd == "status":
        print(strat_mgr.status_table())

    elif cmd == "invent":
        print("Inventing new strategies via Claude...")
        invented = await strat_mgr.run_invention_cycle(force=True)
        if invented:
            print(f"Invented: {invented}")
            strat_mgr._refresh()
            print(strat_mgr.status_table())
        else:
            print("No strategies invented (check ANTHROPIC_API_KEY in .env)")

    elif cmd == "prune":
        killed   = strat_mgr.prune_losers()
        promoted = strat_mgr.promote_proven()
        print(f"Killed: {killed}")
        print(f"Promoted: {promoted}")
        print(strat_mgr.status_table())

    elif cmd == "evolve":
        print("Running full evolution cycle...")
        summary = await strat_mgr.run_evolution_cycle()
        print(f"\nEvolution summary: {json.dumps(summary, indent=2)}")
        print(strat_mgr.status_table())

    elif cmd == "report":
        print("Generating daily LLM report...")
        report = await strat_mgr.daily_report()
        print(f"\n{report}")

    elif cmd == "seed":
        seed_builtin_strategies()
        strat_mgr._refresh()
        print(strat_mgr.status_table())

    else:
        print(f"Unknown command: {cmd}")
        print("Usage: python3 commodity_strategy_manager.py [status|invent|prune|evolve|report|seed]")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s")
    asyncio.run(_main())
