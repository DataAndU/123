#!/usr/bin/env python3
"""
contextual_bandits.py — FinanceAGI v14 Upgrade: LinUCB Strategy Selection

DROP-IN addition. Does NOT modify agent.py.
Replaces tabular Q-learning for strategy selection with LinUCB contextual bandits.

Why LinUCB beats Q-learning here:
  - Strategy selection is a SINGLE-STEP decision (not sequential planning)
  - Contextual bandits converge in 50-200 observations vs 10,000+ for DQN
  - LinUCB uses market context features → picks the right strategy for current regime
  - Upper confidence bound naturally balances explore/exploit

Context features used:
  1. Volatility regime (IV level normalized)
  2. Trend strength (spot change % over last 5 readings)
  3. Volume regime (total volume / mean volume)
  4. India VIX proxy (from IV level)
  5. Time of day (hour normalized)
  6. PCR signal (normalized)
  7. News sentiment
  8. Recent consecutive losses
  9. Day of week (0-4 normalized)
  10. Drawdown level (% from day start)
"""

import json, logging, math, os, pickle
from pathlib import Path
import numpy as np

log = logging.getLogger("agi.bandits")
BASE = Path(__file__).resolve().parent
BANDIT_F = str(BASE / "data" / "linucb.pkl")


class LinUCB:
    """
    LinUCB (disjoint) contextual bandit for strategy arm selection.

    Each arm (strategy) maintains its own linear model:
      A_a: (d x d) matrix = D_a^T D_a + I  (design matrix + regularization)
      b_a: (d x 1) vector = D_a^T c_a       (reward-weighted context sum)

    Predicted reward for arm a with context x:
      theta_a = A_a^{-1} b_a
      p_a = theta_a^T x + alpha * sqrt(x^T A_a^{-1} x)

    alpha controls exploration: higher = more exploration.
    """

    CONTEXT_DIM = 10  # number of context features

    def __init__(self, alpha: float = 1.5):
        self.alpha = alpha
        self.arms = {}  # arm_name → {"A": np.array, "b": np.array, "pulls": int, "rewards": float}
        self.total_pulls = 0

    def _init_arm(self, name: str):
        """Initialize matrices for a new arm."""
        d = self.CONTEXT_DIM
        self.arms[name] = {
            "A": np.eye(d),                    # d x d identity (regularization)
            "b": np.zeros((d, 1)),              # d x 1 zero vector
            "pulls": 0,
            "rewards": 0.0,
        }

    def select(self, context: np.ndarray, arm_names: list, explore: bool = False) -> tuple:
        """
        Select best arm for given context.

        Args:
            context: feature vector (will be padded/trimmed to CONTEXT_DIM)
            arm_names: list of strategy names available
            explore: if True, add extra randomness

        Returns:
            (best_arm_name, index_in_arm_names, predicted_reward)
        """
        if not arm_names:
            return None, 0, 0.0

        x = self._prep_context(context)

        # Ensure all arms exist
        for name in arm_names:
            if name not in self.arms:
                self._init_arm(name)

        best_name = arm_names[0]
        best_idx  = 0
        best_ucb  = -999.0

        for idx, name in enumerate(arm_names):
            arm = self.arms[name]
            A = arm["A"]
            b = arm["b"]

            # theta = A^{-1} b
            try:
                A_inv = np.linalg.solve(A, np.eye(A.shape[0]))
            except np.linalg.LinAlgError:
                A_inv = np.linalg.pinv(A)

            theta = A_inv @ b

            # UCB = theta^T x + alpha * sqrt(x^T A^{-1} x)
            exploit = float((theta.T @ x).item())
            explore_bonus = self.alpha * float(np.sqrt((x.T @ A_inv @ x).item()))

            # Extra randomness during explicit exploration phase
            if explore:
                explore_bonus *= 2.0

            ucb = exploit + explore_bonus

            if ucb > best_ucb:
                best_ucb = ucb
                best_name = name
                best_idx = idx

        return best_name, best_idx, best_ucb

    def update(self, arm_name: str, context: np.ndarray, reward: float):
        """
        Update arm's model after observing reward.

        reward should be normalized: e.g. pnl_pct / 10 + (0.5 if won else -0.3)
        Same scale as existing RL rewards for compatibility.
        """
        if arm_name not in self.arms:
            self._init_arm(arm_name)

        x = self._prep_context(context)
        arm = self.arms[arm_name]

        # A_a += x x^T
        arm["A"] += x @ x.T
        # b_a += reward * x
        arm["b"] += reward * x
        arm["pulls"] += 1
        arm["rewards"] += reward
        self.total_pulls += 1

    def _prep_context(self, context: np.ndarray) -> np.ndarray:
        """Ensure context is (CONTEXT_DIM, 1) column vector."""
        c = np.array(context, dtype=np.float64).flatten()
        if len(c) < self.CONTEXT_DIM:
            c = np.concatenate([c, np.zeros(self.CONTEXT_DIM - len(c))])
        c = c[:self.CONTEXT_DIM]
        # Clip extreme values for numerical stability
        c = np.clip(c, -5.0, 5.0)
        return c.reshape(-1, 1)

    def arm_stats(self) -> dict:
        """Return per-arm stats for logging."""
        return {
            name: {
                "pulls": arm["pulls"],
                "avg_reward": round(arm["rewards"] / max(1, arm["pulls"]), 3),
            }
            for name, arm in self.arms.items()
        }

    def decay_alpha(self, min_alpha: float = 0.3):
        """Gradually reduce exploration as we gather more data."""
        if self.total_pulls > 100:
            self.alpha = max(min_alpha, 1.5 * (0.995 ** (self.total_pulls - 100)))

    def save(self):
        try:
            data = {
                "alpha": self.alpha,
                "total_pulls": self.total_pulls,
                "arms": {},
            }
            for name, arm in self.arms.items():
                data["arms"][name] = {
                    "A": arm["A"].tolist(),
                    "b": arm["b"].tolist(),
                    "pulls": arm["pulls"],
                    "rewards": arm["rewards"],
                }
            pickle.dump(data, open(BANDIT_F, "wb"))
        except Exception as e:
            log.debug(f"  [BANDIT] Save error: {e}")

    def load(self):
        if not os.path.exists(BANDIT_F):
            return False
        try:
            data = pickle.load(open(BANDIT_F, "rb"))
            self.alpha = data.get("alpha", 1.5)
            self.total_pulls = data.get("total_pulls", 0)
            for name, arm_data in data.get("arms", {}).items():
                self.arms[name] = {
                    "A": np.array(arm_data["A"]),
                    "b": np.array(arm_data["b"]),
                    "pulls": arm_data["pulls"],
                    "rewards": arm_data["rewards"],
                }
            log.info(f"  [BANDIT] Loaded: {len(self.arms)} arms, {self.total_pulls} pulls, alpha={self.alpha:.3f}")
            return True
        except Exception as e:
            log.warning(f"  [BANDIT] Load failed: {e}")
            return False

    def status_line(self) -> str:
        top = sorted(self.arms.items(), key=lambda x: x[1]["rewards"] / max(1, x[1]["pulls"]), reverse=True)[:3]
        top_str = " | ".join(f"{n}:{a['pulls']}T {a['rewards']/max(1,a['pulls']):+.2f}R" for n, a in top)
        return f"[BANDIT] {self.total_pulls} pulls alpha={self.alpha:.2f} | {top_str}"


# ═══════════════════════ CONTEXT BUILDER ═══════════════════════

def build_context(
    spots: list,
    last_iv: float,
    pcr_val: float,
    news_score: float,
    losses: int,
    start_cash: float,
    cur_cash: float,
    hour: float,
    weekday: int,
    vol_total: float = 0,
    vol_mean: float = 1,
) -> np.ndarray:
    """
    Build context vector for LinUCB from current market state.
    All features normalized to roughly [-2, 2] range.
    """
    # 1. IV regime (normalized: 12=low → -1, 20=normal → 0, 30=high → +1)
    iv_regime = (last_iv - 20) / 10.0

    # 2. Trend strength (% change over recent spots)
    if len(spots) >= 3:
        trend = (spots[-1] - spots[-3]) / max(1, spots[-3]) * 100
    elif len(spots) >= 2:
        trend = (spots[-1] - spots[-2]) / max(1, spots[-2]) * 100
    else:
        trend = 0.0
    trend = np.clip(trend / 0.5, -2, 2)  # normalize: 0.5% = ±1

    # 3. Volume regime
    vol_ratio = min(3, vol_total / max(1, vol_mean)) - 1.0  # center at 0

    # 4. VIX proxy (same as IV but independent)
    vix_proxy = np.clip((last_iv - 15) / 8.0, -1, 2)

    # 5. Time of day (9=open, 15=close, center at 12)
    time_norm = (hour - 12) / 3.0

    # 6. PCR signal
    pcr_norm = np.clip((pcr_val - 1.0) / 0.3, -2, 2)

    # 7. News sentiment (already -1 to +1)
    news_norm = news_score

    # 8. Loss streak (0=none, 1=one, capped at 2)
    loss_norm = min(2.0, losses / 2.0)

    # 9. Day of week (0=Mon → -1, 4=Fri → +1)
    dow_norm = (weekday - 2) / 2.0

    # 10. Drawdown level (0=none, 1=5%, 2=10%+)
    dd = 0.0
    if start_cash > 0:
        dd = (start_cash - cur_cash) / start_cash * 100
    dd_norm = min(2.0, dd / 5.0)

    return np.array([
        iv_regime, trend, vol_ratio, vix_proxy, time_norm,
        pcr_norm, news_norm, loss_norm, dow_norm, dd_norm
    ], dtype=np.float64)


# ═══════════════════════ SINGLETON ═══════════════════════

bandit = LinUCB(alpha=1.5)
