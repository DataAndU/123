"""
Apply all modifications to agent.py in one pass.
Run: python3 patch_agent.py
"""
import re

with open("agent.py", "r") as f:
    src = f.read()

original = src

# ── 1. Replace Qwen imports with local LLM ───────────────────────────────────
src = src.replace(
    'from qwen_engine import qwen, qwen_commentator, qwen_regime',
    'from llm_engine import trade_commentary as _llm_commentary, regime_classify as _llm_regime, daily_param_tune as _llm_tune'
)
src = src.replace(
    'from qwen_engine import qwen_tasks',
    '# qwen_tasks replaced by llm_engine'
)
src = src.replace(
    'from qwen_engine import',
    '# from qwen_engine import'
)

# ── 2. Wire llm_engine into startup (load model once) ───────────────────────
old_imports_end = "log = logging.getLogger(\"agi\")"
src = src.replace(
    old_imports_end,
    old_imports_end + "\n\n# Load local LLM once at startup\ntry:\n    import llm_engine as _llm_eng\n    import threading\n    threading.Thread(target=_llm_eng.load_model, daemon=True).start()\nexcept Exception as _le:\n    log.warning(f'LLM engine not loaded: {_le}')\n"
)

# ── 3. Disable daily drawdown halt (only halt at zero capital) ────────────────
# Remove daily DD check
src = re.sub(
    r'DAILY_DD_LIMIT\s*=\s*[\d.]+\s*#[^\n]*\n',
    'DAILY_DD_LIMIT    = 1.0   # Disabled — only halt at zero capital\n',
    src
)
# Remove weekly DD halt
src = re.sub(
    r'WEEKLY_DD_LIMIT\s*=\s*[\d.]+\s*#[^\n]*\n',
    'WEEKLY_DD_LIMIT   = 1.0   # Disabled — only halt at zero capital\n',
    src
)

# ── 4. Lower all min_capital to 300 (tradeable with ₹400) ────────────────────
src = re.sub(r'"min_capital":\s*\d+', '"min_capital": 300', src)
src = re.sub(r'min_capital\s*=\s*\d+', 'min_capital=300', src)

# ── 5. Lower free_cash threshold from 3000 to 100 ────────────────────────────
src = src.replace('free_cash < 3000', 'free_cash < 100')
src = src.replace('< Rs3000', '< Rs100')

# ── 6. Remove CAPITAL floor of 10000 — use actual cash ───────────────────────
src = re.sub(
    r'cash = max\(cash, float\(ENV\.get\("CAPITAL", "10000"\)\)\)',
    'cash = max(cash, 1.0)  # No minimum floor — use actual available margin',
    src
)

# ── 7. Paper trading guard — always check PAPER flag before placing ──────────
# Already handled in place_order via PAPER flag — ensure it's consistent
src = src.replace(
    'PAPER = ENV.get("PAPER_TRADING", "true").lower() == "true"',
    'PAPER = ENV.get("PAPER_TRADING", "true").lower() == "true"\nlog.info(f"Trading mode: {\'PAPER\' if PAPER else \'LIVE\'}")'
)

# ── 8. Strategy kill: raise min_trades threshold ─────────────────────────────
src = re.sub(r'INVENTOR_MIN_TRADES\s*=\s*\d+', 'INVENTOR_MIN_TRADES  = 15', src)

# ── 9. trading_economics graceful skip ───────────────────────────────────────
src = src.replace(
    'from trading_economics import (',
    'try:\n  from trading_economics import ('
)
# close the try block after the import group
src = src.replace(
    '    te_status_line, probe_plan as te_probe_plan,\n)',
    '    te_status_line, probe_plan as te_probe_plan,\n)\nexcept Exception as _te_e:\n  log_placeholder = __import__("logging").getLogger("agi")\n  log_placeholder.warning(f"trading_economics disabled: {_te_e}")\n  te_calendar=te_markets=te_forecasts=india_bonds=te_news=india_macro=lambda *a,**k: None\n  compute_te_alpha=te_position_multiplier=lambda *a,**k: 0\n  te_refresh_all=te_status_line=te_probe_plan=lambda *a,**k: None'
)

# ── 10. Disable commodity/MCX by default in code (controlled by env) ─────────
# Already controlled by COMMODITY_ENABLED env — no code change needed

# ── 11. Add SELECTED_EXPIRY auto-populate at startup ────────────────────────
auto_expiry = '''
async def _auto_set_expiry(broker):
    """Auto-populate nearest weekly expiry if not set."""
    try:
        exps = await broker.get_expiries("NSE_INDEX|Nifty 50")
        if exps:
            import sqlite3
            conn = sqlite3.connect(DB)
            conn.execute("INSERT OR REPLACE INTO settings VALUES ('SELECTED_EXPIRY', ?)", (exps[0],))
            conn.commit(); conn.close()
            log.info(f"Auto-set SELECTED_EXPIRY={exps[0]}")
    except Exception as e:
        log.warning(f"Auto expiry set failed: {e}")

'''
# Insert before main()
src = src.replace(
    '\nasync def main():',
    auto_expiry + '\nasync def main():'
)

# ── 12. Call auto_expiry in main ─────────────────────────────────────────────
src = src.replace(
    'broker = UpstoxBroker()',
    'broker = UpstoxBroker()\n    await _auto_set_expiry(broker)'
)

changed = src != original
with open("agent.py", "w") as f:
    f.write(src)

print(f"Patch applied. Changes made: {changed}")
