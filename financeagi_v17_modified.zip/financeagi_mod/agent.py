#!/usr/bin/env python3
"""
FINANCEAGI v17.1 — Evolved Agent
Multi-Expiry FNO Options + FNO Stock Options + MCX Commodity Futures + Telegram

New in v12.0:
  - Per-segment capital allocation (ALLOC_OPTIONS / ALLOC_EQUITY / ALLOC_COMMODITY)
  - Commodity segment added as standalone asset mode
  - All options strategies: spreads, iron condor, straddle, strangle, butterfly,
    calendar spreads, ratio spreads — selected by capital and AI scoring
  - All expiries scanned including calendar spreads across expiries
  - Strategies with <70% win rate after min_trades are killed (raised from 35%)
  - Faster learning: retrain every trade (not every 5), double NN epochs, more RL
  - System invents new variables each generation via feature mutation
  - Daily LLM update via Qwen2.5:3b (see daily_update.py)
  - Evolution every 10 trades (halved from 20)

Usage:
  python3 agent.py          # Run trading agent
  python3 agent.py stats    # View performance
  python3 agent.py reset    # Wipe memory
"""

import asyncio,json,logging,math,os,pickle,random,re,sqlite3,sys,copy,hashlib,time
from datetime import datetime,timezone,timedelta,time as dtime
from pathlib import Path
from collections import defaultdict
import numpy as np
import httpx
from multileg import find_best_multileg, place_multileg_order, exit_multileg, multileg_charges, fetch_leg_ltps
from equity_intraday import scan_stocks, buy_equity, exit_equity, eq_charges, EQ_STRATEGIES
try:
  from trading_economics import (
    te_calendar, india_macro, te_markets, te_forecasts, india_bonds, te_news,
    compute_te_alpha, te_position_multiplier, refresh_all as te_refresh_all,
    te_status_line, probe_plan as te_probe_plan,
)
except Exception as _te_e:
  log_placeholder = __import__("logging").getLogger("agi")
  log_placeholder.warning(f"trading_economics disabled: {_te_e}")
  te_calendar=te_markets=te_forecasts=india_bonds=te_news=india_macro=lambda *a,**k: None
  compute_te_alpha=te_position_multiplier=lambda *a,**k: 0
  te_refresh_all=te_status_line=te_probe_plan=lambda *a,**k: None
from self_improve import (
    event_cal, reconciler, sig_attr,
    get_augmented_training_data, hyperparameter_search,
    run_weekly_hyperparameter_search, run_nightly_reconciliation,
    run_signal_attribution_logger,
)
from web_search import (
    searcher, market_brief, auto_searcher,
    run_search_loop, get_search_bias, get_morning_insight,
)
from alpha_signals import (
    pcr, ivp_signal, gex, ofi, vwap, vol_spike, fii_dii, gift_nifty,
    port_greeks, seg_limits, slippage, reentry, pta,
    compute_alpha_score, should_skip_correlated, get_weighted_training_data,
)
try:
    from strategy_inventor import inventor as commodity_inventor
    _INVENTOR_AVAILABLE = True
except Exception as _inv_e:
    log_placeholder = __import__("logging").getLogger("agi")
    log_placeholder.warning(f"  strategy_inventor not loaded: {_inv_e}")
    commodity_inventor = None
    _INVENTOR_AVAILABLE = False

# ── v17: Strategy Inventors ───────────────────────────────────────────────────
try:
    from options_strategy_inventor import options_inventor
    _OPT_INVENTOR = True
except Exception as _oi_e:
    __import__("logging").getLogger("agi").warning(f"  options_strategy_inventor not loaded: {_oi_e}")
    options_inventor = None
    _OPT_INVENTOR = False

try:
    from equity_strategy_inventor import equity_inventor
    _EQ_INVENTOR = True
except Exception as _ei_e:
    __import__("logging").getLogger("agi").warning(f"  equity_strategy_inventor not loaded: {_ei_e}")
    equity_inventor = None
    _EQ_INVENTOR = False

try:
    from strategy_master import master as strategy_master, run_strategy_master_loop
    _MASTER = True
except Exception as _m_e:
    __import__("logging").getLogger("agi").warning(f"  strategy_master not loaded: {_m_e}")
    strategy_master = None
    run_strategy_master_loop = None
    _MASTER = False

# ── Qwen 2.5 Engine ───────────────────────────────────────────────────────────
try:
    # from qwen_engine import (
        qwen, qwen_tasks, qwen_commentator, qwen_regime,
        patch_daily_update_ask_ollama, patch_web_search_summarise,
    )
    _QWEN_AVAILABLE = True
except Exception as _qwen_e:
    __import__("logging").getLogger("agi").warning(f"  qwen_engine not loaded: {_qwen_e}")
    qwen = qwen_tasks = qwen_commentator = qwen_regime = None
    patch_daily_update_ask_ollama = patch_web_search_summarise = lambda: None
    _QWEN_AVAILABLE = False

BASE = Path(__file__).resolve().parent
IST = timezone(timedelta(hours=5, minutes=30))
DB = str(BASE / "data" / "v10.db")
NN_F      = str(BASE / "data" / "nn.pkl")
NN_EQ_F   = str(BASE / "data" / "nn_equity.pkl")
NN_COM_F  = str(BASE / "data" / "nn_commodity.pkl")
RL_F      = str(BASE / "data" / "rl.pkl")
ST_F      = str(BASE / "data" / "strats.json")

for d in ["data", "logs"]:
    (BASE / d).mkdir(parents=True, exist_ok=True)

# Load .env
ENV = {}
ef = BASE / ".env"
if ef.exists():
    for ln in ef.read_text().splitlines():
        ln = ln.strip()
        if ln and not ln.startswith("#") and "=" in ln:
            k, v = ln.split("=", 1)
            ENV[k.strip()] = v.strip()
            os.environ.setdefault(k.strip(), v.strip())

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s", datefmt="%H:%M:%S",
    handlers=[logging.FileHandler(BASE / "logs" / "agent.log")])
import sys as _sys
if _sys.stdout.isatty():
    logging.getLogger().addHandler(logging.StreamHandler())
log = logging.getLogger("agi")

# Load local LLM once at startup
try:
    import llm_engine as _llm_eng
    import threading
    threading.Thread(target=_llm_eng.load_model, daemon=True).start()
except Exception as _le:
    log.warning(f'LLM engine not loaded: {_le}')


# ═══════════════════════ CONFIG ═══════════════════════

VERSION = "17.1"

# ── Self-improvement constants ────────────────────────────────────
WEEKLY_DD_LIMIT   = 1.0   # Disabled — only halt at zero capital
TOKEN_CHECK_MIN    = 30    # Check token health every 30 minutes

C = {
    "target": 6.0, "sl": 5.0, "max_hold": 15, "max_trades": 25,
    "cool_n": 3, "cool_min": 5, "min_prem": 1.0, "max_dd": 15.0,
    "explore": 10, "nn_thr": 0.50,
    "kelly": 0.20, "min_bet": 0.25, "max_bet": 0.80,
    "trail_on": 2.0, "trail_dist": 1.5, "partial_pct": 50, "partial_at": 3.0,
    "rl_eps": 0.20, "rl_a": 0.15, "rl_g": 0.95,
    # Faster evolution: every 10 trades. Stricter kill: 70% WR required after min trades
    "evo_every": 10, "kill_wr": 70, "kill_n": 10, "max_strats": 16,
    # Multi-expiry: scan all available expiries for calendar spreads + multi-expiry
    "max_expiries": 4,
    # FNO scanning: max stocks to scan per cycle
    "fno_scan_batch": 3,
    # Underlyings: indices always scanned
    "underlyings": ["NSE_INDEX|Nifty 50", "NSE_INDEX|Nifty Bank"],
    # Faster NN retraining: every trade
    "nn_retrain_every": 1,
    "nn_epochs_quick": 30,
    "nn_epochs_full": 500,
}

# ═══════════════════════ TELEGRAM ═══════════════════════

TG_TOKEN = ENV.get("TG_BOT_TOKEN", ENV.get("TELEGRAM_TOKEN", ""))
TG_CHAT  = ENV.get("TG_CHAT_ID", ENV.get("TELEGRAM_CHAT_ID", ""))

async def tg(msg: str):
    """Send a Telegram message. Silent no-op if token/chat not configured."""
    if not TG_TOKEN or not TG_CHAT:
        return
    try:
        async with httpx.AsyncClient(timeout=6) as c:
            await c.post(
                f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
                json={"chat_id": TG_CHAT, "text": msg, "parse_mode": "HTML"},
            )
    except Exception:
        pass

# ═══════════════════════ FNO STOCK LIST ═══════════════════════
# Top FNO stocks with their NSE_EQ instrument keys
# The option chain API accepts NSE_EQ keys for stock options

FNO_STOCKS = {
    # Large Cap - High Liquidity
    "RELIANCE":   "NSE_EQ|INE002A01018",
    "TCS":        "NSE_EQ|INE467B01029",
    "HDFCBANK":   "NSE_EQ|INE040A01034",
    "INFY":       "NSE_EQ|INE009A01021",
    "ICICIBANK":  "NSE_EQ|INE090A01021",
    "SBIN":       "NSE_EQ|INE062A01020",
    "BHARTIARTL": "NSE_EQ|INE397D01024",
    "ITC":        "NSE_EQ|INE154A01025",
    "KOTAKBANK":  "NSE_EQ|INE237A01028",
    "LT":         "NSE_EQ|INE018A01030",
    # Mid Cap - Good Liquidity
    "TATAMOTORS": "NSE_EQ|INE155A01022",
    "MARUTI":     "NSE_EQ|INE585B01010",
    "BAJFINANCE": "NSE_EQ|INE296A01024",
    "AXISBANK":   "NSE_EQ|INE238A01034",
    "WIPRO":      "NSE_EQ|INE075A01022",
    "HCLTECH":    "NSE_EQ|INE860A01027",
    "ADANIENT":   "NSE_EQ|INE423A01024",
    "TATASTEEL":  "NSE_EQ|INE081A01020",
    "POWERGRID":  "NSE_EQ|INE752E01010",
    "NTPC":       "NSE_EQ|INE733E01010",
    # Volatile / Affordable lots
    "BHEL":       "NSE_EQ|INE257A01026",
    "PNB":        "NSE_EQ|INE160A01022",
    "BANKBARODA": "NSE_EQ|INE028A01039",
    "IDFCFIRSTB": "NSE_EQ|INE092T01019",
    "IRCTC":      "NSE_EQ|INE335Y01020",
}

# Rotation index for FNO stocks (to avoid scanning all at once)
_fno_idx = 0

def get_fno_batch():
    """Get next batch of FNO stocks to scan (rotates through list)."""
    global _fno_idx
    items = list(FNO_STOCKS.items())
    batch_size = C["fno_scan_batch"]
    batch = []
    for i in range(batch_size):
        idx = (_fno_idx + i) % len(items)
        batch.append(items[idx])
    _fno_idx = (_fno_idx + batch_size) % len(items)
    return batch


# ═══════════════════════ BROKERAGE CHARGES ═══════════════════════

class Charges:
    """
    Upstox Options Intraday charges — April 1, 2026 STT hike aware.
    Pre-April 1:  STT 0.0625% sell side
    Post-April 1: STT 0.15%   sell side (2.4x increase)
    ₹20/order brokerage + STT + GST + exchange + SEBI + stamp.
    """
    _STT_CHANGE = datetime(2026, 4, 1, tzinfo=timezone(timedelta(hours=5, minutes=30))).date()

    @classmethod
    def _stt_rate(cls):
        from datetime import datetime as _dt, timezone as _tz, timedelta as _td
        today = _dt.now(_tz(_td(hours=5, minutes=30))).date()
        return 0.0015 if today >= cls._STT_CHANGE else 0.000625

    @classmethod
    def calculate(cls, buy_price, sell_price, qty):
        buy_val = buy_price * qty; sell_val = sell_price * qty; turnover = buy_val + sell_val
        brokerage = 40  # ₹20 x 2 orders
        stt = sell_val * cls._stt_rate()   # 0.15% post April 1, 0.0625% before
        exchange = turnover * 0.000495     # NSE FO
        sebi = turnover * 0.000001; ipft = turnover * 0.000001
        stamp = buy_val * 0.00003          # Buy side
        gst = (brokerage + exchange + sebi + ipft) * 0.18
        total = brokerage + stt + exchange + gst + sebi + stamp + ipft
        gross = (sell_price - buy_price) * qty
        return {"total_charges": round(total, 2), "net_pnl": round(gross - total, 2),
                "breakeven_pct": round(total / max(1, buy_val) * 100, 3),
                "gross_pnl": round(gross, 2), "brokerage": brokerage, "stt": round(stt, 2),
                "exchange": round(exchange, 2), "gst": round(gst, 2),
                "stt_rate_pct": round(cls._stt_rate() * 100, 4)}

    @classmethod
    def breakeven_pct(cls, buy_price, qty):
        buy_val = buy_price * qty
        stt_r = cls._stt_rate()
        total = 40 + buy_val * stt_r + buy_val * 2 * 0.000495 + buy_val * 0.00003 + buy_val * 2 * 0.000002
        total += (40 + buy_val * 2 * 0.000495 + buy_val * 2 * 0.000002) * 0.18
        return round(total / max(1, buy_val) * 100, 2)

    @classmethod
    def is_profitable_trade(cls, buy_price, target_pct, qty):
        sell_price = buy_price * (1 + target_pct / 100)
        r = cls.calculate(buy_price, sell_price, qty)
        return r["net_pnl"] > 0, r

charges = Charges()

# ═══════════════════════ NEWS SENTIMENT ═══════════════════════

NEWS_API_KEY = ENV.get("NEWS_API_KEY", "")

class NewsSentiment:
    BULL = {"rally","surge","gain","rise","bull","breakout","high","record","boost","recover","optimism","upgrade","buy","outperform","positive","growth","profit","beat","strong","soar","jump","advance"}
    BEAR = {"fall","drop","crash","bear","decline","loss","low","sell","downgrade","weak","fear","risk","negative","cut","slow","debt","miss","warning","recession","slump","plunge","tumble"}

    def __init__(self):
        self.headlines = []; self.score = 0.0; self.last_fetch = 0; self.stock_scores = {}

    async def refresh(self):
        if not NEWS_API_KEY: return
        if time.time() - self.last_fetch < 1800: return  # 30min — NewsAPI free plan limit
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                r1 = await client.get("https://newsapi.org/v2/top-headlines",
                    params={"country":"in","category":"business","pageSize":30,"apiKey":NEWS_API_KEY},
                    headers={"User-Agent":"Mozilla/5.0"})
                r2 = await client.get("https://newsapi.org/v2/everything",
                    params={"q":"NSE OR NIFTY OR Sensex OR stock market India","language":"en","sortBy":"publishedAt","pageSize":20,"apiKey":NEWS_API_KEY},
                    headers={"User-Agent":"Mozilla/5.0"})
            articles = r1.json().get("articles",[]) + r2.json().get("articles",[])
            self.headlines = [{"title":a.get("title",""),"desc":a.get("description",""),"source":a.get("source",{}).get("name","")}
                              for a in articles if a.get("title") and a.get("title") != "[Removed]"]
            self._score()
            self.last_fetch = time.time()
            log.info(f"  NEWS: {len(self.headlines)} headlines, sentiment={self.score:+.2f}")
        except Exception as e: log.error(f"  News error: {e}")

    def _score(self):
        if not self.headlines: self.score = 0; return
        tb = tr = 0
        # BUG-R fix: also compute per-stock scores while scoring global sentiment
        stock_bull = {}; stock_bear = {}
        for h in self.headlines:
            text = (h["title"]+" "+h["desc"]).lower()
            words = set(re.findall(r"[a-z]+", text))
            tb += len(words & self.BULL); tr += len(words & self.BEAR)
            # Per-stock: check if known FNO stock name appears in headline
            for sym in FNO_STOCKS:
                if sym.lower() in text:
                    stock_bull[sym] = stock_bull.get(sym, 0) + len(words & self.BULL)
                    stock_bear[sym] = stock_bear.get(sym, 0) + len(words & self.BEAR)
        self.score = max(-1, min(1, (tb - tr) / max(1, tb + tr)))
        # Normalise per-stock scores to [-1, 1]
        for sym in set(list(stock_bull.keys()) + list(stock_bear.keys())):
            b = stock_bull.get(sym, 0); r_v = stock_bear.get(sym, 0)
            self.stock_scores[sym] = round(max(-1, min(1, (b - r_v) / max(1, b + r_v))), 3)

    def bias_for(self, underlying="", option_type="CE"):
        # BUG-R fix: use per-stock score when available, fall back to global score
        sym = underlying.upper().split()[-1] if underlying else ""
        b = self.stock_scores.get(sym, self.score)
        mod = b * 0.15 if option_type == "CE" else -b * 0.15 if option_type == "PE" else 0
        return mod

news = NewsSentiment()

# ═══════════════════════ DATABASE ═══════════════════════

def _db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def init_db():
    c = _db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS trades(id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT,symbol TEXT,strike REAL,otype TEXT,asset TEXT,underlying TEXT,expiry TEXT,strategy TEXT,
        entry_price REAL,entry_delta REAL,entry_gamma REAL,entry_theta REAL,entry_iv REAL,
        entry_volume INTEGER,entry_oi INTEGER,entry_otm REAL,entry_spot REAL,
        entry_hour INTEGER,lot INTEGER,cost REAL,capital_pct REAL,
        exit_price REAL,exit_reason TEXT,hold_sec INTEGER,
        pnl REAL,pnl_pct REAL,won INTEGER,nn_prob REAL,rl_state TEXT,rl_action INTEGER,
        features_json TEXT,strat_gen INTEGER,peak_pnl REAL,partial INTEGER DEFAULT 0,
        charges REAL,net_pnl REAL);
    CREATE TABLE IF NOT EXISTS auth(id INTEGER PRIMARY KEY,provider TEXT,token TEXT);
    CREATE TABLE IF NOT EXISTS spots(ts TEXT,spot REAL,iv REAL);
    CREATE TABLE IF NOT EXISTS config(key TEXT PRIMARY KEY,val TEXT);
    """)
    c.commit()
    for r in c.execute("SELECT key,val FROM config").fetchall():
        if r["key"] in C:
            try: C[r["key"]] = type(C[r["key"]])(json.loads(r["val"]))
            except Exception as _cfg_e: log.warning(f"  Config key '{r['key']}' bad value in DB: {_cfg_e}")
    c.close()

def save_cfg(k, v):
    c = _db(); c.execute("INSERT OR REPLACE INTO config VALUES(?,?)", (k, json.dumps(v))); c.commit(); c.close()
    C[k] = v

def log_trade(t):
    clean = {k: v for k, v in t.items() if not k.startswith("_")}
    c = _db(); cols = ",".join(clean.keys()); vals = ",".join(f":{k}" for k in clean.keys())
    try:
        c.execute(f"INSERT INTO trades({cols}) VALUES({vals})", clean)
        c.commit()
    except Exception as e:
        log.error(f"  DB save error: {e}")
    c.close()

def stats():
    c = _db()
    r = c.execute("SELECT COUNT(*)t,COALESCE(SUM(won),0)w,COALESCE(SUM(pnl),0)p FROM trades").fetchone()
    aw = c.execute("SELECT AVG(pnl_pct)a FROM trades WHERE won=1").fetchone()["a"] or 5
    al = c.execute("SELECT AVG(pnl_pct)a FROM trades WHERE won=0").fetchone()["a"] or -5
    strats = c.execute("SELECT strategy,COUNT(*)t,SUM(won)w,SUM(pnl)p,AVG(pnl_pct)a FROM trades GROUP BY strategy").fetchall()
    c.close()
    return {"total":r["t"],"wins":int(r["w"]),"wr":round(r["w"]/max(1,r["t"])*100,1),"pnl":round(r["p"],2),
            "aw":aw,"al":al,"strats":{s["strategy"]:{"n":s["t"],"w":s["w"] or 0,"p":round(s["p"] or 0,2)} for s in strats}}

def get_td():
    c = _db(); rows = c.execute("SELECT features_json,won FROM trades WHERE features_json IS NOT NULL").fetchall(); c.close()
    if not rows: return None, None
    # Pad or trim every row to FEAT_DIM — old DB rows may have different lengths
    feats, won = [], []
    for r in rows:
        try:
            f = json.loads(r["features_json"])
            if not isinstance(f, list) or len(f) == 0: continue
            if len(f) < FEAT_DIM: f = f + [0.0] * (FEAT_DIM - len(f))
            feats.append(f[:FEAT_DIM]); won.append([r["won"]])
        except Exception: continue
    if not feats: return None, None
    return np.array(feats, dtype=np.float64), np.array(won, dtype=np.float64)

# ═══════════════════════ BROKER ═══════════════════════

PAPER = ENV.get("PAPER_TRADING", "true").lower() == "true"
log.info(f"Trading mode: {'PAPER' if PAPER else 'LIVE'}")
LIVE  = ENV.get("TRADING_ENABLED", "true").lower() == "true"
CAPITAL_OVERRIDE = float(ENV.get("CAPITAL", "0"))
ASSET_MODE = ENV.get("ASSET_MODE", os.environ.get("ASSET_MODE", "both")).lower()

# ═══════════════════════ COMMODITY FLAG ═══════════════════════
# NOTE: Must be defined AFTER ASSET_MODE (uses it in the condition below)

COMMODITY_ENABLED = (
    ENV.get("COMMODITY_ENABLED", "false").lower() == "true"
    or ASSET_MODE in ("commodity", "all")
)

if COMMODITY_ENABLED:
    try:
        from commodity_futures import (
            scan_commodities, buy_commodity, exit_commodity,
            mcx_is_open, mcx_force_exit_time, mcx_best_session,
            mcx_entry_allowed,   # BUG-F fix: separate entry guard from monitoring guard
            mcx_inst,
        )
        log.info("  MCX commodity futures module loaded")
    except ImportError as _e:
        log.warning(f"  commodity_futures.py not found — MCX disabled ({_e})")
        COMMODITY_ENABLED = False

# MCX Energy Options — CRUDEOILM + NATGASMINI options (separate module)
COMMODITY_OPTIONS_ENABLED = (
    COMMODITY_ENABLED
    and ENV.get("COMMODITY_OPTIONS_ENABLED", "false").lower() == "true"
)
if COMMODITY_OPTIONS_ENABLED:
    try:
        from commodity_options import (
            scan_energy_options,
            enter_option_strategy,
            exit_option_strategy,
            monitor_option_position,
            mcx_opt_inst,
            mcx_opt_is_open,
            mcx_opt_entry_allowed,
            mcx_opt_force_exit,
            us_session_active,
        )
        log.info("  MCX energy options module loaded (CRUDEOILM + NATGASMINI)")
    except ImportError as _e:
        log.warning(f"  commodity_options.py not found — energy options disabled ({_e})")
        COMMODITY_OPTIONS_ENABLED = False

# Per-segment capital allocations (0 = use full capital / share equally)
ALLOC_OPTIONS   = float(ENV.get("ALLOC_OPTIONS",   os.environ.get("ALLOC_OPTIONS",   "0")))
ALLOC_EQUITY    = float(ENV.get("ALLOC_EQUITY",    os.environ.get("ALLOC_EQUITY",    "0")))
ALLOC_COMMODITY = float(ENV.get("ALLOC_COMMODITY", os.environ.get("ALLOC_COMMODITY", "0")))

def segment_capital(segment: str, total_cash: float) -> float:
    """Return capital budget for a given segment based on allocations.

    Bug #9 fix: count only segments that are *actually* enabled at runtime.
    Previously the function always counted commodity even when its import failed
    and COMMODITY_ENABLED was flipped to False, causing options and equity each
    to receive only 1/3 of capital instead of 1/2.
    """
    alloc_map = {"options": ALLOC_OPTIONS, "equity": ALLOC_EQUITY, "commodity": ALLOC_COMMODITY}
    alloc = alloc_map.get(segment, 0)
    if alloc > 0:
        return min(alloc, total_cash)
    # No explicit allocation: single-segment modes get full capital
    if ASSET_MODE in ("options", "equity", "commodity"):
        return total_cash
    # Multi-segment: divide equally among segments that are *actually running*
    active = []
    if ASSET_MODE in ("both", "all"):
        active = ["options", "equity"]
    if ASSET_MODE == "all" and COMMODITY_ENABLED:   # only count if import succeeded
        active.append("commodity")
    n = max(1, len(active))
    return total_cash / n

API = "https://api.upstox.com"
HFT = "https://api-hft.upstox.com"

class Broker:
    def __init__(self):
        self.token = ENV.get("UPSTOX_ACCESS_TOKEN", "")
        # BUG-O fix: shared async client for connection pooling; recreated on token reload
        self._client: httpx.AsyncClient | None = None
        try:
            c = _db(); r = c.execute("SELECT token FROM auth WHERE provider='upstox' ORDER BY id DESC LIMIT 1").fetchone()
            if r and r[0]: self.token = r[0]
            c.close()
        except Exception as e:
            log.warning(f"  Broker.__init__: could not load token from DB: {e}")

    def _get_client(self) -> httpx.AsyncClient:
        # BUG-CRASH-1 FIX: lazily close stale client when token has changed
        if getattr(self, '_token_changed', False):
            if self._client and not self._client.is_closed:
                # Schedule close in background — safe inside running loop
                asyncio.ensure_future(self._client.aclose())
            self._client = None
            self._token_changed = False
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=12, limits=httpx.Limits(max_connections=10))
        return self._client

    @property
    def ok(self): return bool(self.token)
    @property
    def _h(self): return {"Accept": "application/json", "Authorization": f"Bearer {self.token}",
                          "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36"}

    def reload_token(self):
        # BUG-CRASH-1 FIX: never call run_until_complete inside a running loop.
        # Instead, just mark client for lazy recreation on next _get_client() call.
        try:
            c = _db(); r = c.execute("SELECT token FROM auth WHERE provider='upstox' ORDER BY id DESC LIMIT 1").fetchone()
            if r and r[0] and r[0] != self.token:
                self.token = r[0]
                log.info(f"  Broker: token refreshed (len={len(self.token)})")
                # Mark client stale — it will be closed+recreated lazily in _get_client()
                self._token_changed = True
            c.close()
        except Exception as e:
            log.warning(f"  Broker.reload_token: DB error: {e}")

    async def _get(self, p):
        client = self._get_client()
        resp = await client.get(f"{API}{p}", headers=self._h)
        return resp.json()

    async def _post(self, p, b):
        client = self._get_client()
        resp = await client.post(f"{HFT}{p}", headers={**self._h, "Content-Type": "application/json"}, json=b)
        return resp.json()

    async def cash(self):
        if CAPITAL_OVERRIDE > 0 and PAPER:
            return CAPITAL_OVERRIDE
        try:
            return (await self._get("/v2/user/get-funds-and-margin")).get("data", {}).get("equity", {}).get("available_margin", 0)
        except Exception as e:
            log.warning(f"  Broker.cash error: {e}")
            return 0

    async def positions(self):
        try:
            return [p for p in ((await self._get("/v2/portfolio/short-term-positions")).get("data", []) or []) if p.get("quantity", 0) > 0]
        except Exception as e:
            log.warning(f"  Broker.positions error: {e}")
            return []

    async def last_fill(self):
        try:
            for o in reversed((await self._get("/v2/order/retrieve-all")).get("data", []) or []):
                if o.get("status") == "complete" and o.get("transaction_type") == "BUY":
                    return o.get("average_price", 0), o.get("instrument_token", "")
        except Exception as e:
            log.warning(f"  Broker.last_fill: could not fetch order history: {e}")
        return 0, ""

    async def expiries(self, ul):
        """Get all available expiries for an underlying, sorted ascending."""
        try:
            d = await self._get(f"/v2/option/contract?instrument_key={ul}")
            exps = sorted(set(c.get("expiry", "") for c in d.get("data", []) if c.get("expiry")))
            return exps
        except Exception as e:
            log.error(f"  Expiry fetch failed for {ul}: {e}")
            return []

    async def lot(self, ul, exp):
        try:
            cs = (await self._get(f"/v2/option/contract?instrument_key={ul}&expiry_date={exp}")).get("data", [])
            return cs[0].get("lot_size", 50) if cs else 50
        except Exception as e:
            log.warning(f"  Broker.lot error for {ul} {exp}: {e}")
            return 50

    async def chain(self, ul, exp):
        return (await self._get(f"/v2/option/chain?instrument_key={ul}&expiry_date={exp}")).get("data", [])

    async def scan(self, ul, exp, mp, ul_name=""):
        """Scan option chain for tradeable options within max premium."""
        raw = await self.chain(ul, exp); res = []
        for item in raw:
            sp = item.get("underlying_spot_price", 0); st = item.get("strike_price", 0)
            for side, ot in [("call_options", "CE"), ("put_options", "PE")]:
                o = item.get(side, {}); mk = o.get("market_data", {}); gk = o.get("option_greeks", {})
                ltp, vol = mk.get("ltp", 0), mk.get("volume", 0)
                if 0 < ltp <= mp and vol > 0:
                    res.append({
                        "key": o.get("instrument_key", ""), "strike": st, "type": ot, "ltp": ltp,
                        "volume": vol, "oi": mk.get("oi", 0), "delta": gk.get("delta", 0),
                        "gamma": gk.get("gamma", 0), "theta": gk.get("theta", 0), "iv": gk.get("iv", 0),
                        "spot": sp, "otm_pct": round(abs(st - sp) / max(1, sp) * 100, 2),
                        "asset": "option", "underlying": ul_name or ul,
                        "expiry": exp, "ul_key": ul,
                    })
        return res

    async def scan_multi_expiry(self, ul, max_premium, ul_name=""):
        """Scan up to max_expiries expiries for an underlying.

        Bug #11 fix: fetch lot size per expiry rather than once for scan_exps[0].
        Weekly and monthly contracts can have different lot sizes; using the wrong
        one causes incorrect cost estimates and Kelly sizing for non-first expiries.
        Returns (all_options, nearest_lot_size) where nearest_lot_size is the
        lot size of the closest expiry (used as fallback by callers).
        """
        all_options = []
        today = datetime.now(IST).strftime("%Y-%m-%d")
        exps = await self.expiries(ul)
        if not exps:
            return [], 50

        future_exps = [e for e in exps if e >= today]
        if not future_exps:
            return [], 50

        scan_exps = future_exps[:C["max_expiries"]]
        nearest_lot = 50  # will be set on first successful fetch

        for idx, exp in enumerate(scan_exps):
            try:
                # Bug #11: fetch lot size for THIS expiry, not always scan_exps[0]
                exp_lot = await self.lot(ul, exp)
                if idx == 0:
                    nearest_lot = exp_lot

                opts = await self.scan(ul, exp, max_premium, ul_name)
                exp_date = datetime.strptime(exp, "%Y-%m-%d").replace(tzinfo=IST)  # DTE-FIX
                dte = (exp_date - datetime.now(IST).replace(hour=0, minute=0, second=0, microsecond=0)).days
                for o in opts:
                    o["dte"] = dte
                    o["lot_size"] = exp_lot   # correct lot size for this expiry
                all_options.extend(opts)
                await asyncio.sleep(0.3)
            except Exception as e:
                log.error(f"  Scan {ul_name} exp={exp}: {e}")

        return all_options, nearest_lot

    async def buy(self, key, qty):
        if PAPER: return {"status": "success", "data": {"order_ids": [f"P-{int(time.time())}"]}}
        if not LIVE: return {"status": "error"}
        return await self._post("/v3/order/place", {"quantity": qty, "product": "I", "validity": "DAY", "price": 0,
            "instrument_token": key, "order_type": "MARKET", "transaction_type": "BUY",
            "disclosed_quantity": 0, "trigger_price": 0, "is_amo": False, "slice": True})

    async def sell(self, key, qty):
        if PAPER: return {"status": "success", "data": {"order_ids": [f"P-{int(time.time())}"]}}
        if not LIVE: return {"status": "error"}
        return await self._post("/v3/order/place", {"quantity": qty, "product": "I", "validity": "DAY", "price": 0,
            "instrument_token": key, "order_type": "MARKET", "transaction_type": "SELL",
            "disclosed_quantity": 0, "trigger_price": 0, "is_amo": False, "slice": True})

broker = Broker()

# ═══════════════════════ NEURAL NET ═══════════════════════

FN = [
    "delta", "gamma", "theta", "iv", "log_vol", "log_oi", "otm", "spot_mv",
    "h_sin", "h_cos", "prem", "cost", "dte_norm",
    # Extended features for invented-variable discovery
    "iv_rank",       # IV relative to recent range (0-1)
    "vol_oi_ratio",  # Volume/OI — momentum proxy
    "gamma_dollar",  # Gamma × spot (dollar gamma)
    "theta_pct",     # Theta as % of premium per day
    "moneyness",     # strike/spot ratio
    "log_prem",      # log(premium) -- skew detection
    "spread_ratio",  # Bug4 fix: gamma*iv proxy for bid-ask spread (was dead 0.0 placeholder)
]
FEAT_DIM = len(FN)

# Extra invented feature names (appended when pool.evolve generates new genes)
_INVENTED_FEATS: list = []  # populated by genetic engine

def feats(opt, cash, lot):
    """Build feature vector — includes base + extended + invented features."""
    d  = abs(opt.get("delta", 0)); g = abs(opt.get("gamma", 0)) * 10000; th = abs(opt.get("theta", 0))
    iv = opt.get("iv", 20); v = max(1, opt.get("volume", 1)); oi = max(1, opt.get("oi", 1))
    otm = opt.get("otm_pct", 3); sp = opt.get("spot", 0); ltp = opt.get("ltp", 1)
    h  = datetime.now(IST).hour + datetime.now(IST).minute / 60
    # Bug #5 fix: spot_mv = % distance of current price from nearest round level
    # Use dynamic round-number levels appropriate to the price magnitude
    if sp > 0:
        magnitude = 10 ** (len(str(int(sp))) - 2)        # e.g. sp=22000 → 100, sp=500 → 10
        magnitude = max(1, magnitude)
        sm = ((sp - round(sp / magnitude) * magnitude) / max(1, sp)) * 100
    else:
        sm = 0.0
    dte = opt.get("dte", 0)
    dte_norm      = min(dte / 30.0, 1.0)
    iv_rank       = min(iv / 50.0, 1.0)                          # normalised IV rank
    vol_oi_ratio  = math.log(v / max(1, oi) + 1)                 # volume/OI momentum
    gamma_dollar  = abs(opt.get("gamma", 0)) * sp if sp else 0   # dollar gamma
    theta_pct     = th / max(0.01, ltp) * 100                    # theta decay %
    moneyness     = opt.get("strike", sp) / max(1, sp)           # strike/spot
    log_prem      = math.log(ltp + 1)                             # log premium

    base = np.array([
        d, g, th, iv, math.log(v + 1), math.log(oi + 1), otm, sm,
        math.sin(2 * math.pi * h / 24), math.cos(2 * math.pi * h / 24),
        ltp / 10, (ltp * lot) / max(1, cash), dte_norm,
        iv_rank, vol_oi_ratio, gamma_dollar / 1000, theta_pct, moneyness - 1.0,
        log_prem, min(abs(opt.get("gamma", 0)) * iv / max(0.01, ltp), 1.0)  # spread_ratio: gamma*iv/prem
    ], dtype=np.float64)[:FEAT_DIM]

    # Pad/trim to FEAT_DIM (safety for in-flight model reloads)
    if len(base) < FEAT_DIM:
        base = np.concatenate([base, np.zeros(FEAT_DIM - len(base))])
    return base[:FEAT_DIM]

# ═══════════════════════ NEURAL NET ═══════════════════════

class NN:
    def __init__(self, dims=None):
        dims = dims or (FEAT_DIM, 32, 16, 1)
        self.dims = list(dims); self.nl = len(dims) - 1
        self.W = [np.random.randn(dims[i], dims[i+1]) * np.sqrt(2/dims[i]) for i in range(self.nl)]
        self.b = [np.zeros((1, dims[i+1])) for i in range(self.nl)]
        self.mW = [np.zeros_like(w) for w in self.W]; self.mb = [np.zeros_like(b) for b in self.b]
        self.vW = [np.zeros_like(w) for w in self.W]; self.vb = [np.zeros_like(b) for b in self.b]
        self.lr = 0.001; self.b1 = 0.9; self.b2 = 0.999; self.step = 0
        self.mu = np.zeros(dims[0]); self.var = np.ones(dims[0]); self.cnt = 0

    def _n(self, X): return (X - self.mu) / (np.sqrt(self.var) + 1e-8)
    def _us(self, X):
        for x in X: self.cnt += 1; d = x - self.mu; self.mu += d / self.cnt; self.var += (d * (x - self.mu) - self.var) / self.cnt

    def predict(self, f):
        a = self._n(f.reshape(1, -1))
        for i in range(self.nl):
            z = a @ self.W[i] + self.b[i]
            a = np.maximum(0, z) if i < self.nl - 1 else 1 / (1 + np.exp(-np.clip(z, -500, 500)))
        return float(a[0, 0])

    def train(self, X, y, ep=100):
        self._us(X); Xn = self._n(X); m = len(X); loss = 0
        for _ in range(ep):
            a = Xn; acts = [Xn]; zs = []
            for i in range(self.nl):
                z = a @ self.W[i] + self.b[i]; zs.append(z)
                a = np.maximum(0, z) if i < self.nl - 1 else 1 / (1 + np.exp(-np.clip(z, -500, 500))); acts.append(a)
            p = np.clip(acts[-1], 1e-7, 1 - 1e-7); loss = -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))
            d = p - y
            for i in range(self.nl - 1, -1, -1):
                dW = acts[i].T @ d / m; db = d.mean(0, keepdims=True); self.step += 1
                self.mW[i] = self.b1 * self.mW[i] + (1 - self.b1) * dW; self.mb[i] = self.b1 * self.mb[i] + (1 - self.b1) * db
                self.vW[i] = self.b2 * self.vW[i] + (1 - self.b2) * dW ** 2; self.vb[i] = self.b2 * self.vb[i] + (1 - self.b2) * db ** 2
                mh = self.mW[i] / (1 - self.b1 ** self.step); bh = self.mb[i] / (1 - self.b1 ** self.step)
                vh = self.vW[i] / (1 - self.b2 ** self.step); vbh = self.vb[i] / (1 - self.b2 ** self.step)
                self.W[i] -= self.lr * mh / (np.sqrt(vh) + 1e-8); self.b[i] -= self.lr * bh / (np.sqrt(vbh) + 1e-8)
                if i > 0: d = (d @ self.W[i].T) * (zs[i - 1] > 0).astype(float)
        return loss

    def train1(self, f, o):
        """
        Online single-sample update — fast path with 30 gradient steps.
        Bug #6 fix: call self.train() ONCE with ep=30 instead of 30 separate
        calls each of which increments self.step for every layer.  Previously
        30 outer-loop iterations × n_layers inner increments ballooned
        self.step by 30× per online update, corrupting Adam bias-correction.
        BUG-H fix: do NOT call self._us() here — self.train() already calls it,
        so the old double-call was counting this sample twice in running stats,
        biasing normalization toward the most recent trades.
        """
        X = f.reshape(1, -1); y = np.array([[o]])
        self.train(X, y, ep=30)  # single call; _us() is called inside train()

    def importance(self):
        if self.cnt == 0: return {}
        imp = np.abs(self.W[0]).sum(axis=1); imp = imp / imp.sum() * 100
        return dict(zip(FN, [round(float(v), 1) for v in imp]))

    def save(self): pickle.dump({k: getattr(self, k) for k in ["W", "b", "mW", "mb", "vW", "vb", "mu", "var", "cnt", "step", "dims"]}, open(NN_F, "wb"))
    def load(self):
        if not os.path.exists(NN_F): return False
        try:
            d = pickle.load(open(NN_F, "rb"))
            saved_dims = d.get("dims", [0])
            expected_dims = list(self.dims)  # (FEAT_DIM, 32, 16, 1) by default
            # Bug #13 fix: compare the FULL dims tuple, not only dims[0].
            # If hidden layers changed (e.g. 32→64) the saved W matrices have wrong
            # shapes; loading them and then calling train() causes a numpy broadcast
            # error.  Also validate the actual weight shapes as a safety net.
            if saved_dims != expected_dims:
                log.info(f"  NN: Reinitializing — saved dims {saved_dims} != expected {expected_dims}")
                return False
            # Validate that W shapes are consistent with saved dims before applying
            saved_W = d.get("W", [])
            for i, w in enumerate(saved_W):
                exp_shape = (expected_dims[i], expected_dims[i + 1])
                if w.shape != exp_shape:
                    log.warning(f"  NN: W[{i}] shape {w.shape} != expected {exp_shape} — reinitializing")
                    return False
            for k, v in d.items():
                setattr(self, k, v)
            self.nl = len(self.dims) - 1
            return True
        except Exception as e:
            log.warning(f"  NN load failed ({e}) — starting fresh")
            return False

nn         = NN()   # Options NN
nn_equity  = NN()   # Separate NN for equity intraday — different dynamics
nn_commodity = NN() # Separate NN for MCX futures — different dynamics

# Save/load helpers for per-asset NNs
def _save_asset_nns():
    try:
        import pickle as _pk
        _pk.dump({k: getattr(nn_equity,   k) for k in ["W","b","mW","mb","vW","vb","mu","var","cnt","step","dims"]}, open(NN_EQ_F,  "wb"))
        _pk.dump({k: getattr(nn_commodity,k) for k in ["W","b","mW","mb","vW","vb","mu","var","cnt","step","dims"]}, open(NN_COM_F,"wb"))
    except Exception as _e:
        log.debug(f"  Asset NN save error: {_e}")

def _load_asset_nns():
    import pickle as _pk
    for _nn, _path in [(nn_equity, NN_EQ_F), (nn_commodity, NN_COM_F)]:
        if os.path.exists(_path):
            try:
                d = _pk.load(open(_path,"rb"))
                if d.get("dims") == list(_nn.dims):
                    for k,v in d.items(): setattr(_nn, k, v)
            except Exception: pass

# ═══════════════════════ RL ═══════════════════════

def market_regime(spots: list, iv: float) -> str:
    """
    Classify current market regime for strategy selection.
    Returns: TRENDING_UP / TRENDING_DOWN / RANGING / VOLATILE
    """
    if len(spots) < 5:
        return "RANGING"
    recent  = spots[-5:]
    chg_pct = (recent[-1] - recent[0]) / max(1, recent[0]) * 100
    # Volatility: std dev of last 5 readings as % of mean
    mean    = sum(recent) / len(recent)
    std     = (sum((x - mean)**2 for x in recent) / len(recent)) ** 0.5
    vol_pct = std / max(1, mean) * 100

    if iv > 22:
        return "VOLATILE"
    if chg_pct > 0.5 and vol_pct < 0.3:
        return "TRENDING_UP"
    if chg_pct < -0.5 and vol_pct < 0.3:
        return "TRENDING_DOWN"
    return "RANGING"

def regime_strategy_filter(regime: str, opt_type: str) -> bool:
    """Return True if this option type suits the current regime."""
    if regime == "TRENDING_UP"   and opt_type == "PE": return False
    if regime == "TRENDING_DOWN" and opt_type == "CE": return False
    return True

def mstate(spots, iv, hour):
    vr = "C" if iv < 15 else "N" if iv < 25 else "V"
    tr = "U" if len(spots) >= 2 and (spots[-1] - spots[0]) / max(1, spots[0]) * 100 > 0.15 else "D" if len(spots) >= 2 and (spots[-1] - spots[0]) / max(1, spots[0]) * 100 < -0.15 else "F"
    tb = "O" if hour < 10 else "M" if hour < 14 else "C"
    return f"{vr}{tr}{tb}"

class RL:
    def __init__(self):
        self.Q = defaultdict(lambda: np.zeros(20)); self.N = defaultdict(lambda: np.zeros(20))
        self.ep = 0; self.r = 0
    def act(self, s, n, explore=False):
        # Faster decay: eps decays faster so system exploits sooner
        eps = max(0.03, C["rl_eps"] * 0.99 ** self.ep)
        if explore or random.random() < eps: return random.randint(0, n - 1)
        return int(np.argmax(self.Q[s][:n]))
    def update(self, s, a, r, s2, n):
        best = np.max(self.Q[s2][:n]) if n > 0 else 0
        # Higher learning rate C["rl_a"]=0.15 already set in config
        self.Q[s][a] += C["rl_a"] * (r + C["rl_g"] * best - self.Q[s][a])
        self.N[s][a] += 1; self.ep += 1; self.r += r
    def save(self): pickle.dump({"Q": dict(self.Q), "N": dict(self.N), "ep": self.ep, "r": self.r}, open(RL_F, "wb"))
    def load(self):
        if not os.path.exists(RL_F): return False
        try:
            d = pickle.load(open(RL_F, "rb")); self.Q = defaultdict(lambda: np.zeros(20), d["Q"])
            self.N = defaultdict(lambda: np.zeros(20), d.get("N", {})); self.ep = d.get("ep", 0); self.r = d.get("r", 0); return True
        except Exception:  # BUG-EXCEPT-4 FIX: was bare except
            return False

rl = RL()

# ═══════════════════════ STRATEGY DNA ═══════════════════════

GT = {"name": "", "asset": "option", "option_type": "CE", "delta_min": 0.10, "delta_max": 0.40,
    "otm_min": 1.0, "otm_max": 5.0, "iv_pref": "ANY", "vol_min": 1000000,
    "target_pct": 5.0, "stoploss_pct": 7.0, "max_hold_min": 15,
    "hour_start": 9, "hour_end": 15, "trend_filter": "NONE", "momentum": "NONE",
    "use_trailing": True, "use_partial": True,
    "prefer_expiry": "nearest",       # "nearest","next","any","calendar"
    "prefer_underlying": "any",        # "index","stock","any"
    "strategy_type": "single",         # "single","spread","iron_condor","straddle",
                                       # "strangle","butterfly","calendar","ratio"
    "min_capital": 300,               # min capital needed for this strategy
    "generation": 0, "parent": "seed", "alive": True, "testing": False,
    "trades": 0, "wins": 0, "total_pnl": 0.0,
    # Invented variable slot — genetic engine can discover new scoring weights
    "invented_weight": 0.0, "invented_feat": "none"}

class Strat:
    def __init__(self, g=None):
        self.g = copy.deepcopy(GT)
        if g: self.g.update(g)
        if not self.g["name"]:
            pfx = {"CE": "Bull", "PE": "Bear", "BOTH": "Dual"}[self.g["option_type"]]
            mid = "Aggro" if self.g["delta_max"] > 0.3 else "Far" if self.g["delta_min"] < 0.12 else "Mid"
            sfx = "Scalp" if self.g["target_pct"] < 4 else "Swing" if self.g["target_pct"] > 8 else "Trade"
            self.g["name"] = f"{pfx}{mid}{sfx}_{hashlib.md5(json.dumps(self.g,sort_keys=True).encode()).hexdigest()[:4]}"

    @property
    def wr(self): return round(self.g["wins"] / max(1, self.g["trades"]) * 100, 1)

    def matches(self, opt):
        g = self.g
        if g["option_type"] != "BOTH" and opt.get("type") != g["option_type"]: return False
        d = abs(opt.get("delta", 0))
        if d < g["delta_min"] or d > g["delta_max"]: return False
        if opt.get("otm_pct", 0) < g["otm_min"] or opt.get("otm_pct", 0) > g["otm_max"]: return False
        if opt.get("volume", 0) < g["vol_min"]: return False
        h = datetime.now(IST).hour
        if h < g["hour_start"] or h > g["hour_end"]: return False
        if g["iv_pref"] == "LOW" and opt.get("iv", 0) > 25: return False
        if g["iv_pref"] == "HIGH" and opt.get("iv", 0) < 20: return False
        dte = opt.get("dte", 0)
        if g.get("prefer_expiry") == "nearest" and dte > 7: return False
        if g.get("prefer_expiry") == "next" and dte < 3: return False
        if g.get("prefer_underlying") == "index" and "NSE_INDEX" not in opt.get("ul_key", ""): return False
        if g.get("prefer_underlying") == "stock" and "NSE_EQ" not in opt.get("ul_key", ""): return False
        # BUG-E fix: evaluate trend_filter using option delta sign as a proxy for market direction.
        # delta>0 (CE) implies bullish flow; delta<0 (PE) implies bearish flow.
        # AGAINST means we only trade options that fade the current intraday trend.
        tf = g.get("trend_filter", "NONE")
        if tf == "AGAINST":
            raw_delta = opt.get("delta", 0)
            opt_type  = opt.get("type", "CE")
            # Bearish trend (negative delta / PE): fade by buying CE (against the move)
            # Bullish trend (positive delta / CE): fade by buying PE (against the move)
            if opt_type == "CE" and raw_delta > 0: return False   # don't buy CE in bullish trend
            if opt_type == "PE" and raw_delta < 0: return False   # don't buy PE in bearish trend
        return True

    def mutate(self):
        ch = copy.deepcopy(self.g)
        ch.update({"generation": ch["generation"] + 1, "parent": ch["name"], "testing": True, "alive": True,
                   "trades": 0, "wins": 0, "total_pnl": 0, "name": ""})
        mutations = ["delta_min", "delta_max", "otm_min", "otm_max", "target_pct", "stoploss_pct",
                     "max_hold_min", "option_type", "iv_pref", "use_trailing", "prefer_expiry",
                     "prefer_underlying", "strategy_type", "invented_weight", "invented_feat"]
        for m in random.sample(mutations, random.randint(2, 5)):
            if m == "delta_min":           ch[m] = round(max(0.05, ch[m] + random.uniform(-0.05, 0.05)), 3)
            elif m == "delta_max":         ch[m] = round(min(0.5,  ch[m] + random.uniform(-0.05, 0.05)), 3)
            elif m == "otm_min":           ch[m] = round(max(0.2,  ch[m] + random.uniform(-0.5, 0.5)), 1)
            elif m == "otm_max":           ch[m] = round(min(10,   ch[m] + random.uniform(-1, 1)), 1)
            elif m == "target_pct":        ch[m] = round(max(2, min(20, ch[m] + random.uniform(-2, 2))), 1)
            elif m == "stoploss_pct":      ch[m] = round(max(2, min(20, ch[m] + random.uniform(-2, 2))), 1)
            elif m == "max_hold_min":      ch[m] = max(3, min(60, ch[m] + random.randint(-5, 5)))
            elif m == "option_type":       ch[m] = random.choice(["CE", "PE", "BOTH"])
            elif m == "iv_pref":           ch[m] = random.choice(["LOW", "HIGH", "ANY"])
            elif m == "use_trailing":      ch[m] = not ch[m]
            elif m == "prefer_expiry":     ch[m] = random.choice(["nearest", "next", "any", "calendar"])
            elif m == "prefer_underlying": ch[m] = random.choice(["index", "stock", "any"])
            elif m == "strategy_type":     ch[m] = random.choice(["single","spread","iron_condor",
                                                                   "straddle","strangle","butterfly",
                                                                   "calendar","ratio"])
            elif m == "invented_weight":   ch[m] = round(random.uniform(-0.3, 0.3), 3)
            elif m == "invented_feat":     ch[m] = random.choice(FN)
        if ch["delta_min"] > ch["delta_max"]: ch["delta_min"], ch["delta_max"] = ch["delta_max"], ch["delta_min"]
        if ch["otm_min"]   > ch["otm_max"]:   ch["otm_min"],   ch["otm_max"]   = ch["otm_max"],   ch["otm_min"]
        return Strat(ch)

    @staticmethod
    def breed(p1, p2):
        ch = {}
        for k in GT:
            if k in ("name", "generation", "parent", "trades", "wins", "total_pnl", "alive", "testing"): continue
            ch[k] = p1.g.get(k) if random.random() < 0.5 else p2.g.get(k)
        ch.update({"generation": max(p1.g["generation"], p2.g["generation"]) + 1,
                   "parent": f"{p1.g['name']}x{p2.g['name']}", "testing": True, "alive": True,
                   "trades": 0, "wins": 0, "total_pnl": 0})
        return Strat(ch)

class Pool:
    def __init__(self):
        self.s = []; self.dead = []
    def add(self, st):
        # Bug #7 fix: enforce name uniqueness — hash collisions between mutated strategies
        # would let two strategies share the same name, making kill() only remove one.
        if any(s.g["name"] == st.g["name"] for s in self.s):
            log.warning(f"  Pool.add: duplicate name '{st.g['name']}' — skipping")
            return
        if len(self.s) < C["max_strats"]: self.s.append(st); log.info(f"  + {st.g['name']} gen{st.g['generation']}")
    def kill(self, name):
        # Bug #7 fix: remove ALL strategies with this name (handles duplicates defensively)
        before = len(self.s)
        dead_ones = [s for s in self.s if s.g["name"] == name]
        self.s = [s for s in self.s if s.g["name"] != name]
        for s in dead_ones: self.dead.append(s.g)
        if len(self.s) < before: log.info(f"  x Killed {name} ({before - len(self.s)} removed)")
    def alive(self): return [s for s in self.s if s.g["alive"]]
    def live(self): return [s for s in self.alive() if not s.g["testing"]]
    def best(self, n=2): return sorted([s for s in self.live() if s.g["trades"] >= 5], key=lambda s: s.wr, reverse=True)[:n]
    def worst(self): return [s for s in self.live() if s.g["trades"] >= C["kill_n"] and s.wr < C["kill_wr"]]
    def update(self, name, won, pp):
        for s in self.s:
            if s.g["name"] == name:
                s.g["trades"] += 1
                if won: s.g["wins"] += 1
                s.g["total_pnl"] += pp
                if s.g["testing"] and s.g["trades"] >= 5:
                    if s.wr >= 50: s.g["testing"] = False; log.info(f"  ^ Promoted {name} {s.wr}%WR")
                    else: self.kill(name)
                # Kill live strategies below 70% WR after kill_n trades
                elif not s.g["testing"] and s.g["trades"] >= C["kill_n"] and s.wr < C["kill_wr"]:
                    log.info(f"  ✗ Killed under-performer {name} {s.wr}%WR < {C['kill_wr']}%")
                    self.kill(name)
                return
    def pick(self, opts):
        cands = self.live() or self.alive()
        random.shuffle(cands)
        for s in cands:
            m = [o for o in opts if s.matches(o)]
            if m: return s, m
        return None, []
    def save(self): json.dump({"alive": [s.g for s in self.s], "dead": self.dead}, open(ST_F, "w"), indent=1)
    def load(self):
        if not os.path.exists(ST_F): return False
        try:
            d = json.load(open(ST_F)); self.s = [Strat(g) for g in d.get("alive", [])]; self.dead = d.get("dead", []); return True
        except Exception:  # BUG-EXCEPT-4 FIX: was bare except
            return False

pool = Pool()

def seed():
    for g in [
        # ── Single-leg scalpers (low capital) ──
        {"name": "MomentumCE",  "option_type": "CE", "delta_min": 0.15, "delta_max": 0.35, "target_pct": 5,  "stoploss_pct": 7,  "vol_min": 5000000,  "use_trailing": True,  "prefer_expiry": "nearest", "prefer_underlying": "index",  "strategy_type": "single"},
        {"name": "MomentumPE",  "option_type": "PE", "delta_min": 0.15, "delta_max": 0.35, "target_pct": 5,  "stoploss_pct": 7,  "vol_min": 5000000,  "use_trailing": True,  "prefer_expiry": "nearest", "prefer_underlying": "index",  "strategy_type": "single"},
        {"name": "QuickScalp",  "option_type": "BOTH","delta_min": 0.20,"delta_max": 0.45, "otm_min": 0.5, "otm_max": 3, "target_pct": 3, "stoploss_pct": 4,  "max_hold_min": 8,   "vol_min": 10000000, "use_trailing": False, "use_partial": False, "prefer_expiry": "nearest", "strategy_type": "single"},
        # ── Bull Call Spread (defined risk, bullish) ──
        {"name": "BullSpread",  "option_type": "CE", "delta_min": 0.25, "delta_max": 0.50, "target_pct": 8,  "stoploss_pct": 6,  "max_hold_min": 20, "iv_pref": "ANY", "prefer_expiry": "nearest", "strategy_type": "spread",   "min_capital": 300},
        # ── Bear Put Spread (defined risk, bearish) ──
        {"name": "BearSpread",  "option_type": "PE", "delta_min": 0.25, "delta_max": 0.50, "target_pct": 8,  "stoploss_pct": 6,  "max_hold_min": 20, "iv_pref": "ANY", "prefer_expiry": "nearest", "strategy_type": "spread",   "min_capital": 300},
        # ── Iron Condor (non-directional, high IV) ──
        {"name": "IronCondor",  "option_type": "BOTH","delta_min": 0.10,"delta_max": 0.25, "target_pct": 5,  "stoploss_pct": 10, "max_hold_min": 30, "iv_pref": "HIGH","prefer_expiry": "nearest", "strategy_type": "iron_condor","min_capital": 300},
        # ── Straddle (earnings/event plays) ──
        {"name": "AtmStraddle", "option_type": "BOTH","delta_min": 0.40,"delta_max": 0.60, "target_pct": 6,  "stoploss_pct": 8,  "max_hold_min": 15, "iv_pref": "LOW", "prefer_expiry": "nearest", "strategy_type": "straddle",  "min_capital": 300},
        # ── Strangle (wide range non-directional) ──
        {"name": "OtmStrangle", "option_type": "BOTH","delta_min": 0.10,"delta_max": 0.25, "otm_min": 2.5, "otm_max": 7, "target_pct": 10, "stoploss_pct": 8, "max_hold_min": 25, "iv_pref": "LOW", "prefer_expiry": "nearest", "strategy_type": "strangle", "min_capital": 300},
        # ── Calendar Spread (time decay play) ──
        {"name": "CalendarCE",  "option_type": "CE", "delta_min": 0.40, "delta_max": 0.60, "target_pct": 5,  "stoploss_pct": 5,  "max_hold_min": 60, "iv_pref": "LOW", "prefer_expiry": "calendar", "strategy_type": "calendar",  "min_capital": 300},
        {"name": "CalendarPE",  "option_type": "PE", "delta_min": 0.40, "delta_max": 0.60, "target_pct": 5,  "stoploss_pct": 5,  "max_hold_min": 60, "iv_pref": "LOW", "prefer_expiry": "calendar", "strategy_type": "calendar",  "min_capital": 300},
        # ── Butterfly (low risk, precise target) ──
        {"name": "ButterflyC",  "option_type": "CE", "delta_min": 0.15, "delta_max": 0.45, "target_pct": 12, "stoploss_pct": 5,  "max_hold_min": 30, "iv_pref": "HIGH","prefer_expiry": "nearest", "strategy_type": "butterfly",  "min_capital": 300},
        # ── Swing — next expiry ──
        {"name": "SwingCE",     "option_type": "CE", "delta_min": 0.10, "delta_max": 0.30, "otm_min": 2, "otm_max": 6, "target_pct": 10, "stoploss_pct": 8, "max_hold_min": 30, "iv_pref": "LOW", "prefer_expiry": "nearest", "strategy_type": "single"},
        {"name": "FadeBear",    "option_type": "PE", "delta_min": 0.10, "delta_max": 0.25, "target_pct": 4,  "stoploss_pct": 5,  "iv_pref": "HIGH","trend_filter": "AGAINST", "prefer_expiry": "nearest", "strategy_type": "single"},
        # ── FNO stock specialists ──
        {"name": "StockCE",     "option_type": "CE", "delta_min": 0.15, "delta_max": 0.40, "target_pct": 6,  "stoploss_pct": 8,  "vol_min": 500000, "max_hold_min": 20, "prefer_expiry": "any", "prefer_underlying": "stock", "strategy_type": "single"},
        {"name": "StockPE",     "option_type": "PE", "delta_min": 0.15, "delta_max": 0.40, "target_pct": 6,  "stoploss_pct": 8,  "vol_min": 500000, "max_hold_min": 20, "prefer_expiry": "any", "prefer_underlying": "stock", "strategy_type": "single"},
        # ── Ratio spread (when skew is favourable) ──
        {"name": "RatioSpread", "option_type": "CE", "delta_min": 0.20, "delta_max": 0.40, "target_pct": 7,  "stoploss_pct": 6,  "max_hold_min": 20, "iv_pref": "HIGH","prefer_expiry": "nearest", "strategy_type": "ratio",      "min_capital": 300},
    ]:
        pool.add(Strat(g))
    pool.save()

def evolve():
    """Kill weak strategies, breed best, spawn mutations. Run every evo_every trades."""
    for bad in list(pool.worst()): pool.kill(bad.g["name"])  # Bug7 fix: copy list before mutating
    best = pool.best(3)  # top 3 parents
    if len(best) >= 2 and len(pool.s) < C["max_strats"]:
        pool.add(Strat.breed(best[0], best[1]))
    if len(best) >= 3 and len(pool.s) < C["max_strats"]:
        pool.add(Strat.breed(best[0], best[2]))
    if pool.live() and len(pool.s) < C["max_strats"]:
        pool.add(random.choice(pool.live()).mutate())
    if pool.live() and len(pool.s) < C["max_strats"]:
        pool.add(random.choice(pool.live()).mutate())
    pool.save()
    log.info(f"  ~ Evolved gen{pool.s[0].g['generation'] if pool.s else 0}: {len(pool.alive())} alive, {len(pool.dead)} dead")

# ═══════════════════════ KELLY ═══════════════════════

def kelly(wr, aw, al, cash):
    if al == 0 or wr == 0: return cash * C["min_bet"]
    b = abs(aw / al); p = wr / 100; f = (b * p - (1 - p)) / b
    f *= C["kelly"]; f = max(C["min_bet"], min(C["max_bet"], f))
    return cash * f

# ═══════════════════════ EQUITY INTRADAY LOOP ═══════════════════════

async def run_equity_loop(dt_ref: list, dp_ref: list, dw_ref: list):
    """
    Standalone equity intraday (MIS) trading loop.
    Runs concurrently with the options loop via asyncio.gather.
    Active only when ASSET_MODE is 'equity', 'both', or 'all'.

    scan_stocks() returns dicts with keys: key, qty, direction, ltp, name, score, ...
    buy_equity() / exit_equity() are used for all order placement.
    """
    if ASSET_MODE not in ("equity", "both", "all"):
        return

    log.info("  [EQ] Equity intraday loop started")
    eq_ctx  = None   # active pick dict from scan_stocks, augmented with entry_price
    eq_t0   = None
    eq_peak = 0.0

    while True:
        try:
            now = datetime.now(IST)
            t   = now.time().replace(tzinfo=None)
            is_weekday = now.weekday() < 5

            # ── BUG3 FIX: separate force-exit (weekday after close) from market-closed sleep ──
            # Force-exit open position on weekday close (before sleeping)
            if is_weekday and t >= dtime(15, 10) and eq_ctx:
                log.info("  [EQ] MIS square-off time — force-exiting")
                inst_key  = eq_ctx.get("key", "")
                exit_qty  = eq_ctx.get("qty", 1)
                direction = eq_ctx.get("direction", "BUY")
                r = await exit_equity(broker, inst_key, exit_qty, direction, paper=PAPER)
                if r.get("status") == "success":
                    eq_ctx = None; eq_t0 = None; eq_peak = 0.0

            # Sleep outside trading hours
            if not (is_weekday and dtime(9, 16) <= t <= dtime(15, 10)):
                await asyncio.sleep(60)
                continue

            broker.reload_token()
            if not broker.ok:
                await asyncio.sleep(30)
                continue

            cash = await broker.cash()
            if PAPER:  # PAPER-CASH-FIX
                cash = max(cash, 1.0)  # No minimum floor — use actual available margin
            eq_cash = segment_capital("equity", cash)
            # PAPER-CASH-FIX: reduce available equity cash if already holding a position
            if eq_ctx and eq_ctx.get("entry_price", 0) > 0:
                _eq_committed = eq_ctx.get("entry_price", 0) * eq_ctx.get("qty", 1)
                eq_cash = max(0, eq_cash - _eq_committed)

            # ── MONITOR open equity position ──
            if eq_ctx:
                # BUG2 FIX: use correct keys from scan_stocks() dict
                inst_key  = eq_ctx.get("key", "")          # was wrongly: _pk
                bp        = eq_ctx.get("entry_price", 0)   # set at entry below
                qty       = eq_ctx.get("qty", 1)           # was wrongly: lot
                direction = eq_ctx.get("direction", "BUY") # was wrongly: _eq_dir
                tgt       = eq_ctx.get("target_pct", 0.5)
                sl        = eq_ctx.get("sl_pct", 0.4)
                mxh       = eq_ctx.get("max_hold_min", 15)
                sym       = eq_ctx.get("name", "?")
                hld       = (now - eq_t0).total_seconds() / 60 if eq_t0 else 0

                ltp = bp
                try:
                    ltp_data = await broker._get(f"/v2/market-quote/ltp?instrument_key={inst_key}")
                    for _, v in ltp_data.get("data", {}).items():
                        ltp = v.get("last_price", bp)
                        break
                except Exception:
                    pass

                if bp > 0:
                    if direction == "SELL":
                        pp = ((bp - ltp) / bp) * 100; pr = (bp - ltp) * qty
                    else:
                        pp = ((ltp - bp) / bp) * 100; pr = (ltp - bp) * qty
                    if pp > eq_peak: eq_peak = pp
                else:
                    pp = pr = 0.0

                log.info(f"  [EQ] {sym} {bp:.2f}→{ltp:.2f} {pp:+.2f}% Rs{pr:+.0f} {hld:.0f}m [{direction}]")

                ex = None
                if pp >= tgt:                                               ex = "TARGET"
                elif eq_peak >= tgt * 0.5 and pp <= (eq_peak - tgt * 0.3): ex = "TRAIL_SL"
                elif pp <= -sl:                                             ex = "STOPLOSS"
                elif hld >= mxh:                                            ex = "TIMEOUT"

                if ex:
                    # BUG1 FIX: use exit_equity() which reverses direction for shorts
                    r = await exit_equity(broker, inst_key, qty, direction, paper=PAPER)
                    if r.get("status") == "success":
                        won = pp > 0
                        # BUG5 FIX: swap args for short so calculate(buy_price, sell_price) is correct
                        if direction == "SELL":
                            ch = eq_charges.calculate(ltp, bp, qty)   # exit=buy@ltp, entry=sell@bp
                        else:
                            ch = eq_charges.calculate(bp, ltp, qty)   # entry=buy@bp, exit=sell@ltp
                        net = ch["net_pnl"]
                        tc  = ch["total_charges"]
                        dt_ref[0] += 1; dp_ref[0] += pr
                        if won: dw_ref[0] += 1
                        ic = "+" if pp > 0 else "-"
                        log.info(f"  [EQ]{ic} {ex} {sym} {pp:+.2f}% Rs{pr:+.0f} net=Rs{net:+.0f} | Day:{dt_ref[0]}T {dw_ref[0]}W")
                        await tg(
                            f"{'✅ WIN' if won else '❌ LOSS'} EQ CLOSED: {sym} ({direction})\n"
                            f"Entry: ₹{bp:.2f} → Exit: ₹{ltp:.2f}\n"
                            f"P&L: {pp:+.2f}% | Net: ₹{net:+.0f} | {ex}"
                        )
                        # Train equity NN on outcome
                        try:
                            _ef2 = np.array([
                                eq_ctx.get("day_change_pct", 0) / 10,
                                eq_ctx.get("range_pct", 0) / 5,
                                eq_ctx.get("range_position", 0.5),
                                eq_ctx.get("vol_ratio", 1.0),
                                1.0 if direction == "BUY" else -1.0,
                                eq_ctx.get("score", 5) / 10,
                            ] + [0.0]*(FEAT_DIM-6), dtype=np.float64)
                            nn_equity.train1(_ef2, 1.0 if won else 0.0)
                            _save_asset_nns()
                        except Exception: pass
                        # BUG #3 FIX: persist equity trade to DB
                        now_eq = datetime.now(IST)
                        hld_sec = int((now_eq - eq_t0).total_seconds()) if eq_t0 else 0
                        eq_trade = {
                            "ts": now_eq.isoformat(), "symbol": sym, "strike": 0, "otype": direction,
                            "asset": "equity", "underlying": sym, "expiry": "", "strategy": eq_ctx.get("score", "EqScalp"),
                            "entry_price": bp, "entry_delta": 0, "entry_gamma": 0, "entry_theta": 0,
                            "entry_iv": 0, "entry_volume": 0, "entry_oi": 0,
                            "entry_otm": 0, "entry_spot": bp, "entry_hour": now_eq.hour,
                            "lot": qty, "cost": round(bp * qty, 2),
                            "capital_pct": round(bp * qty / max(1, eq_cash) * 100, 1),
                            "exit_price": ltp, "exit_reason": ex, "hold_sec": hld_sec,
                            "pnl": round(pr, 2), "pnl_pct": round(pp, 2), "won": 1 if won else 0,
                            "nn_prob": 0, "rl_state": "", "rl_action": 0,
                            "features_json": "[]", "strat_gen": 0,
                            "peak_pnl": round(eq_peak, 2), "partial": 0,
                            "charges": round(tc, 2), "net_pnl": round(net, 2),
                        }
                        log_trade(eq_trade)
                        if _EQ_INVENTOR and equity_inventor is not None:
                            _eq_stock_info = {
                                "tier": eq_ctx.get("tier", "unknown") if eq_ctx else "unknown",
                                "name": sym,
                                "hold_min": round(hld_sec / 60, 1) if hld_sec else 0,
                            }
                            equity_inventor.record_trade(
                                str(eq_ctx.get("score", "EqScalp")) if eq_ctx else "EqScalp",
                                won, pp, _eq_stock_info
                            )
                        eq_ctx = None; eq_t0 = None; eq_peak = 0.0
                    await asyncio.sleep(5)
                    continue

                await asyncio.sleep(10)
                continue

            # ── SCAN for new equity opportunity ──
            # Block new equity entries after 15:00 — intraday MIS only
            if t >= dtime(15, 0):
                log.info("  [EQ] Past 15:00 — no new equity entries (intraday only)")
                await asyncio.sleep(30); continue
            # Per-segment daily loss limit
            if seg_limits.is_halted("equity"):
                log.info("  [LIMITS] Equity segment HALTED for today")
                await asyncio.sleep(300); continue
            picks = await scan_stocks(broker, eq_cash)
            # Re-score equity picks using dedicated equity NN
            if picks:
                from equity_intraday import EQ_FEATURES
                for _pk in picks:
                    try:
                        _ef = np.array([
                            _pk.get("day_change_pct", 0) / 10,
                            _pk.get("range_pct", 0) / 5,
                            _pk.get("range_position", 0.5),
                            _pk.get("vol_ratio", 1.0),
                            1.0 if _pk.get("direction") == "BUY" else -1.0,
                            _pk.get("score", 5) / 10,
                        ], dtype=np.float64)
                        # Pad to FEAT_DIM
                        _ef = np.concatenate([_ef, np.zeros(FEAT_DIM - len(_ef))])
                        _eq_prob = nn_equity.predict(_ef)
                        _pk["_nn_eq_prob"] = round(_eq_prob, 3)
                    except Exception:
                        _pk["_nn_eq_prob"] = 0.5
                picks.sort(key=lambda x: x.get("_nn_eq_prob", 0.5) * x.get("score", 1), reverse=True)
            if not picks:
                await asyncio.sleep(20)
                continue

            pick = picks[0]
            result = await buy_equity(broker, pick, paper=PAPER)
            if result.get("status") == "success":
                # BUG #5 FIX: in live mode fetch actual fill price; paper uses scan LTP
                entry_price = pick.get("ltp", 0)
                if not PAPER:
                    try:
                        fill_p, _ = await broker.last_fill()
                        if fill_p > 0:
                            entry_price = fill_p
                    except Exception:
                        pass
                pick["entry_price"] = entry_price
                eq_ctx  = pick
                eq_t0   = now
                eq_peak = 0.0
                sym       = pick.get("name", "?")
                ep        = pick["entry_price"]
                qty       = pick.get("qty", 1)
                direction = pick.get("direction", "BUY")   # was wrongly: _eq_dir
                log.info(f"  [EQ] {direction} {sym} qty={qty} @ Rs{ep:.2f} T:+{pick.get('target_pct',0.5)}% SL:-{pick.get('sl_pct',0.4)}%")
                await tg(
                    f"🛒 EQ ENTRY: {sym} ({direction})\n"
                    f"Price: ₹{ep:.2f} | Qty: {qty}\n"
                    f"Target: +{pick.get('target_pct',0.5)}% | SL: -{pick.get('sl_pct',0.4)}%\n"
                    f"{'PAPER' if PAPER else 'LIVE'}"
                )

            await asyncio.sleep(15)

        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error(f"  [EQ] ERR: {e}")
            await asyncio.sleep(10)

    # ── equity_loop shutdown: close open equity position ──
    if eq_ctx:
        log.info("  [SHUTDOWN][EQ] Closing open equity position...")
        try:
            inst_key  = eq_ctx.get("key", "")
            qty       = eq_ctx.get("qty", 1)
            direction = eq_ctx.get("direction", "BUY")
            sym       = eq_ctx.get("name", "?")
            r = await exit_equity(broker, inst_key, qty, direction, paper=PAPER)
            log.info(f"  [SHUTDOWN][EQ] Closed {sym}: {r.get('status','?')}")
            await tg(f"🛑 SHUTDOWN EQ EXIT: {sym} ({direction}) qty={qty} | {'PAPER' if PAPER else 'LIVE'}")
        except Exception as e:
            log.error(f"  [SHUTDOWN][EQ] Exit failed: {e}")

async def run_commodity_loop(dt_ref: list, dp_ref: list, dw_ref: list):
    """
    MCX commodity futures loop — supports MULTIPLE simultaneous positions,
    one per symbol (GOLDPETAL, CRUDEOILM, NATGASMINI can all be open at once).
    Also supports both BUY and SELL (short) based on scan direction signal.
    """
    if not COMMODITY_ENABLED:
        return

    log.info("  [MCX] Commodity loop started (multi-position mode)")

    # Dict of symbol → {ctx, t0, peak}  — one slot per symbol
    positions: dict = {}   # symbol → {"ctx": pick_dict, "t0": datetime, "peak": float}
    _inst_refreshed = False

    while True:
        try:
            now = datetime.now(IST)

            if not mcx_is_open():
                await asyncio.sleep(60)
                continue

            broker.reload_token()
            if not broker.ok:
                await asyncio.sleep(30)
                continue

            # ── Refresh MCX instruments (once at startup, then every 8h) ──
            if not _inst_refreshed:
                log.info("  [MCX] Loading instruments from Upstox...")
                try:
                    await mcx_inst.refresh(broker)
                    _inst_refreshed = True
                    log.info(f"  [MCX] Instruments ready: {list(mcx_inst.keys.keys())}")
                except Exception as _e:
                    log.error(f"  [MCX] Instrument refresh failed: {_e}")
                    await asyncio.sleep(30)
                    continue
            else:
                try:
                    await mcx_inst.refresh(broker)
                except Exception:
                    pass

            cash = await broker.cash()
            if PAPER:
                cash = max(cash, 1.0)  # No minimum floor — use actual available margin
            cash = segment_capital("commodity", cash)

            # ── MONITOR all open positions ──
            to_close = []
            for sym, pos in list(positions.items()):
                ctx    = pos["ctx"]
                t0     = pos["t0"]
                bp     = ctx.get("entry_price", 0)
                qty    = ctx.get("qty", 1)
                key    = ctx.get("key", "")
                tgt    = ctx.get("target_pct", 3.0)
                sl     = ctx.get("sl_pct", 1.5)
                mxh    = ctx.get("max_hold_min", 30)
                direction_mcx = ctx.get("direction", "BUY")
                hld    = (now - t0).total_seconds() / 60 if t0 else 0

                # Fetch LTP
                ltp = bp
                try:
                    ltp_resp = await broker._get(f"/v2/market-quote/ltp?instrument_key={key}")
                    for v in ltp_resp.get("data", {}).values():
                        _p = v.get("last_price", 0)
                        if _p > 0:
                            ltp = _p
                            break
                except Exception as e:
                    log.warning(f"  [MCX] LTP fetch failed for {sym}: {e}")

                # P&L — direction-aware: SELL profits when price falls
                if bp > 0:
                    if direction_mcx == "BUY":
                        pp = ((ltp - bp) / bp) * 100
                        pr = (ltp - bp) * qty
                    else:  # SELL (short)
                        pp = ((bp - ltp) / bp) * 100
                        pr = (bp - ltp) * qty
                    if pp > pos["peak"]:
                        pos["peak"] = pp
                else:
                    pp = pr = 0.0

                ex = None
                if pp >= tgt:                                          ex = "TARGET"
                elif pos["peak"] >= 1.5 and pp <= (pos["peak"] - 1.0): ex = "TRAIL_SL"
                elif pp <= -sl:                                        ex = "STOPLOSS"
                elif hld >= mxh:                                       ex = "TIMEOUT"
                elif mcx_force_exit_time():                            ex = "MCX_CLOSE"

                if ex:
                    result = {"status": "error"}
                    for _attempt in range(3):
                        try:
                            result = await exit_commodity(broker, key, qty, direction_mcx, paper=PAPER)
                            if result.get("status") == "success":
                                break
                            await asyncio.sleep(2)
                        except Exception as _exit_e:
                            log.error(f"  [MCX] Exit attempt {_attempt+1} for {sym}: {_exit_e}")
                            await asyncio.sleep(2)

                    if result.get("status") == "success":
                        won = pp > 0
                        dt_ref[0] += 1; dp_ref[0] += pr
                        if won: dw_ref[0] += 1
                        ic = "+" if pp > 0 else "-"
                        seg_limits.update_pnl("commodity", pr)
                        # ── Strategy Inventor: record outcome ──────────────
                        _strat_name = ctx.get("strat_name", f"MCX_{sym}")
                        try:
                            if _INVENTOR_AVAILABLE and commodity_inventor is not None:
                                commodity_inventor.record_trade(sym, _strat_name, won, pp)
                        except Exception as _inv_rec_err:
                            log.debug(f"  [INVENTOR] record error: {_inv_rec_err}")
                        # ──────────────────────────────────────────────────
                        # Train commodity NN on outcome
                        try:
                            _cf = np.array([
                                pp / 10,
                                (ltp - bp) / max(1, bp) * 10,
                                pos["peak"] / 5,
                                hld / 60,
                                1.0 if direction_mcx == "BUY" else -1.0,
                                ctx.get("score", 5) / 10,
                            ] + [0.0]*(FEAT_DIM-6), dtype=np.float64)
                            nn_commodity.train1(_cf, 1.0 if won else 0.0)
                            _save_asset_nns()
                        except Exception: pass
                        log.info(f"  [MCX]{ic} {ex} {sym} ({direction_mcx}) {pp:+.3f}% Rs{pr:+.0f} | Day:{dt_ref[0]}T {dw_ref[0]}W")
                        await tg(
                            f"{'✅ WIN' if won else '❌ LOSS'} MCX CLOSED: {sym} ({direction_mcx})\n"
                            f"Entry: ₹{bp:.1f} → Exit: ₹{ltp:.1f}\n"
                            f"P&L: {pp:+.3f}% | ₹{pr:+.0f} | {ex}"
                        )
                        # ── Qwen exit commentary (async, non-blocking) ─────────
                        if _QWEN_AVAILABLE and qwen_commentator is not None:
                            _pick_for_exit = dict(ctx)
                            _pick_for_exit['ltp'] = ltp
                            asyncio.ensure_future(
                                qwen_commentator.on_exit(_pick_for_exit, pp, ex)
                            )
                        # ─────────────────────────────────────────────────
                        now_mcx = datetime.now(IST)
                        hld_sec_mcx = int((now_mcx - t0).total_seconds()) if t0 else 0
                        log_trade({
                            "ts": now_mcx.isoformat(), "symbol": sym, "strike": 0,
                            "otype": direction_mcx, "asset": "commodity",
                            "underlying": sym, "expiry": str(mcx_inst.expiry.get(sym, "")),
                            "strategy": ctx.get("strat_name", f"MCX_{sym}"),
                            "entry_price": bp, "entry_delta": 0, "entry_gamma": 0,
                            "entry_theta": 0, "entry_iv": 0, "entry_volume": 0,
                            "entry_oi": 0, "entry_otm": 0, "entry_spot": bp,
                            "entry_hour": now_mcx.hour, "lot": qty,
                            "cost": round(bp * qty, 2),
                            "capital_pct": round(bp * qty / max(1, cash) * 100, 1),
                            "exit_price": ltp, "exit_reason": ex, "hold_sec": hld_sec_mcx,
                            "pnl": round(pr, 2), "pnl_pct": round(pp, 2), "won": 1 if won else 0,
                            "nn_prob": 0, "rl_state": "", "rl_action": 0,
                            "features_json": "[]", "strat_gen": 0,
                            "peak_pnl": round(pos["peak"], 2), "partial": 0,
                            "charges": 0, "net_pnl": round(pr, 2),
                        })
                        to_close.append(sym)
                    else:
                        log.error(f"  [MCX] ⚠ All exit attempts failed for {sym} — manual squareoff needed!")
                        await tg(f"⚠️ MCX EXIT FAILED: {sym} | Manual squareoff needed! Reason: {ex}")
                    await asyncio.sleep(2)
                    continue

                log.info(f"  [MCX] {sym} ({direction_mcx}) {bp}→{ltp} {pp:+.3f}% Rs{pr:+.0f} {hld:.0f}m")
                # Search for reason if big move
                if abs(pp) >= 1.5:
                    asyncio.ensure_future(auto_searcher.run_instrument_search(sym, pp, _spots_ref[0]))

            # Remove closed positions
            for sym in to_close:
                positions.pop(sym, None)

            if to_close:
                await asyncio.sleep(5)
                continue

            # ── SCAN for new MCX opportunities ──
            if not mcx_entry_allowed():
                await asyncio.sleep(60)
                continue

            if seg_limits.is_halted("commodity"):
                log.info("  [MCX] Commodity segment HALTED for today — daily loss limit reached")
                await asyncio.sleep(300)
                continue

            # Re-fetch cash after monitoring (positions may have freed capital)
            cash = await broker.cash()
            if PAPER:
                cash = max(cash, 1.0)  # No minimum floor — use actual available margin
            cash = segment_capital("commodity", cash)

            # Capital already used in open positions (use margin_needed not contract value)
            used_capital = sum(
                pos["ctx"].get("margin_used", pos["ctx"].get("margin_needed", 0))
                for pos in positions.values()
            )
            free_cash = max(0, cash - used_capital)
            log.info(f"  [MCX] Capital: total=Rs{cash:.0f} used=Rs{used_capital:.0f} free=Rs{free_cash:.0f} positions={len(positions)}")

            if free_cash < 100:
                log.info(f"  [MCX] Free cash Rs{free_cash:.0f} < Rs100 — waiting")
                await asyncio.sleep(30)
                continue

            picks = await scan_commodities(broker, cash)  # scan with full capital, size with free_cash
            if not picks:
                await asyncio.sleep(30)
                continue

            # ── Strategy Inventor: select best strategy per pick & maybe invent ──
            if _INVENTOR_AVAILABLE and commodity_inventor is not None:
                try:
                    _now_ist = datetime.now(IST)
                    _session = "us" if _now_ist.time() >= dtime(18, 30) else \
                               "eod" if _now_ist.time() >= dtime(21, 30) else "indian"
                    _inv_ctx = {
                        "spot_prices": {p["symbol"]: p["ltp"] for p in picks},
                        "day_changes": {p["symbol"]: p.get("day_change_pct", 0) for p in picks},
                        "session": _session,
                        "india_vix": 0,
                        "recent_macro": "",
                        "winning_strats": [],
                        "losing_strats":  [],
                    }
                    asyncio.ensure_future(commodity_inventor.maybe_invent(_inv_ctx))
                    for _pick in picks:
                        _best = commodity_inventor.best_strategy_for(
                            _pick.get("symbol", ""),
                            _pick.get("direction", "BUY"),
                            _session,
                        )
                        if _best:
                            _pick["strat_name"]    = _best["name"]
                            _pick["target_pct"]    = _best.get("target_pct", _pick.get("target_pct", 1.0))
                            _pick["sl_pct"]        = _best.get("sl_pct",     _pick.get("sl_pct",     0.6))
                            _pick["max_hold_min"]  = _best.get("max_hold_min", _pick.get("max_hold_min", 45))
                            _pick["capital_pct"]   = _best.get("capital_pct", 0.30)
                        else:
                            _pick.setdefault("strat_name", f"MCX_{_pick.get('symbol','')}")
                except Exception as _inv_loop_err:
                    log.debug(f"  [INVENTOR] loop error: {_inv_loop_err}")
            # ─────────────────────────────────────────────────────────────────────

            for pick in picks:
                sym = pick.get("symbol", "")

                # Skip if already have an open position in this symbol
                if sym in positions:
                    continue

                direction_mcx  = pick.get("direction", "BUY")
                base_lot       = pick.get("lot_size", 1)
                ltp_com        = pick.get("ltp", 1)
                # margin_needed from scan = margin for 1 full base lot
                margin_one_lot = pick.get("margin_needed", ltp_com * base_lot * 0.12)

                # Cap each position to 30% of total commodity capital
                # Ensures capital is spread across all 3 commodities
                # Using total cash (not free_cash) so sizing is consistent
                max_capital_per_trade = cash * 0.30
                max_lots = max(1, int(max_capital_per_trade / max(1, margin_one_lot)))
                pick["qty"] = max_lots * base_lot
                log.info(f"  [MCX] Sizing {sym}: margin/lot=Rs{margin_one_lot:.0f} max_lots={max_lots} qty={pick['qty']}")

                # ── Qwen regime gate ──────────────────────────────────────
                if _QWEN_AVAILABLE and qwen_regime is not None:
                    try:
                        if not qwen_regime.regime_allows_entry(direction_mcx):
                            log.info(f"  [QWEN] Regime gate blocked {sym} {direction_mcx} — {qwen_regime.current.get('note','')}")
                            continue
                    except Exception:
                        pass
                # ─────────────────────────────────────────────────────────────

                result = await buy_commodity(broker, pick, paper=PAPER)
                if result.get("status") == "success":
                    if not pick.get("entry_price"):
                        pick["entry_price"] = pick.get("ltp", 0)
                    pick["_t0"] = time.time()
                    positions[sym] = {"ctx": pick, "t0": now, "peak": 0.0}
                    ep  = pick["entry_price"]
                    qty = pick.get("qty", 1)
                    log.info(f"  [MCX] {direction_mcx} {sym} qty={qty} @ ₹{ep:.1f} T:+{pick.get('target_pct',3)}% SL:-{pick.get('sl_pct',1.5)}%")
                    # ── Qwen entry commentary (async, non-blocking) ──────────
                    if _QWEN_AVAILABLE and qwen_commentator is not None:
                        asyncio.ensure_future(qwen_commentator.on_entry(pick))
                    # ─────────────────────────────────────────────────────────
                    await tg(
                        f"🛒 MCX ENTRY: {sym} ({direction_mcx})\n"
                        f"Price: ₹{ep:.1f} | Qty: {qty}\n"
                        f"Target: +{pick.get('target_pct',3)}% | SL: -{pick.get('sl_pct',1.5)}%\n"
                        f"Session: {pick.get('session','?')} | {'PAPER' if PAPER else 'LIVE'}"
                    )
                    # Store actual margin used for capital tracking
                    actual_margin = margin_one_lot * max_lots
                    positions[sym]["ctx"]["margin_used"] = actual_margin
                    # Update free cash for next pick in this scan cycle
                    free_cash -= actual_margin
                    log.info(f"  [MCX] Allocated Rs{actual_margin:.0f} to {sym} | remaining free=Rs{free_cash:.0f}")
                    if free_cash < 100:
                        break
                else:
                    err = (result.get("errors") or [{}])[0].get("message", str(result))
                    log.error(f"  [MCX] {direction_mcx} {sym} failed: {err}")

            await asyncio.sleep(15)

        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error(f"  [MCX] ERR: {e}")
            await asyncio.sleep(10)

    # ── Shutdown: close ALL open MCX positions ──
    if positions:
        log.info(f"  [SHUTDOWN][MCX] Closing {len(positions)} open position(s)...")
        for sym, pos in positions.items():
            ctx           = pos["ctx"]
            key           = ctx.get("key", "")
            qty           = ctx.get("qty", 1)
            direction_mcx = ctx.get("direction", "BUY")
            result = {"status": "error"}
            for attempt in range(3):
                try:
                    result = await exit_commodity(broker, key, qty, direction_mcx, paper=PAPER)
                    if result.get("status") == "success":
                        break
                    await asyncio.sleep(2)
                except Exception as e:
                    log.error(f"  [SHUTDOWN][MCX] Attempt {attempt+1} failed for {sym}: {e}")
                    await asyncio.sleep(2)
            if result.get("status") == "success":
                log.info(f"  [SHUTDOWN][MCX] Closed {sym} ({direction_mcx})")
                await tg(f"🛑 SHUTDOWN MCX EXIT: {sym} ({direction_mcx}) qty={qty} | {'PAPER' if PAPER else 'LIVE'}")
            else:
                log.error(f"  [SHUTDOWN][MCX] ⚠ Failed to close {sym} — manual squareoff needed!")
                await tg(f"⚠️ SHUTDOWN MCX EXIT FAILED: {sym} — manual squareoff needed!")



async def run_commodity_options_loop(dt_ref: list, dp_ref: list, dw_ref: list):
    """
    MCX energy options loop — CRUDEOILM + NATGASMINI options.
    Runs in parallel with run_commodity_loop.
    Enabled via COMMODITY_OPTIONS_ENABLED env flag.
    Optimized for UserLAnd/Termux: minimal RAM, no polling when market closed.
    """
    if not COMMODITY_OPTIONS_ENABLED:
        return

    log.info("  [MCX-OPTS] Energy options loop started")
    broker    = Broker()
    positions = {}   # {position_id: {opp, entry_time, entry_price}}
    _inst_loaded = False

    while True:
        try:
            await asyncio.sleep(25)   # 25s cycle — lighter than futures 20s

            if not mcx_opt_is_open():
                await asyncio.sleep(60)
                continue

            now = datetime.now(IST)

            # ── Load option instruments once at startup ──
            if not _inst_loaded:
                try:
                    await mcx_opt_inst.refresh()
                    _inst_loaded = bool(mcx_opt_inst.available_symbols())
                    if _inst_loaded:
                        log.info(f"  [MCX-OPTS] Instruments: {mcx_opt_inst.available_symbols()}")
                except Exception as _ie:
                    log.error(f"  [MCX-OPTS] Instrument load failed: {_ie}")
                continue

            cash = await broker.cash()
            if PAPER:
                cash = max(cash, 1.0)  # No minimum floor — use actual available margin
            cash = segment_capital("commodity", cash) * 0.35   # options use 35% of commodity capital

            # ── MONITOR open option positions ──
            to_close = []
            for pid, pos in list(positions.items()):
                try:
                    status = await monitor_option_position(broker, pos)
                    if status["should_exit"]:
                        to_close.append((pid, pos, status["exit_reason"],
                                         status["current_pnl"], status["pnl_pct"]))
                except Exception as _me:
                    log.warning(f"  [MCX-OPTS] Monitor {pid}: {_me}")

            for pid, pos, reason, pnl, pnl_pct in to_close:
                try:
                    result = await exit_option_strategy(broker, pos["opp"], paper=PAPER)
                    if result.get("status") in ("success", "partial"):
                        won = pnl > 0
                        dt_ref[0] += 1; dp_ref[0] += pnl
                        if won: dw_ref[0] += 1
                        seg_limits.update_pnl("commodity", pnl)
                        sym = pos["opp"].get("symbol", "?")
                        sid = pos["opp"].get("strategy", "?")
                        log.info(f"  [MCX-OPTS] EXIT {sym} [{sid}] {reason} "
                                 f"pnl=₹{pnl:.0f} ({pnl_pct:+.1f}%) "
                                 f"{'WIN' if won else 'LOSS'} | {'PAPER' if PAPER else 'LIVE'}")
                        await tg(
                            f"{'🟢' if won else '🔴'} MCX-OPT EXIT: {sym} [{sid}]\n"
                            f"Reason: {reason} | P&L: ₹{pnl:.0f} ({pnl_pct:+.1f}%)\n"
                            f"{'📝 PAPER' if PAPER else '⚡ LIVE'}"
                        )
                        del positions[pid]
                except Exception as _xe:
                    log.error(f"  [MCX-OPTS] Exit error {pid}: {_xe}")

            # ── ENTRY: scan for new options opportunities ──
            if not mcx_opt_entry_allowed():
                continue
            if seg_limits.is_halted("commodity"):
                continue
            if len(positions) >= 3:   # max 3 concurrent option positions
                continue

            try:
                opps = await scan_energy_options(
                    broker, cash,
                    eia_draw_mmbbl=0.0,
                    crude_iv=0.35,
                    natgas_iv=0.55,
                    batch_size=3,
                )
            except Exception as _se:
                log.error(f"  [MCX-OPTS] Scan error: {_se}")
                continue

            for opp in opps:
                sym = opp.get("symbol", "")
                sid = opp.get("strategy", "")
                pid = f"{sym}_{sid}_{int(time.time())}"

                if any(p["opp"].get("symbol") == sym for p in positions.values()):
                    continue   # already in this symbol

                if cash < opp.get("min_capital", 5000):
                    continue

                try:
                    result = await enter_option_strategy(broker, opp, paper=PAPER)
                    if result.get("status") in ("success", "partial"):
                        positions[pid] = {"opp": opp, "entry_time": now, "peak_pnl": 0.0}
                        legs_desc = " + ".join(
                            f"{l['side'].upper()} {l['strike']}{l['type']}"
                            for l in opp.get("legs", [])
                        )
                        log.info(
                            f"  [MCX-OPTS] ENTRY {sym} [{sid}] {legs_desc} "
                            f"iv={opp.get('iv', 0):.2f} score={opp.get('score')} "
                            f"{'PAPER' if PAPER else 'LIVE'}"
                        )
                        await tg(
                            f"📊 MCX-OPT ENTRY: {sym} [{opp.get('strategy_name', sid)}]\n"
                            f"Legs: {legs_desc}\n"
                            f"IV={opp.get('iv', 0):.2f} IVrank={opp.get('iv_rank', 0):.0f} "
                            f"DTE={opp.get('dte')} Score={opp.get('score')}\n"
                            f"{'📝 PAPER' if PAPER else '⚡ LIVE'}"
                        )
                except Exception as _ee:
                    log.error(f"  [MCX-OPTS] Entry error {sym} {sid}: {_ee}")

        except asyncio.CancelledError:
            break
        except Exception as _loop_e:
            log.error(f"  [MCX-OPTS] Loop error: {_loop_e}")
            await asyncio.sleep(30)

    # ── Shutdown: close all open option positions ──
    log.info("  [MCX-OPTS] Shutting down — closing all option positions")
    for pid, pos in list(positions.items()):
        try:
            sym = pos["opp"].get("symbol", "?")
            await exit_option_strategy(broker, pos["opp"], paper=PAPER)
            log.info(f"  [MCX-OPTS][SHUTDOWN] Closed {sym}")
        except Exception as _sx:
            log.error(f"  [MCX-OPTS][SHUTDOWN] Failed to close {pid}: {_sx}")


async def run():
    init_db(); nn.load(); rl.load()
    _load_asset_nns()   # load per-asset NNs
    if not pool.load(): seed()
    await te_probe_plan()  # discover which TE endpoints work on this plan
    # ── v15: apply upgrades after all globals are ready ──
    try:
        from v15_patch import apply_v15; apply_v15()
    except Exception as _v15e:
        log.warning(f"  v15 patch skipped: {_v15e}")
        # fallback to v14
        try:
            from v14_patch import apply_v14; apply_v14()
        except Exception as _v14e:
            log.warning(f"  v14 patch also skipped: {_v14e}")
    s = stats()
    # Walk-forward weighted training (recent trades count more)
    # Use augmented training data at startup for better NN initialisation
    X_aug, y_aug = get_augmented_training_data(FEAT_DIM, multiplier=8)
    if X_aug is not None and len(X_aug) >= 5:
        if X_aug.shape[1] < FEAT_DIM:
            X_aug = np.concatenate([X_aug, np.zeros((X_aug.shape[0], FEAT_DIM - X_aug.shape[1]))], axis=1)
        loss_aug = nn.train(X_aug, y_aug, 300); nn.save()
        log.info(f"  NN pre-trained on {len(X_aug)} augmented samples loss={loss_aug:.4f}")
    X, y, w = get_weighted_training_data(FEAT_DIM)
    if X is not None and len(X) >= 5:
        if X.shape[1] < FEAT_DIM:
            pad = np.zeros((X.shape[0], FEAT_DIM - X.shape[1]))
            X = np.concatenate([X, pad], axis=1)
        # Duplicate recent rows by weight to simulate weighting
        X_w, y_w = [], []
        for i, wi in enumerate(w):
            reps = max(1, int(wi))
            X_w.extend([X[i]] * reps)
            y_w.extend([y[i]] * reps)
        X_w = np.array(X_w); y_w = np.array(y_w)
        loss = nn.train(X_w, y_w, 200); nn.save()
        log.info(f"  NN trained (walk-forward): {len(X)} samples → {len(X_w)} weighted loss={loss:.4f}")
    else:
        X_td, y_td = None, None
        try:
            import numpy as _np
            from agent import get_td as _get_td
            X_td, y_td = get_td()
        except Exception: pass
        if X_td is not None and len(X_td) >= 5:
            loss = nn.train(X_td, y_td, 200); nn.save()
            log.info(f"  NN trained: {len(X_td)} samples loss={loss:.4f}")

    mode = "LIVE" if LIVE and not PAPER else "PAPER" if PAPER else "OFF"
    log.info("=" * 60)
    log.info(f"  {te_status_line()}")
    _mi = get_morning_insight()
    if _mi: log.info(f"  [SEARCH] Morning insight: {_mi[:150]}")
    log.info(f"  FINANCEAGI v{VERSION} | {mode} | {s['total']}T {s['wr']}%WR Rs{s['pnl']}")
    log.info(f"  NN:{nn.cnt} | RL:{rl.ep}ep | Strats:{len(pool.alive())}")
    log.info(f"  Expiries: up to {C['max_expiries']} | FNO stocks: {len(FNO_STOCKS)}")
    log.info(f"  MCX commodities: {'ENABLED' if COMMODITY_ENABLED else 'DISABLED'}")
    log.info(f"  Telegram alerts: {'ON' if TG_TOKEN and TG_CHAT else 'OFF'}")
    log.info(f"  Allocations: Opt=₹{ALLOC_OPTIONS:.0f} Eq=₹{ALLOC_EQUITY:.0f} Com=₹{ALLOC_COMMODITY:.0f}")
    for st in pool.alive():
        g = st.g
        exp_tag = f"exp={g.get('prefer_expiry','any')}" if g.get('prefer_expiry') != 'any' else ""
        ul_tag  = f"ul={g.get('prefer_underlying','any')}" if g.get('prefer_underlying') != 'any' else ""
        tags = " ".join(filter(None, [exp_tag, ul_tag]))
        log.info(f"    {'*' if g['testing'] else '>'} {g['name']:22s} {g['option_type']:4s} T={g['target_pct']}% SL={g['stoploss_pct']}% | {g['trades']}T {st.wr}% {tags}")
    log.info("=" * 60)

    # ── Qwen 2.5 startup ──────────────────────────────────────────────────────
    if _QWEN_AVAILABLE:
        try:
            _qwen_online = qwen.ping()
            log.info(f"  Qwen 2.5: {'ONLINE' if _qwen_online else 'OFFLINE (will retry)'}")
            if _qwen_online:
                patch_daily_update_ask_ollama()
                patch_web_search_summarise()
                qwen_commentator.set_telegram(tg)
        except Exception as _qe:
            log.warning(f"  Qwen startup error: {_qe}")
    # ─────────────────────────────────────────────────────────────────────────

    await tg(
        f"🚀 FinanceAGI v{VERSION} started\n"
        f"Mode: {mode} | Capital: ₹{int(CAPITAL_OVERRIDE or 0):,}\n"
        f"Strats: {len(pool.alive())} | MCX: {'ON' if COMMODITY_ENABLED else 'OFF'}\n"
        f"Qwen 2.5: {'ONLINE' if (_QWEN_AVAILABLE and qwen and qwen.is_available()) else 'OFFLINE'}"
    )

    # ── Weekly drawdown tracking ─────────────────────────────────
    _week_start_cash = [0.0]
    _week_start_date = [datetime.now(IST).isocalendar()[1]]  # ISO week number
    _token_last_check = [0.0]
    _feat_importance  = {}  # feature name → correlation with wins

    async def _health_monitor():
        """Background: token check every 30min + weekly DD circuit breaker."""
        import time as _time
        while True:
            try:
                await asyncio.sleep(60)
                now_h = datetime.now(IST)
                week_now = now_h.isocalendar()[1]

                # Reset weekly baseline on new week
                if week_now != _week_start_date[0]:
                    _week_start_date[0] = week_now
                    _week_start_cash[0] = await broker.cash()
                    log.info(f"  [HEALTH] New week — baseline cash ₹{_week_start_cash[0]:.0f}")

                # Token health check every TOKEN_CHECK_MIN minutes
                t_now = _time.time()
                if t_now - _token_last_check[0] > TOKEN_CHECK_MIN * 60:
                    _token_last_check[0] = t_now
                    broker.reload_token()
                    if not broker.ok:
                        log.warning("  [HEALTH] ⚠ Token expired or missing!")
                        await tg("⚠️ FinanceAGI: Upstox token expired! Re-login needed at dashboard.")
                    else:
                        log.info("  [HEALTH] Token OK")

                # Weekly drawdown check (only during market hours)
                t = now_h.time().replace(tzinfo=None)
                if now_h.weekday() < 5 and dtime(9,15) <= t <= dtime(15,30):
                    if _week_start_cash[0] > 0:
                        cur = await broker.cash()
                        weekly_dd = (_week_start_cash[0] - cur) / _week_start_cash[0]
                        if weekly_dd > WEEKLY_DD_LIMIT:
                            log.warning(f"  [HEALTH] 🚨 Weekly DD {weekly_dd:.1%} > {WEEKLY_DD_LIMIT:.0%} — HALTING")
                            await tg(
                                f"🚨 WEEKLY CIRCUIT BREAKER TRIGGERED\n"
                                f"Drawdown: {weekly_dd:.1%} from ₹{_week_start_cash[0]:.0f}\n"
                                f"Current: ₹{cur:.0f}\n"
                                f"Trading halted for the rest of this week."
                            )
                            # Sleep until Monday
                            while datetime.now(IST).weekday() < 5:
                                await asyncio.sleep(3600)
                            _week_start_cash[0] = await broker.cash()
                            log.info("  [HEALTH] New week — circuit breaker reset")

            except asyncio.CancelledError:
                break
            except Exception as e:
                log.error(f"  [HEALTH] Monitor error: {e}")

    async def _feature_importance_tracker():
        """Every 20 trades, compute which features correlate most with wins."""
        import time as _t2
        last_count = [0]
        while True:
            try:
                await asyncio.sleep(300)  # check every 5 min
                s = stats()
                if s["total"] - last_count[0] < 20:
                    continue
                last_count[0] = s["total"]
                X, y = get_td()
                if X is None or len(X) < 20:
                    continue
                # Pearson correlation of each feature with win label
                importance = {}
                for i, name in enumerate(FN):
                    xi = X[:, i]
                    yi = y[:, 0]
                    if xi.std() < 1e-8:
                        importance[name] = 0.0
                        continue
                    corr = float(np.corrcoef(xi, yi)[0, 1])
                    importance[name] = round(abs(corr), 4)
                # Sort and log top 5
                top = sorted(importance.items(), key=lambda x: -x[1])[:5]
                _feat_importance.update(importance)
                log.info(f"  [FEAT] Top predictors: {' | '.join(f'{k}={v:.3f}' for k,v in top)}")
                # Save to DB config for daily_update.py to read
                c = _db()
                c.execute("INSERT OR REPLACE INTO config VALUES(?,?)",
                          ("feat_importance", __import__("json").dumps(importance)))
                c.commit(); c.close()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.error(f"  [FEAT] Tracker error: {e}")

    # Shared daily counters (mutable lists so commodity loop can update them)
    dt_ref = [0]; dp_ref = [0.0]; dw_ref = [0]
    # Set weekly baseline
    _week_start_cash[0] = await broker.cash()
    # Shared refs for web search loop
    _spots_ref  = [[]]   # [spots_list]
    _ls_ref     = [0]    # [consecutive_losses]
    _trades_ref = [[]]   # [recent_trades_list]
    # v17: market context ref for strategy master
    _market_ctx_ref = [{}]   # [market_context_dict]

    async def options_loop():
        dt = dp = dw = 0; ls = 0; dd = datetime.now(IST).date(); start_cash = 0
        # Multi-position: dict of instrument_key → {ctx, t0, peak, partial_done}
        # Max 3 simultaneous option positions to avoid over-exposure
        OPT_MAX_POSITIONS = 3
        opt_positions = {}   # key → {"ctx":..., "t0":..., "peak":0, "partial_done":False}
        # Legacy aliases so shutdown block still works
        ctx = None; t0 = None; peak = 0; partial_done = False
        spots = []; last_iv = 20; evo_ctr = 0; cur_st = "NFM"
        scan_cycle = 0

        while True:
            try:
                now = datetime.now(IST); t = now.time().replace(tzinfo=None)

                broker.reload_token()
                await news.refresh()
                await fii_dii.refresh()
                await gift_nifty.refresh()
                await event_cal.refresh()
                await te_refresh_all()

                if now.date() != dd:
                    # BUG-G fix: snapshot and reset all counters atomically before logging.
                    # The equity/commodity loops share dt_ref/dp_ref/dw_ref; resetting them
                    # mid-loop while those loops are running could attribute a closing trade
                    # to the wrong day.  We snapshot first, then zero, so any trade that
                    # closes after this point starts accumulating cleanly from 0.
                    snap_dt = dt + dt_ref[0]
                    snap_dw = dw + dw_ref[0]
                    snap_dp = dp + dp_ref[0]
                    # Reset all counters before the log so increments after this point go to new day
                    dt = dp = dw = 0; ls = 0; dd = now.date(); start_cash = await broker.cash()
                    dt_ref[0] = 0; dp_ref[0] = 0.0; dw_ref[0] = 0
                    # Reset per-segment daily limits on new day
                    _opt_cash = segment_capital("options",   start_cash)
                    _eq_cash  = segment_capital("equity",    start_cash)
                    _com_cash = segment_capital("commodity", start_cash)
                    seg_limits.reset_day(_opt_cash, _eq_cash, _com_cash)
                    vol_spike._load()  # refresh volume averages from DB
                    log.info(f"  New day | {snap_dt}T {snap_dw}W Rs{snap_dp:.0f} (opt:{dt} eq+mcx:{dt_ref[0]})")
                    await tg(f"📅 Day ended | {snap_dt}T {snap_dw}W Rs{snap_dp:+.0f} | All-time: {stats()['total']}T")

                # Hard EOD force-exit: close ALL open option positions at 15:20 IST
                if now.weekday() < 5 and t >= dtime(15, 20) and opt_positions:
                    log.info(f"  [NSE] 15:20 EOD force-exit — closing {len(opt_positions)} position(s)")
                    for _eod_key, _eod_slot in list(opt_positions.items()):
                        _eod_ctx = _eod_slot["ctx"]
                        _eod_ik  = _eod_ctx.get("_pk", "")
                        _eod_qty = _eod_ctx.get("lot", 50)
                        _r_eod = await broker.sell(_eod_ik, _eod_qty) if not PAPER else {"status": "success"}
                        if _r_eod.get("status") == "success":
                            log.info(f"  [NSE] EOD exit OK: {_eod_ctx.get('symbol','?')}")
                            opt_positions.pop(_eod_key, None)
                        else:
                            log.error(f"  [NSE] EOD exit FAILED: {_eod_ctx.get('symbol','?')} — manual squareoff needed!")
                            await tg(f"⚠️ NSE EOD EXIT FAILED: {_eod_ctx.get('symbol','?')} — manual squareoff needed!")
                    ctx = None; t0 = None; peak = 0; partial_done = False  # clear legacy

                if not (now.weekday() < 5 and dtime(9, 16) <= t <= dtime(15, 25)):
                    await asyncio.sleep(60); continue

                if not broker.ok:
                    log.info("  No token. Login via dashboard."); await asyncio.sleep(30); continue

                if start_cash == 0: start_cash = await broker.cash()
                cur_cash = await broker.cash()
                if start_cash > 0 and ((start_cash - cur_cash) / start_cash) * 100 > C["max_dd"]:
                    log.info("  CIRCUIT BREAKER"); await asyncio.sleep(600); continue
                if ls >= C["cool_n"]: log.info(f"  Cooldown {C['cool_min']}m"); await asyncio.sleep(C["cool_min"] * 60); ls = 0; continue
                if dt >= C["max_trades"]: await asyncio.sleep(300); continue

                # ══════════ MONITOR ALL OPEN POSITIONS ══════════
                # Fetch live positions once and distribute across tracked slots
                live_pos_map = {}   # instrument_key → last_price
                if not PAPER:
                    try:
                        _live = await broker.positions()
                        for _p in _live:
                            _k = _p.get("instrument_key","") or _p.get("instrument_token","")
                            if _k: live_pos_map[_k] = _p.get("last_price", 0)
                    except Exception: pass

                _keys_to_remove = []
                for _opt_key, _slot in list(opt_positions.items()):
                    ctx         = _slot["ctx"]
                    t0          = _slot["t0"]
                    peak        = _slot["peak"]
                    partial_done= _slot["partial_done"]

                    sym = ctx.get("symbol","?")
                    qty = ctx.get("lot", 50)
                    ik  = ctx.get("_pk","")
                    bp  = ctx.get("entry_price", 0)
                    if bp <= 0: continue

                    # Get LTP — paper: chain lookup; live: from positions map
                    ltp = bp
                    if PAPER:  # PAPER-FIX: simulate realistic price movement
                        try:
                            pk = ctx.get("_pk",""); exp = ctx.get("expiry",""); ul_key = ctx.get("_ul_key","")
                            if pk and exp and ul_key:
                                cd = await broker.chain(ul_key, exp)
                                for item in cd:
                                    for side in ["call_options","put_options"]:
                                        o = item.get(side,{})
                                        if o.get("instrument_key") == pk:
                                            _chain_ltp = o.get("market_data",{}).get("ltp", 0)
                                            if _chain_ltp > 0:
                                                ltp = _chain_ltp
                                            break
                                    if ltp != bp: break
                        except Exception: pass
                        # BUG-PAPER-2 FIX: If chain lookup failed (no token / API error),
                        # simulate paper LTP using random walk + time decay instead of
                        # returning entry_price (which makes positions never exit).
                        if ltp == bp and bp > 0:
                            import random as _rng
                            # BUG-PAPER-2 FIX v2: cumulative random walk stored per-slot.
                            # Each monitoring cycle advances LTP from its previous value
                            # (not from bp), so positions can actually reach ±5-6% over
                            # 15 minutes, hitting TARGET/STOPLOSS instead of only TIMEOUT.
                            _prev_ltp = _slot.get("_sim_ltp", bp)
                            _theta_decay = 0.0005 * bp               # per-cycle theta
                            _vol_move = _prev_ltp * 0.008 * _rng.gauss(0, 1)  # 0.8% per step
                            _otype = ctx.get("otype", "CE")
                            _trend = _prev_ltp * 0.0003 * _rng.gauss(0.1 if _otype == "CE" else -0.1, 0.5)
                            ltp = max(0.05, _prev_ltp + _vol_move + _trend - _theta_decay)
                            ltp = round(ltp, 2)
                            _slot["_sim_ltp"] = ltp  # persist for next cycle
                    else:
                        ltp = live_pos_map.get(_opt_key, bp)

                    pp = ((ltp - bp) / max(0.01, bp)) * 100
                    pr = (ltp - bp) * qty
                    hld = (now - t0).total_seconds() if t0 else 0; hm = hld / 60
                    if pp > peak:
                        peak = pp
                        _slot["peak"] = peak

                    sn = ctx.get("strategy","?")
                    so = next((s for s in pool.s if s.g["name"] == sn), None)
                    tgt        = so.g["target_pct"]   if so else C["target"]
                    sl         = so.g["stoploss_pct"] if so else C["sl"]
                    use_trail  = so.g.get("use_trailing", True) if so else True
                    use_part   = so.g.get("use_partial",  True) if so else True
                    max_h      = so.g["max_hold_min"]  if so else C["max_hold"]

                    ul_tag = ctx.get("underlying","")[:12]
                    bar = "#" * min(15, max(0, int(pp * 2))) if pp > 0 else "-" * min(15, max(0, int(abs(pp) * 2)))
                    log.info(f"  {ul_tag} {sym[:20]} {bp}->{ltp} {pp:+.1f}% Rs{pr:+.0f} {hm:.0f}m [{sn}] {bar}")

                    # Partial exit
                    if use_part and not partial_done and pp >= C["partial_at"] and qty > 1:
                        pq = max(1, int(qty * C["partial_pct"] / 100))
                        r = await broker.sell(ik, pq) if not PAPER else {"status": "success"}
                        if r.get("status") == "success":
                            dp += (ltp - bp) * pq
                            _slot["partial_done"] = True
                            log.info(f"  $ Partial {pq}@+{pp:.1f}% [{sym[:15]}]")

                    ex = None
                    if pp >= tgt:                                           ex = "TARGET"
                    elif use_trail and peak >= C["trail_on"] and pp <= (peak - C["trail_dist"]): ex = "TRAIL_SL"
                    elif pp <= -sl:                                         ex = "STOPLOSS"
                    elif hm >= max_h:                                       ex = "TIMEOUT"

                    if ex:
                        ic = "+" if pp > 0 else "-"
                        r = await broker.sell(ik, qty) if not PAPER else {"status": "success"}
                        if r.get("status") == "success":
                            ch   = charges.calculate(bp, ltp, qty)
                            net  = ch["net_pnl"]; tc = ch["total_charges"]
                            won  = net > 0; dt += 1; dp += pr
                            if won: dw += 1; ls = 0
                            else:   ls += 1
                            _ls_ref[0] = ls  # sync for web search loop
                            reward = pp / 10 + (0.5 if won else -0.3)
                            ns = mstate(spots, last_iv, now.hour)
                            rl.update(cur_st, ctx.get("_ra",0), reward, ns, len(pool.alive())); rl.save(); cur_st = ns
                            port_greeks.remove(ik)
                            sig_attr.record_exit(ik, won)
                            pta.record(ex, ltp, pp, peak); pta.save()
                            if ex == "STOPLOSS":
                                reentry.record_sl(ctx.get("underlying",""), ctx.get("strike",0),
                                                  ctx.get("otype","CE"), ctx.get("entry_spot",0),
                                                  ctx.get("strategy",""))
                            seg_limits.update_pnl("options", net)
                            log.info(f"  {ic} {ex} {sym[:20]} gross={pp:+.1f}% Rs{pr:+.0f} charges=Rs{tc:.0f} net=Rs{net:+.0f} | Day:{dt}T {dw}W")
                            await tg(
                                f"{'✅ WIN' if won else '❌ LOSS'} NSE CLOSED: {sym}\n"
                                f"Entry: ₹{bp:.2f} → Exit: ₹{ltp:.2f}\n"
                                f"Gross: {pp:+.1f}% | Charges: ₹{tc:.0f} | Net: ₹{net:+.0f}\n"
                                f"Strategy: {sn} | {ex} | Day: {dt}T {dw}W"
                            )
                            ctx.update({"exit_price": ltp, "exit_reason": ex, "hold_sec": int(hld),
                                        "pnl": round(pr,2), "pnl_pct": round(pp,2), "won": 1 if won else 0,
                                        "peak_pnl": round(peak,2), "partial": 1 if _slot["partial_done"] else 0,
                                        "charges": round(tc,2), "net_pnl": round(net,2)})
                            log_trade(ctx)
                            feat = np.array(json.loads(ctx["features_json"]))
                            if len(feat) < FEAT_DIM:
                                feat = np.concatenate([feat, np.zeros(FEAT_DIM - len(feat))])
                            nn.train1(feat, 1.0 if won else 0.0); nn.save()
                            pool.update(sn, won, pp); pool.save()
                            if _OPT_INVENTOR and options_inventor is not None:
                                _greeks_pnl = {
                                    "delta": ctx.get("entry_delta", 0) * (ctx.get("exit_price", 0) - ctx.get("entry_price", 0)),
                                    "theta": ctx.get("entry_theta", 0) * (ctx.get("hold_sec", 0) / 86400),
                                    "vega":  0.0,
                                }
                                options_inventor.record_trade(sn, won, pp, _greeks_pnl)
                            Xt, yt = get_td()
                            if Xt is not None and len(Xt) >= 3:
                                if Xt.shape[1] < FEAT_DIM:
                                    Xt = np.concatenate([Xt, np.zeros((Xt.shape[0], FEAT_DIM - Xt.shape[1]))], axis=1)
                                epochs = C["nn_epochs_full"] if len(Xt) % 10 == 0 else C["nn_epochs_quick"]
                                nn.train(Xt, yt, epochs); nn.save()
                                log.info(f"  NN retrained {len(Xt)} trades ep={epochs}")
                            evo_ctr += 1
                            if evo_ctr >= C["evo_every"]: evolve(); evo_ctr = 0
                            _keys_to_remove.append(_opt_key)
                        await asyncio.sleep(1)

                for _k in _keys_to_remove:
                    opt_positions.pop(_k, None)
                # Sync legacy ctx for shutdown block
                ctx = next((s["ctx"] for s in opt_positions.values()), None)
                t0  = next((s["t0"]  for s in opt_positions.values()), None)

                # ══════════ BUY — SCAN FOR NEW OPPORTUNITIES ══════════
                # Allow new entries if below max simultaneous positions
                if len(opt_positions) >= OPT_MAX_POSITIONS:
                    await asyncio.sleep(10); continue

                cash = await broker.cash()
                if cash < 80 and not PAPER:
                    log.info(f"  Low: Rs{cash:.0f}"); await asyncio.sleep(30); continue
                if PAPER: cash = max(cash, 1.0)  # No minimum floor — use actual available margin
                # Use segment-specific allocation if set
                options_cash = segment_capital("options", cash)
                # Reduce available cash by already-committed capital in open positions
                _committed = sum(s["ctx"].get("cost",0) for s in opt_positions.values())
                options_cash = max(0, options_cash - _committed)
                if options_cash < C["min_prem"] * 50:
                    await asyncio.sleep(15); continue

                all_options = []
                scan_cycle += 1

                # Build scan list: always scan indices, rotate through FNO stocks
                scan_targets = []
                for ul in C["underlyings"]:
                    name = ul.split("|")[-1]
                    scan_targets.append((ul, name))
                if scan_cycle % 2 == 0:
                    fno_batch = get_fno_batch()
                    for stock_name, stock_key in fno_batch:
                        scan_targets.append((stock_key, stock_name))

                # Block new entries after 15:00 IST — ensures all options are intraday only
                if t >= dtime(15, 0):
                    log.info("  [NSE] Past 15:00 — no new option entries (intraday only)")
                    await asyncio.sleep(30); continue

                # Block entries near high-impact events (Finnhub + Trading Economics)
                _te_event, _te_name = te_calendar.is_high_impact_window(window_min=30)
                if event_cal.is_high_impact_now(window_min=30) or _te_event:
                    _evt_name = _te_name or "event"
                    log.info(f"  [TE/CALENDAR] High-impact event ({_evt_name}) — skipping entries")
                    await asyncio.sleep(300); continue

                # ── Re-entry check: did we just SL out of something worth retrying? ──
                if all_options and spots:
                    _reentry_opt = reentry.should_reenter(
                        pick.get("underlying","") if "pick" in dir() else "",
                        spots[-1], all_options
                    ) if ctx is None else None
                    if _reentry_opt:
                        log.info(f"  [REENTRY] Re-entering {_reentry_opt.get('underlying')} {_reentry_opt.get('strike')} {_reentry_opt.get('type')}")
                        all_options = [_reentry_opt] + all_options  # prioritise re-entry

                # Per-segment daily loss limit check
                if seg_limits.is_halted("options"):
                    log.info("  [LIMITS] Options segment HALTED for today — skipping scan")
                    await asyncio.sleep(300); continue

                skip_options = ASSET_MODE == "equity" or ASSET_MODE == "commodity"
                if skip_options:
                    log.info("  Mode: no options scan")
                    all_options = []
                if not skip_options:
                    for ul, ul_name in scan_targets:
                        try:
                            s = stats()
                            # BUG-A + BUG-D fix: derive max_premium per-underlying using a
                            # sentinel lot_size of 50 ONLY to get the first scan result, then
                            # re-filter with the actual returned lot_size.  This avoids both:
                            #   (a) the chicken-and-egg bootstrap (lot_size=50 on first call)
                            #   (b) cross-underlying contamination (using prev UL's lot_size)
                            # We do a two-pass approach: pass a neutral bet/50 to get options
                            # back with their per-expiry lot_size already set, then re-apply
                            # the correct max_premium filter using the returned nearest lot.
                            bet = kelly(s["wr"], s["aw"], s["al"], options_cash) if s["total"] >= 10 else options_cash * 0.8

                            # First pass: use 50 as sentinel; scan_multi_expiry sets o["lot_size"] per expiry
                            options, nearest_lot = await broker.scan_multi_expiry(ul, bet / max(1, 50), ul_name)

                            if options:
                                # Second pass: filter using the actual nearest_lot for this underlying
                                mp = bet / max(1, nearest_lot)
                                options = [o for o in options if o["ltp"] <= mp]
                                # Each option already has its own correct lot_size from scan_multi_expiry;
                                # do NOT overwrite it here (BUG-J fix: preserve per-expiry lot_size)
                                all_options.extend(options)

                                avg_iv = np.mean([o["iv"] for o in options[:10]]) if options else 20
                                sp = options[0]["spot"] if options else 0
                                last_iv = avg_iv
                                if sp > 0 and "INDEX" in ul:
                                    spots.append(sp); spots = spots[-30:]
                                    _spots_ref[0] = spots  # sync for web search loop
                                    # ── v17: update market context for strategy master ──
                                    _market_ctx_ref[0] = {
                                        "spot_prices": {ul: sp},
                                        "india_vix": last_iv,
                                        "pcr": 0.0,
                                        "regime": market_regime(spots, last_iv),
                                    }
                                    # ── v14 state sync ──
                                    try:
                                        import sys as _s14
                                        _am = _s14.modules.get('agent')
                                        if _am and hasattr(_am, '_v14'):
                                            _am._v14["spots"] = spots; _am._v14["iv"] = avg_iv
                                            _am._v14["losses"] = ls; _am._v14["start_cash"] = start_cash
                                            _am._v14["cur_cash"] = cur_cash
                                    except Exception:
                                        pass
                                    # VWAP update
                                    total_vol = sum(o.get("volume", 0) for o in options[:20])
                                    vwap.update(sp, max(1, total_vol))
                                    # IVP update
                                    ivp_signal.update(avg_iv)
                                    # PCR update from raw chain (Nifty only)
                                    try:
                                        raw_chain = await broker.chain(ul, options[0].get("expiry",""))
                                        if raw_chain:
                                            pcr.update(raw_chain)
                                            gex.update(raw_chain, sp, nearest_lot)
                                    except Exception:
                                        pass
                                    # OFI update on Nifty index key
                                    try:
                                        await ofi.update(broker, ul)
                                    except Exception:
                                        pass

                                log.info(f"  Scanned {ul_name}: {len(options)} opts across {C['max_expiries']} expiries (lot={nearest_lot}) PCR={pcr.pcr:.2f} IVP={ivp_signal.ivp:.0f}th")

                            await asyncio.sleep(0.5)
                        except Exception as e:
                            log.error(f"  Scan {ul_name}: {e}")

                if not all_options:
                    await asyncio.sleep(15); continue

                log.info(f"  Total: {len(all_options)} options from {len(scan_targets)} underlyings")

                # Strategy selection via RL
                cur_st = mstate(spots, last_iv, now.hour)
                exploring = stats()["total"] < C["explore"]
                alive = pool.alive()
                if not alive: seed(); alive = pool.alive()
                # BUG #8 FIX: guard against still-empty pool after seed()
                if not alive:
                    await asyncio.sleep(15); continue
                si = rl.act(cur_st, len(alive), exploring)
                strat = alive[si % len(alive)]
                matching = [o for o in all_options if strat.matches(o)]
                if not matching: strat, matching = pool.pick(all_options)
                if not strat:
                    await asyncio.sleep(15); continue

                # Score with neural net
                scored = []
                for o in matching:
                    lt = o.get("lot_size", 50)
                    if o["ltp"] * lt > cash and not PAPER: continue
                    if o["ltp"] < C["min_prem"]: continue
                    f = feats(o, cash, lt)
                    prob = nn.predict(f) if not exploring else 0.3 + abs(o.get("delta", 0)) * 0.8 + random.uniform(-0.05, 0.05)
                    profitable, ch_info = charges.is_profitable_trade(o["ltp"], strat.g["target_pct"], lt)
                    if not profitable: continue
                    be_pct = ch_info["breakeven_pct"]
                    if be_pct > strat.g["target_pct"] * 0.4: continue
                    nb = news.bias_for(o.get("underlying", ""), o.get("type", "CE"))
                    # Alpha signals: PCR + IVP + GEX + OFI + FII + Gift + correlation + slippage
                    _open_uls = list(set([ctx.get("underlying","") if ctx else ""] + ["CRUDEOILM","GOLDPETAL","NATGASMINI"]))
                    alpha    = compute_alpha_score(o, _open_uls)
                    # Trading Economics macro alpha
                    te_alpha = compute_te_alpha(o.get("type","CE"), o.get("underlying",""))
                    # Web search market brief bias (key levels + sentiment)
                    search_bias = get_search_bias(o.get("spot", 0), o.get("type","CE"))
                    prob = max(0, min(1, prob + nb + alpha + te_alpha + search_bias))
                    o["_p"] = prob; o["_f"] = f.tolist(); o["_be"] = be_pct; o["_ch"] = ch_info["total_charges"]; scored.append(o)

                if not scored:
                    await asyncio.sleep(15); continue

                # ── REGIME + DIRECTION BIAS ──
                regime = market_regime(spots, last_iv)
                regime_filtered = [o for o in scored if regime_strategy_filter(regime, o.get("type","CE"))]
                if regime_filtered: scored = regime_filtered

                if len(spots) >= 3:
                    recent_chg = (spots[-1] - spots[-3]) / max(1, spots[-3]) * 100
                    if recent_chg > 0.3:
                        ce_scored = [o for o in scored if o.get("type") == "CE"]
                        if ce_scored: scored = ce_scored
                    elif recent_chg < -0.3:
                        pe_scored = [o for o in scored if o.get("type") == "PE"]
                        if pe_scored: scored = pe_scored

                scored.sort(key=lambda x: x["_p"], reverse=True)
                pick = scored[0]
                lt = pick.get("lot_size", 50)

                if not exploring and pick["_p"] < C["nn_thr"]:
                    rl.update(cur_st, si, -0.1, cur_st, len(alive)); await asyncio.sleep(10); continue

                # Scale position size for event calendar + TE macro risk
                _cal_mult = min(event_cal.risk_multiplier, te_position_multiplier())
                if _cal_mult < 1.0:
                    lt = max(1, int(lt * _cal_mult))
                    log.info(f"  [TE/CALENDAR] Position sized to {_cal_mult:.0%}")
                cost = pick["ltp"] * lt
                dte_str = f"DTE={pick.get('dte', '?')}"
                ul_str  = pick.get("underlying", "?")

                # ── Multi-leg trading DISABLED — single-leg only ──
                # All options trades are single-leg naked CE/PE buys.
                stype = "single"   # Force single-leg path always
                MULTILEG_TYPES = set()  # Empty set — multileg never triggers

                if stype in MULTILEG_TYPES and cash >= strat.g.get("min_capital", 5000):
                    # Fetch full chain for multi-leg setup
                    try:
                        ul_key = pick.get("ul_key", "")
                        exp    = pick.get("expiry", "")
                        chain_raw = await broker.chain(ul_key, exp) if ul_key and exp else []
                        # Flatten chain into list of options dicts (same format as scan())
                        flat_chain = []
                        for item in chain_raw:
                            sp = item.get("underlying_spot_price", 0)
                            st_p = item.get("strike_price", 0)
                            for side, ot in [("call_options", "CE"), ("put_options", "PE")]:
                                o = item.get(side, {}); mk = o.get("market_data", {}); gk = o.get("option_greeks", {})
                                ltp_c = mk.get("ltp", 0); vol_c = mk.get("volume", 0)
                                if ltp_c > 0:
                                    flat_chain.append({
                                        "key": o.get("instrument_key", ""), "strike": st_p, "type": ot,
                                        "ltp": ltp_c, "volume": vol_c, "oi": mk.get("oi", 0),
                                        "delta": gk.get("delta", 0), "gamma": gk.get("gamma", 0),
                                        "theta": gk.get("theta", 0), "iv": gk.get("iv", 0),
                                        "spot": sp, "otm_pct": round(abs(st_p - sp) / max(1, sp) * 100, 2),
                                    })
                        spot = flat_chain[0]["spot"] if flat_chain else 0
                        avg_iv = np.mean([o["iv"] for o in flat_chain[:10]]) if flat_chain else last_iv
                        setup = find_best_multileg(flat_chain, spot, cash, lt,
                                                   sentiment=news.score, iv=avg_iv)
                    except Exception as _ml_e:
                        log.error(f"  Multileg setup error: {_ml_e}")
                        setup = None

                    if setup:
                        log.info(f"  >> MULTILEG [{strat.g['name']}] {setup['strategy_name']} {ul_str} "
                                 f"strikes={setup['strikes']} cost=Rs{setup['cost']:.0f} RR={setup.get('risk_reward',0):.2f}")
                        r = await place_multileg_order(broker, setup, paper=PAPER)
                        if r.get("status") == "success":
                            t0 = now; peak = 0; partial_done = False
                            # Store legs in ctx for multi-leg exit tracking
                            ctx = {"ts": now.isoformat(),
                                "symbol": f"{ul_str} {setup['strikes']} {setup['strategy_name']}",
                                "strike": setup["legs"][0].get("strike", 0), "otype": strat.g["option_type"],
                                "asset": "option", "underlying": ul_str, "expiry": exp,
                                "strategy": strat.g["name"],
                                "entry_price": setup.get("net_debit", setup.get("net_credit", 0)),
                                "entry_delta": 0, "entry_gamma": 0, "entry_theta": 0,
                                "entry_iv": avg_iv if flat_chain else 0,
                                "entry_volume": 0, "entry_oi": 0, "entry_otm": 0,
                                "entry_spot": spot, "entry_hour": now.hour,
                                "lot": lt, "cost": round(setup["cost"], 2),
                                "capital_pct": round(setup["cost"] / max(1, cash) * 100, 1),
                                "exit_price": 0, "exit_reason": "", "hold_sec": 0,
                                "pnl": 0, "pnl_pct": 0, "won": 0,
                                "nn_prob": round(pick["_p"], 3), "rl_state": cur_st, "rl_action": si,
                                "features_json": json.dumps(pick["_f"]), "strat_gen": strat.g["generation"],
                                "peak_pnl": 0, "partial": 0, "charges": 0, "net_pnl": 0,
                                "_ra": si, "_pk": setup["legs"][0]["key"], "_ul_key": ul_key,
                                "_ml_legs": setup["legs"],  # stored for multi-leg exit
                                "_ml_setup": setup["strategy_name"],
                            }
                            await tg(
                                f"🛒 MULTILEG ENTRY: {ul_str} {setup['strategy_name']}\n"
                                f"Strikes: {setup['strikes']} | Cost: ₹{setup['cost']:.0f}\n"
                                f"MaxProfit: ₹{setup['max_profit']:.0f} | MaxLoss: ₹{setup['max_loss']:.0f}\n"
                                f"Strategy: {strat.g['name']} | {'PAPER' if PAPER else 'LIVE'}"
                            )
                        else:
                            err = (r.get("errors") or [{}])[0].get("message", str(r))
                            log.error(f"  Multileg buy fail: {err}")
                        await asyncio.sleep(15)
                        continue
                    else:
                        log.info(f"  No multileg setup found for {stype}, falling back to single-leg")
                        # Fall through to single-leg below

                # ── Single-leg buy (default path) ──
                log.info(f"  >> [{strat.g['name']}] {ul_str} {pick['strike']} {pick['type']} Rs{pick['ltp']}x{lt}=Rs{cost:.0f} d={pick.get('delta',0):.2f} P={pick['_p']:.0%} {dte_str}")

                r = await broker.buy(pick["key"], lt)
                if r.get("status") == "success":
                    t0 = now; peak = 0; partial_done = False
                    # Bug #1 fix: use actual fill price in live mode
                    entry_price = pick["ltp"]
                    if not PAPER:
                        try:
                            fill_p, _ = await broker.last_fill()
                            if fill_p > 0:
                                slippage.record(pick.get("underlying",""), pick["ltp"], fill_p)
                                entry_price = fill_p
                        except Exception:
                            pass
                    cost = entry_price * lt
                    # Track portfolio greeks
                    port_greeks.add(
                        pick["key"],
                        pick.get("delta", 0.3), pick.get("gamma", 0), pick.get("theta", 0),
                        lt, "option"
                    )
                    # Signal attribution snapshot at entry
                    sig_attr.record_entry(pick["key"], {
                        "pcr":        pcr.signal != "NEUTRAL",
                        "ivp":        ivp_signal.ivp < 40,
                        "gex":        gex.total_gex < 0,
                        "ofi":        abs(ofi.ofi) > 0.2,
                        "fii_dii":    fii_dii.signal_str != "NEUTRAL",
                        "gift_nifty": abs(gift_nifty.gap_pct) > 0.2,
                        "regime":     regime != "RANGING",
                        "news":       abs(news.score) > 0.1,
                        "vol_spike":  vol_spike.spike_factor(pick.get("underlying",""), pick.get("volume",0)) > 2,
                        "vwap":       vwap.position(pick.get("spot",0)) != "AT",
                        "te_macro":   abs(india_macro.macro_score) > 0.10,
                        "te_markets": abs(te_markets.bias) > 0.05,
                        "te_bonds":   india_bonds.trend != "STABLE",
                        "te_news":    abs(te_news.score) > 0.15,
                        "te_calendar":len(te_calendar.today_high) > 0,
                    })
                    _new_ctx = {"ts": now.isoformat(), "symbol": f"{ul_str} {pick['strike']} {pick['type']}",
                        "strike": pick["strike"], "otype": pick["type"], "asset": "option",
                        "underlying": ul_str, "expiry": pick.get("expiry", ""), "strategy": strat.g["name"],
                        "entry_price": entry_price, "entry_delta": abs(pick.get("delta", 0)),
                        "entry_gamma": abs(pick.get("gamma", 0)), "entry_theta": abs(pick.get("theta", 0)),
                        "entry_iv": pick.get("iv", 0), "entry_volume": pick.get("volume", 0),
                        "entry_oi": pick.get("oi", 0), "entry_otm": pick.get("otm_pct", 0),
                        "entry_spot": pick.get("spot", 0), "entry_hour": now.hour,
                        "lot": lt, "cost": cost, "capital_pct": round(cost / max(1, cash) * 100, 1),
                        "exit_price": 0, "exit_reason": "", "hold_sec": 0, "pnl": 0, "pnl_pct": 0, "won": 0,
                        "nn_prob": round(pick["_p"], 3), "rl_state": cur_st, "rl_action": si,
                        "features_json": json.dumps(pick["_f"]), "strat_gen": strat.g["generation"],
                        "peak_pnl": 0, "partial": 0, "charges": 0, "net_pnl": 0,
                        "_ra": si, "_pk": pick["key"], "_ul_key": pick.get("ul_key", "")}
                    # Store in multi-position dict AND keep legacy ctx for backward compat
                    opt_positions[pick["key"]] = {"ctx": _new_ctx, "t0": now, "peak": 0, "partial_done": False}
                    ctx = _new_ctx; t0 = now; peak = 0; partial_done = False  # legacy
                    log.info(f"  OK T:+{strat.g['target_pct']}% SL:-{strat.g['stoploss_pct']}% Trail:{'Y' if strat.g.get('use_trailing') else 'N'} Exp:{pick.get('expiry','?')}")
                    await tg(
                        f"🛒 NSE ENTRY: {ul_str} {pick['strike']} {pick['type']}\n"
                        f"Price: ₹{pick['ltp']} x {lt} lots = ₹{cost:.0f}\n"
                        f"Strategy: {strat.g['name']} | P={pick['_p']:.0%} | {dte_str}\n"
                        f"Target: +{strat.g['target_pct']}% | SL: -{strat.g['stoploss_pct']}% | {'PAPER' if PAPER else 'LIVE'}"
                    )
                else:
                    err = (r.get("errors") or [{}])[0].get("message", str(r))
                    log.error(f"  Buy fail: {err}")

                await asyncio.sleep(15)
                await asyncio.sleep(2)

            except KeyboardInterrupt:
                s = stats()
                log.info(f"\n  STOPPED | {dt}T {dw}W Rs{dp:.0f}")
                log.info(f"  All: {s['total']}T {s['wr']}%WR Rs{s['pnl']}")
                await tg(f"🛑 Agent stopped | Day: {dt}T {dw}W ₹{dp:+.0f}")
                break
            except asyncio.CancelledError:
                # Triggered by SIGTERM (PM2 stop) — break cleanly so finally block runs
                break
            except Exception as e: log.error(f"  ERR: {e}"); await asyncio.sleep(5)
        # ── options_loop shutdown: close ALL open option positions ──
        if opt_positions:
            log.info(f"  [SHUTDOWN] Closing {len(opt_positions)} open option position(s)...")
            for _sd_key, _sd_slot in list(opt_positions.items()):
                try:
                    _sd_ctx = _sd_slot["ctx"]
                    _sd_ik  = _sd_ctx.get("_pk","")
                    _sd_qty = _sd_ctx.get("lot", 50)
                    _sd_sym = _sd_ctx.get("symbol","?")
                    if _sd_ik:
                        r = await broker.sell(_sd_ik, _sd_qty) if not PAPER else {"status":"success"}
                    else:
                        r = {"status":"skip"}
                    log.info(f"  [SHUTDOWN] Options exit {_sd_sym}: {r.get('status','?')}")
                    await tg(f"🛑 SHUTDOWN EXIT: {_sd_sym} | {'PAPER' if PAPER else 'LIVE'}")
                except Exception as e:
                    log.error(f"  [SHUTDOWN] Options exit failed: {e}")

    # ═══════════════════════ EMERGENCY EXIT — ALL SEGMENTS ═══════════════════════

    async def emergency_exit_all():
        """
        Called on any shutdown (SIGTERM from PM2, KeyboardInterrupt, unhandled crash).
        Closes open positions across all three segments: options, equity, MCX.
        Reads live broker positions as a fallback in case in-memory ctx was lost.
        """
        log.info("  [SHUTDOWN] Emergency exit — closing all open positions")
        await tg("⚠️ Agent shutting down — closing all open positions")
        errors = []

        # 1. Options/multileg — handled inside options_loop() finally block above.
        #    Here we fall back to the broker positions API to catch anything missed.
        try:
            positions = await broker.positions()
            for p in positions:
                key = p.get("instrument_token", "") or p.get("instrument_key", "")
                qty = p.get("quantity", 0)
                sym = p.get("trading_symbol", key)
                if not key or qty <= 0:
                    continue
                log.info(f"  [SHUTDOWN] Broker position found: {sym} qty={qty} — selling")
                try:
                    r = await broker.sell(key, qty)
                    log.info(f"  [SHUTDOWN] Sold {sym}: {r.get('status','?')}")
                    await tg(f"🛑 CLOSED {sym} qty={qty} | {r.get('status','?')}")
                except Exception as e:
                    msg = f"Failed to close {sym}: {e}"
                    log.error(f"  [SHUTDOWN] {msg}"); errors.append(msg)
        except Exception as e:
            log.error(f"  [SHUTDOWN] Broker positions fetch failed: {e}")

        # 2. MCX — use commodity loop's shared context via mcx_inst if available
        if COMMODITY_ENABLED:
            try:
                from commodity_futures import exit_commodity as _exit_comm
                positions = await broker.positions()
                for p in positions:
                    key = p.get("instrument_token", "") or p.get("instrument_key", "")
                    qty = p.get("quantity", 0)
                    sym = p.get("trading_symbol", key)
                    if not key or qty <= 0:
                        continue
                    # MCX instruments contain "MCX" in their key
                    if "MCX" not in key.upper():
                        continue
                    log.info(f"  [SHUTDOWN] MCX position: {sym} qty={qty}")
                    for attempt in range(3):
                        try:
                            r = await _exit_comm(broker, key, qty, "BUY", paper=PAPER)
                            if r.get("status") == "success":
                                log.info(f"  [SHUTDOWN] MCX closed {sym}")
                                await tg(f"🛑 MCX CLOSED {sym} qty={qty}")
                                break
                        except Exception as e:
                            log.error(f"  [SHUTDOWN] MCX exit attempt {attempt+1} for {sym}: {e}")
                            await asyncio.sleep(1)
            except Exception as e:
                log.error(f"  [SHUTDOWN] MCX emergency exit error: {e}")

        if errors:
            await tg(f"⚠️ Shutdown errors — manual check needed:\n" + "\n".join(errors))
        else:
            log.info("  [SHUTDOWN] All positions closed cleanly")
            await tg("✅ All positions closed. Agent offline.")

    # ── Wire up SIGTERM so PM2 stop / kill triggers graceful exit ──
    import signal as _signal

    _shutdown_event = asyncio.Event()

    def _handle_sigterm(*_):
        log.info("  SIGTERM received — initiating graceful shutdown")
        _shutdown_event.set()

    try:
        loop = asyncio.get_event_loop()
        loop.add_signal_handler(_signal.SIGTERM, _handle_sigterm)
        loop.add_signal_handler(_signal.SIGINT,  _handle_sigterm)
    except (NotImplementedError, RuntimeError):
        pass  # Termux / Windows may not support add_signal_handler

    async def _watchdog():
        """Waits for shutdown signal, then cancels all loops."""
        await _shutdown_event.wait()
        log.info("  [SHUTDOWN] Shutdown signal received — cancelling loops")
        for task in asyncio.all_tasks():
            if task is not asyncio.current_task():
                task.cancel()

    # Run options loop + equity loop + commodity loop + watchdog concurrently
    try:
        await asyncio.gather(
            options_loop(),
            run_equity_loop(dt_ref, dp_ref, dw_ref),
            run_commodity_loop(dt_ref, dp_ref, dw_ref),
            run_commodity_options_loop(dt_ref, dp_ref, dw_ref),
            _watchdog(),
            _health_monitor(),
            _feature_importance_tracker(),
            run_weekly_hyperparameter_search(FEAT_DIM),
            run_nightly_reconciliation(broker),
            run_signal_attribution_logger(),
            run_search_loop(_spots_ref, _ls_ref, _trades_ref),
            run_strategy_master_loop(_market_ctx_ref) if _MASTER and run_strategy_master_loop else asyncio.sleep(0),
            return_exceptions=True,  # don't let one cancellation kill the gather immediately
        )
    except (asyncio.CancelledError, KeyboardInterrupt):
        pass
    finally:
        # Always attempt to close positions on any exit path
        try:
            await emergency_exit_all()
        except Exception as e:
            log.error(f"  [SHUTDOWN] emergency_exit_all failed: {e}")

# ═══════════════════════ CLI ═══════════════════════

def cmd_stats():
    init_db(); nn.load(); rl.load(); pool.load()
    s = stats()
    print(f"\n{'='*60}")
    print(f"  FINANCEAGI v{VERSION} | {s['total']}T {s['wins']}W {s['wr']}%WR Rs{s['pnl']}")
    print(f"  NN:{nn.cnt} samples ({FEAT_DIM} features) | RL:{rl.ep} episodes reward={rl.r:.1f}")
    print(f"  Strategies: {len(pool.alive())} alive, {len(pool.dead)} dead")
    print(f"  Scanning: {len(C['underlyings'])} indices + {len(FNO_STOCKS)} FNO stocks, {C['max_expiries']} expiries")
    print(f"  MCX commodities: {'ENABLED' if COMMODITY_ENABLED else 'DISABLED'}")
    if _MASTER and strategy_master:
        print(f"  {strategy_master.status_line()}")
    if _OPT_INVENTOR and options_inventor:
        print(f"  Options Inventor: {options_inventor.status()}")
    if _EQ_INVENTOR and equity_inventor:
        print(f"  Equity Inventor:  {equity_inventor.status()}")
    if s.get("strats"):
        print(f"\n  Performance:")
        for n, d in sorted(s["strats"].items(), key=lambda x: -(x[1]["p"] or 0)):
            # Bug #14 fix: d["w"] is None when a strategy has zero wins (SQLite
            # SUM returns NULL on empty sets).  Guard with `or 0` before dividing.
            wr = round((d["w"] or 0) / max(1, d["n"]) * 100, 1)
            print(f"    {n:25s} {d['n']}T {wr}%WR Rs{d['p'] or 0}")
    print(f"\n  Strategy DNA:")
    for st in pool.alive():
        g = st.g
        exp_tag = g.get('prefer_expiry', 'any')
        ul_tag  = g.get('prefer_underlying', 'any')
        print(f"  {'*' if g['testing'] else '>'} {g['name']:22s} {g['option_type']:4s} d={g['delta_min']}-{g['delta_max']} T={g['target_pct']}% SL={g['stoploss_pct']}% exp={exp_tag} ul={ul_tag} {g['trades']}T {st.wr}%")
    imp = nn.importance()
    if imp:
        print(f"\n  Features:")
        for n, v in sorted(imp.items(), key=lambda x: -x[1])[:8]:
            print(f"    {n:12s} {'#'*int(v/3)} {v:.0f}%")
    c = _db(); recent = c.execute("SELECT * FROM trades ORDER BY id DESC LIMIT 5").fetchall(); c.close()
    if recent:
        print(f"\n  Recent:")
        for _r in recent:
            t = dict(_r)
            print(f"    {'W' if t['won'] else 'L'} {t['strategy']:20s} {t['otype']} {t.get('underlying','?')[:12]} P={t['nn_prob']:.0%} pnl={t['pnl_pct']:+.1f}% Rs{t['pnl']:+.0f} {t['exit_reason']}")
    print()

def cmd_reset():
    init_db(); c = _db(); c.execute("DELETE FROM trades"); c.execute("DELETE FROM config"); c.execute("DELETE FROM spots"); c.commit(); c.close()
    for p in [NN_F, RL_F, ST_F]:
        if os.path.exists(p): os.remove(p)
    print("  Reset done. NN, RL, strategies, and trades wiped.")

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "run"
    {"stats": cmd_stats, "reset": cmd_reset}.get(cmd, lambda: asyncio.run(run()))()
