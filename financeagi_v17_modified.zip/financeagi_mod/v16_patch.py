#!/usr/bin/env python3
"""
v16_patch.py — FinanceAGI v16 Commodity Strategy Upgrade Patch

DROP-IN patch. Does NOT modify agent.py.

Hooks added:
  1. Extended commodity symbol list (8 symbols, was 3)
  2. Strategy-aware scanner (12 strategies via STRATEGY_CATALOGUE)
  3. Commodity Strategy Manager (invention, pruning, evolution)
  4. On every MCX trade close → records to DB, triggers evolution when due
  5. Daily report from strategy manager injected into Telegram digest

Usage in agent.py (add these calls):
    # At startup (after mcx_inst.refresh()):
    from v16_patch import init_v16, on_commodity_trade_closed, commodity_evolution_hook
    await init_v16(broker)

    # After every MCX trade closes (in your position monitor):
    await on_commodity_trade_closed(trade_dict)

    # In your daily background task:
    await commodity_evolution_hook(force=False)
"""

import asyncio, logging
from pathlib import Path

log = logging.getLogger("agi.v16")

# ── Lazy imports to avoid circular deps ──────────────────────────────────────

def _get_mgr():
    from commodity_strategy_manager import strat_mgr, seed_builtin_strategies
    return strat_mgr, seed_builtin_strategies

def _get_mcx():
    from commodity_futures import mcx_inst, scan_commodities, COMMODITY_META, list_strategies
    return mcx_inst, scan_commodities, COMMODITY_META, list_strategies


async def init_v16(broker=None):
    """
    Call at agent startup.
    - Seeds built-in strategies into DB
    - Refreshes MCX instrument keys for all 8 symbols
    - Logs strategy catalogue
    """
    log.info("  [v16] Initialising v16 commodity upgrade...")

    strat_mgr, seed_builtin_strategies = _get_mgr()
    seed_builtin_strategies()
    strat_mgr._refresh()

    mcx_inst, _, COMMODITY_META, list_strategies = _get_mcx()
    if broker:
        await mcx_inst.refresh(broker)

    active = sum(1 for s in strat_mgr.strategies if s.get("status") in ("active", "proven"))
    log.info(f"  [v16] {len(COMMODITY_META)} commodity symbols | {active} active strategies")
    log.info(list_strategies())
    log.info("  [v16] Commodity Strategy Manager ready")


async def on_commodity_trade_closed(trade: dict):
    """
    Call after every MCX futures trade closes.

    trade dict (required fields):
        strategy:     str   — strategy ID
        symbol:       str   — MCX symbol
        direction:    str   — BUY | SELL
        entry_price:  float
        exit_price:   float
        qty:          int
        gross_pnl:    float
        net_pnl:      float
        hold_min:     float — minutes held
        won:          bool | int
    """
    strat_mgr, _ = _get_mgr()
    await strat_mgr.on_trade_closed(trade)

    # Trigger evolution if trade count milestone reached
    from commodity_strategy_manager import INVENT_EVERY_N_TRADES
    if strat_mgr.trade_count % INVENT_EVERY_N_TRADES == 0:
        log.info(f"  [v16] Trade count {strat_mgr.trade_count} — triggering evolution")
        asyncio.create_task(strat_mgr.run_evolution_cycle())


async def commodity_evolution_hook(force: bool = False) -> dict:
    """
    Call from daily background task.
    Runs prune → promote → invent if due.
    Returns evolution summary.
    """
    strat_mgr, _ = _get_mgr()
    if force:
        return await strat_mgr.run_evolution_cycle()
    else:
        # Only invent if due; still prune/promote always
        killed   = strat_mgr.prune_losers()
        promoted = strat_mgr.promote_proven()
        invented = await strat_mgr.run_invention_cycle(force=False)
        return {"killed": killed, "promoted": promoted, "invented": invented}


async def commodity_daily_report() -> str:
    """Generate and return the LLM strategy daily report for Telegram."""
    strat_mgr, _ = _get_mgr()
    return await strat_mgr.daily_report()


def commodity_status() -> str:
    """Return formatted strategy status table (for Telegram or logs)."""
    strat_mgr, _ = _get_mgr()
    return strat_mgr.status_table()


async def scan_with_strategies(broker, cash: float, **kwargs) -> list:
    """
    Strategy-aware MCX scan that also enriches with invented strategy params.
    Drop-in replacement for scan_commodities() in agent.py.
    """
    _, scan_commodities, _, _ = _get_mcx()
    strat_mgr, _              = _get_mgr()

    opps = await scan_commodities(broker, cash, **kwargs)

    # Enrich with DB strategy params (invented strategies override defaults)
    enriched = [strat_mgr.enrich_opportunity(o) for o in opps]
    return enriched


if __name__ == "__main__":
    import sys
    asyncio.run(init_v16())
    strat_mgr, _ = _get_mgr()
    print(strat_mgr.status_table())
