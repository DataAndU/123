#!/usr/bin/env python3
"""
qwen_engine.py — FinanceAGI v16: Dedicated Qwen 2.5 Engine
============================================================

Qwen 2.5 (via local Ollama) is a FIRST-CLASS inference engine in this system,
not just a fallback.  Each task is routed to the model best suited for it:

  Task                          Qwen 2.5:3b     Claude (API)
  ─────────────────────────────────────────────────────────────
  Intraday trade commentary     ✓ PRIMARY       ✗ too slow/expensive
  MCX candle pattern read       ✓ PRIMARY       ✗ —
  Daily param tuning            ✓ PRIMARY       ✓ (used if Qwen offline)
  Strategy invention            ✗ (too small)   ✓ PRIMARY
  Web search summarisation      ✓ PRIMARY       ✓ (if Qwen offline)
  Market regime classification  ✓ PRIMARY       ✗ —
  Post-trade rationale          ✓ PRIMARY       ✗ —
  Weekly performance review     ✓ CO-PRIMARY    ✓ CO-PRIMARY

Architecture:
  QwenClient          — raw HTTP wrapper around Ollama /api/generate
  QwenTasks           — structured tasks returning typed dicts
  QwenCommentator     — live trade commentary streamed to Telegram
  QwenRegimeDetector  — classifies market regime every N minutes
  QwenParamAdvisor    — real-time (not just daily) parameter suggestions

Integration:
  agent.py:
    from qwen_engine import qwen, qwen_commentator, qwen_regime
    # On entry:
    asyncio.ensure_future(qwen_commentator.on_entry(pick))
    # Every 15 min:
    regime = await qwen_regime.classify(spot, vix, breadth)

  daily_update.py:
    from qwen_engine import qwen_tasks
    suggestions = qwen_tasks.daily_param_tune(stats)

  strategy_inventor.py:
    from qwen_engine import qwen_tasks
    rationale = qwen_tasks.explain_strategy(strat_dict)

Usage (standalone):
  python3 qwen_engine.py ping            # Check Ollama is reachable
  python3 qwen_engine.py regime          # Classify regime with dummy data
  python3 qwen_engine.py commentary      # Generate example trade commentary
  python3 qwen_engine.py tune            # Run param tuning on live DB
  python3 qwen_engine.py chat "..."      # Free-form chat with Qwen

Environment variables:
  OLLAMA_HOST         default http://localhost:11434
  OLLAMA_MODEL        default qwen2.5:3b
  QWEN_TIMEOUT        default 90 (seconds)
  QWEN_MAX_TOKENS     default 512
"""

import asyncio
import json
import logging
import os
import sqlite3
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

log = logging.getLogger("agi.qwen")
IST  = timezone(timedelta(hours=5, minutes=30))
BASE = Path(__file__).resolve().parent
DB   = str(BASE / "data" / "v10.db")

# ── Load environment ───────────────────────────────────────────────────────────
def _env(key: str, default: str = "") -> str:
    ef = BASE / ".env"
    if ef.exists():
        for ln in ef.read_text().splitlines():
            ln = ln.strip()
            if ln and not ln.startswith("#") and "=" in ln:
                k, v = ln.split("=", 1)
                if k.strip() == key:
                    return v.strip()
    return os.environ.get(key, default)

OLLAMA_HOST   = _env("OLLAMA_HOST",  "http://localhost:11434")
OLLAMA_MODEL  = _env("OLLAMA_MODEL", "qwen2.5:3b")
QWEN_TIMEOUT  = int(_env("QWEN_TIMEOUT",  "90"))
QWEN_MAX_TOKENS = int(_env("QWEN_MAX_TOKENS", "512"))


# ═══════════════════════ RAW CLIENT ════════════════════════════════════════════

class QwenClient:
    """
    Thin wrapper around the Ollama /api/generate endpoint.
    Supports both synchronous (generate) and async (agenerate) calls.
    """

    def __init__(
        self,
        host: str  = OLLAMA_HOST,
        model: str = OLLAMA_MODEL,
        timeout: int = QWEN_TIMEOUT,
    ):
        self.host    = host.rstrip("/")
        self.model   = model
        self.timeout = timeout
        self._available: bool | None = None   # None = not yet checked
        self._last_health_check: float = 0.0
        self._call_count  = 0
        self._error_count = 0
        self._total_ms    = 0.0

    # ── Availability ──────────────────────────────────────────────────────────

    def ping(self) -> bool:
        """Returns True if Ollama is up and the model is loaded."""
        try:
            req = urllib.request.Request(
                f"{self.host}/api/tags",
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=5) as r:
                data = json.loads(r.read())
            models = [m.get("name", "") for m in data.get("models", [])]
            # Accept both "qwen2.5:3b" and "qwen2.5:latest" etc.
            base = self.model.split(":")[0]
            available = any(base in m for m in models)
            self._available = available
            self._last_health_check = time.time()
            if available:
                log.debug(f"  [QWEN] ping OK — model={self.model} host={self.host}")
            else:
                log.warning(f"  [QWEN] Ollama up but model '{self.model}' not found. "
                            f"Available: {models}")
            return available
        except Exception as e:
            log.warning(f"  [QWEN] ping failed: {e}")
            self._available = False
            self._last_health_check = time.time()
            return False

    def is_available(self) -> bool:
        """Cached availability check — re-pings every 5 minutes."""
        if (time.time() - self._last_health_check) > 300:
            self.ping()
        return bool(self._available)

    # ── Synchronous generate ──────────────────────────────────────────────────

    def generate(
        self,
        prompt: str,
        system: str = "",
        temperature: float = 0.2,
        max_tokens: int = QWEN_MAX_TOKENS,
        json_mode: bool = False,
    ) -> str:
        """
        Send a prompt to Qwen and return the text response.
        Returns "" on any error (never raises).
        """
        if not self.is_available():
            log.debug("  [QWEN] generate skipped — model unavailable")
            return ""

        payload: dict[str, Any] = {
            "model":  self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature":  temperature,
                "num_predict":  max_tokens,
                "top_p":        0.9,
                "repeat_penalty": 1.1,
            },
        }
        if system:
            payload["system"] = system
        if json_mode:
            payload["format"] = "json"

        data = json.dumps(payload).encode()
        req  = urllib.request.Request(
            f"{self.host}/api/generate",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        t0 = time.time()
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                raw = json.loads(r.read())
            elapsed = int((time.time() - t0) * 1000)
            self._call_count  += 1
            self._total_ms    += elapsed
            text = raw.get("response", "").strip()
            log.debug(f"  [QWEN] {elapsed}ms | tokens≈{len(text.split())} | prompt_words={len(prompt.split())}")
            return text
        except urllib.error.URLError as e:
            self._error_count += 1
            self._available = False
            log.warning(f"  [QWEN] URLError: {e}")
            return ""
        except Exception as e:
            self._error_count += 1
            log.warning(f"  [QWEN] generate error: {e}")
            return ""

    # ── Async generate ────────────────────────────────────────────────────────

    async def agenerate(
        self,
        prompt: str,
        system: str = "",
        temperature: float = 0.2,
        max_tokens: int = QWEN_MAX_TOKENS,
        json_mode: bool = False,
    ) -> str:
        """Async wrapper — runs generate in a thread pool to avoid blocking."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.generate(prompt, system, temperature, max_tokens, json_mode),
        )

    # ── JSON helper ───────────────────────────────────────────────────────────

    def generate_json(self, prompt: str, system: str = "", **kwargs) -> dict:
        """
        Call Qwen requesting JSON output.
        Strips any markdown fences and parses.  Returns {} on failure.
        """
        raw = self.generate(prompt, system=system, json_mode=True, **kwargs)
        if not raw:
            return {}
        # Strip markdown fences
        text = raw.strip()
        if "```" in text:
            for part in text.split("```"):
                part = part.strip().lstrip("json").strip()
                if part.startswith("{"):
                    text = part
                    break
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # Try to extract first {...} block
            start = text.find("{")
            end   = text.rfind("}")
            if start != -1 and end != -1 and end > start:
                try:
                    return json.loads(text[start:end+1])
                except Exception:
                    pass
            log.debug(f"  [QWEN] JSON parse failed. Raw: {raw[:200]}")
            return {}

    async def agenerate_json(self, prompt: str, system: str = "", **kwargs) -> dict:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.generate_json(prompt, system=system, **kwargs),
        )

    # ── Stats ─────────────────────────────────────────────────────────────────

    def status_line(self) -> str:
        avg_ms = int(self._total_ms / max(1, self._call_count))
        return (
            f"[QWEN] {self.model}@{self.host} | "
            f"calls={self._call_count} errors={self._error_count} "
            f"avg={avg_ms}ms | available={self._available}"
        )


# Module-level singleton
qwen = QwenClient()


# ═══════════════════════ STRUCTURED TASKS ══════════════════════════════════════

class QwenTasks:
    """
    Named, typed tasks that agent.py and daily_update.py call.
    Each method has a clear input/output contract and never raises.
    """

    SYSTEM_TRADER = (
        "You are a concise quantitative trading assistant for Indian NSE/MCX markets. "
        "You give brief, actionable, data-driven answers. "
        "Never add disclaimers, caveats, or pleasantries. "
        "When returning JSON, return ONLY the JSON object — no markdown, no explanation."
    )

    def __init__(self, client: QwenClient):
        self.q = client

    # ── 1. Trade commentary ───────────────────────────────────────────────────

    def trade_commentary(self, pick: dict, action: str = "ENTRY") -> str:
        """
        Generate a 1-2 sentence commentary for a trade entry or exit.
        Returns "" if Qwen is unavailable.

        pick fields used: symbol, direction, ltp, target_pct, sl_pct,
                          day_change_pct, range_pct, strat_name, session
        """
        sym    = pick.get("symbol", "?")
        dir_   = pick.get("direction", "BUY")
        ltp    = pick.get("ltp", 0)
        tgt    = pick.get("target_pct", 1.0)
        sl     = pick.get("sl_pct", 0.6)
        chg    = pick.get("day_change_pct", 0)
        rng    = pick.get("range_pct", 0)
        strat  = pick.get("strat_name", "MCX")
        sess   = pick.get("session", "both")

        prompt = (
            f"MCX {action}: {sym} {dir_} @ ₹{ltp:.1f}\n"
            f"Day: {chg:+.1f}% | Range: {rng:.1f}% | Session: {sess}\n"
            f"Strategy: {strat} | Target: +{tgt}% | SL: -{sl}%\n\n"
            f"Write exactly 1-2 sentences explaining why this {action.lower()} makes sense "
            f"given the price action. Be direct and specific."
        )
        return self.q.generate(prompt, system=self.SYSTEM_TRADER,
                               temperature=0.3, max_tokens=80)

    async def atrade_commentary(self, pick: dict, action: str = "ENTRY") -> str:
        return await self.q.agenerate(
            self._commentary_prompt(pick, action),
            system=self.SYSTEM_TRADER,
            temperature=0.3,
            max_tokens=80,
        )

    def _commentary_prompt(self, pick: dict, action: str) -> str:
        sym   = pick.get("symbol", "?")
        dir_  = pick.get("direction", "BUY")
        ltp   = pick.get("ltp", 0)
        tgt   = pick.get("target_pct", 1.0)
        sl    = pick.get("sl_pct", 0.6)
        chg   = pick.get("day_change_pct", 0)
        strat = pick.get("strat_name", "MCX")
        return (
            f"MCX {action}: {sym} {dir_} @ ₹{ltp:.1f} | "
            f"day={chg:+.1f}% strat={strat} T=+{tgt}% SL=-{sl}%\n"
            f"1-2 sentences: why does this {action.lower()} make sense? Be direct."
        )

    # ── 2. Candle pattern recognition ─────────────────────────────────────────

    def read_candle_pattern(self, symbol: str, candles: list[dict]) -> dict:
        """
        Identify candle pattern from the last 5 candles and return direction bias.

        candles: list of {open, high, low, close, volume} dicts (most recent last)
        Returns: {"pattern": str, "bias": "BUY|SELL|NEUTRAL", "confidence": 0-1}
        """
        if len(candles) < 3:
            return {"pattern": "insufficient_data", "bias": "NEUTRAL", "confidence": 0}

        recent = candles[-5:]
        lines = []
        for i, c in enumerate(recent):
            body  = abs(c["close"] - c["open"])
            range_ = c["high"] - c["low"]
            bull  = "▲" if c["close"] > c["open"] else "▼"
            lines.append(
                f"  C{i+1}: O={c['open']:.1f} H={c['high']:.1f} "
                f"L={c['low']:.1f} C={c['close']:.1f} {bull} "
                f"body={body:.1f} range={range_:.1f}"
            )

        prompt = (
            f"MCX {symbol} — last {len(recent)} candles (oldest→newest):\n"
            + "\n".join(lines)
            + "\n\nIdentify the candlestick pattern and directional bias.\n"
            + 'Return ONLY JSON: {"pattern": "name", "bias": "BUY|SELL|NEUTRAL", "confidence": 0.0-1.0, "note": "brief reason"}'
        )
        return self.q.generate_json(prompt, system=self.SYSTEM_TRADER, max_tokens=100)

    # ── 3. Market regime classification ───────────────────────────────────────

    def classify_regime(
        self,
        spot: float,
        vix: float,
        day_change_pct: float,
        advance_decline: float,
        crude_chg: float = 0,
        gold_chg:  float = 0,
    ) -> dict:
        """
        Classify current market regime.
        Returns: {"regime": str, "bias": str, "volatility": str, "note": str}
        """
        prompt = (
            f"Indian market snapshot:\n"
            f"  Nifty: {spot:.0f} | VIX: {vix:.1f} | Day: {day_change_pct:+.2f}%\n"
            f"  Advance/Decline ratio: {advance_decline:.2f}\n"
            f"  MCX Crude: {crude_chg:+.2f}% | MCX Gold: {gold_chg:+.2f}%\n\n"
            f"Classify the current market regime.\n"
            f'Return ONLY JSON: {{'
            f'"regime": "TRENDING_UP|TRENDING_DOWN|RANGING|VOLATILE|BREAKOUT",'
            f'"bias": "BULLISH|BEARISH|NEUTRAL",'
            f'"volatility": "HIGH|NORMAL|LOW",'
            f'"best_strategy": "MOMENTUM|MEAN_REVERT|BREAKOUT|STAY_OUT",'
            f'"note": "one sentence max"}}'
        )
        result = self.q.generate_json(prompt, system=self.SYSTEM_TRADER, max_tokens=120)
        # Defaults if Qwen is offline or returns bad JSON
        if not result:
            result = {
                "regime": "RANGING",
                "bias": "NEUTRAL",
                "volatility": "NORMAL",
                "best_strategy": "MEAN_REVERT",
                "note": "Qwen offline — default regime",
            }
        return result

    async def aclassify_regime(self, spot, vix, day_change_pct,
                                advance_decline, crude_chg=0, gold_chg=0) -> dict:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.classify_regime(
                spot, vix, day_change_pct, advance_decline, crude_chg, gold_chg
            ),
        )

    # ── 4. Post-trade rationale ───────────────────────────────────────────────

    def post_trade_rationale(
        self,
        symbol: str,
        direction: str,
        entry: float,
        exit_: float,
        exit_reason: str,
        hold_min: float,
        pnl_pct: float,
    ) -> str:
        """
        One-sentence explanation of what happened in the trade.
        Used in Telegram exit messages and DB notes.
        """
        outcome = "profit" if pnl_pct > 0 else "loss"
        prompt = (
            f"MCX trade result:\n"
            f"  {symbol} {direction} | Entry ₹{entry:.1f} → Exit ₹{exit_:.1f}\n"
            f"  Exit: {exit_reason} | Held: {hold_min:.0f}min | P&L: {pnl_pct:+.2f}%\n\n"
            f"Write exactly 1 sentence explaining why the trade ended in a {outcome}. "
            f"Reference specific price action. No fluff."
        )
        return self.q.generate(prompt, system=self.SYSTEM_TRADER,
                               temperature=0.25, max_tokens=60)

    async def apost_trade_rationale(self, symbol, direction, entry, exit_,
                                     exit_reason, hold_min, pnl_pct) -> str:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.post_trade_rationale(
                symbol, direction, entry, exit_, exit_reason, hold_min, pnl_pct
            ),
        )

    # ── 5. Real-time parameter suggestions ────────────────────────────────────

    def realtime_param_suggestion(self, recent_trades: list[dict]) -> dict:
        """
        Quick param suggestion based on last N trades (not daily — can run every hour).
        Returns: {"changes": [{"param": str, "suggested": float, "reason": str}]}
        """
        if len(recent_trades) < 5:
            return {"changes": []}

        lines = []
        for t in recent_trades[-10:]:
            lines.append(
                f"  {t.get('strategy','?'):15s} {t.get('exit_reason','?'):12s} "
                f"pnl={t.get('pnl_pct',0):+.2f}% hold={t.get('hold_sec',0)//60}min "
                f"{'W' if t.get('won') else 'L'}"
            )

        wins  = sum(1 for t in recent_trades[-10:] if t.get("won"))
        sl_exits = sum(1 for t in recent_trades[-10:] if "STOP" in str(t.get("exit_reason","")).upper())
        timeout  = sum(1 for t in recent_trades[-10:] if "TIME" in str(t.get("exit_reason","")).upper())

        prompt = (
            f"Last {min(10,len(recent_trades))} MCX trades:\n"
            + "\n".join(lines)
            + f"\n\nSummary: {wins}/10 wins | SL exits: {sl_exits} | Timeout: {timeout}\n\n"
            + "Suggest 1-3 parameter adjustments to improve performance.\n"
            + 'Return ONLY JSON: {"changes": [{"param": "target_pct|sl_pct|max_hold_min", '
              '"suggested": <number>, "reason": "<10 words>"}]}'
        )
        return self.q.generate_json(prompt, system=self.SYSTEM_TRADER, max_tokens=150)

    # ── 6. Daily parameter tuning (replaces daily_update ask_ollama) ──────────

    def daily_param_tune(self, stats: dict) -> dict:
        """
        Full daily analysis — drop-in replacement for daily_update.ask_ollama().
        Returns the same schema that apply_suggestions() expects.
        """
        stats_json = json.dumps({
            "all_time":   stats.get("all_time", {}),
            "last_7_days":stats.get("last_7_days", {}),
            "yesterday":  stats.get("yesterday", {}),
            "by_strategy": stats.get("by_strategy", [])[:8],
            "exit_reasons":stats.get("exit_reasons", [])[:6],
            "best_hours":  stats.get("best_hours", [])[:5],
        }, indent=1)

        prompt = (
            "FinanceAGI MCX/NSE trading bot performance stats:\n\n"
            + stats_json
            + "\n\nAnalyze and return parameter improvement suggestions.\n"
            + 'Return ONLY this JSON:\n'
            + '{\n'
            + '  "parameter_changes": [{"param": "target_pct", "suggested": 7.5, "reason": "..."}],\n'
            + '  "strategy_actions": [{"strategy": "Name", "action": "boost|kill|keep", "reason": "..."}],\n'
            + '  "best_trading_hours": [9, 10, 14],\n'
            + '  "regime_insight": "one sentence",\n'
            + '  "improvement_insight": "one sentence",\n'
            + '  "urgency": "high|medium|low",\n'
            + '  "confidence": 0.7\n'
            + '}'
        )

        result = self.q.generate_json(
            prompt,
            system=(
                "You are an expert algorithmic trading system optimizer for Indian NSE/MCX markets. "
                "Return ONLY valid JSON — no markdown, no explanation, no preamble."
            ),
            temperature=0.1,
            max_tokens=600,
        )
        return result

    # ── 7. Strategy explanation ───────────────────────────────────────────────

    def explain_strategy(self, strat: dict) -> str:
        """
        Write a plain-English explanation of a strategy's edge.
        Used by strategy_inventor when inventing new strategies.
        """
        prompt = (
            f"MCX commodity strategy:\n"
            f"  Name: {strat.get('name','?')}\n"
            f"  Signal: {strat.get('signal_type','?')}\n"
            f"  Direction: {strat.get('direction','?')}\n"
            f"  Session: {strat.get('session','?')}\n"
            f"  Target: {strat.get('target_pct','?')}% | SL: {strat.get('sl_pct','?')}%\n"
            f"  Assets: {strat.get('symbols','?')}\n"
            f"  Filter: trend={strat.get('trend_filter','?')} iv={strat.get('iv_pref','?')}\n\n"
            f"In 2 sentences, explain the trading edge this strategy exploits. "
            f"Be specific about market microstructure, timing, or behavioural bias."
        )
        return self.q.generate(prompt, system=self.SYSTEM_TRADER,
                               temperature=0.4, max_tokens=100)

    # ── 8. News/web summary ───────────────────────────────────────────────────

    def summarise_news(self, headline: str, body: str, asset: str = "") -> str:
        """
        Distil a news article into a 1-sentence trading implication.
        Replaces the Ollama call in web_search.py's _summarise_with_llm.
        """
        prompt = (
            f"Asset: {asset or 'Indian markets'}\n"
            f"Headline: {headline}\n"
            f"Body (first 300 chars): {body[:300]}\n\n"
            f"In exactly 1 sentence, state the trading implication for MCX/NSE. "
            f"Format: 'This is [bullish/bearish/neutral] for [X] because [Y].' "
            f"No caveats."
        )
        return self.q.generate(prompt, system=self.SYSTEM_TRADER,
                               temperature=0.2, max_tokens=70)

    # ── 9. Streak break analysis ──────────────────────────────────────────────

    def analyse_loss_streak(self, trades: list[dict]) -> str:
        """
        When the bot hits a losing streak (3+ consecutive losses),
        Qwen diagnoses the likely cause.
        """
        if not trades:
            return ""
        lines = [
            f"  {t.get('strategy','?')} {t.get('exit_reason','?')} "
            f"pnl={t.get('pnl_pct',0):+.2f}% {t.get('asset','?')}"
            for t in trades[-5:]
        ]
        prompt = (
            f"Losing streak — last {len(lines)} consecutive losses:\n"
            + "\n".join(lines)
            + "\n\nDiagnose in 2 sentences: what is likely causing these losses "
              "and what single parameter change would help most?"
        )
        return self.q.generate(prompt, system=self.SYSTEM_TRADER,
                               temperature=0.3, max_tokens=90)

    # ── 10. Free-form chat ────────────────────────────────────────────────────

    def chat(self, message: str) -> str:
        """
        Free-form chat with Qwen about markets, strategy, or the system.
        Used for debugging / command_centre interactive mode.
        """
        return self.q.generate(
            message,
            system=self.SYSTEM_TRADER,
            temperature=0.5,
            max_tokens=300,
        )


# Module-level task runner
qwen_tasks = QwenTasks(qwen)


# ═══════════════════════ LIVE COMMENTATOR ══════════════════════════════════════

class QwenCommentator:
    """
    Generates and caches live trade commentary.
    Runs async so it never blocks the trading loop.

    Usage in agent.py:
      asyncio.ensure_future(qwen_commentator.on_entry(pick))
      asyncio.ensure_future(qwen_commentator.on_exit(pick, pp, ex))
    """

    def __init__(self, client: QwenClient):
        self.q = client
        self._cache: dict[str, str] = {}   # symbol → last commentary
        self._tg_fn = None                  # injected by agent.py

    def set_telegram(self, tg_fn):
        """Inject the tg() coroutine from agent.py."""
        self._tg_fn = tg_fn

    async def on_entry(self, pick: dict):
        sym   = pick.get("symbol", "?")
        text  = await qwen_tasks.atrade_commentary(pick, "ENTRY")
        if text:
            self._cache[sym] = text
            log.info(f"  [QWEN] Entry commentary [{sym}]: {text}")
            if self._tg_fn:
                await self._tg_fn(f"🧠 Qwen: {text}")

    async def on_exit(self, pick: dict, pnl_pct: float, exit_reason: str):
        sym    = pick.get("symbol", "?")
        entry  = pick.get("entry_price", pick.get("ltp", 0))
        ltp    = pick.get("ltp", entry)
        dir_   = pick.get("direction", "BUY")
        hold   = (time.time() - pick.get("_t0", time.time())) / 60
        text   = await qwen_tasks.apost_trade_rationale(
            sym, dir_, entry, ltp, exit_reason, hold, pnl_pct
        )
        if text:
            self._cache[f"{sym}_exit"] = text
            log.info(f"  [QWEN] Exit rationale [{sym}]: {text}")
            if self._tg_fn:
                icon = "✅" if pnl_pct > 0 else "❌"
                await self._tg_fn(f"{icon} Qwen: {text}")

    def last(self, symbol: str) -> str:
        return self._cache.get(symbol, "")


qwen_commentator = QwenCommentator(qwen)


# ═══════════════════════ REGIME DETECTOR ═══════════════════════════════════════

class QwenRegimeDetector:
    """
    Classifies market regime every N minutes using Qwen.
    agent.py reads self.current before entering new trades.
    """

    REFRESH_MIN = 15   # reclassify every 15 minutes

    def __init__(self, client: QwenClient):
        self.q = client
        self.current: dict = {
            "regime":       "RANGING",
            "bias":         "NEUTRAL",
            "volatility":   "NORMAL",
            "best_strategy":"MEAN_REVERT",
            "note":         "not yet classified",
        }
        self._last_ts: float = 0.0

    def is_stale(self) -> bool:
        return (time.time() - self._last_ts) > (self.REFRESH_MIN * 60)

    async def classify(
        self,
        spot: float,
        vix: float,
        day_change_pct: float,
        advance_decline: float = 1.0,
        crude_chg: float = 0.0,
        gold_chg:  float = 0.0,
    ) -> dict:
        """
        Classify regime and cache result.
        Returns cached result if last classification was recent.
        """
        if not self.is_stale():
            return self.current

        result = await qwen_tasks.aclassify_regime(
            spot, vix, day_change_pct, advance_decline, crude_chg, gold_chg
        )
        if result:
            self.current = result
            self._last_ts = time.time()
            log.info(
                f"  [QWEN] Regime: {result.get('regime','?')} | "
                f"bias={result.get('bias','?')} | "
                f"vol={result.get('volatility','?')} | "
                f"{result.get('note','')}"
            )
        return self.current

    def regime_allows_entry(self, direction: str) -> bool:
        """
        Quick check: does the current regime support a BUY or SELL entry?
        """
        bias = self.current.get("bias", "NEUTRAL")
        vol  = self.current.get("volatility", "NORMAL")
        strat = self.current.get("best_strategy", "MEAN_REVERT")

        if vol == "HIGH" and strat == "STAY_OUT":
            return False
        if direction == "BUY"  and bias == "BEARISH":
            return False
        if direction == "SELL" and bias == "BULLISH":
            return False
        return True


qwen_regime = QwenRegimeDetector(qwen)


# ═══════════════════════ PATCH: daily_update.py integration ════════════════════

def patch_daily_update_ask_ollama():
    """
    Monkey-patch ask_ollama in daily_update module to use QwenTasks.
    Call this once at startup if you want Qwen to handle the daily analysis.
    Import order: import daily_update; then call this function.
    """
    try:
        import daily_update as du

        def _qwen_ask_ollama(stats: dict) -> dict:
            log.info("  [QWEN] Handling daily_update ask_ollama via qwen_tasks.daily_param_tune")
            return qwen_tasks.daily_param_tune(stats)

        du.ask_ollama = _qwen_ask_ollama
        log.info("  [QWEN] Patched daily_update.ask_ollama → qwen_tasks.daily_param_tune")
    except ImportError:
        pass


def patch_web_search_summarise():
    """
    Monkey-patch the Ollama summarisation call in web_search.py to use QwenTasks.
    """
    try:
        import web_search as ws

        original = getattr(ws, "_summarise_with_llm", None)
        if original is None:
            return

        def _qwen_summarise(prompt: str) -> str:
            # Extract asset from prompt heuristically
            asset = ""
            for tok in ["NIFTY", "CRUDE", "GOLD", "NATGAS", "BANKNIFTY"]:
                if tok in prompt.upper():
                    asset = tok
                    break
            # Use headline + body split if prompt has newlines
            parts = prompt.split("\n", 2)
            headline = parts[0] if parts else prompt
            body     = parts[-1] if len(parts) > 1 else ""
            return qwen_tasks.summarise_news(headline, body, asset)

        ws._summarise_with_llm = _qwen_summarise
        log.info("  [QWEN] Patched web_search._summarise_with_llm → qwen_tasks.summarise_news")
    except ImportError:
        pass


# ═══════════════════════ CLI ENTRY POINT ═══════════════════════════════════════

if __name__ == "__main__":
    import sys
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(message)s",
        datefmt="%H:%M:%S",
        handlers=[logging.StreamHandler()],
    )

    cmd = sys.argv[1] if len(sys.argv) > 1 else "ping"

    if cmd == "ping":
        ok = qwen.ping()
        print(f"Qwen ping: {'✓ ONLINE' if ok else '✗ OFFLINE'}")
        print(qwen.status_line())

    elif cmd == "regime":
        result = qwen_tasks.classify_regime(
            spot=22500, vix=14.5, day_change_pct=-0.4,
            advance_decline=0.85, crude_chg=0.8, gold_chg=-0.2,
        )
        print("Regime:", json.dumps(result, indent=2))

    elif cmd == "commentary":
        pick = {
            "symbol": "CRUDEOILM", "direction": "BUY", "ltp": 6520.0,
            "target_pct": 1.5, "sl_pct": 0.8, "day_change_pct": 1.2,
            "range_pct": 1.8, "strat_name": "CrudeUSBreakout", "session": "us",
        }
        text = qwen_tasks.trade_commentary(pick, "ENTRY")
        print("Commentary:", text or "(Qwen offline)")

    elif cmd == "tune":
        # Pull real stats from DB and run param tune
        try:
            import daily_update as du
            stats = du.gather_stats()
            if stats.get("all_time", {}).get("trades", 0) == 0:
                print("No trades in DB yet — using dummy stats")
                stats = {
                    "all_time":    {"trades": 50, "wins": 28, "win_rate_pct": 56, "net_pnl": 1200},
                    "last_7_days": {"trades": 18, "wins": 9,  "win_rate_pct": 50, "net_pnl": 200},
                    "yesterday":   {"trades": 4,  "wins": 2,  "win_rate_pct": 50, "net_pnl": 80},
                    "by_strategy": [{"name": "CrudeUSBreakout", "trades": 20, "win_rate": 60, "net_pnl": 800}],
                    "exit_reasons": [{"reason": "TARGET", "count": 28, "avg_pnl_pct": 1.2}],
                    "best_hours": [{"hour": 19, "trades": 12, "win_rate": 67}],
                }
        except Exception:
            print("daily_update import failed — using dummy stats")
            stats = {"all_time": {"trades": 0}}

        result = qwen_tasks.daily_param_tune(stats)
        print("Param tune:", json.dumps(result, indent=2))

    elif cmd == "chat":
        msg = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else "What is the best time to trade MCX Crude Oil?"
        print(f"You: {msg}")
        reply = qwen_tasks.chat(msg)
        print(f"Qwen: {reply or '(offline)'}")

    elif cmd == "candles":
        import random
        base = 6500.0
        candles = []
        for _ in range(6):
            o = base + random.uniform(-20, 20)
            c = o + random.uniform(-15, 15)
            h = max(o, c) + random.uniform(0, 10)
            l = min(o, c) - random.uniform(0, 10)
            candles.append({"open": round(o,1), "high": round(h,1),
                            "low": round(l,1), "close": round(c,1), "volume": 1000})
            base = c
        result = qwen_tasks.read_candle_pattern("CRUDEOILM", candles)
        print("Pattern:", json.dumps(result, indent=2))

    elif cmd == "streak":
        trades = [
            {"strategy": "CrudeUSBreakout", "exit_reason": "STOPLOSS", "pnl_pct": -0.8, "asset": "commodity"},
            {"strategy": "GoldMeanRev",      "exit_reason": "STOPLOSS", "pnl_pct": -0.4, "asset": "commodity"},
            {"strategy": "NatGasEIA",        "exit_reason": "TIMEOUT",  "pnl_pct": -0.1, "asset": "commodity"},
        ]
        text = qwen_tasks.analyse_loss_streak(trades)
        print("Streak analysis:", text or "(Qwen offline)")

    else:
        print(f"Unknown command: {cmd}")
        print("Usage: python3 qwen_engine.py [ping|regime|commentary|tune|chat <msg>|candles|streak]")
