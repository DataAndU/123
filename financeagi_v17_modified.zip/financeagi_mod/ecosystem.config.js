// FinanceAGI v17.1 — PM2 Ecosystem Config
// Agent is run manually: python3 agent.py
// First time setup:
//   pm2 start ecosystem.config.js
//   pm2 save
//   pm2 startup   (follow printed command)

module.exports = {
  apps: [
    {
      name: "financeagi-dashboard",
      script: "python3",
      args: "command_centre.py",
      cwd: process.env.FINANCEAGI_DIR || require("path").resolve(__dirname),
      interpreter: "none",
      autorestart: true,
      watch: false,
      max_restarts: 20,
      restart_delay: 3000,
      env: { PYTHONUNBUFFERED: "1" },
      out_file: "logs/dashboard.stdout.log",
      error_file: "logs/dashboard.stderr.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss",
      merge_logs: false,
    },
    {
      // Daily AI update — runs automatically at 6:00 AM IST every day
      // No manual action needed. Sends Telegram report + applies suggestions.
      name: "financeagi-daily-update",
      script: "python3",
      args: "daily_update.py",
      cwd: process.env.FINANCEAGI_DIR || require("path").resolve(__dirname),
      interpreter: "none",
      cron_restart: "30 0 * * *",   // 6:00 AM IST = 00:30 UTC
      autorestart: false,
      watch: false,
      out_file: "logs/llm_update.log",
      error_file: "logs/llm_update.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss",
    },
  ],
};
