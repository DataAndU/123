#!/usr/bin/env python3
"""
v17_patch.py — FinanceAGI v17: Strategy Invention & Management Patch
=====================================================================

New in v17:
  - options_strategy_inventor.py  → AI-powered F&O options strategy creation
  - equity_strategy_inventor.py   → AI-powered equity intraday strategy creation
  - strategy_master.py            → Unified cross-asset strategy orchestrator

This patch shows the integration points for agent.py.
Run: python3 v17_patch.py verify   to check all modules load correctly.
Run: python3 v17_patch.py info     to see what's new.

INTEGRATION INSTRUCTIONS FOR agent.py:
======================================

1. ADD IMPORTS (after existing imports in agent.py):

    # ── v17: Strategy Inventors ───────────────────────────────────────────────
    try:
        from options_strategy_inventor import options_inventor
        _OPT_INVENTOR = True
    except Exception as _oi_e:
        log.warning(f"  options_strategy_inventor not loaded: {_oi_e}")
        options_inventor = None
        _OPT_INVENTOR = False

    try:
        from equity_strategy_inventor import equity_inventor
        _EQ_INVENTOR = True
    except Exception as _ei_e:
        log.warning(f"  equity_strategy_inventor not loaded: {_ei_e}")
        equity_inventor = None
        _EQ_INVENTOR = False

    try:
        from strategy_master import master as strategy_master, run_strategy_master_loop
        _MASTER = True
    except Exception as _m_e:
        log.warning(f"  strategy_master not loaded: {_m_e}")
        strategy_master = None
        run_strategy_master_loop = None
        _MASTER = False


2. WIRE OPTIONS INVENTOR into options_loop() trade recording:
   After a trade closes (where pool.update() is called), add:

    if _OPT_INVENTOR:
        greeks_pnl = {
            "delta": delta_pnl,   # compute from position delta * spot move
            "theta": theta_pnl,   # daily theta * hold time
            "vega":  vega_pnl,    # vega * IV change
        }
        options_inventor.record_trade(strat_name, won, pp, greeks_pnl)


3. WIRE EQUITY INVENTOR into run_equity_loop() trade recording:
   After an equity trade closes, add:

    if _EQ_INVENTOR:
        stock_info = {
            "tier": pos.get("tier", "unknown"),
            "name": pos.get("name", ""),
            "hold_min": hold_minutes,
        }
        equity_inventor.record_trade(strat_name, won, pp, stock_info)


4. ADD STRATEGY MASTER LOOP to asyncio.gather in run():

    await asyncio.gather(
        options_loop(),
        run_equity_loop(dt_ref, dp_ref, dw_ref),
        run_commodity_loop(dt_ref, dp_ref, dw_ref),
        run_strategy_master_loop(_market_ctx_ref) if _MASTER else asyncio.sleep(0),
        _watchdog(),
        _health_monitor(),
        ...
    )

   Where _market_ctx_ref is a mutable list updated with current context:
    _market_ctx_ref = [{}]
    # Update periodically:
    _market_ctx_ref[0] = {
        "spot_prices": spots,
        "day_changes": changes,
        "india_vix": vix,
        "pcr": pcr_val,
        "regime": regime,
        ...
    }


5. USE STRATEGY MASTER for picks (optional, enhances existing pool.pick()):

    if _OPT_INVENTOR:
        inv_strat, inv_opts = options_inventor.pick_strategy(
            all_options, spot, cash, vix=vix_val
        )
        if inv_strat and inv_opts:
            # Use invented strategy's parameters for the trade
            ...

    if _EQ_INVENTOR:
        eq_strat, eq_stock = equity_inventor.pick_strategy(stock_opps, cash)
        if eq_strat and eq_stock:
            # Use invented strategy's exit rules
            exit_reason, pnl = equity_inventor.should_exit(
                eq_strat, entry_price, current_price, direction, hold_min, peak_pnl
            )


6. ADD TO cmd_stats() display:

    if _MASTER:
        print(strategy_master.status_line())
    if _OPT_INVENTOR:
        print(options_inventor.status())
    if _EQ_INVENTOR:
        print(equity_inventor.status())


7. UPDATE .env.example with new variables:

    # Strategy Inventors
    OPT_INVENTOR_MAX_STRATS=20
    OPT_INVENTOR_KILL_WR=0.40
    OPT_INVENTOR_MIN_TRADES=6
    EQ_INVENTOR_MAX_STRATS=15
    EQ_INVENTOR_KILL_WR=0.40
    EQ_INVENTOR_MIN_TRADES=8

"""

import sys
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s", datefmt="%H:%M:%S",
                    handlers=[logging.StreamHandler()])

def verify():
    """Verify all v17 modules load correctly."""
    print("=" * 60)
    print("  FinanceAGI v17 Module Verification")
    print("=" * 60)

    results = {}

    # Options Strategy Inventor
    try:
        from options_strategy_inventor import options_inventor, OPT_STRATEGY_DEFAULTS
        n = len(options_inventor.active_strategies())
        results["options_strategy_inventor"] = f"✅ Loaded ({n} active strategies)"
    except Exception as e:
        results["options_strategy_inventor"] = f"❌ Failed: {e}"

    # Equity Strategy Inventor
    try:
        from equity_strategy_inventor import equity_inventor, EQ_STRATEGY_DEFAULTS
        n = len(equity_inventor.active_strategies())
        results["equity_strategy_inventor"] = f"✅ Loaded ({n} active strategies)"
    except Exception as e:
        results["equity_strategy_inventor"] = f"❌ Failed: {e}"

    # Strategy Master
    try:
        from strategy_master import master, run_strategy_master_loop
        c = master.strategy_count()
        results["strategy_master"] = f"✅ Loaded (total={c.get('total', 0)} strategies)"
    except Exception as e:
        results["strategy_master"] = f"❌ Failed: {e}"

    # Existing modules
    try:
        from strategy_inventor import inventor
        results["strategy_inventor (commodity)"] = "✅ Loaded"
    except Exception as e:
        results["strategy_inventor (commodity)"] = f"⚠️ {e}"

    for module, status in results.items():
        print(f"\n  {module}:")
        print(f"    {status}")

    print(f"\n{'='*60}")

    # Check ANTHROPIC_API_KEY
    from pathlib import Path
    env_file = Path(__file__).resolve().parent / ".env"
    has_key = False
    if env_file.exists():
        for ln in env_file.read_text().splitlines():
            if ln.strip().startswith("ANTHROPIC_API_KEY") and "=" in ln:
                val = ln.split("=", 1)[1].strip()
                if val and val != "your_key_here":
                    has_key = True
    import os
    if os.environ.get("ANTHROPIC_API_KEY"):
        has_key = True

    if has_key:
        print("  ANTHROPIC_API_KEY: ✅ Set (LLM invention enabled)")
    else:
        print("  ANTHROPIC_API_KEY: ⚠️ Not set (LLM invention disabled, seeds only)")

    print()


def info():
    """Show what's new in v17."""
    print("""
╔══════════════════════════════════════════════════════════════════════════╗
║  FINANCEAGI v17 — STRATEGY INVENTION & MANAGEMENT ENGINE               ║
╠══════════════════════════════════════════════════════════════════════════╣
║                                                                          ║
║  NEW MODULES:                                                            ║
║                                                                          ║
║  1. options_strategy_inventor.py                                         ║
║     • 13 strategy types: single, spread, iron_condor, straddle,          ║
║       strangle, butterfly, calendar, ratio, jade_lizard,                 ║
║       iron_butterfly, collar, diagonal, synthetic                        ║
║     • 16 signal types: momentum, IV crush, theta harvest, gamma scalp,   ║
║       PCR, OI, FII flow, VWAP, skew exploit, etc.                       ║
║     • Greeks-aware scoring (delta/theta/vega/gamma attribution)           ║
║     • 13 seed strategies covering NIFTY/BANKNIFTY/FNO stocks             ║
║     • LLM-powered invention via Claude claude-sonnet-4-20250514                       ║
║     • Genetic evolution: mutate, crossbreed, kill underperformers        ║
║                                                                          ║
║  2. equity_strategy_inventor.py                                          ║
║     • 12 strategy types: momentum_scalp, mean_revert, orb_breakout,     ║
║       vwap_bounce, gap_fill, sector_rotation, pair_trade, volume_spike,  ║
║       reversal, premarket_follow, eod_scalp, news_momentum              ║
║     • 15 signal types: price momentum, volume breakout, range position,  ║
║       VWAP cross, RSI, sector strength, Bollinger squeeze, etc.          ║
║     • Per-tier performance tracking (penny/low/mid/high)                 ║
║     • Sector-aware strategies (Banking, Power, IT, etc.)                 ║
║     • 12 seed strategies across all equity styles                        ║
║                                                                          ║
║  3. strategy_master.py                                                    ║
║     • Unified orchestrator across Options + Equity + Commodities          ║
║     • Cross-asset learning: transfers winning patterns between classes    ║
║     • Lifecycle management: SEED → TESTING → PROMOTED → MATURE → KILLED  ║
║     • Dynamic capital allocation weighted by Sharpe + win rate            ║
║     • Unified performance dashboard and reporting                         ║
║     • Background loop (5-min cycles) for agent.py integration            ║
║                                                                          ║
║  STRATEGY COUNTS:                                                        ║
║     • Options: 13 seeds + unlimited LLM inventions                       ║
║     • Equity:  12 seeds + unlimited LLM inventions                       ║
║     • Commodity: existing seeds + inventions (unchanged)                  ║
║                                                                          ║
║  CLI USAGE:                                                              ║
║     python3 options_strategy_inventor.py [status|invent|evolve|reset]     ║
║     python3 equity_strategy_inventor.py  [status|invent|evolve|reset]     ║
║     python3 strategy_master.py [report|invent|evolve|crossover|counts]    ║
║     python3 v17_patch.py [verify|info]                                   ║
║                                                                          ║
╚══════════════════════════════════════════════════════════════════════════╝
""")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "info"
    {"verify": verify, "info": info}.get(cmd, info)()
