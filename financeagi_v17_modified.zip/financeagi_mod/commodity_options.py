"""
commodity_options.py — MCX Commodity Options Module for FinanceAGI v17.2
Supports MCX options on CRUDEOILM (Crude Oil Mini) and NATGASMINI (Natural Gas Mini).

Architecture:
  - Fully separated from commodity_futures.py (no cross-imports)
  - Black-Scholes pricing with MCX CTT/charges
  - Strategy catalogue: 10 option strategies for energy commodities
  - Upstox MCX_FO options chain integration
  - Lazy-loads everything — UserLAnd/Termux safe (<30MB RAM at idle)
  - No heavy deps: pure stdlib + httpx + numpy (already in requirements)

Supported underlyings:
  CRUDEOILM  — Crude Oil Mini (10 bbl/lot)  MCX options CE/PE weekly + monthly
  NATGASMINI — Natural Gas Mini (250 mmBtu)  MCX options CE/PE monthly

Option strategies:
  1.  CRUDE_STRANGLE      — Sell OTM CE + PE on low IV; collect premium both sides
  2.  CRUDE_BULL_SPREAD   — Bull call spread on momentum breakout
  3.  CRUDE_BEAR_SPREAD   — Bear put spread on breakdown / inventory build
  4.  CRUDE_STRADDLE_BUY  — Buy ATM straddle before EIA Wednesday
  5.  CRUDE_IV_CRUSH      — Sell ATM straddle day after EIA; fade vol pop
  6.  NATGAS_CALL_BUY     — Buy OTM call in winter/summer peak demand months
  7.  NATGAS_PUT_BUY      — Buy OTM put in shoulder months (Mar/Apr/Oct)
  8.  NATGAS_STRANGLE     — Sell strangle on quiet sideways US session
  9.  ENERGY_RATIO_SPREAD — Crude vs NatGas ratio options play on 2σ deviation
  10. CRUDE_PROTECTIVE_PUT — Hedge long crude futures position with ATM put

MCX options rules:
  - European exercise (no early assignment)
  - CTT on sell side: 0.05% of premium (options)
  - Square-off by 11:20 PM IST (10 min before MCX close)
  - Minimum capital: ₹5,000 per position
  - Never hold through expiry — exit ≥ 1 day before expiry

Upstox instrument_type filter: OPT, segment: MCX_FO
"""

import asyncio
import gzip
import json
import logging
import math
import time
from datetime import datetime, timedelta, timezone, time as dtime
from pathlib import Path

log = logging.getLogger("agi.commodity_options")
IST = timezone(timedelta(hours=5, minutes=30))

# ═══════════════════════ UNDERLYING META ══════════════════════════════════════

ENERGY_META = {
    "CRUDEOILM": {
        "name":           "Crude Oil Mini",
        "lot_size":       10,          # 10 barrels per lot
        "tick_size":      1.0,
        "min_capital":    5000,
        "max_capital":    40000,
        "iv_typical":     0.30,        # 30% annualised IV typical range
        "iv_high":        0.55,
        "price_range":    (3000, 10000),
        "strike_step":    50,          # MCX standard strike interval
        "option_types":   ["CE", "PE"],
        "expiry_cycle":   "weekly",    # weekly + monthly options available
        "corr_asset":     "BRENT_USD",
        "session":        "both",      # morning (9-11:30 AM) + US (6:30-11:30 PM IST)
        "strategies": [
            "CRUDE_STRANGLE", "CRUDE_BULL_SPREAD", "CRUDE_BEAR_SPREAD",
            "CRUDE_STRADDLE_BUY", "CRUDE_IV_CRUSH", "CRUDE_PROTECTIVE_PUT",
            "ENERGY_RATIO_SPREAD",
        ],
    },
    "NATGASMINI": {
        "name":           "Natural Gas Mini",
        "lot_size":       250,         # 250 mmBtu per lot
        "tick_size":      0.1,
        "min_capital":    5000,
        "max_capital":    25000,
        "iv_typical":     0.50,        # NatGas is highly volatile
        "iv_high":        0.90,
        "price_range":    (100, 600),
        "strike_step":    10,
        "option_types":   ["CE", "PE"],
        "expiry_cycle":   "monthly",
        "corr_asset":     "WEATHER_US",
        "session":        "us",        # US session most active (6:30 PM+ IST)
        "strategies": [
            "NATGAS_CALL_BUY", "NATGAS_PUT_BUY", "NATGAS_STRANGLE",
            "ENERGY_RATIO_SPREAD",
        ],
    },
}

# Seasonal NatGas option bias — same as futures but used for option direction
NATGAS_SEASONAL_OPTION = {
    1: ("CE", "winter peak — buy calls"),
    2: ("CE", "late winter — buy calls"),
    3: ("PE", "shoulder season — buy puts"),
    4: ("PE", "spring low demand — buy puts"),
    5: (None, "neutral — no bias"),
    6: ("CE", "summer cooling — buy calls"),
    7: ("CE", "peak summer — buy calls"),
    8: ("CE", "late summer — buy calls"),
    9: ("PE", "shoulder season — buy puts"),
    10: (None, "neutral — no bias"),
    11: ("CE", "early winter — buy calls"),
    12: ("CE", "peak winter — buy calls"),
}

# MCX session constants
MCX_OPT_OPEN     = dtime(9, 0)
MCX_OPT_CLOSE    = dtime(23, 30)
MCX_OPT_NO_ENTRY = dtime(23, 10)
MCX_OPT_SQ_OFF   = dtime(23, 20)   # force-exit options 10 min before close
US_SESSION_START  = dtime(18, 30)
MIN_DTE_ENTRY    = 2               # options: never enter with < 2 DTE
FORCE_EXIT_DTE   = 1               # force-exit if DTE ≤ 1

# ═══════════════════════ MCX OPTIONS CHARGES ══════════════════════════════════

class MCXOptionCharges:
    """
    MCX options charge calculator (FY 2025-26 rates).
    Premium-based, not turnover-based for options.
    """

    @staticmethod
    def calculate(buy_premium: float, sell_premium: float, qty: int,
                  is_buy: bool = True) -> dict:
        """
        is_buy=True  → we bought the option (paid premium)
        is_buy=False → we sold the option (collected premium)
        """
        lot_premium_buy  = buy_premium * qty
        lot_premium_sell = sell_premium * qty

        brokerage = 20.0                                  # flat per order
        ctt       = lot_premium_sell * 0.0005             # CTT 0.05% on sell-side premium
        exchange  = (lot_premium_buy + lot_premium_sell) * 0.0005   # MCX options exchange fee
        sebi      = (lot_premium_buy + lot_premium_sell) * 0.000001
        stamp     = lot_premium_buy * 0.00003
        gst       = (brokerage + exchange + sebi) * 0.18

        total_charges = brokerage + ctt + exchange + gst + sebi + stamp

        if is_buy:
            gross_pnl = lot_premium_sell - lot_premium_buy
        else:
            gross_pnl = lot_premium_buy - lot_premium_sell   # sold first, buy to close

        net_pnl = gross_pnl - total_charges
        max_loss = lot_premium_buy if is_buy else float("inf")

        return {
            "total_charges": round(total_charges, 2),
            "gross_pnl":     round(gross_pnl, 2),
            "net_pnl":       round(net_pnl, 2),
            "ctt":           round(ctt, 2),
            "brokerage":     brokerage,
            "gst":           round(gst, 2),
            "max_loss":      round(max_loss, 2) if is_buy else None,
            "breakeven_pct": round(total_charges / max(1, lot_premium_buy) * 100, 3) if is_buy else 0,
        }

    @staticmethod
    def min_profitable_move(spot: float, strike: float, premium: float,
                            lot_size: int, option_type: str) -> float:
        """
        Returns minimum spot % move needed for the option to expire profitable.
        """
        charges = 20 + premium * lot_size * 0.0005 * 2 + (20 + premium * lot_size * 0.001) * 0.18
        net_premium = premium + charges / max(lot_size, 1)
        if option_type == "CE":
            breakeven_spot = strike + net_premium
        else:
            breakeven_spot = strike - net_premium
        return round(abs(breakeven_spot - spot) / max(spot, 1) * 100, 3)


mcx_opt_charges = MCXOptionCharges()

# ═══════════════════════ BLACK-SCHOLES PRICING (stdlib only) ══════════════════

class BlackScholes:
    """
    Pure-Python Black-Scholes for MCX energy options.
    No scipy needed — uses erf approximation for norm_cdf.
    Memory: ~2KB. Fast enough for Termux/UserLAnd.
    """

    @staticmethod
    def _norm_cdf(x: float) -> float:
        """Abramowitz & Stegun approximation (max error 1.5e-7)."""
        if x >= 0:
            t = 1.0 / (1.0 + 0.2316419 * x)
            poly = t * (0.319381530
                        + t * (-0.356563782
                               + t * (1.781477937
                                      + t * (-1.821255978
                                             + t * 1.330274429))))
            return 1.0 - (1.0 / math.sqrt(2 * math.pi)) * math.exp(-0.5 * x * x) * poly
        return 1.0 - BlackScholes._norm_cdf(-x)

    @classmethod
    def price(cls, S: float, K: float, T: float, r: float,
              sigma: float, option_type: str) -> dict:
        """
        S     = current spot/futures price
        K     = strike price
        T     = time to expiry in years (DTE / 365)
        r     = risk-free rate (India: ~7% = 0.07)
        sigma = implied / historical volatility (annualised, e.g. 0.30)
        option_type = 'CE' or 'PE'
        Returns: premium, delta, gamma, theta, vega, iv_used
        """
        if T <= 0:
            intrinsic = max(S - K, 0) if option_type == "CE" else max(K - S, 0)
            return {
                "premium": round(intrinsic, 2), "delta": 1.0 if intrinsic > 0 else 0.0,
                "gamma": 0.0, "theta": 0.0, "vega": 0.0, "iv": sigma, "intrinsic": intrinsic,
            }
        if S <= 0 or K <= 0 or sigma <= 0:
            return {"premium": 0.0, "delta": 0.0, "gamma": 0.0, "theta": 0.0, "vega": 0.0,
                    "iv": sigma, "intrinsic": 0.0}

        sqrt_T = math.sqrt(T)
        d1 = (math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * sqrt_T)
        d2 = d1 - sigma * sqrt_T

        nd1  = cls._norm_cdf(d1)
        nd2  = cls._norm_cdf(d2)
        nd1_ = cls._norm_cdf(-d1)
        nd2_ = cls._norm_cdf(-d2)

        pdf_d1 = math.exp(-0.5 * d1 * d1) / math.sqrt(2 * math.pi)
        disc   = math.exp(-r * T)

        if option_type == "CE":
            premium = S * nd1 - K * disc * nd2
            delta   = nd1
        else:
            premium = K * disc * nd2_ - S * nd1_
            delta   = nd1 - 1.0

        gamma = pdf_d1 / (S * sigma * sqrt_T)
        theta = (-(S * pdf_d1 * sigma) / (2 * sqrt_T) -
                 r * K * disc * (nd2 if option_type == "CE" else nd2_)) / 365
        vega  = S * pdf_d1 * sqrt_T / 100   # per 1% vol move

        intrinsic = max(S - K, 0) if option_type == "CE" else max(K - S, 0)

        return {
            "premium":   round(max(premium, 0.0), 2),
            "delta":     round(delta, 4),
            "gamma":     round(gamma, 6),
            "theta":     round(theta, 4),
            "vega":      round(vega, 4),
            "iv":        sigma,
            "intrinsic": round(intrinsic, 2),
            "time_val":  round(max(premium - intrinsic, 0), 2),
            "d1":        round(d1, 4),
            "d2":        round(d2, 4),
        }

    @classmethod
    def implied_vol(cls, S: float, K: float, T: float, r: float,
                    market_price: float, option_type: str,
                    lo: float = 0.01, hi: float = 5.0, tol: float = 1e-5) -> float:
        """Newton-bisection IV solver. Max 50 iterations. Safe for Termux."""
        if T <= 0 or market_price <= 0:
            return 0.0
        for _ in range(50):
            mid   = (lo + hi) / 2
            price = cls.price(S, K, T, r, mid, option_type)["premium"]
            if abs(price - market_price) < tol:
                return round(mid, 5)
            if price < market_price:
                lo = mid
            else:
                hi = mid
            if hi - lo < tol:
                break
        return round((lo + hi) / 2, 5)

    @classmethod
    def atm_strike(cls, spot: float, step: float) -> float:
        """Round spot to nearest MCX strike step."""
        return round(round(spot / step) * step, 2)

    @classmethod
    def otm_strikes(cls, spot: float, step: float,
                    n_steps_away: int = 2) -> dict:
        """Return ATM, OTM CE strike, OTM PE strike."""
        atm = cls.atm_strike(spot, step)
        return {
            "atm":  atm,
            "ce_otm": atm + step * n_steps_away,
            "pe_otm": atm - step * n_steps_away,
        }


bs = BlackScholes()

# ═══════════════════════ STRATEGY CATALOGUE ═══════════════════════════════════

OPTION_STRATEGY_CATALOGUE = {
    "CRUDE_STRANGLE": {
        "name":        "Crude Strangle Sell",
        "description": "Sell OTM CE + OTM PE when IV is high. Collect premium both sides on range-bound crude.",
        "direction":   "SHORT_STRANGLE",
        "legs":        2,
        "otm_steps":   2,
        "min_iv":      0.30,
        "max_iv":      0.65,
        "session":     "both",
        "hold_min":    120,
        "score_bonus": 2,
        "min_capital": 8000,
        "max_loss":    "unlimited",
        "preferred_assets": ["CRUDEOILM"],
    },
    "CRUDE_BULL_SPREAD": {
        "name":        "Crude Bull Call Spread",
        "description": "Buy ATM CE + Sell OTM CE. Defined-risk bullish play on crude breakout above ORB.",
        "direction":   "BULL_SPREAD",
        "legs":        2,
        "otm_steps_buy":  0,   # ATM
        "otm_steps_sell": 2,   # 2 steps OTM
        "session":     "both",
        "hold_min":    60,
        "score_bonus": 1,
        "min_capital": 5000,
        "max_loss":    "debit_paid",
        "preferred_assets": ["CRUDEOILM"],
    },
    "CRUDE_BEAR_SPREAD": {
        "name":        "Crude Bear Put Spread",
        "description": "Buy ATM PE + Sell OTM PE. Defined-risk bearish play on EIA inventory build or breakdown.",
        "direction":   "BEAR_SPREAD",
        "legs":        2,
        "otm_steps_buy":  0,
        "otm_steps_sell": 2,
        "session":     "both",
        "hold_min":    60,
        "score_bonus": 1,
        "min_capital": 5000,
        "max_loss":    "debit_paid",
        "preferred_assets": ["CRUDEOILM"],
    },
    "CRUDE_STRADDLE_BUY": {
        "name":        "Crude Pre-EIA Straddle Buy",
        "description": "Buy ATM CE + PE before EIA Wednesday release (6:30-8:00 PM IST). Big move expected.",
        "direction":   "LONG_STRADDLE",
        "legs":        2,
        "session":     "us",
        "entry_window": {"day": 2, "hour_start": 18, "hour_end": 20},  # Wednesday 6-8 PM IST
        "hold_min":    45,
        "score_bonus": 3,
        "min_capital": 8000,
        "max_loss":    "net_premium",
        "preferred_assets": ["CRUDEOILM"],
    },
    "CRUDE_IV_CRUSH": {
        "name":        "Crude Post-EIA IV Crush",
        "description": "Sell ATM straddle day after EIA. IV crush as volatility mean-reverts post-event.",
        "direction":   "SHORT_STRADDLE",
        "legs":        2,
        "session":     "us",
        "entry_window": {"day": 3, "hour_start": 9, "hour_end": 12},   # Thursday morning
        "hold_min":    90,
        "score_bonus": 2,
        "min_capital": 8000,
        "max_loss":    "unlimited",
        "preferred_assets": ["CRUDEOILM"],
    },
    "CRUDE_PROTECTIVE_PUT": {
        "name":        "Crude Futures Protective Put",
        "description": "Buy 1-step OTM PE to hedge existing long crude futures position.",
        "direction":   "PROTECTIVE_PUT",
        "legs":        1,
        "otm_steps":   1,
        "session":     "both",
        "hold_min":    None,           # matches futures position duration
        "score_bonus": 1,
        "min_capital": 5000,
        "max_loss":    "premium_paid",
        "preferred_assets": ["CRUDEOILM"],
        "requires_futures_position": True,
    },
    "NATGAS_CALL_BUY": {
        "name":        "NatGas Seasonal Call Buy",
        "description": "Buy 1-step OTM CE in peak demand months (Nov-Feb, Jun-Aug). Ride weather premium.",
        "direction":   "LONG_CALL",
        "legs":        1,
        "otm_steps":   1,
        "session":     "us",
        "hold_min":    120,
        "score_bonus": 2,
        "min_capital": 5000,
        "max_loss":    "premium_paid",
        "preferred_assets": ["NATGASMINI"],
        "seasonal_months": [11, 12, 1, 2, 6, 7, 8],
    },
    "NATGAS_PUT_BUY": {
        "name":        "NatGas Shoulder Put Buy",
        "description": "Buy 1-step OTM PE in shoulder months (Mar/Apr/Sep/Oct). Low demand, inventory builds.",
        "direction":   "LONG_PUT",
        "legs":        1,
        "otm_steps":   1,
        "session":     "us",
        "hold_min":    120,
        "score_bonus": 2,
        "min_capital": 5000,
        "max_loss":    "premium_paid",
        "preferred_assets": ["NATGASMINI"],
        "seasonal_months": [3, 4, 9, 10],
    },
    "NATGAS_STRANGLE": {
        "name":        "NatGas Quiet Strangle Sell",
        "description": "Sell OTM CE + PE during sideways US-session NatGas. High IV → premium collection.",
        "direction":   "SHORT_STRANGLE",
        "legs":        2,
        "otm_steps":   3,              # NatGas needs wider strikes due to high vol
        "min_iv":      0.45,
        "max_iv":      1.00,
        "session":     "us",
        "hold_min":    90,
        "score_bonus": 2,
        "min_capital": 8000,
        "max_loss":    "unlimited",
        "preferred_assets": ["NATGASMINI"],
    },
    "ENERGY_RATIO_SPREAD": {
        "name":        "Crude/NatGas Ratio Options",
        "description": "Buy Crude CE + Sell NatGas CE (or vice versa) when energy ratio deviates >2σ.",
        "direction":   "RATIO_SPREAD",
        "legs":        2,
        "session":     "us",
        "hold_min":    180,
        "score_bonus": 1,
        "min_capital": 12000,
        "max_loss":    "limited",
        "preferred_assets": ["CRUDEOILM", "NATGASMINI"],
    },
}

# ═══════════════════════ MCX OPTIONS INSTRUMENT MANAGER ═══════════════════════

class MCXOptionInstruments:
    """
    Fetches and caches MCX options instrument keys from Upstox.
    Optimized for Termux: lazy load, 8-hour cache, minimal RAM.
    """

    INSTRUMENTS_URL = "https://assets.upstox.com/market-quote/instruments/exchange/MCX.json.gz"

    def __init__(self):
        self.options: dict[str, list] = {}   # {symbol: [{strike, type, key, expiry, dte, lot_size}]}
        self.last_refresh = 0
        self._cache = Path(__file__).resolve().parent / "data" / "mcx_opts.json"

    async def refresh(self, _broker=None):
        """Download and parse MCX options chain. Skips if < 8h since last refresh."""
        now_ts = time.time()
        if now_ts - self.last_refresh < 3600 * 8:
            return
        try:
            import httpx
            async with httpx.AsyncClient(timeout=25) as client:
                r   = await client.get(self.INSTRUMENTS_URL,
                                       headers={"User-Agent": "Mozilla/5.0"})
                raw = gzip.decompress(r.content)
                data = json.loads(raw)
            self._cache.parent.mkdir(parents=True, exist_ok=True)
            # Store compact version — only OPT rows for our symbols
            compact = [
                inst for inst in data
                if inst.get("instrument_type") == "OPT"
                and inst.get("segment") == "MCX_FO"
                and inst.get("underlying_symbol", "") in ENERGY_META
            ]
            json.dump(compact, open(self._cache, "w"))
            log.info(f"  [OPTS] Downloaded {len(compact)} MCX option contracts")
            self._parse(compact)
            self.last_refresh = now_ts
        except Exception as e:
            log.error(f"  [OPTS] Instrument download failed: {e}")
            self._load_cache()

    def _load_cache(self):
        try:
            if self._cache.exists():
                self._parse(json.load(open(self._cache)))
        except Exception as e:
            log.error(f"  [OPTS] Cache load failed: {e}")

    def _parse(self, data: list):
        """Parse instrument list into per-symbol options chain."""
        now_ist   = datetime.now(IST)
        today_ms  = now_ist.timestamp() * 1000
        min_dte   = timedelta(days=MIN_DTE_ENTRY)

        by_symbol: dict = {}
        for inst in data:
            sym = inst.get("underlying_symbol", "")
            if sym not in ENERGY_META:
                continue
            if inst.get("instrument_type") != "OPT":
                continue
            if inst.get("expiry", 0) <= today_ms:
                continue
            exp_dt  = datetime.fromtimestamp(inst["expiry"] / 1000, tz=IST)
            dte     = (exp_dt.date() - now_ist.date()).days
            if dte < MIN_DTE_ENTRY:
                continue

            by_symbol.setdefault(sym, []).append({
                "key":        inst.get("instrument_key", ""),
                "trading_sym": inst.get("trading_symbol", ""),
                "strike":     inst.get("strike_price", 0),
                "type":       inst.get("option_type", "CE"),    # CE or PE
                "expiry":     inst.get("expiry", 0),
                "expiry_dt":  exp_dt.strftime("%Y-%m-%d"),
                "dte":        dte,
                "lot_size":   inst.get("lot_size", ENERGY_META[sym]["lot_size"]),
                "tick_size":  inst.get("tick_size", ENERGY_META[sym]["tick_size"]),
            })

        for sym, contracts in by_symbol.items():
            contracts.sort(key=lambda x: (x["expiry"], x["type"], x["strike"]))
            self.options[sym] = contracts
            log.info(f"  [OPTS] {sym}: {len(contracts)} option contracts loaded")

    def get_chain(self, symbol: str, expiry_dt: str = None) -> list:
        """
        Return sorted option chain for symbol.
        If expiry_dt given, filter to that expiry; else return nearest expiry.
        """
        contracts = self.options.get(symbol, [])
        if not contracts:
            return []
        if expiry_dt:
            return [c for c in contracts if c["expiry_dt"] == expiry_dt]
        # Default: nearest expiry
        min_exp = min(c["expiry"] for c in contracts)
        return [c for c in contracts if c["expiry"] == min_exp]

    def get_near_expiry_chain(self, symbol: str) -> list:
        """Chain for nearest expiry with DTE >= MIN_DTE_ENTRY."""
        return self.get_chain(symbol)

    def find_strike(self, symbol: str, strike: float,
                    option_type: str, expiry_dt: str = None) -> dict | None:
        """Find exact or nearest strike contract."""
        chain = self.get_chain(symbol, expiry_dt)
        matches = [c for c in chain if c["type"] == option_type]
        if not matches:
            return None
        return min(matches, key=lambda c: abs(c["strike"] - strike))

    def get_atm(self, symbol: str, spot: float,
                option_type: str, expiry_dt: str = None) -> dict | None:
        """ATM contract (nearest strike to spot)."""
        step = ENERGY_META[symbol]["strike_step"]
        atm_strike = bs.atm_strike(spot, step)
        return self.find_strike(symbol, atm_strike, option_type, expiry_dt)

    def get_otm(self, symbol: str, spot: float,
                option_type: str, n_steps: int = 2,
                expiry_dt: str = None) -> dict | None:
        """OTM contract n_steps away from ATM."""
        step = ENERGY_META[symbol]["strike_step"]
        atm_k = bs.atm_strike(spot, step)
        if option_type == "CE":
            target = atm_k + step * n_steps
        else:
            target = atm_k - step * n_steps
        return self.find_strike(symbol, target, option_type, expiry_dt)

    def available_symbols(self) -> list:
        return [s for s in self.options if self.options[s]]


mcx_opt_inst = MCXOptionInstruments()

# ═══════════════════════ SIGNAL LIBRARY ═══════════════════════════════════════

class OptionSignals:
    """
    Lightweight signal generators for MCX energy options.
    All methods are pure functions — no async, no I/O. Termux-friendly.
    """

    @staticmethod
    def iv_rank(current_iv: float, iv_min: float, iv_max: float) -> float:
        """0-100: where current IV sits in its 52-week range."""
        if iv_max <= iv_min:
            return 50.0
        return round((current_iv - iv_min) / (iv_max - iv_min) * 100, 1)

    @staticmethod
    def strangle_signal(spot: float, iv: float, day_chg_pct: float,
                        iv_rank_val: float, meta: dict) -> dict:
        """Sell strangle when IV is elevated but not extreme, range-bound price."""
        if iv < meta.get("iv_typical", 0.30) * 1.1:
            return {"direction": "SKIP", "strength": 0, "reason": "IV too low"}
        if iv > meta.get("iv_high", 0.55) * 0.90:
            return {"direction": "SKIP", "strength": 0, "reason": "IV too high — event risk"}
        if abs(day_chg_pct) > 1.5:
            return {"direction": "SKIP", "strength": 0, "reason": "trending day"}
        strength = 1
        if iv_rank_val > 60:  strength += 1
        if abs(day_chg_pct) < 0.5: strength += 1
        return {"direction": "SHORT_STRANGLE", "strength": strength, "iv": iv, "iv_rank": iv_rank_val}

    @staticmethod
    def bull_spread_signal(candles: list, orb_high: float) -> dict:
        """Bullish signal: price breaks above ORB with momentum."""
        if len(candles) < 5:
            return {"direction": "SKIP", "strength": 0}
        closes = [c["close"] for c in candles[-10:]]
        mom = (closes[-1] - closes[0]) / max(closes[0], 1) * 100
        ltp = closes[-1]
        if ltp > orb_high and mom > 0.5:
            return {"direction": "BULL_SPREAD", "strength": 2 + (1 if mom > 1.0 else 0), "mom": mom}
        return {"direction": "SKIP", "strength": 0}

    @staticmethod
    def bear_spread_signal(candles: list, orb_low: float,
                           eia_draw: float = 0.0) -> dict:
        """Bearish signal: price breaks below ORB or EIA inventory build."""
        if len(candles) < 5:
            return {"direction": "SKIP", "strength": 0}
        closes = [c["close"] for c in candles[-10:]]
        mom = (closes[-1] - closes[0]) / max(closes[0], 1) * 100
        ltp = closes[-1]
        # EIA inventory build → bearish crude
        if eia_draw < -3.0:
            return {"direction": "BEAR_SPREAD", "strength": 3, "eia": eia_draw}
        if ltp < orb_low and mom < -0.5:
            return {"direction": "BEAR_SPREAD", "strength": 2 + (1 if mom < -1.0 else 0)}
        return {"direction": "SKIP", "strength": 0}

    @staticmethod
    def pre_eia_straddle_signal(eia_draw: float = 0.0) -> dict:
        """Enter long straddle on Wednesday before EIA (big move expected either way)."""
        now = datetime.now(IST)
        if now.weekday() != 2:   # Wednesday = 2
            return {"direction": "SKIP", "strength": 0, "reason": "not_wednesday"}
        t = now.time()
        if not (dtime(18, 0) <= t <= dtime(20, 0)):
            return {"direction": "SKIP", "strength": 0, "reason": "outside_pre_eia_window"}
        return {"direction": "LONG_STRADDLE", "strength": 3,
                "reason": "pre_EIA_vol_expected", "expected_draw": eia_draw}

    @staticmethod
    def post_eia_iv_crush_signal() -> dict:
        """Enter short straddle Thursday after IV pops from EIA."""
        now = datetime.now(IST)
        if now.weekday() != 3:   # Thursday = 3
            return {"direction": "SKIP", "strength": 0, "reason": "not_thursday"}
        t = now.time()
        if not (dtime(9, 0) <= t <= dtime(12, 0)):
            return {"direction": "SKIP", "strength": 0, "reason": "outside_post_eia_window"}
        return {"direction": "SHORT_STRADDLE", "strength": 2, "reason": "post_EIA_iv_crush"}

    @staticmethod
    def natgas_seasonal_signal(option_type_hint: str | None, month: int) -> dict:
        """Seasonal NatGas directional option signal."""
        if option_type_hint is None:
            return {"direction": "SKIP", "strength": 0, "reason": "neutral_month"}
        return {
            "direction": f"LONG_{option_type_hint}",
            "strength":  2,
            "month":     month,
            "type":      option_type_hint,
        }

    @staticmethod
    def ratio_spread_signal(crude_chg: float, natgas_chg: float,
                             crude_natgas_ratio: float,
                             ratio_mean: float, ratio_std: float) -> dict:
        """Crude/NatGas ratio deviation signal."""
        if ratio_std <= 0:
            return {"direction": "SKIP", "strength": 0}
        z = (crude_natgas_ratio - ratio_mean) / ratio_std
        if z > 2.0:
            # Crude expensive vs NatGas → sell crude CE, buy NatGas CE
            return {"direction": "RATIO_CRUDE_EXPENSIVE", "strength": 2 + (1 if z > 3 else 0), "z": z}
        if z < -2.0:
            # NatGas expensive vs Crude → sell natgas CE, buy crude CE
            return {"direction": "RATIO_NATGAS_EXPENSIVE", "strength": 2 + (1 if z < -3 else 0), "z": z}
        return {"direction": "SKIP", "strength": 0}


opt_sig = OptionSignals()

# ═══════════════════════ OPTIONS SCANNER ══════════════════════════════════════

async def scan_energy_options(
    broker,
    cash: float,
    candle_cache: dict = None,
    eia_draw_mmbbl: float = 0.0,
    crude_iv: float = 0.35,
    natgas_iv: float = 0.55,
    vix: float = 14.0,
    batch_size: int = 4,
) -> list:
    """
    Scan CRUDEOILM and NATGASMINI for options opportunities.
    Returns list of opportunity dicts, sorted by score descending.

    Optimized for UserLAnd/Termux:
      - Single LTP fetch per symbol (no candle fetch unless cache provided)
      - All BS pricing is in-process (no subprocess)
      - Compact opportunity dicts (no large lists)
    """
    if not mcx_opt_inst.options:
        log.warning("  [OPTS] No instruments — call mcx_opt_inst.refresh() first")
        return []

    now        = datetime.now(IST)
    t          = now.time()
    us_session = t >= US_SESSION_START
    is_morning = t <= dtime(9, 30)

    if not (MCX_OPT_OPEN <= t <= MCX_OPT_NO_ENTRY):
        log.debug("  [OPTS] Outside MCX option trading hours")
        return []

    candle_cache  = candle_cache or {}
    opportunities = []
    rfr           = 0.07    # India risk-free rate

    for sym in ["CRUDEOILM", "NATGASMINI"]:
        meta  = ENERGY_META[sym]
        ivs   = {"CRUDEOILM": crude_iv, "NATGASMINI": natgas_iv}
        iv    = ivs[sym]
        step  = meta["strike_step"]

        if cash < meta["min_capital"]:
            continue
        if sym == "NATGASMINI" and not us_session:
            continue   # NatGas options only during US session

        key_fut = ""   # We'll use a spot proxy from LTP
        try:
            # Attempt to get spot price from any loaded futures key
            # (re-uses MCXInstruments if available, else skip)
            from commodity_futures import mcx_inst as fut_inst
            key_fut = fut_inst.get_key(sym)
        except ImportError:
            pass

        ltp = 0.0
        if key_fut:
            try:
                r = await broker._get(f"/v2/market-quote/ltp?instrument_key={key_fut}")
                for v in r.get("data", {}).values():
                    p = v.get("last_price", 0)
                    if p > 0:
                        ltp = p
                        break
            except Exception as e:
                log.warning(f"  [OPTS] LTP for {sym}: {e}")

        if ltp <= 0:
            log.debug(f"  [OPTS] No LTP for {sym} — skipping")
            continue

        chain = mcx_opt_inst.get_near_expiry_chain(sym)
        if not chain:
            log.debug(f"  [OPTS] No chain for {sym}")
            continue

        nearest_dte = chain[0]["dte"] if chain else 30
        T = max(nearest_dte, 1) / 365.0

        candles    = candle_cache.get(sym, [])
        day_chg    = 0.0
        orb_high   = ltp * 1.005
        orb_low    = ltp * 0.995

        if len(candles) >= 2:
            open_px  = candles[0]["close"]
            day_chg  = (ltp - open_px) / max(open_px, 1) * 100
            if len(candles) >= 3:
                highs = [c["high"] for c in candles[:3]]
                lows  = [c["low"]  for c in candles[:3]]
                orb_high = max(highs)
                orb_low  = min(lows)

        # Calculate IV rank
        iv_min  = meta["iv_typical"] * 0.5
        iv_max  = meta["iv_high"]
        iv_rank_val = opt_sig.iv_rank(iv, iv_min, iv_max)

        month = now.month
        seasonal_type, seasonal_reason = NATGAS_SEASONAL_OPTION.get(month, (None, "neutral"))

        # Price ATM and OTM options using Black-Scholes
        atm_k    = bs.atm_strike(ltp, step)
        otm_info = bs.otm_strikes(ltp, step, n_steps_away=2)

        atm_ce_bs = bs.price(ltp, atm_k, T, rfr, iv, "CE")
        atm_pe_bs = bs.price(ltp, atm_k, T, rfr, iv, "PE")
        otm_ce_bs = bs.price(ltp, otm_info["ce_otm"], T, rfr, iv, "CE")
        otm_pe_bs = bs.price(ltp, otm_info["pe_otm"], T, rfr, iv, "PE")

        lot_size = meta["lot_size"]

        # Evaluate each strategy
        for sid in meta.get("strategies", []):
            strat = OPTION_STRATEGY_CATALOGUE.get(sid, {})
            if cash < strat.get("min_capital", 5000):
                continue

            ss = strat.get("session", "both")
            if ss == "us" and not us_session:
                continue
            if ss == "morning" and not is_morning:
                continue

            # Seasonal month check for NatGas directional strategies
            if sid == "NATGAS_CALL_BUY":
                if month not in strat.get("seasonal_months", []):
                    continue
            if sid == "NATGAS_PUT_BUY":
                if month not in strat.get("seasonal_months", []):
                    continue

            sig = {"direction": "SKIP", "strength": 0}

            if   sid == "CRUDE_STRANGLE":
                sig = opt_sig.strangle_signal(ltp, iv, day_chg, iv_rank_val, meta)
            elif sid == "CRUDE_BULL_SPREAD":
                sig = opt_sig.bull_spread_signal(candles, orb_high)
            elif sid == "CRUDE_BEAR_SPREAD":
                sig = opt_sig.bear_spread_signal(candles, orb_low, eia_draw_mmbbl)
            elif sid == "CRUDE_STRADDLE_BUY":
                sig = opt_sig.pre_eia_straddle_signal(eia_draw_mmbbl)
            elif sid == "CRUDE_IV_CRUSH":
                sig = opt_sig.post_eia_iv_crush_signal()
            elif sid == "CRUDE_PROTECTIVE_PUT":
                # Only if we have an open long futures position (external check)
                sig = {"direction": "PROTECTIVE_PUT", "strength": 1}
            elif sid == "NATGAS_CALL_BUY":
                sig = opt_sig.natgas_seasonal_signal(seasonal_type, month)
                if sig["direction"] != "LONG_CE":
                    sig["direction"] = "LONG_CE"  # force to CE for call buy
            elif sid == "NATGAS_PUT_BUY":
                sig = opt_sig.natgas_seasonal_signal(seasonal_type, month)
                if sig["direction"] != "LONG_PE":
                    sig["direction"] = "LONG_PE"
            elif sid == "NATGAS_STRANGLE":
                sig = opt_sig.strangle_signal(ltp, iv, day_chg, iv_rank_val, meta)
            elif sid == "ENERGY_RATIO_SPREAD":
                # Simplified: use crude/natgas price ratio
                crude_p  = ltp if sym == "CRUDEOILM" else 6000.0
                natgas_p = ltp if sym == "NATGASMINI" else 200.0
                ratio    = crude_p / max(natgas_p, 1)
                sig = opt_sig.ratio_spread_signal(day_chg, 0.0, ratio, 30.0, 5.0)

            if sig["direction"] == "SKIP":
                continue

            score = sig["strength"] + strat.get("score_bonus", 0)
            if iv_rank_val > 70: score += 1
            if score < 3: continue

            # Build legs
            legs = _build_legs(sid, sym, ltp, atm_k, otm_info, step,
                               atm_ce_bs, atm_pe_bs, otm_ce_bs, otm_pe_bs,
                               chain, lot_size)

            if not legs:
                continue

            # Estimate max debit / credit
            net_premium = sum(
                (l["bs_premium"] * (-1 if l["side"] == "sell" else 1))
                for l in legs
            )

            opportunities.append({
                "symbol":         sym,
                "name":           meta["name"],
                "strategy":       sid,
                "strategy_name":  strat["name"],
                "direction":      sig["direction"],
                "score":          score,
                "legs":           legs,
                "ltp":            ltp,
                "atm_strike":     atm_k,
                "dte":            nearest_dte,
                "iv":             round(iv, 3),
                "iv_rank":        iv_rank_val,
                "net_premium":    round(net_premium, 2),
                "lot_size":       lot_size,
                "min_capital":    strat["min_capital"],
                "max_loss":       strat["max_loss"],
                "signal_data":    sig,
                "asset_class":    "energy_option",
                "session":        meta["session"],
                "day_chg_pct":    round(day_chg, 2),
            })

    opportunities.sort(key=lambda x: x["score"], reverse=True)
    return opportunities[:batch_size]


def _build_legs(sid: str, sym: str, ltp: float,
                atm_k: float, otm_info: dict, step: float,
                atm_ce: dict, atm_pe: dict, otm_ce: dict, otm_pe: dict,
                chain: list, lot_size: int) -> list:
    """Build option legs for a given strategy."""
    legs = []

    def _inst(strike: float, opt_type: str) -> dict | None:
        return mcx_opt_inst.find_strike(sym, strike, opt_type)

    if sid in ("CRUDE_STRANGLE", "NATGAS_STRANGLE"):
        ce_inst = _inst(otm_info["ce_otm"], "CE")
        pe_inst = _inst(otm_info["pe_otm"], "PE")
        if ce_inst and pe_inst:
            legs = [
                {"side": "sell", "type": "CE", "strike": otm_info["ce_otm"],
                 "key": ce_inst["key"], "bs_premium": otm_ce["premium"],
                 "delta": otm_ce["delta"], "dte": ce_inst["dte"], "lot_size": lot_size},
                {"side": "sell", "type": "PE", "strike": otm_info["pe_otm"],
                 "key": pe_inst["key"], "bs_premium": otm_pe["premium"],
                 "delta": otm_pe["delta"], "dte": pe_inst["dte"], "lot_size": lot_size},
            ]

    elif sid == "CRUDE_BULL_SPREAD":
        buy_inst  = _inst(atm_k, "CE")
        sell_inst = _inst(otm_info["ce_otm"], "CE")
        if buy_inst and sell_inst:
            legs = [
                {"side": "buy",  "type": "CE", "strike": atm_k,
                 "key": buy_inst["key"], "bs_premium": atm_ce["premium"],
                 "delta": atm_ce["delta"], "dte": buy_inst["dte"], "lot_size": lot_size},
                {"side": "sell", "type": "CE", "strike": otm_info["ce_otm"],
                 "key": sell_inst["key"], "bs_premium": otm_ce["premium"],
                 "delta": otm_ce["delta"], "dte": sell_inst["dte"], "lot_size": lot_size},
            ]

    elif sid == "CRUDE_BEAR_SPREAD":
        buy_inst  = _inst(atm_k, "PE")
        sell_inst = _inst(otm_info["pe_otm"], "PE")
        if buy_inst and sell_inst:
            legs = [
                {"side": "buy",  "type": "PE", "strike": atm_k,
                 "key": buy_inst["key"], "bs_premium": atm_pe["premium"],
                 "delta": atm_pe["delta"], "dte": buy_inst["dte"], "lot_size": lot_size},
                {"side": "sell", "type": "PE", "strike": otm_info["pe_otm"],
                 "key": sell_inst["key"], "bs_premium": otm_pe["premium"],
                 "delta": otm_pe["delta"], "dte": sell_inst["dte"], "lot_size": lot_size},
            ]

    elif sid in ("CRUDE_STRADDLE_BUY", "CRUDE_IV_CRUSH"):
        ce_inst = _inst(atm_k, "CE")
        pe_inst = _inst(atm_k, "PE")
        if ce_inst and pe_inst:
            side = "buy" if sid == "CRUDE_STRADDLE_BUY" else "sell"
            legs = [
                {"side": side, "type": "CE", "strike": atm_k,
                 "key": ce_inst["key"], "bs_premium": atm_ce["premium"],
                 "delta": atm_ce["delta"], "dte": ce_inst["dte"], "lot_size": lot_size},
                {"side": side, "type": "PE", "strike": atm_k,
                 "key": pe_inst["key"], "bs_premium": atm_pe["premium"],
                 "delta": atm_pe["delta"], "dte": pe_inst["dte"], "lot_size": lot_size},
            ]

    elif sid == "CRUDE_PROTECTIVE_PUT":
        inst = _inst(atm_k - step, "PE")
        if inst:
            legs = [
                {"side": "buy", "type": "PE", "strike": atm_k - step,
                 "key": inst["key"], "bs_premium": atm_pe["premium"],
                 "delta": atm_pe["delta"], "dte": inst["dte"], "lot_size": lot_size},
            ]

    elif sid == "NATGAS_CALL_BUY":
        inst = _inst(atm_k + step, "CE")
        if inst:
            legs = [
                {"side": "buy", "type": "CE", "strike": atm_k + step,
                 "key": inst["key"], "bs_premium": otm_ce["premium"],
                 "delta": otm_ce["delta"], "dte": inst["dte"], "lot_size": lot_size},
            ]

    elif sid == "NATGAS_PUT_BUY":
        inst = _inst(atm_k - step, "PE")
        if inst:
            legs = [
                {"side": "buy", "type": "PE", "strike": atm_k - step,
                 "key": inst["key"], "bs_premium": otm_pe["premium"],
                 "delta": otm_pe["delta"], "dte": inst["dte"], "lot_size": lot_size},
            ]

    elif sid == "ENERGY_RATIO_SPREAD":
        ce_inst = _inst(atm_k, "CE")
        if ce_inst:
            legs = [
                {"side": "buy", "type": "CE", "strike": atm_k,
                 "key": ce_inst["key"], "bs_premium": atm_ce["premium"],
                 "delta": atm_ce["delta"], "dte": ce_inst["dte"], "lot_size": lot_size},
            ]

    return legs

# ═══════════════════════ ORDER EXECUTION ══════════════════════════════════════

async def place_option_order(broker, leg: dict, paper: bool = True) -> dict:
    """Place a single option leg order."""
    if paper:
        return {
            "status": "success",
            "data": {"order_ids": [f"P-OPTS-{int(time.time())}"]},
            "leg": leg,
        }
    tx_type = "BUY" if leg["side"] == "buy" else "SELL"
    return await broker._post("/v3/order/place", {
        "quantity":           leg["lot_size"],
        "product":            "I",
        "validity":           "DAY",
        "price":              0,
        "instrument_token":   leg["key"],
        "order_type":         "MARKET",
        "transaction_type":   tx_type,
        "disclosed_quantity": 0,
        "trigger_price":      0,
        "is_amo":             False,
        "slice":              True,
    })


async def enter_option_strategy(broker, opp: dict, paper: bool = True) -> dict:
    """Enter all legs of an option strategy."""
    results = []
    for leg in opp.get("legs", []):
        r = await place_option_order(broker, leg, paper=paper)
        results.append(r)
        await asyncio.sleep(0.1)   # small delay between legs — Termux safe
    success = all(r.get("status") == "success" for r in results)
    return {"status": "success" if success else "partial", "leg_results": results}


async def exit_option_strategy(broker, position: dict, paper: bool = True) -> dict:
    """Exit all legs of an open option strategy position."""
    results = []
    for leg in position.get("legs", []):
        exit_leg = dict(leg)
        exit_leg["side"] = "sell" if leg["side"] == "buy" else "buy"
        r = await place_option_order(broker, exit_leg, paper=paper)
        results.append(r)
        await asyncio.sleep(0.1)
    success = all(r.get("status") == "success" for r in results)
    return {"status": "success" if success else "partial", "leg_results": results}

# ═══════════════════════ P&L MONITOR ══════════════════════════════════════════

async def fetch_option_ltp(broker, leg: dict) -> float:
    """Fetch current premium for a single option leg."""
    key = leg.get("key", "")
    if not key:
        return leg.get("bs_premium", 0.0)
    try:
        r = await broker._get(f"/v2/market-quote/ltp?instrument_key={key}")
        for v in r.get("data", {}).values():
            p = v.get("last_price", 0)
            if p > 0:
                return p
    except Exception as e:
        log.warning(f"  [OPTS] LTP fetch leg {leg.get('strike')}{leg.get('type')}: {e}")
    return leg.get("bs_premium", 0.0)


async def monitor_option_position(broker, position: dict) -> dict:
    """
    Check current P&L for an open option strategy position.
    Returns status dict with current_pnl, pnl_pct, exit_reason if applicable.
    """
    opp     = position.get("opp", {})
    legs    = opp.get("legs", [])
    entry_t = position.get("entry_time")
    sid     = opp.get("strategy", "")
    strat   = OPTION_STRATEGY_CATALOGUE.get(sid, {})
    max_hold = strat.get("hold_min", 60)

    current_pnl = 0.0
    for leg in legs:
        current_premium = await fetch_option_ltp(broker, leg)
        lot_size = leg.get("lot_size", 1)
        entry_prem = leg.get("bs_premium", current_premium)

        if leg["side"] == "buy":
            leg_pnl = (current_premium - entry_prem) * lot_size
        else:
            leg_pnl = (entry_prem - current_premium) * lot_size
        current_pnl += leg_pnl

    net_debit   = abs(opp.get("net_premium", 0)) * opp.get("lot_size", 1)
    pnl_pct     = (current_pnl / max(net_debit, 1)) * 100

    now     = datetime.now(IST)
    held_min = 0.0
    if entry_t:
        held_min = (now - entry_t).total_seconds() / 60

    exit_reason = None
    if pnl_pct >= 50.0:                           exit_reason = "TARGET_50PCT"
    elif pnl_pct <= -80.0:                        exit_reason = "MAX_LOSS_80PCT"
    elif max_hold and held_min >= max_hold:        exit_reason = "TIMEOUT"
    elif now.time() >= MCX_OPT_SQ_OFF:            exit_reason = "MCX_CLOSE"
    elif opp.get("dte", 99) <= FORCE_EXIT_DTE:    exit_reason = "DTE_EXPIRY"

    return {
        "current_pnl":  round(current_pnl, 2),
        "pnl_pct":      round(pnl_pct, 2),
        "held_min":     round(held_min, 1),
        "exit_reason":  exit_reason,
        "should_exit":  exit_reason is not None,
    }

# ═══════════════════════ SESSION HELPERS ══════════════════════════════════════

def mcx_opt_is_open() -> bool:
    now = datetime.now(IST)
    if now.weekday() >= 5:
        return False
    return MCX_OPT_OPEN <= now.time() <= MCX_OPT_CLOSE


def mcx_opt_entry_allowed() -> bool:
    now = datetime.now(IST)
    if now.weekday() >= 5:
        return False
    return MCX_OPT_OPEN <= now.time() < MCX_OPT_NO_ENTRY


def mcx_opt_force_exit() -> bool:
    return datetime.now(IST).time() >= MCX_OPT_SQ_OFF


def us_session_active() -> bool:
    return datetime.now(IST).time() >= US_SESSION_START

# ═══════════════════════ INFO HELPERS ═════════════════════════════════════════

def describe_options(cash: float) -> str:
    now   = datetime.now(IST)
    month = now.month
    lines = [
        f"\nMCX Energy Options v17.2 — Capital: ₹{cash:,.0f}",
        f"Underlyings: CRUDEOILM, NATGASMINI",
        f"Loaded chains: {mcx_opt_inst.available_symbols()}",
        f"Active strategies: {len(OPTION_STRATEGY_CATALOGUE)}",
        "",
    ]
    for sym, meta in ENERGY_META.items():
        chain  = mcx_opt_inst.get_near_expiry_chain(sym)
        dte    = chain[0]["dte"] if chain else "—"
        status = "✓" if cash >= meta["min_capital"] and chain else "✗"
        lines.append(f"  {status} {sym:12s} {meta['name']:20s} min=₹{meta['min_capital']:>6,}  DTE={dte}")

    if month in NATGAS_SEASONAL_OPTION:
        opt_t, reason = NATGAS_SEASONAL_OPTION[month]
        lines.append(f"\n  NatGas seasonal ({now.strftime('%b')}): {reason}")

    lines.append("")
    lines.append("  Strategy Catalogue:")
    for sid, s in OPTION_STRATEGY_CATALOGUE.items():
        assets = "/".join(s["preferred_assets"])
        lines.append(f"    [{sid:<24s}] {s['name']:30s} {assets}  sess={s['session']}")
    return "\n".join(lines)


def bs_quote(symbol: str, spot: float, strike: float,
             option_type: str, dte: int, iv: float) -> str:
    """Quick BS quote for CLI / debugging."""
    T      = max(dte, 1) / 365.0
    result = bs.price(spot, strike, T, 0.07, iv, option_type)
    charges = mcx_opt_charges.calculate(
        result["premium"], result["premium"] * 1.3,
        ENERGY_META.get(symbol, {}).get("lot_size", 10), is_buy=True
    )
    return (
        f"{symbol} {strike}{option_type} DTE={dte}\n"
        f"  BS Premium : ₹{result['premium']}\n"
        f"  Delta      : {result['delta']}\n"
        f"  Theta/day  : ₹{result['theta']}\n"
        f"  Vega/1%IV  : ₹{result['vega']}\n"
        f"  Intrinsic  : ₹{result['intrinsic']}\n"
        f"  Time Value : ₹{result['time_val']}\n"
        f"  Min move   : {mcx_opt_charges.min_profitable_move(spot, strike, result['premium'], ENERGY_META.get(symbol, {}).get('lot_size', 10), option_type):.2f}%\n"
        f"  Breakeven  : ₹{charges['breakeven_pct']}% of debit"
    )


if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.INFO, format="%(message)s")

    print("=" * 60)
    print("MCX Energy Options Module v17.2")
    print("Underlyings: CRUDEOILM, NATGASMINI")
    print("=" * 60)

    # BS sanity check
    print("\n--- Black-Scholes Quick Quote ---")
    print(bs_quote("CRUDEOILM", 6500, 6500, "CE", 7, 0.35))
    print()
    print(bs_quote("NATGASMINI", 220, 230, "CE", 14, 0.55))

    print("\n--- Strategy Catalogue ---")
    for sid, s in OPTION_STRATEGY_CATALOGUE.items():
        assets = "/".join(s["preferred_assets"])
        print(f"  [{sid}] {s['name']}")
        print(f"    {s['description']}")
        print(f"    Legs={s['legs']} | {assets} | sess={s['session']} | hold={s['hold_min']}min")

    print("\n--- Seasonal NatGas Option Bias ---")
    from calendar import month_abbr
    for m, (t, reason) in NATGAS_SEASONAL_OPTION.items():
        print(f"  {month_abbr[m]:3s}: {(t or 'NEUTRAL'):8s} — {reason}")
