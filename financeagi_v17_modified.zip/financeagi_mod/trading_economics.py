#!/usr/bin/env python3
"""
trading_economics.py — FinanceAGI Trading Economics Integration
Provides macro-level signals for Indian markets using Trading Economics API.

Signals:
  1. TE Economic Calendar  — India + US high-impact events with actual vs forecast
  2. India Macro Indicators — Repo rate, CPI, GDP, PMI, current account surplus/deficit
  3. Cross-Asset Markets    — USD/INR, crude oil (TE feed), gold, DXY
  4. TE Forecasts           — Proprietary India macro forecasts (next quarter)
  5. India Bond Yield       — 10Y bond yield as risk-off signal
  6. TE News                — Market-moving financial headlines with importance score

All data cached to DB and refreshed at appropriate intervals.
Pure REST — no tradingeconomics pip package needed (avoids Termux install issues).

Base URL: https://api.tradingeconomics.com
Auth:     ?c={TE_API_KEY}  (appended to every request)
"""

import asyncio, json, logging, math, sqlite3, time
from datetime import datetime, timezone, timedelta, time as dtime
from pathlib import Path
from collections import deque

try:  # IMPORT-FIX
    import httpx
except ImportError:
    httpx = None  # graceful degradation — TE features disabled

log  = logging.getLogger("agi.te")
IST  = timezone(timedelta(hours=5, minutes=30))
BASE = Path(__file__).resolve().parent
DB   = str(BASE / "data" / "v10.db")

ENV = {}
ef  = BASE / ".env"
if ef.exists():
    for ln in ef.read_text().splitlines():
        ln = ln.strip()
        if ln and not ln.startswith("#") and "=" in ln:
            k, v = ln.split("=", 1); ENV[k.strip()] = v.strip()

TE_KEY   = ENV.get("TE_API_KEY", "")
TE_BASE  = "https://api.tradingeconomics.com"
TIMEOUT  = 12

# ── DB helpers ────────────────────────────────────────────────────────────────

def _db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def _save_cache(key: str, value: dict):
    try:
        c = _db()
        c.execute("INSERT OR REPLACE INTO config(key,val) VALUES(?,?)",
                  (f"te_{key}", json.dumps(value)))
        c.commit(); c.close()
    except Exception: pass

def _load_cache(key: str) -> dict:
    try:
        c = _db()
        row = c.execute("SELECT val FROM config WHERE key=?", (f"te_{key}",)).fetchone()
        c.close()
        return json.loads(row["val"]) if row else {}
    except Exception:
        return {}

# ── HTTP helper ───────────────────────────────────────────────────────────────

# Track which endpoints failed so we only log once per session
_endpoint_blocked: set = set()

async def _get(endpoint: str, params: dict = None) -> list | dict:
    """Make a GET request to Trading Economics API."""
    if not TE_KEY:
        return []
    # Skip endpoints we already know are blocked on this plan
    if endpoint in _endpoint_blocked:
        return []
    p = params or {}
    p["c"] = TE_KEY
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            r = await client.get(
                f"{TE_BASE}{endpoint}",
                params=p,
                headers={"User-Agent": "FinanceAGI/13.2"}
            )
            if r.status_code == 200:
                return r.json()
            elif r.status_code in (403, 409):
                # Plan does not have access to this endpoint — block permanently this session
                _endpoint_blocked.add(endpoint)
                log.warning(f"  [TE] {endpoint} → {r.status_code} — endpoint not available on this plan (silencing)")
                return []
            elif r.status_code == 500:
                log.debug(f"  [TE] {endpoint} → 500 server error")
                return []
            else:
                log.debug(f"  [TE] {endpoint} → HTTP {r.status_code}")
                return []
    except Exception as e:
        log.debug(f"  [TE] {endpoint} error: {e}")
        return []

# ═══════════════════════ 1. ECONOMIC CALENDAR ═══════════════════════

class TECalendar:
    """
    Trading Economics economic calendar for India + US.
    Much richer than Finnhub — includes Actual vs Forecast vs Previous,
    Importance (1-3), and RBI-specific events.

    Key Indian events tracked:
      - RBI Interest Rate Decision (importance=3)
      - India CPI Inflation (importance=3)
      - India GDP Growth Rate (importance=3)
      - India Manufacturing PMI (importance=2)
      - India Balance of Trade (importance=2)
      - India Foreign Exchange Reserves (importance=2)
      - US Fed Rate Decision (importance=3, affects FII flows)
      - US CPI (importance=3, affects global risk appetite)
      - US Non-Farm Payrolls (importance=3)
    """
    HIGH_IMPORTANCE = 3
    MED_IMPORTANCE  = 2

    def __init__(self):
        self.events      = []
        self.today_high  = []
        self.week_events = []
        self.last_fetch  = 0.0
        self.surprise_score = 0.0   # +ve = better than expected (bullish), -ve = worse (bearish)

    async def refresh(self):
        """Refresh calendar. Runs every 4 hours."""
        if not TE_KEY:
            return
        if time.time() - self.last_fetch < 3600 * 4:
            return

        now      = datetime.now(IST)
        date_from = now.strftime("%Y-%m-%d")
        date_to   = (now + timedelta(days=7)).strftime("%Y-%m-%d")

        # Fetch India + US events
        # TE calendar: separate requests for India and US to avoid URL encoding issues
        data_in = await _get(f"/calendar/country/india",
                             {"d1": date_from, "d2": date_to})
        data_us = await _get(f"/calendar/country/united%20states",
                             {"d1": date_from, "d2": date_to})
        # Filter to importance 2-3 client-side (TE free plan may not support importance filter)
        data = [e for e in (data_in if isinstance(data_in, list) else []) +
                           (data_us if isinstance(data_us, list) else [])
                if int(e.get("Importance", 1)) >= 2]

        if not data or not isinstance(data, list):
            # Try loading from cache
            cached = _load_cache("calendar")
            if cached:
                self.events = cached.get("events", [])
                self._process()
            return

        self.events = data
        self.last_fetch = time.time()
        self._process()
        _save_cache("calendar", {"events": data, "ts": now.isoformat()})
        log.info(f"  [TE] Calendar: {len(self.events)} events | today_high={len(self.today_high)}")

    def _process(self):
        now   = datetime.now(IST)
        today = now.strftime("%Y-%m-%d")

        self.today_high  = []
        self.week_events = []

        for e in self.events:
            e_date = str(e.get("Date",""))[:10]
            imp    = int(e.get("Importance", 1))
            if e_date == today and imp >= self.MED_IMPORTANCE:
                self.today_high.append(e)
            self.week_events.append(e)

        # Compute surprise score from recent actual vs forecast
        surprises = []
        for e in self.events[-20:]:
            actual   = e.get("Actual")
            forecast = e.get("Forecast") or e.get("TEForecast")
            if actual is None or forecast is None:
                continue
            try:
                a = float(str(actual).replace("%","").replace("K","").replace("B","").strip())
                f = float(str(forecast).replace("%","").replace("K","").replace("B","").strip())
                if f != 0:
                    surprises.append((a - f) / abs(f))
            except Exception:
                pass

        self.surprise_score = round(sum(surprises) / max(1, len(surprises)), 3) if surprises else 0.0

    def is_high_impact_window(self, window_min: int = 45) -> tuple:
        """Returns (True, event_name) if high-impact event within window_min minutes."""
        now = datetime.now(IST)
        for e in self.today_high:
            if int(e.get("Importance",1)) < self.HIGH_IMPORTANCE:
                continue
            try:
                et = datetime.fromisoformat(str(e["Date"]).replace("Z",""))
                if et.tzinfo is None:
                    et = et.replace(tzinfo=IST)
                delta_min = (et - now).total_seconds() / 60
                if -15 <= delta_min <= window_min:
                    return True, e.get("Event", "Unknown")
            except Exception:
                pass
        return False, ""

    @property
    def risk_reduction(self) -> float:
        """
        Position size multiplier based on event risk.
        0.5 = half size (imminent high-impact event)
        0.75 = reduced size (event today)
        1.0 = normal
        """
        in_window, name = self.is_high_impact_window(45)
        if in_window:
            log.info(f"  [TE] Event window: {name} — reducing position to 50%")
            return 0.5
        if self.today_high:
            return 0.75
        return 1.0

    @property
    def macro_bias(self) -> float:
        """
        Score bias from recent surprise: +0.08 if economy beating forecasts, -0.08 if missing.
        """
        if self.surprise_score > 0.05:  return +0.08
        if self.surprise_score < -0.05: return -0.08
        return 0.0

    def week_summary(self) -> str:
        high = [e.get("Event","?") for e in self.week_events if int(e.get("Importance",1)) >= 3]
        return f"{len(self.week_events)} events this week | High: {high[:3]}"

te_calendar = TECalendar()

# ═══════════════════════ 2. INDIA MACRO INDICATORS ═══════════════════════

class IndiaMacro:
    """
    Key Indian macro indicators from Trading Economics.
    Refreshed daily — these are slow-moving but provide the macro backdrop.

    Indicators fetched:
      - Interest Rate (RBI repo rate)
      - Inflation Rate (CPI)
      - GDP Growth Rate
      - Manufacturing PMI
      - Balance of Trade
      - Foreign Exchange Reserves
      - Unemployment Rate
      - Current Account (surplus = INR supportive = Nifty bullish)
    """
    INDICATORS = [
        "interest rate",
        "inflation rate",
        "gdp growth rate",
        "manufacturing pmi",
        "balance of trade",
        "foreign exchange reserves",
        "current account",
    ]

    def __init__(self):
        self.data        = {}   # indicator → {value, previous, forecast, unit}
        self.last_fetch  = 0.0
        self.macro_score = 0.0  # composite macro health score

    async def refresh(self):
        """Refresh once per day."""
        if not TE_KEY:
            return
        if time.time() - self.last_fetch < 3600 * 12:
            return

        # Free TE plan restricts /country endpoint — try individual indicator endpoints
        # These use the historical data API which is more accessible
        raw = await _get("/country/india")
        if not raw:
            # Try indicators by symbol (alternative endpoint)
            raw = await _get("/historical/country/india/indicator/interest rate")

        if not raw or not isinstance(raw, list):
            cached = _load_cache("india_macro")
            if cached:
                self.data = cached.get("data", {})
                self._compute_score()
            return

        self.data = {}
        for item in raw:
            cat = item.get("Category","").lower()
            if any(ind in cat for ind in self.INDICATORS):
                self.data[cat] = {
                    "value":    item.get("LatestValue") or item.get("Value"),
                    "previous": item.get("PreviousValue"),
                    "forecast": item.get("ForecastValue"),
                    "unit":     item.get("Unit",""),
                    "date":     str(item.get("LastUpdate",""))[:10],
                }

        self.last_fetch = time.time()
        self._compute_score()
        _save_cache("india_macro", {"data": self.data, "ts": datetime.now(IST).isoformat()})
        log.info(f"  [TE] India macro: {len(self.data)} indicators | score={self.macro_score:+.2f}")

    def _compute_score(self):
        """
        Composite macro health score for Indian markets.
        Positive = macro tailwinds (bullish), Negative = headwinds (bearish).
        """
        score = 0.0

        # Low inflation = good for markets
        cpi = self._get_val("inflation rate")
        if cpi is not None:
            if cpi < 4:    score += 0.15   # below RBI target = bullish
            elif cpi < 6:  score += 0.05
            elif cpi > 7:  score -= 0.15   # high inflation = RBI hawkish = bearish
            elif cpi > 6:  score -= 0.05

        # GDP growth
        gdp = self._get_val("gdp growth rate")
        if gdp is not None:
            if gdp > 7:    score += 0.15   # strong growth = bullish
            elif gdp > 5:  score += 0.05
            elif gdp < 3:  score -= 0.10

        # Manufacturing PMI > 50 = expansion
        pmi = self._get_val("manufacturing pmi")
        if pmi is not None:
            if pmi > 55:   score += 0.10
            elif pmi > 50: score += 0.05
            elif pmi < 50: score -= 0.10   # contraction

        # Trade balance: surplus = INR strong = FII inflows = bullish
        trade = self._get_val("balance of trade")
        if trade is not None:
            if trade > 0:  score += 0.05
            elif trade < -20: score -= 0.10  # large deficit = INR pressure

        # Interest rate: high rate = tighter liquidity = bearish for equities
        rate = self._get_val("interest rate")
        if rate is not None:
            if rate <= 5.5: score += 0.05   # accommodative
            elif rate >= 7: score -= 0.05   # restrictive

        self.macro_score = round(max(-0.50, min(0.50, score)), 3)

    def _get_val(self, indicator: str) -> float | None:
        for key, data in self.data.items():
            if indicator in key:
                v = data.get("value")
                try: return float(v)
                except Exception:  # BUG-EXCEPT-4 FIX: was bare except
                    return None
        return None

    @property
    def bias(self) -> float:
        """Direct score adjustment from macro conditions. Range ±0.15."""
        return round(self.macro_score * 0.3, 3)  # scale to ±0.15 max

    @property
    def preferred_direction(self) -> str:
        """CE if macro bullish, PE if bearish, BOTH if neutral."""
        if self.macro_score > 0.10: return "CE"
        if self.macro_score < -0.10: return "PE"
        return "BOTH"

    def summary(self) -> str:
        parts = []
        for key, d in list(self.data.items())[:5]:
            v = d.get("value")
            if v is not None:
                parts.append(f"{key.title()[:12]}={v}{d.get('unit','')}")
        return " | ".join(parts) if parts else "No data"

india_macro = IndiaMacro()

# ═══════════════════════ 3. CROSS-ASSET MARKETS ═══════════════════════

class TEMarkets:
    """
    Cross-asset market data from Trading Economics.
    Key for India:
      - USD/INR: Strong rupee = FII inflows = Nifty bullish
      - Crude Oil (Brent): High crude = bad for India (import-heavy) = bearish
      - Gold: High gold = risk-off = bearish for equities
      - DXY (USD Index): Strong dollar = EM selloff = bearish
      - VIX: High VIX = fear = avoid buying options (IV expensive)
    """
    def __init__(self):
        self.usdinr   = 0.0
        self.crude    = 0.0
        self.gold     = 0.0
        self.dxy      = 0.0
        self.vix      = 0.0
        self.last_fetch = 0.0
        self._prev    = {}   # previous values for momentum

    async def refresh(self):
        """Refresh every 30 minutes during trading hours."""
        if not TE_KEY:
            return
        if time.time() - self.last_fetch < 1800:
            return

        # Fetch currency and commodity markets
        # Fetch markets one by one — free plan may restrict batch symbol queries
        # Try batch first, fall back to individual if blocked
        data = await _get("/markets/symbol/USDINR,CRUDOIL,XAUUSD,DXY,VIX")
        if not data:
            # Individual fallback
            all_data = []
            for sym in ["USDINR", "CRUDOIL", "XAUUSD", "DXY", "VIX"]:
                d = await _get(f"/markets/symbol/{sym}")
                if isinstance(d, list): all_data.extend(d)
                elif isinstance(d, dict): all_data.append(d)
            data = all_data

        if not data or not isinstance(data, list):
            cached = _load_cache("markets")
            if cached:
                self._apply(cached.get("data", []))
            return

        self._apply(data)
        self.last_fetch = time.time()
        _save_cache("markets", {"data": data, "ts": datetime.now(IST).isoformat()})
        log.info(f"  [TE] Markets: USDINR={self.usdinr} Crude={self.crude} Gold={self.gold} DXY={self.dxy} VIX={self.vix}")

    def _apply(self, data: list):
        for item in data:
            sym   = str(item.get("Symbol","")).upper()
            price = item.get("Last") or item.get("Price") or 0
            try: price = float(price)
            except Exception:  # BUG-EXCEPT-4 FIX: was bare except
                price = 0.0
            if "USDINR" in sym: self.usdinr = price
            elif "CRUDOIL" in sym or "CRUDE" in sym: self.crude = price
            elif "XAUUSD" in sym or "GOLD" in sym: self.gold = price
            elif "DXY" in sym: self.dxy = price
            elif "VIX" in sym: self.vix = price

    @property
    def crude_signal(self) -> str:
        """BEARISH if crude >90, BULLISH if <70 (for India)."""
        if self.crude > 90: return "BEARISH"
        if self.crude < 70: return "BULLISH"
        return "NEUTRAL"

    @property
    def rupee_signal(self) -> str:
        """BULLISH if INR strengthening (lower USD/INR)."""
        if self.usdinr > 0:
            if self.usdinr < 83: return "BULLISH"
            if self.usdinr > 86: return "BEARISH"
        return "NEUTRAL"

    @property
    def risk_signal(self) -> str:
        """RISK_OFF if VIX > 20 or gold surging."""
        if self.vix > 25: return "RISK_OFF"
        if self.vix > 20: return "CAUTION"
        return "RISK_ON"

    @property
    def bias(self) -> float:
        """Combined cross-asset score adjustment."""
        score = 0.0
        # Crude oil impact on India
        if self.crude > 90:   score -= 0.08
        elif self.crude < 70: score += 0.05
        # Rupee strength
        if self.usdinr > 0:
            if self.usdinr < 83: score += 0.05
            elif self.usdinr > 86: score -= 0.05
        # VIX
        if self.vix > 25: score -= 0.10
        elif self.vix > 20: score -= 0.05
        # DXY
        if self.dxy > 105: score -= 0.05
        elif self.dxy < 100: score += 0.03
        return round(score, 3)

    @property
    def preferred_type(self) -> str:
        """Option type preference from cross-asset signals."""
        b = self.bias
        if b > 0.05:  return "CE"
        if b < -0.05: return "PE"
        return "BOTH"

te_markets = TEMarkets()

# ═══════════════════════ 4. TE FORECASTS ═══════════════════════

class TEForecasts:
    """
    Trading Economics proprietary macro forecasts for India.
    Shows where TE models expect key indicators to be next quarter.
    If forecast is bullish vs current = regime bias.
    Refreshed weekly (slow-moving data).
    """
    def __init__(self):
        self.forecasts   = {}   # indicator → {value, date}
        self.last_fetch  = 0.0
        self.outlook     = "NEUTRAL"   # BULLISH / BEARISH / NEUTRAL

    async def refresh(self):
        """Refresh once per week."""
        if not TE_KEY:
            return
        if time.time() - self.last_fetch < 3600 * 48:
            return

        # Try forecast endpoint — may require paid plan
        data = await _get("/forecast/country/india/indicator/interest%20rate")
        if not data:
            data = await _get("/forecast/country/india")

        if not data or not isinstance(data, list):
            cached = _load_cache("forecasts")
            if cached:
                self.forecasts = cached.get("forecasts", {})
                self._compute_outlook()
            return

        self.forecasts = {}
        for item in data:
            cat = item.get("Category","").lower()
            # TE forecast fields
            self.forecasts[cat] = {
                "current":  item.get("LatestValue"),
                "forecast": item.get("ForecastValue") or item.get("q1") or item.get("Forecast"),
                "date":     str(item.get("ForecastDate",""))[:10],
            }

        self.last_fetch = time.time()
        self._compute_outlook()
        _save_cache("forecasts", {"forecasts": self.forecasts, "ts": datetime.now(IST).isoformat()})
        log.info(f"  [TE] Forecasts: {list(self.forecasts.keys())} | outlook={self.outlook}")

    def _compute_outlook(self):
        bullish = bearish = 0

        # If TE forecasts rate cut → bullish for markets
        rate = self.forecasts.get("interest rate", {})
        cur_r  = self._val(rate.get("current"))
        fc_r   = self._val(rate.get("forecast"))
        if cur_r and fc_r:
            if fc_r < cur_r: bullish += 2   # rate cut = bullish
            elif fc_r > cur_r: bearish += 2  # rate hike = bearish

        # If TE forecasts inflation falling → bullish
        inf = self.forecasts.get("inflation rate", {})
        cur_i = self._val(inf.get("current"))
        fc_i  = self._val(inf.get("forecast"))
        if cur_i and fc_i:
            if fc_i < cur_i: bullish += 1
            elif fc_i > cur_i: bearish += 1

        # GDP forecast
        gdp = self.forecasts.get("gdp growth rate", {})
        cur_g = self._val(gdp.get("current"))
        fc_g  = self._val(gdp.get("forecast"))
        if cur_g and fc_g:
            if fc_g > cur_g: bullish += 1
            elif fc_g < cur_g: bearish += 1

        if bullish > bearish + 1:   self.outlook = "BULLISH"
        elif bearish > bullish + 1: self.outlook = "BEARISH"
        else:                       self.outlook = "NEUTRAL"

    @staticmethod
    def _val(v) -> float | None:
        try: return float(v) if v is not None else None
        except Exception:  # BUG-EXCEPT-4 FIX: was bare except
            return None

    @property
    def bias(self) -> float:
        if self.outlook == "BULLISH": return +0.06
        if self.outlook == "BEARISH": return -0.06
        return 0.0

te_forecasts = TEForecasts()

# ═══════════════════════ 5. INDIA BOND YIELD ═══════════════════════

class IndiaBondYield:
    """
    India 10-year government bond yield from Trading Economics.
    Rising yield = risk-off = institutional money leaving equities → bearish for Nifty
    Falling yield = risk-on = money flowing into equities → bullish
    """
    def __init__(self):
        self.yield_10y   = 0.0
        self.prev_yield  = 0.0
        self.last_fetch  = 0.0

    async def refresh(self):
        """Refresh every hour."""
        if not TE_KEY:
            return
        if time.time() - self.last_fetch < 3600:
            return

        # Try bond by symbol first (more reliable on free plan)
        data = await _get("/markets/symbol/IN10Y-RR")
        if not data:
            data = await _get("/markets/bond", {"country": "india"})

        if not data or not isinstance(data, list):
            return

        for item in data:
            sym = str(item.get("Symbol","") or item.get("Ticker","")).upper()
            if True:  # accept first result from targeted query
                self.prev_yield  = self.yield_10y
                try: self.yield_10y = float(item.get("Last") or item.get("Price") or 0)
                except Exception:  # BUG-EXCEPT-4 FIX: was bare except
                    pass
                self.last_fetch = time.time()
                log.info(f"  [TE] India 10Y: {self.yield_10y:.2f}%")
                break

    @property
    def trend(self) -> str:
        """RISING / FALLING / STABLE."""
        if self.prev_yield <= 0: return "STABLE"
        chg = self.yield_10y - self.prev_yield
        if chg > 0.05:  return "RISING"
        if chg < -0.05: return "FALLING"
        return "STABLE"

    @property
    def bias(self) -> float:
        """Rising yield = bearish for equities."""
        if self.trend == "RISING":  return -0.06
        if self.trend == "FALLING": return +0.06
        # Absolute level: > 7.5% = high yield environment = cautious
        if self.yield_10y > 7.5:    return -0.03
        if self.yield_10y < 6.5:    return +0.03
        return 0.0

india_bonds = IndiaBondYield()

# ═══════════════════════ 6. TE NEWS ═══════════════════════

class TENews:
    """
    Trading Economics financial news for India.
    Higher quality than NewsAPI for market-moving events.
    Each article has an importance score from TE.
    Refreshed every 15 minutes.
    """
    BULL_WORDS = {"surges","rises","gains","record","high","beat","rally","upgrade",
                  "growth","profit","strong","positive","buy","inflows","bullish"}
    BEAR_WORDS = {"falls","drops","plunges","low","miss","selloff","cut","outflows",
                  "recession","weak","bearish","concern","risk","debt","deficit"}

    def __init__(self):
        self.headlines    = []
        self.score        = 0.0   # -1 to +1
        self.last_fetch   = 0.0

    async def refresh(self):
        """Refresh every 15 minutes."""
        if not TE_KEY:
            return
        if time.time() - self.last_fetch < 900:
            return

        # TE news endpoint
        data = await _get("/news/country/india")
        if not data:
            data = await _get("/news/latest/country/india")

        if not data or not isinstance(data, list):
            return

        self.headlines = [
            {"title": item.get("Title",""), "importance": item.get("Importance",1),
             "date": str(item.get("Date",""))[:16]}
            for item in data[:30]
        ]
        self._score()
        self.last_fetch = time.time()
        log.info(f"  [TE] News: {len(self.headlines)} articles | sentiment={self.score:+.2f}")

    def _score(self):
        if not self.headlines:
            self.score = 0.0; return
        bull = bear = 0
        for h in self.headlines:
            words = set(h["title"].lower().split())
            imp   = int(h.get("importance",1))
            bull += len(words & self.BULL_WORDS) * imp
            bear += len(words & self.BEAR_WORDS) * imp
        self.score = round(max(-1, min(1, (bull - bear) / max(1, bull + bear))), 3)

    @property
    def bias(self) -> float:
        """Score adjustment. Range ±0.08."""
        return round(self.score * 0.08, 3)

    def preferred_type(self, underlying: str = "") -> str:
        if self.score > 0.15: return "CE"
        if self.score < -0.15: return "PE"
        return "BOTH"

te_news = TENews()

# ═══════════════════════ COMBINED TE ALPHA SCORE ═══════════════════════

def compute_te_alpha(opt_type: str = "CE", underlying: str = "") -> float:
    """
    Combine all Trading Economics signals into a single score adjustment.
    Range: approximately -0.35 to +0.35
    Called from agent.py alongside compute_alpha_score().
    """
    if not TE_KEY:
        return 0.0

    score = 0.0

    # 1. Economic calendar macro surprise
    score += te_calendar.macro_bias

    # 2. India macro health
    score += india_macro.bias
    if india_macro.preferred_direction not in (opt_type, "BOTH"):
        score -= 0.04

    # 3. Cross-asset markets
    score += te_markets.bias
    if te_markets.preferred_type not in (opt_type, "BOTH"):
        score -= 0.04

    # 4. TE forecasts
    score += te_forecasts.bias
    if te_forecasts.outlook == "BULLISH" and opt_type == "PE": score -= 0.04
    if te_forecasts.outlook == "BEARISH" and opt_type == "CE": score -= 0.04

    # 5. Bond yield
    score += india_bonds.bias

    # 6. TE news
    score += te_news.bias
    if te_news.preferred_type(underlying) not in (opt_type, "BOTH"):
        score -= 0.03

    return round(score, 4)

def te_position_multiplier() -> float:
    """
    Combined position size multiplier from TE risk signals.
    0.5 = imminent high-impact event
    0.75 = event today or high VIX
    1.0 = normal conditions
    """
    mult = te_calendar.risk_reduction
    if te_markets.vix > 25:
        mult = min(mult, 0.6)
    elif te_markets.vix > 20:
        mult = min(mult, 0.8)
    return mult

async def probe_plan():
    """
    Called once at startup to discover which TE endpoints work on this plan.
    Logs a clear summary so you know what data is available.
    """
    if not TE_KEY:
        log.info("  [TE] No API key set — Trading Economics disabled")
        return

    log.info("  [TE] Probing plan access...")
    probes = [
        ("/calendar/country/india",            "Calendar (India)"),
        ("/markets/symbol/USDINR",             "Markets (USDINR)"),
        ("/markets/symbol/CRUDOIL",            "Markets (Crude)"),
        ("/country/india",                     "Indicators (India)"),
        ("/forecast/country/india",            "Forecasts (India)"),
        ("/news/country/india",                "News (India)"),
        ("/markets/bond",                      "Bond Yields"),
    ]
    available = []
    for endpoint, name in probes:
        result = await _get(endpoint)
        status = "✓" if result else "✗ (blocked)"
        if result:
            available.append(name)
        log.info(f"    {status} {name}")

    log.info(f"  [TE] Available on this plan: {available if available else 'None — upgrade at tradingeconomics.com/api'}")
    if not available:
        log.warning("  [TE] Free plan has no accessible endpoints. TE signals disabled.")

async def refresh_all():
    """Refresh all TE signals. Called from agent's background loop."""
    await asyncio.gather(
        te_calendar.refresh(),
        india_macro.refresh(),
        te_markets.refresh(),
        te_forecasts.refresh(),
        india_bonds.refresh(),
        te_news.refresh(),
        return_exceptions=True
    )

def te_status_line() -> str:
    """One-line status for logging."""
    return (
        f"TE: macro={india_macro.macro_score:+.2f} "
        f"mkt={te_markets.bias:+.2f}({te_markets.crude_signal}) "
        f"bond={india_bonds.yield_10y:.1f}%({india_bonds.trend}) "
        f"news={te_news.score:+.2f} "
        f"outlook={te_forecasts.outlook}"
    )
