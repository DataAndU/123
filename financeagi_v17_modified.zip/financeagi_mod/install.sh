#!/bin/bash
set -e
echo "=== FinanceAGI v17.2 + Local LLM Installer ==="

# Swap (4GB VPS needs this for model)
if [ ! -f /swapfile ]; then
    fallocate -l 2G /swapfile && chmod 600 /swapfile
    mkswap /swapfile && swapon /swapfile
    echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi

pip install --break-system-packages -r requirements.txt 2>/dev/null || pip install -r requirements.txt

# Install llama-cpp-python (CPU build)
CMAKE_ARGS="-DLLAMA_BLAS=ON -DLLAMA_BLAS_VENDOR=OpenBLAS" \
pip install llama-cpp-python --no-cache-dir --break-system-packages 2>/dev/null || \
CMAKE_ARGS="-DLLAMA_BLAS=ON" pip install llama-cpp-python --no-cache-dir

# Download model
bash models/download.sh

# Setup env
[ ! -f .env ] && cp .env.example .env && echo "Created .env — edit with your Upstox keys"

echo ""
echo "=== Done ==="
echo "1. Edit .env with your credentials"
echo "2. Set PAPER_TRADING=false when ready for live"
echo "3. python3 agent.py"
