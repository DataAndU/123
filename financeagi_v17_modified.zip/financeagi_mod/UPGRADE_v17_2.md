# FinanceAGI v17.2 Upgrade Notes
## MCX Energy Options — CRUDEOILM + NATGASMINI

---

### What Changed

#### New file: `commodity_options.py`
Fully standalone MCX options module for Crude Oil Mini and Natural Gas Mini.
Zero cross-import with `commodity_futures.py` at runtime — each module loads
independently, so killing one doesn't affect the other.

**Key features:**
- **Black-Scholes engine** — pure Python, no scipy, no numba.
  `math.erf` approximation (Abramowitz & Stegun, max error 1.5e-7).
  Runs in ~0.2ms on Termux ARM64. Returns: premium, delta, gamma, theta, vega.
- **IV solver** — Newton-bisection, 50 iterations max, Termux-safe.
- **MCX options charges** — CTT 0.05% on sell-side premium, brokerage ₹20/order,
  exchange fee 0.05%, GST 18%. Separate from futures CTT (which is on turnover).
- **10 option strategies** across 2 session types (both / us-only):

| ID | Name | Direction | Assets |
|----|------|-----------|--------|
| `CRUDE_STRANGLE` | Crude Strangle Sell | SHORT_STRANGLE | CRUDEOILM |
| `CRUDE_BULL_SPREAD` | Bull Call Spread | BULL_SPREAD | CRUDEOILM |
| `CRUDE_BEAR_SPREAD` | Bear Put Spread | BEAR_SPREAD | CRUDEOILM |
| `CRUDE_STRADDLE_BUY` | Pre-EIA Straddle Buy | LONG_STRADDLE | CRUDEOILM |
| `CRUDE_IV_CRUSH` | Post-EIA IV Crush | SHORT_STRADDLE | CRUDEOILM |
| `CRUDE_PROTECTIVE_PUT` | Futures Protective Put | PROTECTIVE_PUT | CRUDEOILM |
| `NATGAS_CALL_BUY` | Seasonal Call Buy | LONG_CALL | NATGASMINI |
| `NATGAS_PUT_BUY` | Shoulder Put Buy | LONG_PUT | NATGASMINI |
| `NATGAS_STRANGLE` | Quiet Strangle Sell | SHORT_STRANGLE | NATGASMINI |
| `ENERGY_RATIO_SPREAD` | Crude/NatGas Ratio | RATIO_SPREAD | Both |

- **MCX instrument loader** — same Upstox gzip URL as futures, filters
  `instrument_type=OPT`, `segment=MCX_FO`. Caches to `data/mcx_opts.json`.
- **Force-exit** at 11:20 PM IST (10 min before MCX close), DTE ≤ 1 day.
- **UserLAnd/Termux optimizations:**
  - 25s polling cycle (vs 20s futures) — lighter on CPU
  - Lazy instrument load — options chain only loaded once at startup
  - All signal evaluation is synchronous + pure-Python
  - No pandas dependency in this module
  - Compact position dicts — no large arrays in memory

#### Modified: `commodity_futures.py`
- Header updated: removed stale "No options" comment, added cross-reference
  to `commodity_options.py` with import example.
- Added `describe_options_module()` helper — printed at bottom of
  `describe_commodity()` output.
- Version bumped to v17.2.

#### Modified: `agent.py`
- Added `COMMODITY_OPTIONS_ENABLED` env flag (requires `COMMODITY_ENABLED=true`).
- Added conditional import block for `commodity_options` symbols.
- Added `run_commodity_options_loop()` — runs parallel to `run_commodity_loop()`.
  Max 3 concurrent option positions. Uses 35% of the commodity capital slice.
- Wired into `asyncio.gather()`.

#### Modified: `.env.example`
- Added `COMMODITY_OPTIONS_ENABLED=false` with full description.

---

### Enable It

```bash
# In your .env:
COMMODITY_ENABLED=true
COMMODITY_OPTIONS_ENABLED=true
PAPER_TRADING=true          # test paper first

# Restart:
pm2 restart financeagi
# or in Termux/UserLAnd:
python3 agent.py
```

### Standalone test

```bash
# Verify BS pricing and strategy catalogue:
python3 commodity_options.py

# Check that imports are clean:
python3 -c "from commodity_options import scan_energy_options, mcx_opt_inst; print('OK')"
python3 -c "from commodity_futures import scan_commodities, mcx_inst; print('OK')"
```

### Capital split (commodity segment)

| Slice | Allocation |
|-------|-----------|
| Futures (run_commodity_loop) | 65% of ALLOC_COMMODITY |
| Options (run_commodity_options_loop) | 35% of ALLOC_COMMODITY |

Max 3 concurrent option positions. Max 3 concurrent futures positions (unchanged).

### MCX Options specifics (India)
- **European exercise** — no early assignment, squared off intraday (MIS)
- **CTT**: 0.05% on sell-side premium (different from futures CTT on turnover)
- **Weekly expiry** available for CRUDEOILM; NATGASMINI is monthly only
- **Strike step**: CRUDEOILM ₹50 | NATGASMINI ₹10
- **US session** (6:30 PM IST+) required for NatGas strategies and
  EIA-related Crude strategies
- **EIA release**: Wednesday ~8:30 PM IST — use `CRUDE_STRADDLE_BUY` before,
  `CRUDE_IV_CRUSH` on Thursday

---

### Rollback
If issues arise, set `COMMODITY_OPTIONS_ENABLED=false` in `.env` and restart.
`commodity_futures.py` and the existing futures loop are untouched.
