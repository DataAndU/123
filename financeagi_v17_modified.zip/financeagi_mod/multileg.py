"""
multileg.py — DISABLED
Multi-leg options strategies have been removed from FinanceAGI.
Only single-leg options (naked CE/PE buys) are used.

This stub provides empty/no-op versions of the functions that agent.py imports
so the rest of the system continues to work without modification.
"""

import logging
log = logging.getLogger("agi.multileg")

# ── Public API (all no-ops) ──────────────────────────────────────────────────

def find_best_multileg(chain_data, spot, cash, lot_size, sentiment=0, iv=20):
    """Always returns None — multileg disabled."""
    return None


async def place_multileg_order(broker, setup, paper=True):
    """No-op — multileg disabled."""
    log.warning("place_multileg_order called but multileg is disabled")
    return {"status": "error", "error": "multileg disabled"}


async def exit_multileg(broker, legs, paper=True):
    """No-op — multileg disabled."""
    log.warning("exit_multileg called but multileg is disabled")
    return {"status": "error", "error": "multileg disabled"}


async def fetch_leg_ltps(broker, legs):
    """No-op — multileg disabled."""
    return {}


def multileg_charges(legs, exit_prices=None):
    """No-op — multileg disabled."""
    return {"total_charges": 0, "gross_pnl": 0, "net_pnl": 0, "legs_count": 0}


def describe_strategies(cash):
    return "Multi-leg strategies: DISABLED (single-leg only mode)"


def select_strategies_for_capital(cash):
    return []
