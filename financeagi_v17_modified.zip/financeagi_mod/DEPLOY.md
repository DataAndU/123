# FinanceAGI v17.1 — Deploy & Running Guide

## Prerequisites

| Requirement | Minimum | Notes |
|---|---|---|
| OS | Ubuntu 20.04+ / Debian 11+ | Also works on Termux (Android) |
| Python | 3.10+ | `python3 --version` |
| Node.js | 16+ | Required for PM2 |
| RAM | 512 MB | 1 GB recommended for full `all` mode |
| Disk | 500 MB | Logs + DB + model files |
| Network | Stable broadband | Agent makes API calls every 15–30s |

---

## Step 1 — Upload & Extract

```bash
# From your local machine
scp financeagi_v17.tar.gz user@your-vps:/tmp/

# On the VPS
cd /tmp
tar -xzf financeagi_v17.tar.gz
mv financeagi_v17 /data/financeagi
```

Or directly on the server if you cloned/downloaded there:

```bash
mkdir -p /data/financeagi
tar -xzf financeagi_v17.tar.gz -C /data/financeagi --strip-components=1
```

---

## Step 2 — Python Dependencies

```bash
cd /data/financeagi

# Ubuntu / Debian VPS
pip3 install -r requirements.txt --break-system-packages

# If above fails (older pip)
pip3 install httpx numpy
```

Verify:

```bash
python3 -c "import httpx, numpy; print('OK')"
```

---

## Step 3 — Node.js & PM2

```bash
# Ubuntu — install Node.js if missing
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt install -y nodejs

# Termux
pkg install nodejs

# Install PM2 globally
npm install -g pm2
pm2 --version   # should print 5.x
```

---

## Step 4 — Upstox API Setup

1. Log in to **https://developer.upstox.com**
2. Create an app → note your **API Key** and **API Secret**
3. Set the **Redirect URI** to: `http://localhost:8000/callback`
   - For remote VPS access: `http://YOUR_VPS_IP:8000/callback`

---

## Step 5 — Configure `.env`

```bash
cd /data/financeagi
cp .env.example .env
nano .env          # or: vim .env
```

Fill in at minimum:

```dotenv
# ── Required ───────────────────────────────────────────────────
UPSTOX_API_KEY=your_api_key
UPSTOX_API_SECRET=your_api_secret
UPSTOX_REDIRECT_URI=http://localhost:8000/callback

# ── Trading mode ───────────────────────────────────────────────
PAPER_TRADING=true          # KEEP true until you verify everything works
TRADING_ENABLED=true
CAPITAL=10000               # total capital in INR

# ── Asset mode ─────────────────────────────────────────────────
# options | equity | commodity | both | all
ASSET_MODE=both

# ── Capital allocation (0 = divide equally) ────────────────────
ALLOC_OPTIONS=0
ALLOC_EQUITY=0
ALLOC_COMMODITY=0

# ── MCX (only needed if ASSET_MODE=commodity or all) ───────────
COMMODITY_ENABLED=false

# ── Telegram alerts (optional but recommended) ─────────────────
TG_BOT_TOKEN=
TG_CHAT_ID=

# ── News sentiment (optional) ──────────────────────────────────
NEWS_API_KEY=

# ── Ollama LLM for daily self-improvement (optional) ───────────
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=qwen2.5:3b
```

### Capital allocation examples

```dotenv
# ₹30,000 split equally between options and equity
CAPITAL=30000
ASSET_MODE=both
ALLOC_OPTIONS=0
ALLOC_EQUITY=0

# ₹50,000 with custom split: options gets ₹30K, equity ₹20K
CAPITAL=50000
ASSET_MODE=both
ALLOC_OPTIONS=30000
ALLOC_EQUITY=20000

# Full three-way split with MCX
CAPITAL=60000
ASSET_MODE=all
ALLOC_OPTIONS=25000
ALLOC_EQUITY=20000
ALLOC_COMMODITY=15000
COMMODITY_ENABLED=true
```

---

## Step 6 — Deploy with PM2

```bash
cd /data/financeagi
bash deploy.sh
```

The script will:
1. Copy all files into place
2. Install Python deps
3. Verify PM2 is available
4. Stop any old processes
5. Start `financeagi-agent` and `financeagi-dashboard` under PM2
6. Run `pm2 save`

### Persist across reboots (run once)

```bash
pm2 startup
# Copy and run the command it prints, e.g.:
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u ubuntu --hp /home/ubuntu
pm2 save
```

---

## Step 7 — Upstox OAuth Login

The agent needs a daily access token from Upstox. You do this through the dashboard.

1. Open the dashboard in a browser:

   ```
   http://localhost:8000        # local machine
   http://YOUR_VPS_IP:8000      # remote VPS (open port 8000 in firewall)
   ```

2. Click **"Login with Upstox"** — you'll be redirected to Upstox
3. Authorise the app
4. You'll be redirected back to `http://localhost:8000/callback?code=...`
5. The dashboard exchanges the code for an access token and stores it in the DB
6. The status panel should show **"Connected ✓"** with your name and cash balance

> **Daily requirement:** Upstox access tokens expire at midnight. You must log in once per trading day before market open (9:00 AM IST). The dashboard shows a login button when the token has expired.

### Remote VPS — forwarding the OAuth redirect

If your VPS has no browser, forward the port to your laptop first:

```bash
# On your laptop
ssh -L 8000:localhost:8000 user@your-vps

# Then open http://localhost:8000 in your laptop browser
# The OAuth callback will hit your laptop's port 8000
# which tunnels back to the VPS automatically
```

---

## Step 8 — Start / Stop the Agent

All agent control goes through the dashboard UI, or directly via PM2:

```bash
# Start everything
pm2 start ecosystem.config.js

# Stop agent only (leave dashboard running)
pm2 stop financeagi-agent

# Restart agent (e.g. after config change)
pm2 restart financeagi-agent

# Restart everything
pm2 restart all

# View live logs
pm2 logs financeagi-agent
pm2 logs financeagi-agent --lines 200

# Process status + CPU/RAM
pm2 status
pm2 monit
```

> **Important:** Never start the agent from both the dashboard Start button AND PM2 at the same time. The dashboard now detects this and will warn you. Use PM2 as the single source of truth for production.

---

## Daily Workflow

### Trading day checklist

```
[ ] 08:45 AM IST — Open dashboard, click "Login with Upstox"
[ ] 08:50 AM IST — Verify "Connected ✓" and cash balance is correct
[ ] 08:55 AM IST — Confirm PAPER_TRADING=true (first few days)
[ ] 09:00 AM IST — Agent begins scanning at 9:16 AM automatically
[ ] 03:30 PM IST — NSE closes; agent stops trading, waits for MCX if enabled
[ ] 11:30 PM IST — MCX closes; agent idles until next morning
```

### Checking performance during the day

```bash
python3 agent.py stats
```

Output shows: total trades, win rate, P&L, per-strategy breakdown, feature importance, and last 5 trades.

### Reset all learning data (start fresh)

```bash
pm2 stop financeagi-agent
python3 agent.py reset
pm2 start financeagi-agent
```

---

## Optional: Telegram Alerts

1. Message **@BotFather** on Telegram → `/newbot` → copy the token
2. Send any message to your new bot
3. Get your chat ID:
   ```bash
   curl "https://api.telegram.org/botYOUR_TOKEN/getUpdates" | python3 -m json.tool | grep '"id"'
   ```
4. Add to `.env`:
   ```dotenv
   TG_BOT_TOKEN=123456:ABCdef...
   TG_CHAT_ID=987654321
   ```
5. Restart the agent: `pm2 restart financeagi-agent`

You'll now receive trade entry/exit alerts, daily summaries, and error notifications on your phone.

---

## Optional: Daily LLM Self-Improvement (Ollama)

The `daily_update.py` script analyses trade history and asks a local LLM (Qwen2.5:3b) for parameter improvement suggestions, then applies them automatically.

```bash
# Install Ollama
curl -fsSL https://ollama.ai/install.sh | sh

# Pull the model (~2 GB)
ollama pull qwen2.5:3b

# Test it
ollama run qwen2.5:3b "Reply OK"
```

Enable automated daily runs by uncommenting the cron entry in `ecosystem.config.js`:

```js
{
  name: "financeagi-daily-update",
  script: "python3",
  args: "daily_update.py",
  cwd: "/data/financeagi",
  interpreter: "none",
  cron_restart: "0 6 * * *",   // 6 AM IST daily
  autorestart: false,
  ...
}
```

Then: `pm2 restart ecosystem.config.js --update-env`

Or run manually after market close:

```bash
python3 daily_update.py
```

---

## Optional: MCX Commodity Futures

To enable MCX trading:

1. Log in to Upstox → Account → Segments → **Enable MCX Commodity**
2. Wait for activation (usually same day)
3. Update `.env`:
   ```dotenv
   ASSET_MODE=all
   COMMODITY_ENABLED=true
   ALLOC_COMMODITY=15000    # minimum ~₹7,000 for CRUDEOILM
   ```
4. `pm2 restart financeagi-agent`

MCX trades from **9:00 AM – 11:20 PM IST** Mon–Fri. The agent stops new entries at 11:10 PM and force-exits all positions by 11:20 PM.

---

## Monitoring & Logs

```bash
# Live agent log (trades, scans, errors)
pm2 logs financeagi-agent

# Last 500 lines
pm2 logs financeagi-agent --lines 500 --nostream

# Dashboard log
pm2 logs financeagi-dashboard

# Raw log files
tail -f /data/financeagi/logs/agent.log
tail -f /data/financeagi/logs/agent.stdout.log

# LLM update log
cat /data/financeagi/logs/llm_update.log
cat /data/financeagi/logs/llm_suggestions_$(date +%Y%m%d).json
```

---

## Going Live (Real Money)

Only after you have verified paper trading is profitable over at least 2–3 weeks:

1. `pm2 stop financeagi-agent`
2. Edit `.env`:
   ```dotenv
   PAPER_TRADING=false
   CAPITAL=0        # 0 = use actual Upstox margin balance
   ```
3. Confirm your Upstox account has sufficient funds and F&O/equity/MCX segments enabled
4. `pm2 start financeagi-agent`
5. Watch the first few trades closely via Telegram and the dashboard

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `No token. Login via dashboard` | Token expired or not set | Open dashboard → Login with Upstox |
| `Broker.cash error: 401` | Expired/invalid token | Re-login via dashboard |
| `MCX: No instruments loaded` | Instrument refresh failed | Check network; agent retries every 8h |
| Agent exits immediately | Syntax/import error | `python3 agent.py` and read the traceback |
| `Already running externally (PM2?)` | Dashboard tried to start while PM2 is running | Use PM2 only; don't use dashboard Start button when PM2 is active |
| No trades being placed | Outside market hours | NSE: 9:16–15:25 IST weekdays |
| `CIRCUIT BREAKER` in logs | Max drawdown hit | Normal safety feature; resets next day |
| Dashboard unreachable | Port 8000 blocked | `sudo ufw allow 8000` or use SSH tunnel |
| `MCX instruments download failed` | Upstox CDN unreachable | Agent loads from cache automatically |

---

## File Structure

```
/data/financeagi/
├── agent.py              # Main trading agent
├── command_centre.py     # Web dashboard (port 8000)
├── equity_intraday.py    # Equity MIS module
├── commodity_futures.py  # MCX futures module
├── multileg.py           # Multi-leg options engine
├── daily_update.py       # LLM self-improvement
├── ecosystem.config.js   # PM2 process config
├── requirements.txt      # Python dependencies
├── deploy.sh             # One-shot deploy script
├── .env                  # Your credentials (never commit)
├── .env.example          # Template
├── data/
│   ├── v10.db            # SQLite trade history + config
│   ├── nn.pkl            # Neural net weights
│   ├── rl.pkl            # RL Q-table
│   ├── strats.json       # Strategy DNA pool
│   └── mcx_keys.json     # MCX instrument key cache
└── logs/
    ├── agent.log         # Main agent log
    ├── agent.stdout.log  # PM2 stdout
    ├── agent.stderr.log  # PM2 stderr
    ├── dashboard.stdout.log
    └── llm_suggestions_YYYYMMDD.json
```
