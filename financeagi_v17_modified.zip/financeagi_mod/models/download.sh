#!/bin/bash
MODEL_FILE="$(dirname "$0")/phi-3-mini-4k-instruct-q4_k_m.gguf"
[ -f "$MODEL_FILE" ] && echo "Model exists" && exit 0
echo "Downloading Phi-3-mini Q4_K_M (~2.4GB)..."
curl -L --progress-bar -o "$MODEL_FILE" \
  "https://huggingface.co/bartowski/Phi-3-mini-4k-instruct-GGUF/resolve/main/Phi-3-mini-4k-instruct-Q4_K_M.gguf"
