#!/usr/bin/env python3
"""
regime_hmm.py — FinanceAGI v14 Upgrade: HMM Regime + ATR Stops + VIX Kelly

DROP-IN addition. Does NOT modify agent.py.

Three independent upgrades in one file:

1. HMM REGIME DETECTION (3-state: Bull / Bear / Chop)
   - Uses hmmlearn if installed, else falls back to simple rule-based
   - Drives strategy parameter adaptation (wider/tighter SL, position sizing)

2. ATR-BASED DYNAMIC STOPS
   - Replaces fixed % SL with volatility-adaptive stops
   - 5-bar ATR with VIX-scaled multiplier (1.5x calm → 3x storm)

3. VIX-SCALED HALF-KELLY SIZING
   - Scales position from full (VIX<13) to 25% (VIX>22)
   - Drawdown governor: reduces size linearly as DD deepens

Install on Termux (optional, for HMM):
  pip install hmmlearn --break-system-packages
"""

import logging, math, os, pickle, time
from collections import deque
from pathlib import Path

import numpy as np

log = logging.getLogger("agi.regime")
BASE = Path(__file__).resolve().parent
HMM_F = str(BASE / "data" / "hmm_model.pkl")

# ── Try importing hmmlearn ──────────────────────────────────────────────────
_HAS_HMM = False
try:
    from hmmlearn.hmm import GaussianHMM
    _HAS_HMM = True
    log.info("  [REGIME] hmmlearn available — using 3-state Gaussian HMM")
except ImportError:
    log.info("  [REGIME] hmmlearn not installed — using rule-based regime detection")


# ═══════════════════════ 1. HMM REGIME DETECTION ═══════════════════════

class RegimeDetector:
    """
    3-state Hidden Markov Model for regime classification.
    States: BULL (0), BEAR (1), CHOP (2)

    Input features per bar:
      - Log return
      - Realized volatility (rolling 5-bar std)
      - Price range (high-low as % of close)

    Falls back to rule-based if hmmlearn is not installed.
    """

    STATES = {0: "BULL", 1: "BEAR", 2: "CHOP"}
    MIN_SAMPLES = 30  # minimum to fit HMM

    def __init__(self):
        self.model = None
        self.current_regime = "CHOP"
        self.regime_prob = 0.5
        self._history = deque(maxlen=500)  # (return, vol, range) tuples
        self._returns = deque(maxlen=50)
        self._fitted = False
        self._last_fit = 0

    def update(self, spot: float, prev_spot: float, iv: float = 20.0):
        """Feed new price bar. Call every scan cycle."""
        if prev_spot <= 0 or spot <= 0:
            return

        log_ret = math.log(spot / prev_spot)
        self._returns.append(log_ret)

        # Rolling realized vol (5-bar)
        rvol = float(np.std(list(self._returns)[-5:])) if len(self._returns) >= 5 else abs(log_ret)

        # Price range proxy (use IV as substitute since we don't have H/L per bar)
        range_pct = iv / 100.0  # IV as annualized %, scale down

        self._history.append([log_ret, rvol, range_pct])

    def detect(self) -> str:
        """Return current regime string: BULL / BEAR / CHOP"""
        if _HAS_HMM and len(self._history) >= self.MIN_SAMPLES:
            return self._hmm_detect()
        return self._rule_detect()

    def _hmm_detect(self) -> str:
        """Fit HMM and predict current state."""
        try:
            X = np.array(list(self._history))

            # Refit periodically (every 50 new samples or 30 min)
            should_fit = (
                not self._fitted
                or len(self._history) - self._last_fit > 50
                or time.time() - self._last_fit > 1800
            )

            if should_fit:
                self.model = GaussianHMM(
                    n_components=3,
                    covariance_type="full",
                    n_iter=100,
                    random_state=42,
                    init_params="stmc",
                )
                self.model.fit(X)
                self._fitted = True
                self._last_fit = len(self._history)

            if self.model is not None:
                states = self.model.predict(X)
                current_state = states[-1]

                # Identify which HMM state maps to which regime
                # by looking at mean return per state
                means = self.model.means_
                state_returns = {i: means[i][0] for i in range(3)}
                sorted_states = sorted(state_returns.items(), key=lambda x: x[1])

                # Lowest return = BEAR, highest = BULL, middle = CHOP
                bear_state = sorted_states[0][0]
                chop_state = sorted_states[1][0]
                bull_state = sorted_states[2][0]

                mapping = {bull_state: "BULL", bear_state: "BEAR", chop_state: "CHOP"}
                self.current_regime = mapping.get(current_state, "CHOP")

                # Posterior probability of current state
                posteriors = self.model.predict_proba(X[-1:])
                self.regime_prob = float(posteriors[0][current_state])

                return self.current_regime

        except Exception as e:
            log.debug(f"  [REGIME] HMM error: {e}")

        return self._rule_detect()

    def _rule_detect(self) -> str:
        """Simple rule-based fallback."""
        if len(self._returns) < 5:
            self.current_regime = "CHOP"
            self.regime_prob = 0.5
            return "CHOP"

        returns = list(self._returns)[-10:]
        cum_ret = sum(returns)
        vol = float(np.std(returns))

        if cum_ret > 0.003 and vol < 0.005:
            self.current_regime = "BULL"
            self.regime_prob = 0.7
        elif cum_ret < -0.003 and vol < 0.005:
            self.current_regime = "BEAR"
            self.regime_prob = 0.7
        elif vol > 0.006:
            self.current_regime = "CHOP"  # high vol = choppy
            self.regime_prob = 0.6
        else:
            self.current_regime = "CHOP"
            self.regime_prob = 0.5

        return self.current_regime

    @property
    def strategy_params(self) -> dict:
        """
        Regime-adaptive parameter multipliers.
        Apply these to strategy SL/target/size.
        """
        if self.current_regime == "BULL":
            return {
                "sl_mult": 1.2,       # wider SL in trends (let it run)
                "target_mult": 1.3,   # extend targets
                "size_mult": 1.0,     # full size
                "prefer_type": "CE",
            }
        elif self.current_regime == "BEAR":
            return {
                "sl_mult": 1.2,
                "target_mult": 1.3,
                "size_mult": 1.0,
                "prefer_type": "PE",
            }
        else:  # CHOP
            return {
                "sl_mult": 0.8,       # tighter SL in chop (cut quick)
                "target_mult": 0.8,   # smaller targets
                "size_mult": 0.6,     # reduced size
                "prefer_type": "BOTH",
            }

    def save(self):
        try:
            pickle.dump({
                "history": list(self._history),
                "returns": list(self._returns),
                "regime": self.current_regime,
            }, open(HMM_F, "wb"))
        except Exception:
            pass

    def load(self):
        if not os.path.exists(HMM_F):
            return
        try:
            d = pickle.load(open(HMM_F, "rb"))
            self._history = deque(d.get("history", []), maxlen=500)
            self._returns = deque(d.get("returns", []), maxlen=50)
            self.current_regime = d.get("regime", "CHOP")
        except Exception:
            pass

    def status_line(self) -> str:
        return f"[REGIME] {self.current_regime} ({self.regime_prob:.0%}) samples={len(self._history)} {'HMM' if _HAS_HMM and self._fitted else 'RULE'}"


regime_detector = RegimeDetector()


# ═══════════════════════ 2. ATR-BASED DYNAMIC STOPS ═══════════════════════

class ATRStopCalculator:
    """
    ATR (Average True Range) based dynamic stop-loss and target.

    Instead of fixed 5% SL:
      SL = ATR_multiplier × ATR_pct
      where multiplier scales with IV/VIX:
        VIX < 13  → 1.5x ATR
        VIX 13-17 → 2.0x ATR
        VIX 17-22 → 2.5x ATR
        VIX > 22  → 3.0x ATR

    ATR is computed from option premium changes (not underlying price),
    because we're trading options where premium is the actual P&L driver.
    """

    def __init__(self, lookback: int = 14):
        self.lookback = lookback
        self._premium_bars = deque(maxlen=lookback + 1)  # recent premium readings per underlying

    def feed_premium(self, premium: float):
        """Feed option premium for ATR computation."""
        self._premium_bars.append(premium)

    def atr_pct(self) -> float:
        """
        ATR as percentage of current premium.
        Returns a reasonable default if not enough data.
        """
        bars = list(self._premium_bars)
        if len(bars) < 3:
            return 3.0  # default 3% ATR

        # True Range = |current - previous| as % of current
        trs = []
        for i in range(1, len(bars)):
            if bars[i] > 0:
                tr = abs(bars[i] - bars[i-1]) / bars[i] * 100
                trs.append(tr)

        if not trs:
            return 3.0

        return float(np.mean(trs[-self.lookback:]))

    @staticmethod
    def vix_multiplier(iv: float) -> float:
        """
        Scale ATR multiplier based on IV level (proxy for VIX).
        Higher vol → wider stop to avoid noise whipsaws.
        """
        if iv < 13:   return 1.5
        if iv < 17:   return 2.0
        if iv < 22:   return 2.5
        return 3.0

    def dynamic_sl(self, iv: float, strategy_sl_pct: float) -> float:
        """
        Compute dynamic SL as max(ATR-based, floor).
        Returns SL in percentage (same unit as strategy's stoploss_pct).

        The floor is 50% of the strategy's configured SL to never be too tight.
        """
        atr = self.atr_pct()
        mult = self.vix_multiplier(iv)
        atr_sl = atr * mult
        floor = strategy_sl_pct * 0.5
        # Cap at 2x the strategy's SL to prevent infinite holding
        ceiling = strategy_sl_pct * 2.0
        return round(max(floor, min(ceiling, atr_sl)), 2)

    def dynamic_target(self, iv: float, strategy_target_pct: float) -> float:
        """
        Dynamic target: scale target based on volatility.
        In low vol: smaller targets (realistic).
        In high vol: bigger targets (let it run).
        """
        mult = self.vix_multiplier(iv)
        # Target scales: 0.8x in calm, 1.5x in storm
        target_scale = 0.6 + (mult - 1.5) * 0.6  # maps 1.5→0.6, 3.0→1.5
        target_scale = max(0.7, min(1.5, target_scale))
        return round(strategy_target_pct * target_scale, 2)


# Per-underlying ATR trackers
_atr_trackers = {}  # underlying_name → ATRStopCalculator

def get_atr_tracker(underlying: str) -> ATRStopCalculator:
    """Get or create ATR tracker for an underlying."""
    if underlying not in _atr_trackers:
        _atr_trackers[underlying] = ATRStopCalculator()
    return _atr_trackers[underlying]


# ═══════════════════════ 3. VIX-SCALED HALF-KELLY ═══════════════════════

class AdaptiveKelly:
    """
    Half-Kelly position sizing with VIX scaling and drawdown governor.

    Base: Kelly fraction × 0.5 (half-Kelly = 75% of full growth, much less DD)
    VIX scale: 1.0 (VIX<13) → 0.5 (VIX 17-22) → 0.25 (VIX>22)
    DD governor: 1.0 (DD<5%) → 0.5 (DD=10%) → 0.25 (DD≥15%)
    Time decay: full before 11:30, ramps down to 25% by 15:00

    Final position = cash × half_kelly × vix_scale × dd_scale × time_scale
    """

    @staticmethod
    def vix_scale(iv: float) -> float:
        """Position multiplier based on IV (VIX proxy)."""
        if iv < 13:   return 1.0
        if iv < 17:   return 0.75
        if iv < 22:   return 0.5
        return 0.25

    @staticmethod
    def dd_scale(start_cash: float, cur_cash: float) -> float:
        """Drawdown governor: reduce size as drawdown deepens."""
        if start_cash <= 0:
            return 1.0
        dd_pct = (start_cash - cur_cash) / start_cash * 100
        if dd_pct < 3:    return 1.0
        if dd_pct < 5:    return 0.8
        if dd_pct < 10:   return 0.5
        if dd_pct < 15:   return 0.25
        return 0.1  # near circuit-breaker territory

    @staticmethod
    def time_scale(hour: float) -> float:
        """Reduce position size as day progresses (theta decay)."""
        if hour < 11.5:   return 1.0
        if hour < 13.5:   return 0.8
        if hour < 14.5:   return 0.5
        return 0.25

    @staticmethod
    def half_kelly(wr: float, avg_win: float, avg_loss: float) -> float:
        """
        Half-Kelly fraction.
        wr: win rate as decimal (0.55 = 55%)
        avg_win: average win in % (e.g. 5.0)
        avg_loss: average loss in % (e.g. -3.0, takes abs)
        """
        avg_loss = abs(avg_loss)
        if avg_loss == 0 or wr == 0:
            return 0.25  # minimum bet default

        b = avg_win / avg_loss  # odds ratio
        p = wr
        f = (b * p - (1 - p)) / b  # Kelly fraction
        f *= 0.5  # HALF Kelly

        # Floor and ceiling
        return max(0.10, min(0.60, f))

    def compute(
        self,
        wr: float,        # win rate as decimal
        avg_win: float,   # average win %
        avg_loss: float,  # average loss % (negative)
        cash: float,      # total available cash
        iv: float,        # current IV (VIX proxy)
        start_cash: float,# day start cash
        cur_cash: float,  # current cash
        hour: float,      # current hour (24h)
    ) -> float:
        """
        Compute position budget in rupees.
        Returns: amount of cash to risk on this trade.
        """
        hk = self.half_kelly(wr, avg_win, avg_loss)
        vs = self.vix_scale(iv)
        ds = self.dd_scale(start_cash, cur_cash)
        ts = self.time_scale(hour)

        # Regime adjustment from regime detector
        regime_params = regime_detector.strategy_params
        rs = regime_params.get("size_mult", 1.0)

        fraction = hk * vs * ds * ts * rs
        budget = cash * fraction

        log.info(f"  [KELLY] hk={hk:.2f} vix={vs:.2f} dd={ds:.2f} time={ts:.2f} regime={rs:.2f} → {fraction:.2f} → Rs{budget:.0f}")

        return budget

    def status_line(self, iv: float, start_cash: float, cur_cash: float, hour: float) -> str:
        vs = self.vix_scale(iv)
        ds = self.dd_scale(start_cash, cur_cash)
        ts = self.time_scale(hour)
        return f"[KELLY] VIX={vs:.2f} DD={ds:.2f} Time={ts:.2f}"


adaptive_kelly = AdaptiveKelly()


# ═══════════════════════ 4. VANNA + CHARM GREEKS ═══════════════════════

class HigherGreeks:
    """
    Second-order Greeks: Vanna and Charm.
    Adds edge on 0-3 DTE options where these dominate P&L.

    Vanna = dDelta/dVol = dVega/dSpot
      - As IV rises → OTM put deltas increase → dealers sell more underlying → acceleration
      - Positive vanna + falling IV = tailwind for long calls

    Charm = dDelta/dTime (delta decay per day)
      - OTM options lose delta as time passes → dealers unwind hedges
      - Creates a structural bid late in the day (positive for CE buyers PM session)

    We approximate from available Greeks since Upstox doesn't provide vanna/charm directly:
      Vanna ≈ Gamma × sqrt(T) / (IV × sqrt(2π))    [simplified BSM]
      Charm ≈ -Gamma × (r - (IV² / 2) × d₁) / (2T) [simplified]

    For practical use: we just compute bias scores, not exact values.
    """

    @staticmethod
    def vanna_bias(delta: float, gamma: float, iv: float, dte: int) -> float:
        """
        Vanna signal: how much will IV change affect this option?
        Returns score adjustment (-0.10 to +0.10).
        """
        if dte <= 0 or iv <= 0 or gamma <= 0:
            return 0.0

        # Approximate vanna magnitude
        T = max(0.01, dte / 365.0)
        vanna_approx = abs(gamma) * math.sqrt(T) / (iv / 100.0) if iv > 0 else 0

        # High vanna + low IV = options are cheap and sensitive to vol expansion
        # This is GOOD for option buyers
        if iv < 18 and vanna_approx > 0.001:
            return +0.06  # boost: IV expansion will help
        # High vanna + high IV = risky, IV crush will hurt
        if iv > 25 and vanna_approx > 0.001:
            return -0.06  # penalize: IV crush will hurt
        return 0.0

    @staticmethod
    def charm_bias(delta: float, gamma: float, theta: float, dte: int, hour: float) -> float:
        """
        Charm signal: is time decay working for or against us?
        Returns score adjustment (-0.08 to +0.08).

        Key insight: charm creates a PM session bias:
        - After 2 PM, OTM options decay faster → dealers unwind → market stabilizes
        - Buying OTM options PM session = fighting charm (bad)
        - Buying ITM/ATM options PM session = charm is less relevant
        """
        if dte <= 0:
            return 0.0

        # Strong charm effect only on 0-3 DTE
        if dte > 3:
            return 0.0

        abs_delta = abs(delta)

        # PM session (after 2 PM): charm accelerates for OTM options
        if hour >= 14:
            if abs_delta < 0.25:  # OTM
                return -0.08  # penalize: theta decay accelerating
            elif abs_delta > 0.45:  # ATM/ITM
                return +0.04  # slight boost: delta is sticky
            return -0.03

        # AM session: charm effect is gentler
        if abs_delta < 0.15:
            return -0.04  # far OTM still penalized
        return 0.0

    def combined_bias(self, delta: float, gamma: float, theta: float,
                      iv: float, dte: int, hour: float) -> float:
        """Combined Vanna + Charm bias score."""
        v = self.vanna_bias(delta, gamma, iv, dte)
        c = self.charm_bias(delta, gamma, theta, dte, hour)
        return round(v + c, 4)


higher_greeks = HigherGreeks()
