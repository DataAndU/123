#!/usr/bin/env python3
"""
equity_strategy_inventor.py — FinanceAGI v17: AI Equity Strategy Inventor & Manager
=====================================================================================

Invents, evaluates, mutates, and manages NSE equity intraday (MIS) trading
strategies using Claude claude-sonnet-4-20250514. Covers penny stocks through large caps
with MIS leverage.

Strategy Types Invented:
  MOMENTUM_SCALP    — Ride intraday momentum (0.3-1% moves)
  MEAN_REVERT       — Fade extremes, buy low sell high within day range
  ORB_BREAKOUT      — Opening Range Breakout (first 15/30 min range)
  VWAP_BOUNCE       — Trade bounces off VWAP
  GAP_FILL          — Trade gap fills on opening gaps
  SECTOR_ROTATION   — Rotate into strongest/weakest sector stocks
  PAIR_TRADE         — Long strong + short weak in same sector
  NEWS_MOMENTUM     — Trade on news-driven moves
  VOLUME_SPIKE      — Enter on unusual volume surge
  REVERSAL          — Catch intraday reversals at support/resistance
  PREMARKET_FOLLOW  — Follow GIFT Nifty / SGX direction
  EOD_SCALP         — Last-hour momentum scalps

Architecture:
  ┌──────────────────────────────────────────────────────────────────────┐
  │  EquityStrategyInventor  (main class)                               │
  │   ├─ EquityStrategyDB       — persist strategies to JSON            │
  │   ├─ EquityPerformance      — rolling WR / Sharpe / per-tier stats  │
  │   ├─ EquityLLMInventor      — Claude API invention engine           │
  │   ├─ EquityEvolution        — kill / breed / mutate                 │
  │   └─ StockUniverse          — capital-adaptive stock selection       │
  └──────────────────────────────────────────────────────────────────────┘

Integration with agent.py:
  1. Import: `from equity_strategy_inventor import equity_inventor`
  2. After each equity trade closes:
       equity_inventor.record_trade(strategy_name, won, pnl_pct, stock_info)
  3. Periodically:
       new_strats = await equity_inventor.maybe_invent(market_context)
  4. equity_inventor.pick_strategy(stock_opps, cash) replaces EQ_STRATEGIES
  5. equity_inventor.active_strategies() for live strategy list

Usage (standalone):
  python3 equity_strategy_inventor.py              # Print active strategies
  python3 equity_strategy_inventor.py invent       # Force-invent via LLM
  python3 equity_strategy_inventor.py status       # Performance table
  python3 equity_strategy_inventor.py evolve       # Run evolution cycle

Environment:
  ANTHROPIC_API_KEY          — required for LLM invention
  EQ_INVENTOR_MAX_STRATS     — max live strategies (default 15)
  EQ_INVENTOR_KILL_WR        — kill threshold (default 0.40)
  EQ_INVENTOR_MIN_TRADES     — min trades before kill eligible (default 8)
"""

import asyncio
import copy
import hashlib
import json
import logging
import math
import os
import random
import sqlite3
import sys
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

try:
    import httpx
    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False
    httpx = None

log = logging.getLogger("agi.eq_inventor")
IST = timezone(timedelta(hours=5, minutes=30))
BASE = Path(__file__).resolve().parent
DB   = str(BASE / "data" / "v10.db")
EQ_STRAT_FILE = BASE / "data" / "invented_equity_strategies.json"

# ── Load environment ───────────────────────────────────────────────────────────
def _env(key: str, default: str = "") -> str:
    ef = BASE / ".env"
    if ef.exists():
        for ln in ef.read_text().splitlines():
            ln = ln.strip()
            if ln and not ln.startswith("#") and "=" in ln:
                k, v = ln.split("=", 1)
                if k.strip() == key:
                    return v.strip()
    return os.environ.get(key, default)

ANTHROPIC_API_KEY = _env("ANTHROPIC_API_KEY")
MAX_STRATS        = int(_env("EQ_INVENTOR_MAX_STRATS", "15"))
KILL_WR           = float(_env("EQ_INVENTOR_KILL_WR", "0.40"))
MIN_TRADES        = int(_env("EQ_INVENTOR_MIN_TRADES", "8"))


# ═══════════════════════ STRATEGY SCHEMA ═══════════════════════════════════════

EQ_STRATEGY_TYPES = [
    "momentum_scalp", "mean_revert", "orb_breakout", "vwap_bounce",
    "gap_fill", "sector_rotation", "pair_trade", "news_momentum",
    "volume_spike", "reversal", "premarket_follow", "eod_scalp",
]

EQ_SIGNAL_TYPES = [
    "PRICE_MOMENTUM",      # Simple price momentum (up=buy, down=sell)
    "VOLUME_BREAKOUT",     # Volume surge + price breakout
    "RANGE_POSITION",      # Trade based on position within day range
    "VWAP_CROSS",          # VWAP crossover
    "GAP_ANALYSIS",        # Opening gap direction / fill
    "RSI_EXTREME",         # RSI overbought/oversold
    "SECTOR_STRENGTH",     # Relative sector strength
    "OI_DELIVERY",         # OI + delivery % signal (for MIS stocks)
    "FII_DII_FLOW",        # Institutional flow direction
    "GIFT_NIFTY_LEAD",     # GIFT Nifty / SGX leading indicator
    "NEWS_SENTIMENT",      # News-driven sentiment score
    "TICK_MOMENTUM",       # Tick-by-tick momentum (micro-structure)
    "EMA_CROSS",           # EMA crossover (e.g. 9/21 EMA)
    "BOLLINGER_SQUEEZE",   # Bollinger band squeeze → breakout
    "CUSTOM_LLM",         # Pure LLM-invented signal
]

STOCK_TIERS = ["penny", "low", "mid", "high"]

# Stock sectors for sector-aware strategies
STOCK_SECTORS = {
    "BANKING":  ["SBIN", "PNB", "BANKBARODA", "IDFCFIRSTB", "HDFCBANK", "ICICIBANK", "AXISBANK"],
    "POWER":    ["NHPC", "NTPC", "POWERGRID", "PFC", "RECLTD"],
    "INFRA":    ["IRFC", "RVNL", "NBCC", "IRCTC", "HUDCO"],
    "METAL":    ["TATASTEEL"],
    "IT":       ["INFY", "WIPRO", "TCS"],
    "ENERGY":   ["IOC", "RELIANCE", "BHARTIARTL"],
    "CONSUMER": ["ITC", "ADANIENT"],
    "GREEN":    ["SUZLON", "JPPOWER", "HFCL"],
}

EQ_STRATEGY_DEFAULTS: dict = {
    "name":              "",
    "version":           1,
    "generation":        0,
    "created_at":        "",
    "asset_class":       "equity",
    # Stock targeting
    "target_tiers":      ["penny", "low", "mid"],   # which tiers to trade
    "target_sectors":    ["ALL"],                     # which sectors
    "target_stocks":     [],                          # specific stocks (empty=all in tiers)
    # Strategy type
    "strategy_type":     "momentum_scalp",
    "signal_type":       "PRICE_MOMENTUM",
    "direction":         "BOTH",        # "BUY" | "SELL" | "BOTH"
    # Entry conditions
    "min_volatility":    0.3,           # min day range %
    "max_volatility":    5.0,           # max day range %
    "min_score":         2,             # min scanner score to enter
    "min_volume_ratio":  1.0,           # volume vs avg ratio (1.0 = normal)
    "range_pos_min":     0.0,           # min position in day range (0=low, 1=high)
    "range_pos_max":     1.0,           # max position in day range
    "day_change_min":    -5.0,          # min day change %
    "day_change_max":    5.0,           # max day change %
    # Risk parameters
    "target_pct":        0.5,           # profit target %
    "stoploss_pct":      0.3,           # stoploss %
    "max_hold_min":      15,            # max holding time
    "trailing_sl":       True,
    "trailing_activation_pct": 0.3,     # activate after this profit
    "trailing_distance_pct":   0.15,    # trailing distance
    # Timing
    "hour_start":        9,
    "hour_end":          15,
    "avoid_first_min":   5,             # avoid first N minutes
    "avoid_last_min":    5,             # avoid last N minutes
    # Capital & sizing
    "capital_pct":       0.30,          # fraction of equity allocation
    "max_shares_pct":    0.60,          # max % of buying power on single stock
    "min_shares":        5,             # minimum shares
    "leverage_use":      "FULL",        # "FULL" | "HALF" | "NONE"
    # Filters
    "breakeven_max_pct": 0.25,          # max breakeven % to accept
    "trend_filter":      "NONE",        # "NONE" | "WITH" | "AGAINST"
    "sector_filter":     "ANY",         # "ANY" | "STRONGEST" | "WEAKEST"
    # MIS-specific
    "short_allowed":     True,          # allow MIS short selling
    "exit_before_close": True,          # exit 10 min before close
    # Metadata
    "rationale":         "",
    "tags":              [],
    "parent_names":      [],
    "active":            True,
    "trades":            0,
    "wins":              0,
    "total_pnl":         0.0,
    "peak_pnl":          0.0,
    "max_drawdown":      0.0,
    "last_trade_ts":     "",
    "avg_hold_min":      0.0,
    # Per-tier performance
    "tier_performance":  {},            # {"penny": {"n": 0, "wr": 0}, ...}
}

EQ_MUTABLE_GENES = [
    "direction", "strategy_type", "signal_type",
    "min_volatility", "max_volatility", "min_score",
    "min_volume_ratio", "range_pos_min", "range_pos_max",
    "day_change_min", "day_change_max",
    "target_pct", "stoploss_pct", "max_hold_min",
    "trailing_sl", "trailing_activation_pct", "trailing_distance_pct",
    "hour_start", "hour_end", "capital_pct", "max_shares_pct",
    "breakeven_max_pct", "trend_filter", "sector_filter",
    "short_allowed", "leverage_use",
]


# ═══════════════════════ EQUITY SCORER ═════════════════════════════════════════

class EquityScorer:
    """
    Scores equity opportunities against strategies.
    Uses price action, volume, sector, and timing signals.
    """

    @staticmethod
    def score_stock(stock: dict, strategy: dict, cash: float) -> float:
        """Score a stock opportunity for a strategy. Higher = better fit."""
        score = 0.0
        s = strategy

        volatility = stock.get("volatility", 0)
        range_pos  = stock.get("range_position", 0.5)
        day_change = stock.get("day_change_pct", 0)
        vol_score  = stock.get("score", 0)
        be_pct     = stock.get("breakeven_pct", 0.5)
        tier       = stock.get("tier", "mid")
        direction  = stock.get("direction", "BUY")

        # Volatility fit
        if s["min_volatility"] <= volatility <= s["max_volatility"]:
            score += 1.5
        elif volatility < s["min_volatility"]:
            return 0.0  # too quiet, skip

        # Range position fit
        if s["range_pos_min"] <= range_pos <= s["range_pos_max"]:
            score += 1.0

        # Day change fit
        if s["day_change_min"] <= day_change <= s["day_change_max"]:
            score += 0.5

        # Scanner score
        if vol_score >= s["min_score"]:
            score += 1.0
            if vol_score >= s["min_score"] + 2:
                score += 0.5

        # Charges check
        if be_pct <= s["breakeven_max_pct"]:
            score += 1.5
        else:
            score -= 1.0

        # Tier fit
        if tier in s.get("target_tiers", STOCK_TIERS):
            score += 0.5

        # Direction fit
        if s["direction"] == "BOTH" or s["direction"] == direction:
            score += 1.0
        elif not s.get("short_allowed", True) and direction == "SELL":
            return 0.0

        # Strategy-type specific scoring
        st = s["strategy_type"]
        if st == "momentum_scalp":
            if abs(day_change) > 0.3 and volatility > 0.5:
                score += 1.5
        elif st == "mean_revert":
            if range_pos < 0.2 or range_pos > 0.8:
                score += 2.0  # at extremes = mean revert opportunity
        elif st == "orb_breakout":
            h = datetime.now(IST).hour
            m = datetime.now(IST).minute
            if h == 9 and m < 45:
                score += 1.5  # ORB window
        elif st == "vwap_bounce":
            if 0.45 <= range_pos <= 0.55:
                score += 1.5  # near VWAP
        elif st == "volume_spike":
            vol_ratio = stock.get("volume", 0) / max(stock.get("avg_volume", 1), 1)
            if vol_ratio > 2.0:
                score += 2.0
        elif st == "eod_scalp":
            h = datetime.now(IST).hour
            if h >= 14:
                score += 2.0  # EOD window
        elif st == "gap_fill":
            if abs(day_change) > 1.0:
                score += 1.5  # gap exists
        elif st == "reversal":
            if (range_pos < 0.15 and day_change < -1.0) or \
               (range_pos > 0.85 and day_change > 1.0):
                score += 2.5

        return round(score, 2)


eq_scorer = EquityScorer()


# ═══════════════════════ PERFORMANCE TRACKER ═══════════════════════════════════

class EquityPerformanceTracker:
    """Per-strategy rolling performance with tier attribution."""

    def __init__(self, window: int = 40):
        self.window = window
        self._trades: dict[str, deque] = defaultdict(lambda: deque(maxlen=window))
        self._tier_trades: dict[str, dict[str, list]] = defaultdict(lambda: defaultdict(list))

    def record(self, strategy: str, won: bool, pnl_pct: float,
               stock_info: dict = None):
        entry = {"won": won, "pnl": pnl_pct, "ts": time.time()}
        if stock_info:
            entry["tier"]  = stock_info.get("tier", "unknown")
            entry["stock"] = stock_info.get("name", "")
            entry["hold_min"] = stock_info.get("hold_min", 0)
            # Track per-tier
            tier = entry["tier"]
            self._tier_trades[strategy][tier].append({"won": won, "pnl": pnl_pct})
        self._trades[strategy].append(entry)

    def win_rate(self, strategy: str) -> float:
        d = self._trades.get(strategy, [])
        return sum(1 for t in d if t["won"]) / max(len(d), 1)

    def avg_pnl(self, strategy: str) -> float:
        d = self._trades.get(strategy, [])
        return sum(t["pnl"] for t in d) / max(len(d), 1) if d else 0.0

    def sharpe(self, strategy: str) -> float:
        d = self._trades.get(strategy, [])
        if len(d) < 3:
            return 0.0
        pnls = [t["pnl"] for t in d]
        mean = sum(pnls) / len(pnls)
        std = math.sqrt(sum((p - mean) ** 2 for p in pnls) / len(pnls))
        return round(mean / max(std, 0.01), 3)

    def trade_count(self, strategy: str) -> int:
        return len(self._trades.get(strategy, []))

    def should_kill(self, strategy: str) -> bool:
        n = self.trade_count(strategy)
        return n >= MIN_TRADES and self.win_rate(strategy) < KILL_WR

    def tier_performance(self, strategy: str) -> dict:
        result = {}
        for tier, trades in self._tier_trades.get(strategy, {}).items():
            n = len(trades)
            w = sum(1 for t in trades if t["won"])
            result[tier] = {"n": n, "wr": round(w / max(n, 1), 2)}
        return result

    def avg_hold_time(self, strategy: str) -> float:
        d = self._trades.get(strategy, [])
        holds = [t.get("hold_min", 0) for t in d if t.get("hold_min")]
        return round(sum(holds) / max(len(holds), 1), 1) if holds else 0.0

    def summary(self, strategy: str) -> dict:
        return {
            "n":         self.trade_count(strategy),
            "wr":        round(self.win_rate(strategy), 3),
            "avg_pnl":   round(self.avg_pnl(strategy), 3),
            "sharpe":    self.sharpe(strategy),
            "avg_hold":  self.avg_hold_time(strategy),
            "tiers":     self.tier_performance(strategy),
        }


eq_perf = EquityPerformanceTracker()


# ═══════════════════════ STRATEGY DATABASE ═════════════════════════════════════

class EquityStrategyDB:
    """Persist and load equity strategies from JSON."""

    def __init__(self, path: Path = EQ_STRAT_FILE):
        self.path = path
        self._strategies: dict[str, dict] = {}
        self._load()

    def _load(self):
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text())
                self._strategies = {s["name"]: s for s in data if s.get("name")}
                log.info(f"  [EQ_INV] Loaded {len(self._strategies)} equity strategies")
            except Exception as e:
                log.warning(f"  [EQ_INV] Load failed: {e}")

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(list(self._strategies.values()), indent=2, ensure_ascii=False)
        )

    def add(self, strat: dict) -> bool:
        name = strat.get("name", "")
        if not name:
            return False
        self._strategies[name] = strat
        self.save()
        log.info(f"  [EQ_INV] + Added: {name}")
        return True

    def update(self, name: str, **kwargs):
        if name in self._strategies:
            self._strategies[name].update(kwargs)
            self.save()

    def get(self, name: str) -> dict | None:
        return self._strategies.get(name)

    def all(self) -> list[dict]:
        return list(self._strategies.values())

    def active(self) -> list[dict]:
        return [s for s in self._strategies.values() if s.get("active", True)]

    def remove(self, name: str):
        self._strategies.pop(name, None)
        self.save()

    def active_count(self) -> int:
        return sum(1 for s in self._strategies.values() if s.get("active", True))

    def record_trade(self, name: str, won: bool, pnl_pct: float):
        if name not in self._strategies:
            return
        s = self._strategies[name]
        s["trades"] = s.get("trades", 0) + 1
        if won:
            s["wins"] = s.get("wins", 0) + 1
        s["total_pnl"] = round(s.get("total_pnl", 0.0) + pnl_pct, 4)
        s["peak_pnl"]  = round(max(s.get("peak_pnl", 0.0), s["total_pnl"]), 4)
        s["last_trade_ts"] = datetime.now(IST).isoformat()
        self.save()


eq_strat_db = EquityStrategyDB()


# ═══════════════════════ LLM INVENTOR ═════════════════════════════════════════

class EquityLLMInventor:
    """Calls Claude claude-sonnet-4-20250514 to invent equity intraday strategies."""

    MODEL = "claude-sonnet-4-20250514"
    MAX_TOKENS = 1000
    COOLDOWN_SEC = 300

    def __init__(self):
        self._last_call = 0.0
        self._call_count = 0

    def _is_ready(self) -> bool:
        return (
            bool(ANTHROPIC_API_KEY)
            and (time.time() - self._last_call) > self.COOLDOWN_SEC
        )

    async def invent(
        self,
        market_context: dict,
        existing_strategies: list[dict],
        trade_history_summary: str = "",
    ) -> dict | None:
        if not ANTHROPIC_API_KEY or not _HAS_HTTPX:
            return None
        if not self._is_ready():
            return None

        existing_names = [s.get("name", "") for s in existing_strategies]
        known_types = ", ".join(EQ_STRATEGY_TYPES)
        known_signals = ", ".join(EQ_SIGNAL_TYPES)

        system_prompt = (
            "You are a quantitative equity intraday strategist for NSE (India). "
            "You design MIS (Margin Intraday Square-off) strategies for NSE stocks. "
            "You understand MIS leverage (3-5x), equity intraday charges (₹20/order brokerage, "
            "0.025% STT sell side, low breakeven ~0.1-0.2%), and Indian market microstructure. "
            "Return ONLY a valid JSON object — no explanation, no markdown, no code fences."
        )

        sector_info = "\n".join(f"  {s}: {', '.join(stocks[:4])}" for s, stocks in STOCK_SECTORS.items())

        user_prompt = f"""
MARKET SNAPSHOT ({datetime.now(IST).strftime('%H:%M IST')}):
  NIFTY: {market_context.get('nifty', 'unknown')} ({market_context.get('nifty_change', '?')}%)
  BANKNIFTY: {market_context.get('banknifty', 'unknown')}
  India VIX: {market_context.get('india_vix', 'unknown')}
  Market breadth: {market_context.get('breadth', 'unknown')}

STOCK SECTORS:
{sector_info}

STOCK TIERS:
  Penny (₹5-30): IRFC, NHPC, SUZLON, RVNL, HFCL — 3x MIS leverage
  Low (₹30-100): PNB, BHEL, IOC, NTPC — 4x MIS leverage
  Mid (₹100-500): TATASTEEL, SBIN, ITC, AXISBANK — 5x MIS leverage
  High (₹500+): HDFCBANK, RELIANCE, INFY, TCS — 5x MIS leverage

TRADE HISTORY:
{trade_history_summary or "No recent trades."}

WINNING TODAY: {market_context.get("winning_strats", [])}
LOSING TODAY:  {market_context.get("losing_strats", [])}

EXISTING (avoid duplicating): {existing_names}

AVAILABLE STRATEGY TYPES: {known_types}
AVAILABLE SIGNAL TYPES: {known_signals}

Equity intraday facts:
  - Breakeven ~0.1-0.2% (much lower than options)
  - MIS allows short selling
  - Square off before 3:15 PM
  - STT only 0.025% on sell side

TASK: Invent ONE new equity intraday strategy different from existing ones.

Return ONLY this JSON:
{{
  "name": "UniqueNameCamelCase",
  "target_tiers": ["penny", "low", "mid"] or ["all"],
  "target_sectors": ["BANKING", "POWER"] or ["ALL"],
  "target_stocks": [] or ["SBIN", "NHPC"],
  "strategy_type": "one_of_available_types",
  "signal_type": "one_of_available_signals",
  "direction": "BUY" or "SELL" or "BOTH",
  "min_volatility": <float 0.2-3.0>,
  "max_volatility": <float 1.0-8.0>,
  "min_score": <int 1-5>,
  "min_volume_ratio": <float 0.5-3.0>,
  "range_pos_min": <float 0.0-0.5>,
  "range_pos_max": <float 0.5-1.0>,
  "day_change_min": <float -5 to 0>,
  "day_change_max": <float 0 to 5>,
  "target_pct": <float 0.2-2.0>,
  "stoploss_pct": <float 0.1-1.0>,
  "max_hold_min": <int 3-60>,
  "trailing_sl": true/false,
  "trailing_activation_pct": <float 0.1-1.0>,
  "trailing_distance_pct": <float 0.05-0.5>,
  "hour_start": <int 9-14>,
  "hour_end": <int 10-15>,
  "avoid_first_min": <int 0-30>,
  "avoid_last_min": <int 0-15>,
  "capital_pct": <float 0.15-0.50>,
  "max_shares_pct": <float 0.3-0.8>,
  "breakeven_max_pct": <float 0.1-0.4>,
  "trend_filter": "NONE" or "WITH" or "AGAINST",
  "sector_filter": "ANY" or "STRONGEST" or "WEAKEST",
  "short_allowed": true/false,
  "leverage_use": "FULL" or "HALF" or "NONE",
  "rationale": "1-3 sentence explanation of the edge",
  "tags": ["tag1", "tag2", "tag3"]
}}
""".strip()

        try:
            self._last_call = time.time()
            self._call_count += 1

            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key":         ANTHROPIC_API_KEY,
                        "anthropic-version": "2023-06-01",
                        "content-type":      "application/json",
                    },
                    json={
                        "model":      self.MODEL,
                        "max_tokens": self.MAX_TOKENS,
                        "system":     system_prompt,
                        "messages":   [{"role": "user", "content": user_prompt}],
                    },
                )
                resp.raise_for_status()
                data = resp.json()

            raw_text = ""
            for block in data.get("content", []):
                if block.get("type") == "text":
                    raw_text += block.get("text", "")

            raw_text = raw_text.strip()
            if raw_text.startswith("```"):
                raw_text = raw_text.split("```")[1]
                if raw_text.startswith("json"):
                    raw_text = raw_text[4:]

            strat_dict = json.loads(raw_text.strip())
            validated  = self._validate(strat_dict, existing_names)
            log.info(f"  [EQ_INV] LLM invented: {validated['name']} — {validated.get('rationale', '')[:80]}")
            return validated

        except json.JSONDecodeError as e:
            log.error(f"  [EQ_INV] LLM invalid JSON: {e}")
        except Exception as e:
            log.error(f"  [EQ_INV] LLM call failed: {e}")

        return None

    def _validate(self, d: dict, existing_names: list) -> dict:
        strat = dict(EQ_STRATEGY_DEFAULTS)
        strat.update({k: v for k, v in d.items() if k in EQ_STRATEGY_DEFAULTS})

        # Type coercions
        for f in ["min_volatility", "max_volatility", "min_volume_ratio",
                   "range_pos_min", "range_pos_max", "day_change_min", "day_change_max",
                   "target_pct", "stoploss_pct", "capital_pct", "max_shares_pct",
                   "breakeven_max_pct", "trailing_activation_pct", "trailing_distance_pct"]:
            if f in strat and strat[f] is not None:
                strat[f] = float(strat[f])

        for f in ["max_hold_min", "hour_start", "hour_end", "min_score",
                   "avoid_first_min", "avoid_last_min", "min_shares"]:
            if f in strat and strat[f] is not None:
                strat[f] = int(strat[f])

        # Bounds
        strat["capital_pct"]   = min(max(strat["capital_pct"], 0.10), 0.50)
        strat["target_pct"]    = min(max(strat["target_pct"],  0.1), 3.0)
        strat["stoploss_pct"]  = min(max(strat["stoploss_pct"], 0.05), 2.0)

        if strat["strategy_type"] not in EQ_STRATEGY_TYPES:
            strat["strategy_type"] = "momentum_scalp"
        if strat["signal_type"] not in EQ_SIGNAL_TYPES:
            strat["signal_type"] = "CUSTOM_LLM"

        # Unique name
        base_name = strat.get("name", "EqInvented")
        name = base_name
        i = 2
        while name in existing_names:
            name = f"{base_name}{i}"
            i += 1
        strat["name"]       = name
        strat["created_at"] = datetime.now(IST).isoformat()
        strat["generation"] = 1
        strat["active"]     = True
        strat["trades"]     = 0
        strat["wins"]       = 0
        strat["total_pnl"]  = 0.0

        return strat

    def status(self) -> str:
        return (
            f"[EQ_INV] LLM calls: {self._call_count} | "
            f"last: {int(time.time() - self._last_call)}s ago | "
            f"ready: {self._is_ready()}"
        )


eq_llm = EquityLLMInventor()


# ═══════════════════════ EVOLUTION ENGINE ══════════════════════════════════════

class EquityEvolutionEngine:
    """Kill / Breed / Mutate equity strategies."""

    @staticmethod
    def _uid(strat: dict) -> str:
        seed = f"{strat['name']}{strat.get('generation', 0)}{time.time()}"
        return hashlib.md5(seed.encode()).hexdigest()[:6]

    @staticmethod
    def mutate(parent: dict, mutation_rate: float = 0.30) -> dict:
        child = copy.deepcopy(parent)
        child["parent_names"] = [parent["name"]]
        child["generation"]   = parent.get("generation", 0) + 1
        child["trades"] = child["wins"] = 0
        child["total_pnl"] = child["peak_pnl"] = child["max_drawdown"] = 0.0
        child["created_at"] = datetime.now(IST).isoformat()

        mutated = []
        for gene in EQ_MUTABLE_GENES:
            if random.random() > mutation_rate:
                continue
            val = parent.get(gene)
            if gene == "direction":
                child[gene] = random.choice(["BUY", "SELL", "BOTH"])
            elif gene == "strategy_type":
                child[gene] = random.choice(EQ_STRATEGY_TYPES)
            elif gene == "signal_type":
                child[gene] = random.choice(EQ_SIGNAL_TYPES)
            elif gene == "trend_filter":
                child[gene] = random.choice(["NONE", "WITH", "AGAINST"])
            elif gene == "sector_filter":
                child[gene] = random.choice(["ANY", "STRONGEST", "WEAKEST"])
            elif gene == "leverage_use":
                child[gene] = random.choice(["FULL", "HALF", "NONE"])
            elif gene in ("trailing_sl", "short_allowed"):
                child[gene] = not child.get(gene, True)
            elif isinstance(val, float):
                noise = random.uniform(0.75, 1.30)
                child[gene] = round(val * noise, 3)
            elif isinstance(val, int):
                noise = random.randint(-2, 2)
                child[gene] = max(1, val + noise)
            mutated.append(gene)

        # Bounds
        child["capital_pct"]  = min(max(child.get("capital_pct", 0.30), 0.10), 0.50)
        child["target_pct"]   = min(max(child.get("target_pct",  0.5),  0.1), 3.0)
        child["stoploss_pct"] = min(max(child.get("stoploss_pct", 0.3), 0.05), 2.0)

        uid = EquityEvolutionEngine._uid(child)
        base = parent["name"].rstrip("0123456789_")
        child["name"] = f"{base}_{uid}"
        child["rationale"] = (
            f"Mutation of {parent['name']} (gen{child['generation']}). "
            f"Mutated: {mutated}."
        )
        return child

    @staticmethod
    def crossbreed(a: dict, b: dict) -> dict:
        child = {}
        for gene in EQ_MUTABLE_GENES:
            child[gene] = a.get(gene) if random.random() < 0.5 else b.get(gene)

        child["name"]         = f"EqBred_{EquityEvolutionEngine._uid({'name': a['name']+b['name']})}"
        child["generation"]   = max(a.get("generation", 0), b.get("generation", 0)) + 1
        child["parent_names"] = [a["name"], b["name"]]
        child["created_at"]   = datetime.now(IST).isoformat()
        child["active"]       = True
        child["trades"] = child["wins"] = 0
        child["total_pnl"] = child["peak_pnl"] = child["max_drawdown"] = 0.0
        child["rationale"] = f"Crossbreed of {a['name']} × {b['name']} (gen{child['generation']})."
        child["tags"] = list(set(a.get("tags", []) + b.get("tags", [])))

        merged = dict(EQ_STRATEGY_DEFAULTS)
        merged.update(child)
        merged["capital_pct"] = min(max(merged.get("capital_pct", 0.30), 0.10), 0.50)
        return merged

    def evolve(self, strategies: list[dict]) -> list[str]:
        actions = []

        # Kill weak
        to_kill = []
        for s in strategies:
            name = s.get("name", "")
            if not s.get("active", True):
                continue
            if eq_perf.should_kill(name):
                wr = eq_perf.win_rate(name)
                to_kill.append(name)
                actions.append(f"KILL {name} (WR={wr:.0%})")
                eq_strat_db.update(name, active=False)

        active = [s for s in strategies if s.get("active", True) and s["name"] not in to_kill]

        # Breed top 2
        if len(active) >= 2 and len(active) < MAX_STRATS:
            ranked = sorted(
                [s for s in active if eq_perf.trade_count(s["name"]) >= 3],
                key=lambda s: eq_perf.sharpe(s["name"]),
                reverse=True
            )
            if len(ranked) >= 2:
                child = self.crossbreed(ranked[0], ranked[1])
                eq_strat_db.add(child)
                actions.append(f"BREED {ranked[0]['name']} × {ranked[1]['name']} → {child['name']}")

        # Mutate
        if active and len(active) < MAX_STRATS:
            parent = random.choice(active)
            mutant = self.mutate(parent)
            eq_strat_db.add(mutant)
            actions.append(f"MUTATE {parent['name']} → {mutant['name']}")

        return actions


eq_evolution = EquityEvolutionEngine()


# ═══════════════════════ SEED STRATEGIES ═══════════════════════════════════════

SEED_EQ_STRATEGIES: list[dict] = [
    {**EQ_STRATEGY_DEFAULTS,
     "name": "PennyMomentum", "target_tiers": ["penny"],
     "strategy_type": "momentum_scalp", "signal_type": "PRICE_MOMENTUM",
     "direction": "BUY", "target_pct": 0.5, "stoploss_pct": 0.3,
     "max_hold_min": 12, "min_volatility": 0.4,
     "rationale": "Buy penny stocks (IRFC, NHPC etc) on intraday momentum with 3x leverage",
     "tags": ["penny", "momentum", "scalp", "leverage"]},

    {**EQ_STRATEGY_DEFAULTS,
     "name": "QuickScalpAny", "target_tiers": ["penny", "low", "mid"],
     "strategy_type": "momentum_scalp", "signal_type": "PRICE_MOMENTUM",
     "direction": "BOTH", "target_pct": 0.3, "stoploss_pct": 0.2,
     "max_hold_min": 8, "trailing_sl": False,
     "rationale": "Ultra-quick scalp any tier, in and out within 8 min for 0.3% target",
     "tags": ["quick", "scalp", "all_tiers"]},

    {**EQ_STRATEGY_DEFAULTS,
     "name": "SwingEquity", "target_tiers": ["mid", "high"],
     "strategy_type": "momentum_scalp", "signal_type": "PRICE_MOMENTUM",
     "direction": "BOTH", "target_pct": 1.0, "stoploss_pct": 0.5,
     "max_hold_min": 30, "min_volatility": 0.8,
     "rationale": "Wider target/SL on mid/high tier stocks with strong intraday moves",
     "tags": ["swing", "mid_high", "wider_target"]},

    {**EQ_STRATEGY_DEFAULTS,
     "name": "ORBPenny", "target_tiers": ["penny", "low"],
     "strategy_type": "orb_breakout", "signal_type": "VOLUME_BREAKOUT",
     "direction": "BOTH", "target_pct": 0.6, "stoploss_pct": 0.3,
     "max_hold_min": 20, "hour_start": 9, "hour_end": 10,
     "avoid_first_min": 15, "min_volume_ratio": 1.5,
     "rationale": "Opening Range Breakout on penny/low stocks first 45 min with volume confirm",
     "tags": ["orb", "breakout", "morning", "penny"]},

    {**EQ_STRATEGY_DEFAULTS,
     "name": "VWAPBounce", "target_tiers": ["low", "mid"],
     "strategy_type": "vwap_bounce", "signal_type": "VWAP_CROSS",
     "direction": "BUY", "target_pct": 0.4, "stoploss_pct": 0.25,
     "max_hold_min": 15, "range_pos_min": 0.40, "range_pos_max": 0.60,
     "rationale": "Buy stocks bouncing off VWAP in the middle of day range",
     "tags": ["vwap", "bounce", "mean_revert"]},

    {**EQ_STRATEGY_DEFAULTS,
     "name": "MeanRevertExtreme", "target_tiers": ["penny", "low", "mid"],
     "strategy_type": "mean_revert", "signal_type": "RANGE_POSITION",
     "direction": "BOTH", "target_pct": 0.5, "stoploss_pct": 0.3,
     "max_hold_min": 20, "range_pos_min": 0.0, "range_pos_max": 0.15,
     "day_change_min": -3.0, "day_change_max": -0.5,
     "rationale": "Buy stocks at day lows (range pos < 15%) after 0.5%+ fall, expect revert",
     "tags": ["mean_revert", "contrarian", "day_low"]},

    {**EQ_STRATEGY_DEFAULTS,
     "name": "ShortOverextended", "target_tiers": ["mid", "high"],
     "strategy_type": "mean_revert", "signal_type": "RSI_EXTREME",
     "direction": "SELL", "target_pct": 0.4, "stoploss_pct": 0.3,
     "max_hold_min": 15, "range_pos_min": 0.85, "range_pos_max": 1.0,
     "day_change_min": 1.0, "day_change_max": 5.0,
     "short_allowed": True,
     "rationale": "Short overextended stocks at day highs via MIS short sell",
     "tags": ["short", "overbought", "mean_revert"]},

    {**EQ_STRATEGY_DEFAULTS,
     "name": "EODMomentum", "target_tiers": ["low", "mid"],
     "strategy_type": "eod_scalp", "signal_type": "PRICE_MOMENTUM",
     "direction": "BOTH", "target_pct": 0.4, "stoploss_pct": 0.2,
     "max_hold_min": 15, "hour_start": 14, "hour_end": 15,
     "rationale": "Last-hour scalp on stocks with clear direction, ride closing momentum",
     "tags": ["eod", "closing", "momentum"]},

    {**EQ_STRATEGY_DEFAULTS,
     "name": "VolumeSurge", "target_tiers": ["penny", "low", "mid"],
     "strategy_type": "volume_spike", "signal_type": "VOLUME_BREAKOUT",
     "direction": "BOTH", "target_pct": 0.7, "stoploss_pct": 0.4,
     "max_hold_min": 20, "min_volume_ratio": 2.0,
     "rationale": "Enter on volume surge (2x+ avg), ride the institutional move",
     "tags": ["volume", "surge", "institutional"]},

    {**EQ_STRATEGY_DEFAULTS,
     "name": "BankingMomentum", "target_tiers": ["penny", "low", "mid", "high"],
     "target_sectors": ["BANKING"],
     "strategy_type": "momentum_scalp", "signal_type": "SECTOR_STRENGTH",
     "direction": "BOTH", "target_pct": 0.5, "stoploss_pct": 0.3,
     "max_hold_min": 15, "sector_filter": "STRONGEST",
     "rationale": "Trade banking stocks when banking sector is strongest/weakest of the day",
     "tags": ["banking", "sector", "rotation"]},

    {**EQ_STRATEGY_DEFAULTS,
     "name": "GapFillPlay", "target_tiers": ["low", "mid", "high"],
     "strategy_type": "gap_fill", "signal_type": "GAP_ANALYSIS",
     "direction": "BOTH", "target_pct": 0.5, "stoploss_pct": 0.4,
     "max_hold_min": 30, "hour_start": 9, "hour_end": 11,
     "day_change_min": -3.0, "day_change_max": 3.0, "min_volatility": 0.5,
     "rationale": "Trade gap fills — stocks opening with 0.5%+ gap tend to fill within 2 hours",
     "tags": ["gap", "fill", "morning", "revert"]},

    {**EQ_STRATEGY_DEFAULTS,
     "name": "PowerSectorPlay", "target_tiers": ["penny", "low"],
     "target_sectors": ["POWER"],
     "strategy_type": "momentum_scalp", "signal_type": "SECTOR_STRENGTH",
     "direction": "BUY", "target_pct": 0.5, "stoploss_pct": 0.3,
     "max_hold_min": 15,
     "rationale": "Power sector penny stocks (NHPC, NTPC, PFC) momentum with 3-4x leverage",
     "tags": ["power", "sector", "penny", "leverage"]},
]


# ═══════════════════════ MAIN ORCHESTRATOR ═════════════════════════════════════

class EquityStrategyInventor:
    """Main orchestrator: invent, evolve, manage equity strategies."""

    def __init__(self):
        self._invention_count = 0
        self._evolution_count = 0
        self._ensure_seeds()

    def _ensure_seeds(self):
        if eq_strat_db.active_count() == 0:
            log.info("  [EQ_INV] Seeding initial equity strategies...")
            for s in SEED_EQ_STRATEGIES:
                s["created_at"] = datetime.now(IST).isoformat()
                eq_strat_db.add(s)
            log.info(f"  [EQ_INV] Seeded {len(SEED_EQ_STRATEGIES)} strategies")

    def active_strategies(self) -> list[dict]:
        return eq_strat_db.active()

    def record_trade(self, strategy_name: str, won: bool, pnl_pct: float,
                     stock_info: dict = None):
        eq_perf.record(strategy_name, won, pnl_pct, stock_info)
        eq_strat_db.record_trade(strategy_name, won, pnl_pct)

    async def maybe_invent(self, market_context: dict, force: bool = False) -> dict | None:
        existing = eq_strat_db.active()
        if len(existing) >= MAX_STRATS and not force:
            self._run_evolution()
            return None

        trade_summary = self._trade_history_summary()
        result = await eq_llm.invent(market_context, existing, trade_summary)
        if result:
            eq_strat_db.add(result)
            self._invention_count += 1
            self._run_evolution()
        return result

    def pick_strategy(self, stock_opportunities: list[dict], cash: float) -> tuple:
        """
        Pick best (strategy, stock) pair from active strategies + stock opps.
        Returns (strategy_dict, stock_dict) or (None, None).
        """
        active = eq_strat_db.active()
        if not active or not stock_opportunities:
            return None, None

        best_score = -1
        best_strat = None
        best_stock = None

        for strat in active:
            # Time filter
            h = datetime.now(IST).hour
            m = datetime.now(IST).minute
            if h < strat.get("hour_start", 9) or h > strat.get("hour_end", 15):
                continue
            if h == 9 and m < strat.get("avoid_first_min", 5):
                continue

            for stock in stock_opportunities:
                s = eq_scorer.score_stock(stock, strat, cash)
                if s <= 2.0:
                    continue

                # Weight by performance
                perf = eq_perf.summary(strat["name"])
                perf_bonus = perf["sharpe"] * 0.3 + perf["wr"] * 1.5
                combined = s + perf_bonus

                if combined > best_score:
                    best_score = combined
                    best_strat = strat
                    best_stock = stock

        return best_strat, best_stock

    def should_exit(self, strat: dict, entry_price: float, current_price: float,
                    direction: str, hold_minutes: float, peak_pnl_pct: float) -> tuple:
        """Check if we should exit based on strategy rules."""
        if direction == "BUY":
            pnl_pct = ((current_price - entry_price) / entry_price) * 100
        else:
            pnl_pct = ((entry_price - current_price) / entry_price) * 100

        target = strat.get("target_pct", 0.5)
        sl     = strat.get("stoploss_pct", 0.3)
        max_hold = strat.get("max_hold_min", 15)

        # Target
        if pnl_pct >= target:
            return "TARGET", pnl_pct

        # Stop loss
        if pnl_pct <= -sl:
            return "STOPLOSS", pnl_pct

        # Trailing stop
        if strat.get("trailing_sl", True):
            act = strat.get("trailing_activation_pct", 0.3)
            dist = strat.get("trailing_distance_pct", 0.15)
            if peak_pnl_pct > act and pnl_pct < peak_pnl_pct - dist:
                return "TRAIL_SL", pnl_pct

        # Timeout
        if hold_minutes >= max_hold:
            return "TIMEOUT", pnl_pct

        return None, pnl_pct

    def status(self) -> str:
        active = eq_strat_db.active()
        n_active = len(active)
        total = len(eq_strat_db.all())
        lines = [
            f"[EQ_INV] Equity Strategy Inventor",
            f"  Active: {n_active}/{total} | Invented: {self._invention_count} | Evolved: {self._evolution_count}",
        ]
        type_counts = defaultdict(int)
        for s in active:
            type_counts[s.get("strategy_type", "momentum_scalp")] += 1
        dist = " | ".join(f"{t}:{c}" for t, c in sorted(type_counts.items()))
        lines.append(f"  Types: {dist}")
        lines.append(eq_llm.status())
        return "\n".join(lines)

    def print_table(self):
        active = eq_strat_db.active()
        print(f"\n{'─'*105}")
        print(f"{'NAME':<22} {'TYPE':<16} {'SIGNAL':<16} {'DIR':<5} {'TGT':>5} {'SL':>4} "
              f"{'N':>4} {'WR':>6} {'SHARPE':>7} {'HOLD':>5} {'AVG':>7}")
        print(f"{'─'*105}")
        for s in sorted(active, key=lambda x: x["name"]):
            nm = s["name"]
            p  = eq_perf.summary(nm)
            print(
                f"{nm:<22} {s.get('strategy_type','?'):<16} {s.get('signal_type','?'):<16} "
                f"{s.get('direction','?'):<5} {s.get('target_pct',0):>5.2f} "
                f"{s.get('stoploss_pct',0):>4.2f} {p['n']:>4} {p['wr']:>6.0%} "
                f"{p['sharpe']:>7.2f} {p['avg_hold']:>5.1f} {p['avg_pnl']:>7.3f}%"
            )
        print(f"{'─'*105}\n")

    def _run_evolution(self):
        active = eq_strat_db.active()
        actions = eq_evolution.evolve(active)
        if actions:
            self._evolution_count += 1
            log.info("  [EQ_INV] Evolution: " + " | ".join(actions))

    def _trade_history_summary(self) -> str:
        try:
            c = sqlite3.connect(DB)
            c.row_factory = sqlite3.Row
            rows = c.execute("""
                SELECT strategy, COUNT(*) n, SUM(won) wins,
                       ROUND(AVG(pnl_pct),2) avg_pnl
                FROM trades
                WHERE asset = 'equity'
                  AND ts >= datetime('now', '-3 days')
                GROUP BY strategy
                ORDER BY avg_pnl DESC
                LIMIT 10
            """).fetchall()
            c.close()
            if not rows:
                return "No recent equity trades."
            return "\n".join(
                f"{r['strategy']:22s} n={r['n']} wr={r['wins']/r['n']:.0%} avg={r['avg_pnl']:+.2f}%"
                for r in rows
            )
        except Exception:
            return "DB unavailable."


# ── Module-level singleton ──────────────────────────────────────────────────
equity_inventor = EquityStrategyInventor()


# ═══════════════════════ CLI ═══════════════════════════════════════════════════

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s", datefmt="%H:%M:%S",
                        handlers=[logging.StreamHandler()])

    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"

    if cmd == "status":
        equity_inventor.print_table()
        print(equity_inventor.status())

    elif cmd == "invent":
        print("Requesting LLM equity strategy invention...")
        ctx = {
            "nifty": 22450, "nifty_change": +0.3,
            "banknifty": 48200, "india_vix": 14.5,
            "breadth": "positive (650 adv / 550 dec)",
            "winning_strats": ["PennyMomentum"],
            "losing_strats":  ["ShortOverextended"],
        }
        result = asyncio.run(equity_inventor.maybe_invent(ctx, force=True))
        if result:
            print(f"\n✅ Invented: {result['name']}")
            print(json.dumps(result, indent=2))
        else:
            print("❌ Invention failed (check ANTHROPIC_API_KEY)")

    elif cmd == "evolve":
        print("Running evolution cycle...")
        actions = eq_evolution.evolve(eq_strat_db.active())
        for a in actions:
            print(f"  {a}")
        equity_inventor.print_table()

    elif cmd == "reset":
        confirm = input("Delete all invented equity strategies? [y/N] ").strip().lower()
        if confirm == "y":
            EQ_STRAT_FILE.unlink(missing_ok=True)
            print("Cleared. Seeds re-load on next run.")

    else:
        print(f"Unknown: {cmd}")
        print("Usage: python3 equity_strategy_inventor.py [status|invent|evolve|reset]")
