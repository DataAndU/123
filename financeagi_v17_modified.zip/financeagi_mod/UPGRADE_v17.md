# FinanceAGI v17 — Strategy Invention & Management Engine

## What's New

### 3 New Modules

| Module | Lines | Purpose |
|--------|-------|---------|
| `options_strategy_inventor.py` | ~700 | AI-powered F&O options strategy creation & management |
| `equity_strategy_inventor.py` | ~650 | AI-powered equity intraday strategy creation & management |
| `strategy_master.py` | ~520 | Unified cross-asset orchestrator |
| `v17_patch.py` | ~180 | Verification + integration instructions |

### Options Strategy Inventor

**13 Strategy Types:**
single, spread, iron_condor, straddle, strangle, butterfly, calendar, ratio, jade_lizard, iron_butterfly, collar, diagonal, synthetic

**16 Signal Types:**
MOMENTUM_LONG, MEAN_REVERT, BREAKOUT_SCALP, IV_CRUSH_SELL, IV_EXPANSION_BUY, THETA_HARVEST, GAMMA_SCALP, DELTA_HEDGE, SKEW_EXPLOIT, EVENT_STRADDLE, EXPIRY_DECAY, PCR_SIGNAL, OI_BUILDUP, FII_FLOW, VWAP_CROSS, CUSTOM_LLM

**13 Seed Strategies:**
- `NiftyMomentumCE` — NIFTY CE momentum with 20-40 delta
- `BankNiftyScalpPE` — BNF PE scalp on breakdown
- `NiftyBullSpread` — Bull call spread (buy ATM, sell 100pt OTM)
- `IronCondorWeekly` — Weekly NIFTY iron condor (200pt wings)
- `EventStraddle` — ATM straddle pre-event in low IV
- `OTMStrangleBuy` — Cheap OTM strangle for big moves
- `BNFButterflyATM` — BankNifty butterfly (low cost, precise target)
- `CalendarNifty` — Calendar spread (sell near, buy far same strike)
- `JadeLizardBNF` — Short put + short call spread for premium
- `GammaScalpATM` — Near-ATM gamma scalp, quick exits
- `PCRReversalCE` — Buy CE when PCR > 1.3 (contrarian)
- `FIIFlowMomentum` — Trade with FII/DII institutional flow
- `IronButterflyNifty` — Sell ATM straddle + buy OTM wings

**Features:**
- Greeks-aware scoring (delta fit, IV fit, gamma, theta value)
- Greeks P&L attribution per trade (delta/theta/vega/gamma)
- VIX and regime filters
- Multi-leg config with strike offsets and delta targets

### Equity Strategy Inventor

**12 Strategy Types:**
momentum_scalp, mean_revert, orb_breakout, vwap_bounce, gap_fill, sector_rotation, pair_trade, news_momentum, volume_spike, reversal, premarket_follow, eod_scalp

**15 Signal Types:**
PRICE_MOMENTUM, VOLUME_BREAKOUT, RANGE_POSITION, VWAP_CROSS, GAP_ANALYSIS, RSI_EXTREME, SECTOR_STRENGTH, OI_DELIVERY, FII_DII_FLOW, GIFT_NIFTY_LEAD, NEWS_SENTIMENT, TICK_MOMENTUM, EMA_CROSS, BOLLINGER_SQUEEZE, CUSTOM_LLM

**12 Seed Strategies:**
- `PennyMomentum` — Penny stock momentum with 3x leverage
- `QuickScalpAny` — Ultra-quick 0.3% scalp, 8 min max hold
- `SwingEquity` — Wider target on mid/high tier stocks
- `ORBPenny` — Opening Range Breakout first 45 min
- `VWAPBounce` — Buy at VWAP bounce in mid-range
- `MeanRevertExtreme` — Buy at day lows (range pos < 15%)
- `ShortOverextended` — MIS short sell at day highs
- `EODMomentum` — Last-hour closing momentum scalp
- `VolumeSurge` — Enter on 2x+ volume surge
- `BankingMomentum` — Banking sector rotation play
- `GapFillPlay` — Trade gap fills on morning gaps
- `PowerSectorPlay` — Power sector penny stock momentum

**Features:**
- Per-tier performance tracking (penny/low/mid/high)
- Sector-aware: Banking, Power, Infra, Metal, IT, Energy, Consumer, Green
- MIS short selling support
- Capital-adaptive stock selection with real LTP

### Strategy Master

- **Cross-asset learning**: Transfers winning patterns between asset classes via LLM
- **Lifecycle management**: SEED → INVENTED → TESTING → PROMOTED → MATURE → DECLINING → KILLED
- **Capital allocation**: Sharpe-weighted Kelly allocation
- **Unified dashboard**: Single report across options + equity + commodities
- **Background loop**: 5-min cycles with scheduled invention (1hr), evolution (30min), crossover (2hr)

## Quick Start

```bash
# Verify all modules load
python3 v17_patch.py verify

# View options strategies
python3 options_strategy_inventor.py status

# View equity strategies
python3 equity_strategy_inventor.py status

# Full cross-asset report
python3 strategy_master.py report

# Force LLM invention (needs ANTHROPIC_API_KEY in .env)
python3 options_strategy_inventor.py invent
python3 equity_strategy_inventor.py invent

# Run evolution cycle
python3 strategy_master.py evolve

# Cross-asset learning
python3 strategy_master.py crossover
```

## Integration with agent.py

See `v17_patch.py` for full step-by-step instructions. Summary:

1. Add imports for `options_inventor`, `equity_inventor`, `strategy_master`
2. Wire `record_trade()` calls after trade closures
3. Add `run_strategy_master_loop()` to `asyncio.gather()`
4. Optionally use `pick_strategy()` for enhanced strategy selection

## New .env Variables

```env
# Options Strategy Inventor
OPT_INVENTOR_MAX_STRATS=20
OPT_INVENTOR_KILL_WR=0.40
OPT_INVENTOR_MIN_TRADES=6

# Equity Strategy Inventor
EQ_INVENTOR_MAX_STRATS=15
EQ_INVENTOR_KILL_WR=0.40
EQ_INVENTOR_MIN_TRADES=8
```

## New Data Files Created

```
data/invented_options_strategies.json    — Options strategy state
data/invented_equity_strategies.json     — Equity strategy state
data/strategy_master_state.json          — Master orchestrator state
```

## Architecture

```
strategy_master.py
  ├── options_strategy_inventor.py
  │     ├── OptionsStrategyDB        (JSON persistence)
  │     ├── OptionsPerformanceTracker (rolling metrics + Greeks attribution)
  │     ├── OptionsLLMInventor       (Claude claude-sonnet-4-20250514 invention)
  │     ├── OptionsEvolutionEngine   (mutate/crossbreed/kill)
  │     └── GreeksAwareScorer        (strategy-option matching)
  ├── equity_strategy_inventor.py
  │     ├── EquityStrategyDB
  │     ├── EquityPerformanceTracker (rolling metrics + tier attribution)
  │     ├── EquityLLMInventor
  │     ├── EquityEvolutionEngine
  │     └── EquityScorer
  └── strategy_inventor.py (existing commodity, unchanged)
        ├── StrategyDB
        ├── PerformanceTracker
        ├── LLMInventor
        └── EvolutionEngine
```
