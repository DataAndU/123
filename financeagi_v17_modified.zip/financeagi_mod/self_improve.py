#!/usr/bin/env python3
"""
self_improve.py — FinanceAGI v13.2 Self-Improvement Module
Runs automatically. Called from agent.py background tasks.

Features:
  5. Event Calendar     — Finnhub economic calendar awareness
  6. Trade Reconciliation — nightly DB vs Upstox account check
  7. Signal Attribution  — which alpha signals actually produce wins
  8. Synthetic Data Aug  — multiply training data 10x with noise
  10. Hyperparameter Search — weekly NN architecture tuning
"""

import asyncio, json, logging, math, os, pickle, random, sqlite3, time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from collections import defaultdict

log  = logging.getLogger("agi.self_improve")
IST  = timezone(timedelta(hours=5, minutes=30))
BASE = Path(__file__).resolve().parent
DB   = str(BASE / "data" / "v10.db")

ENV = {}
ef  = BASE / ".env"
if ef.exists():
    for ln in ef.read_text().splitlines():
        ln = ln.strip()
        if ln and not ln.startswith("#") and "=" in ln:
            k, v = ln.split("=", 1); ENV[k.strip()] = v.strip()

FINNHUB_TOKEN = ENV.get("FINNHUB_TOKEN", "")

# ═══════════════════════ 5. EVENT CALENDAR ═══════════════════════

class EventCalendar:
    """
    Fetches upcoming high-impact Indian economic events from Finnhub.
    Warns before RBI policy, Budget, earnings, expiry days.
    On high-impact days: tightens SL, reduces position size, avoids new entries
    within 30 minutes of event.
    """
    HIGH_IMPACT = {"RBI", "FOMC", "CPI", "GDP", "PMI", "BUDGET", "EARNINGS", "EXPIRY"}

    def __init__(self):
        self.events      = []      # list of {date, time, name, impact, country}
        self.last_fetch  = 0.0
        self._today_events = []

    async def refresh(self):
        """
        Mark NSE expiry days (every Thursday) — no Finnhub needed.
        Finnhub free plan does not include economic calendar (403).
        High-impact event data comes from Trading Economics (te_calendar).
        """
        now = datetime.now(IST)
        self._today_events = []
        # NSE weekly expiry = every Thursday
        if now.weekday() == 3:
            self._today_events.append({"event": "NSE_EXPIRY", "impact": "high",
                                        "time": now.strftime("%Y-%m-%d")})
            log.info("  [CALENDAR] NSE weekly expiry day — position size reduced")
        self.last_fetch = time.time()

    def is_high_impact_now(self, window_min: int = 30) -> bool:
        """True if a high-impact event is within window_min minutes."""
        now = datetime.now(IST)
        for e in self._today_events:
            if e.get("impact","").lower() != "high":
                continue
            # Parse event time
            try:
                et = datetime.fromisoformat(e.get("time","")).replace(tzinfo=IST)
                delta_min = abs((et - now).total_seconds() / 60)
                if delta_min <= window_min:
                    log.info(f"  [CALENDAR] High-impact event in {delta_min:.0f}m: {e.get('event','?')}")
                    return True
            except Exception:
                pass
        return False

    def is_expiry_day(self) -> bool:
        return any(e.get("event","") == "NSE_EXPIRY" for e in self._today_events)

    @property
    def risk_multiplier(self) -> float:
        """
        Return position size multiplier for today.
        0.5 = half size on high-impact days, 1.0 = normal.
        """
        if self.is_high_impact_now(60):  return 0.5
        if self.is_expiry_day():         return 0.75
        return 1.0

    @property
    def sl_multiplier(self) -> float:
        """Tighten SL on high-impact days."""
        if self.is_high_impact_now(60): return 0.7  # 30% tighter SL
        return 1.0

event_cal = EventCalendar()

# ═══════════════════════ 6. TRADE RECONCILIATION ═══════════════════════

class TradeReconciler:
    """
    Nightly check: compare DB trade count vs Upstox order history.
    Flags discrepancies — open positions in broker not in DB, or
    DB trades with no matching broker order.
    Saves report to logs/reconciliation_YYYYMMDD.json
    """

    async def reconcile(self, broker) -> dict:
        """Run reconciliation. Returns report dict."""
        report = {
            "ts": datetime.now(IST).isoformat(),
            "db_trades_today": 0,
            "broker_orders_today": 0,
            "open_positions_broker": [],
            "open_positions_db": [],
            "discrepancies": [],
            "status": "ok"
        }
        try:
            # 1. Count today's DB trades
            today = datetime.now(IST).strftime("%Y-%m-%d")
            c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
            db_today = c.execute(
                "SELECT COUNT(*) n FROM trades WHERE ts >= ?", (today,)
            ).fetchone()["n"]
            report["db_trades_today"] = db_today

            # Open positions in DB (no exit_reason)
            db_open = c.execute(
                "SELECT symbol, otype, entry_price, lot FROM trades WHERE exit_reason='' AND ts >= ?",
                ((datetime.now(IST) - timedelta(days=1)).isoformat(),)
            ).fetchall()
            report["open_positions_db"] = [dict(r) for r in db_open]
            c.close()

            # 2. Fetch broker open positions
            broker_pos = await broker.positions()
            report["open_positions_broker"] = [
                {"symbol": p.get("trading_symbol",""), "qty": p.get("quantity",0),
                 "ltp": p.get("last_price",0)}
                for p in broker_pos if p.get("quantity",0) > 0
            ]
            report["broker_orders_today"] = len(broker_pos)

            # 3. Flag discrepancies
            broker_syms = {p["symbol"] for p in report["open_positions_broker"]}
            db_syms     = {p["symbol"] for p in report["open_positions_db"]}

            for sym in broker_syms - db_syms:
                report["discrepancies"].append(f"BROKER_NOT_IN_DB: {sym}")
                log.warning(f"  [RECON] Position in broker but not DB: {sym}")

            for sym in db_syms - broker_syms:
                report["discrepancies"].append(f"DB_NOT_IN_BROKER: {sym}")
                log.warning(f"  [RECON] Position in DB but not broker: {sym}")

            if report["discrepancies"]:
                report["status"] = "discrepancy"

        except Exception as e:
            report["status"] = f"error: {e}"
            log.error(f"  [RECON] Reconciliation error: {e}")

        # Save report
        try:
            out = BASE / "logs" / f"reconciliation_{datetime.now(IST).strftime('%Y%m%d')}.json"
            out.write_text(json.dumps(report, indent=2))
            log.info(f"  [RECON] Report saved: {out.name} — status={report['status']}")
        except Exception: pass

        return report

reconciler = TradeReconciler()

# ═══════════════════════ 7. SIGNAL ATTRIBUTION ═══════════════════════

class SignalAttributor:
    """
    Track which alpha signals were active at entry for each trade.
    After N trades, compute per-signal win rate to see what's actually working.
    Saves to DB config as 'signal_attribution'.
    """

    SIGNALS = ["pcr", "ivp", "gex", "ofi", "vwap", "vol_spike",
               "fii_dii", "gift_nifty", "regime", "news"]

    def __init__(self):
        self._pending = {}  # key → {signal_name: value_at_entry}

    def record_entry(self, key: str, signal_snapshot: dict):
        """Record which signals fired at entry for this position key."""
        self._pending[key] = signal_snapshot

    def record_exit(self, key: str, won: bool):
        """After exit, attribute the outcome to each signal that was active."""
        snap = self._pending.pop(key, {})
        if not snap: return
        try:
            c = sqlite3.connect(DB)
            row = c.execute("SELECT val FROM config WHERE key='signal_attribution'").fetchone()
            attr = json.loads(row["val"]) if row else {s: {"wins":0,"total":0} for s in self.SIGNALS}
            for sig, fired in snap.items():
                if sig not in attr: attr[sig] = {"wins":0,"total":0}
                if fired:
                    attr[sig]["total"] += 1
                    if won: attr[sig]["wins"] += 1
            c.execute("INSERT OR REPLACE INTO config(key,val) VALUES(?,?)",
                      ("signal_attribution", json.dumps(attr)))
            c.commit(); c.close()
        except Exception as e:
            log.debug(f"  [ATTR] save error: {e}")

    @staticmethod
    def report() -> dict:
        """Get current signal attribution from DB."""
        try:
            c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
            row = c.execute("SELECT val FROM config WHERE key='signal_attribution'").fetchone()
            c.close()
            if not row: return {}
            attr = json.loads(row["val"])
            result = {}
            for sig, data in attr.items():
                t = data.get("total",0)
                w = data.get("wins",0)
                result[sig] = {
                    "total": t, "wins": w,
                    "win_rate": round(w/max(1,t)*100, 1),
                    "useful": t >= 10 and w/max(1,t) > 0.55
                }
            return result
        except Exception:
            return {}

    def log_report(self):
        attr = self.report()
        if not attr: return
        log.info("  [ATTR] Signal win rates:")
        for sig, data in sorted(attr.items(), key=lambda x: -x[1].get("win_rate",0)):
            if data["total"] >= 5:
                useful = "✓" if data["useful"] else "✗"
                log.info(f"    {useful} {sig:12s} {data['win_rate']:5.1f}%WR ({data['total']}T)")

sig_attr = SignalAttributor()

# ═══════════════════════ 8. SYNTHETIC DATA AUGMENTATION ═══════════════════════

def augment_training_data(X, y, multiplier: int = 10, noise_std: float = 0.05):
    """
    Multiply training data by adding Gaussian noise to feature vectors.
    Labels are preserved exactly.
    multiplier=10 → 183 trades becomes ~1830 training samples.
    noise_std=0.05 → 5% feature noise (enough to generalise, not enough to corrupt)
    """
    import numpy as np
    if X is None or len(X) == 0:
        return X, y
    augmented_X = [X]
    augmented_y = [y]
    for _ in range(multiplier - 1):
        noise = np.random.normal(0, noise_std, X.shape)
        augmented_X.append(X + noise)
        augmented_y.append(y)
    return np.vstack(augmented_X), np.vstack(augmented_y)

def get_augmented_training_data(feat_dim: int, multiplier: int = 8):
    """Load trades from DB, augment, return (X, y)."""
    import numpy as np
    try:
        c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
        rows = c.execute(
            "SELECT features_json, won FROM trades WHERE features_json IS NOT NULL"
        ).fetchall()
        c.close()
        if not rows: return None, None
        feats, labels = [], []
        for r in rows:
            try:
                f = json.loads(r["features_json"])
                if not isinstance(f, list) or len(f) == 0: continue
                if len(f) < feat_dim: f = f + [0.0]*(feat_dim - len(f))
                feats.append(f[:feat_dim]); labels.append([r["won"]])
            except Exception: continue
        if not feats: return None, None
        X = np.array(feats, dtype=np.float64)
        y = np.array(labels, dtype=np.float64)
        X_aug, y_aug = augment_training_data(X, y, multiplier=multiplier)
        log.info(f"  [AUG] {len(X)} real → {len(X_aug)} augmented samples (x{multiplier})")
        return X_aug, y_aug
    except Exception as e:
        log.error(f"  [AUG] augmentation error: {e}")
        return None, None

# ═══════════════════════ 10. HYPERPARAMETER SEARCH ═══════════════════════

HYPER_LOG = BASE / "logs" / "hyperparameter_search.json"

def hyperparameter_search(X, y, feat_dim: int, n_trials: int = 8) -> dict:
    """
    Try different NN architectures and learning rates on current trade data.
    Uses 80/20 train/val split. Runs weekly.
    Returns best config found.
    """
    import numpy as np

    if X is None or len(X) < 20:
        log.info("  [HYPER] Not enough data for search (need 20+ trades)")
        return {}

    # Candidate architectures
    architectures = [
        (feat_dim, 32, 16, 1),
        (feat_dim, 64, 32, 1),
        (feat_dim, 48, 24, 8, 1),
        (feat_dim, 32, 32, 1),
        (feat_dim, 16, 8, 1),
        (feat_dim, 64, 16, 1),
        (feat_dim, 32, 16, 8, 1),
        (feat_dim, 128, 64, 1),
    ]
    learning_rates = [0.001, 0.003, 0.0005]

    # 80/20 split
    split = int(len(X) * 0.8)
    X_tr, y_tr = X[:split], y[:split]
    X_val, y_val = X[split:], y[split:]

    best_val_loss = float("inf")
    best_config = {}
    results = []

    trials = [(arch, lr) for arch in architectures for lr in learning_rates]
    random.shuffle(trials)
    trials = trials[:n_trials]

    log.info(f"  [HYPER] Testing {n_trials} configurations on {len(X_tr)} train / {len(X_val)} val samples")

    for arch, lr in trials:
        try:
            # Import NN class from agent context (avoid circular import)
            import importlib.util, sys
            spec = importlib.util.spec_from_file_location("agent_module", BASE / "agent.py")
            # Instead: inline a minimal NN for hyperparameter testing
            dims = list(arch); nl = len(dims) - 1
            W = [np.random.randn(dims[i], dims[i+1]) * np.sqrt(2/dims[i]) for i in range(nl)]
            b = [np.zeros((1, dims[i+1])) for i in range(nl)]
            mu = np.zeros(dims[0]); var = np.ones(dims[0]); cnt = 0
            mW = [np.zeros_like(w) for w in W]; mb = [np.zeros_like(bb) for bb in b]
            vW = [np.zeros_like(w) for w in W]; vb = [np.zeros_like(bb) for bb in b]
            step = 0; b1 = 0.9; b2 = 0.999

            # Normalise
            for x in X_tr:
                cnt += 1; d = x - mu; mu += d/cnt; var += (d*(x-mu) - var)/cnt
            Xn = (X_tr - mu) / (np.sqrt(var) + 1e-8)
            Xv = (X_val - mu) / (np.sqrt(var) + 1e-8)

            # Train 100 epochs
            for _ in range(100):
                a = Xn; acts = [Xn]; zs = []
                for i in range(nl):
                    z = a @ W[i] + b[i]; zs.append(z)
                    a = np.maximum(0,z) if i < nl-1 else 1/(1+np.exp(-np.clip(z,-500,500)))
                    acts.append(a)
                d_out = acts[-1] - y_tr
                for i in range(nl-1, -1, -1):
                    dW = acts[i].T @ d_out / len(X_tr); db_g = d_out.mean(0, keepdims=True)
                    step += 1
                    mW[i] = b1*mW[i] + (1-b1)*dW; mb[i] = b1*mb[i] + (1-b1)*db_g
                    vW[i] = b2*vW[i] + (1-b2)*dW**2; vb[i] = b2*vb[i] + (1-b2)*db_g**2
                    mh = mW[i]/(1-b1**step); bh = mb[i]/(1-b1**step)
                    vh = vW[i]/(1-b2**step); vbh = vb[i]/(1-b2**step)
                    W[i] -= lr * mh/(np.sqrt(vh)+1e-8); b[i] -= lr*bh/(np.sqrt(vbh)+1e-8)
                    if i > 0: d_out = (d_out @ W[i].T) * (zs[i-1] > 0).astype(float)

            # Val loss
            a = Xv
            for i in range(nl):
                z = a @ W[i] + b[i]
                a = np.maximum(0,z) if i < nl-1 else 1/(1+np.exp(-np.clip(z,-500,500)))
            p = np.clip(a, 1e-7, 1-1e-7)
            val_loss = float(-np.mean(y_val * np.log(p) + (1-y_val)*np.log(1-p)))

            results.append({"arch": list(arch), "lr": lr, "val_loss": round(val_loss, 5)})
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_config = {"arch": list(arch), "lr": lr, "val_loss": round(val_loss, 5)}

        except Exception as e:
            log.debug(f"  [HYPER] trial error {arch} lr={lr}: {e}")

    results.sort(key=lambda x: x["val_loss"])
    log.info(f"  [HYPER] Best: arch={best_config.get('arch')} lr={best_config.get('lr')} val_loss={best_config.get('val_loss')}")

    # Save results
    try:
        existing = json.loads(HYPER_LOG.read_text()) if HYPER_LOG.exists() else []
        existing.append({
            "ts": datetime.now(IST).isoformat(),
            "best": best_config,
            "all": results[:5]
        })
        HYPER_LOG.write_text(json.dumps(existing[-10:], indent=2))  # keep last 10 runs
    except Exception: pass

    # Save best config to DB
    if best_config:
        try:
            c = sqlite3.connect(DB)
            c.execute("INSERT OR REPLACE INTO config(key,val) VALUES(?,?)",
                      ("best_nn_arch", json.dumps(best_config)))
            c.commit(); c.close()
        except Exception: pass

    return best_config

async def run_weekly_hyperparameter_search(feat_dim: int):
    """Background task: run hyperparameter search weekly."""
    while True:
        try:
            await asyncio.sleep(3600)  # check every hour
            now = datetime.now(IST)
            # Run on Sunday at 8 PM IST (after markets closed for the week)
            if now.weekday() == 6 and now.hour == 20:
                log.info("  [HYPER] Weekly search starting...")
                from self_improve import get_augmented_training_data, hyperparameter_search
                X, y = get_augmented_training_data(feat_dim, multiplier=1)  # no augment for search
                if X is not None and len(X) >= 20:
                    best = hyperparameter_search(X, y, feat_dim)
                    if best:
                        log.info(f"  [HYPER] Weekly search done. Best arch: {best['arch']}")
                await asyncio.sleep(3600)  # don't re-run within same hour
        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error(f"  [HYPER] Weekly search error: {e}")

async def run_nightly_reconciliation(broker):
    """Background task: reconcile trades at end of day."""
    while True:
        try:
            await asyncio.sleep(60)
            now = datetime.now(IST)
            # Run at 3:45 PM IST on weekdays (after market close)
            if now.weekday() < 5 and now.hour == 15 and now.minute == 45:
                log.info("  [RECON] Running nightly reconciliation...")
                report = await reconciler.reconcile(broker)
                if report["discrepancies"]:
                    # Import tg from agent — use log as fallback
                    log.warning(f"  [RECON] Discrepancies found: {report['discrepancies']}")
                await asyncio.sleep(3600)  # don't re-run within same hour
        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error(f"  [RECON] Nightly task error: {e}")

async def run_signal_attribution_logger():
    """Background task: log signal attribution every 50 trades."""
    last_total = [0]
    while True:
        try:
            await asyncio.sleep(300)
            c = sqlite3.connect(DB)
            total = c.execute("SELECT COUNT(*) n FROM trades").fetchone()["n"]
            c.close()
            if total - last_total[0] >= 50:
                last_total[0] = total
                sig_attr.log_report()
        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error(f"  [ATTR] logger error: {e}")
