#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# FinanceAGI v13.0 -- Deploy Script (Ubuntu VPS / Termux)
# Usage: bash deploy.sh
# Override install dir: INSTALL_DIR=/opt/financeagi bash deploy.sh
# ─────────────────────────────────────────────────────────────
set -euo pipefail

# Auto-detect Termux vs standard Linux
if [ -d "/data/data/com.termux" ]; then
    DEFAULT_DIR="$HOME/financeagi"
else
    DEFAULT_DIR="/data/financeagi"
fi

INSTALL_DIR="${INSTALL_DIR:-$DEFAULT_DIR}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=== FinanceAGI v13.0 Deploy ==="
echo "Install dir : $INSTALL_DIR"
echo "Source dir  : $SCRIPT_DIR"

# 1. Create install dir
mkdir -p "$INSTALL_DIR/logs"

# 2. Copy files
echo "[1/5] Copying files..."
cp "$SCRIPT_DIR/agent.py"           "$INSTALL_DIR/"
cp "$SCRIPT_DIR/command_centre.py"  "$INSTALL_DIR/"
cp "$SCRIPT_DIR/commodity_futures.py" "$INSTALL_DIR/" 2>/dev/null || true
cp "$SCRIPT_DIR/equity_intraday.py" "$INSTALL_DIR/" 2>/dev/null || true
cp "$SCRIPT_DIR/multileg.py"        "$INSTALL_DIR/" 2>/dev/null || true
cp "$SCRIPT_DIR/daily_update.py"    "$INSTALL_DIR/" 2>/dev/null || true
cp "$SCRIPT_DIR/ecosystem.config.js" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/requirements.txt"   "$INSTALL_DIR/"
cp "$SCRIPT_DIR/DEPLOY.md"          "$INSTALL_DIR/" 2>/dev/null || true
# Copy .env only if it doesn't already exist (don't overwrite live credentials)
if [ ! -f "$INSTALL_DIR/.env" ]; then
    cp "$SCRIPT_DIR/.env" "$INSTALL_DIR/" 2>/dev/null || true
    echo "    .env copied (first time)"
else
    echo "    .env already exists -- skipping (credentials preserved)"
fi

# 3. Python dependencies
echo "[2/5] Installing Python dependencies..."
pip install --break-system-packages -q aiohttp numpy 2>/dev/null || \
pip install -q aiohttp numpy || \
pip3 install -q aiohttp numpy

# 4. Install pm2 if missing
echo "[3/5] Checking pm2..."
if ! command -v pm2 &>/dev/null; then
    echo "    pm2 not found -- installing via npm..."
    if command -v npm &>/dev/null; then
        npm install -g pm2
    else
        echo "    [WARN] npm not found. Install Node.js first:"
        if [ -d "/data/data/com.termux" ]; then
            echo "      Termux: pkg install nodejs"
        else
            echo "      Ubuntu: apt install nodejs npm -y"
        fi
        exit 1
    fi
else
    echo "    pm2 found: $(pm2 --version)"
fi

# 5. Update cwd in ecosystem.config.js
echo "[4/5] Patching ecosystem.config.js with install dir..."
sed -i "s|/data/financeagi|$INSTALL_DIR|g" "$INSTALL_DIR/ecosystem.config.js"
# Also patch any remaining __dirname references to be explicit
sed -i "s|require(\"path\").resolve(__dirname)|\"$INSTALL_DIR\"|g" "$INSTALL_DIR/ecosystem.config.js"

# 6. Start / restart with pm2
echo "[5/5] Starting pm2 processes..."
cd "$INSTALL_DIR"

# Load .env if present
if [ -f "$INSTALL_DIR/.env" ]; then
    set -a
    # shellcheck disable=SC1090
    source "$INSTALL_DIR/.env"
    set +a
    echo "    .env loaded"
fi

# Stop old processes gracefully
pm2 stop financeagi-agent     2>/dev/null || true
pm2 stop financeagi-dashboard 2>/dev/null || true
pm2 delete financeagi-agent     2>/dev/null || true
pm2 delete financeagi-dashboard 2>/dev/null || true

# Start fresh
pm2 start ecosystem.config.js

# Persist so pm2 restarts after reboot
pm2 save

echo ""
echo "=== Deploy Complete ==="
echo "Dashboard : http://localhost:8000"
echo ""
echo "Next steps:"
echo "  1. Open http://localhost:8000 and login with Upstox"
echo "  2. Verify balance shows correctly"
echo "  3. Agent auto-trades 9:16 AM – 3:25 PM IST (NSE)"
echo ""
echo "Useful commands:"
echo "  pm2 logs financeagi-agent      # live agent logs"
echo "  pm2 logs financeagi-dashboard  # dashboard logs"
echo "  pm2 monit                      # CPU/RAM monitor"
echo "  pm2 restart all                # restart everything"
echo "  pm2 stop all                   # stop everything"
echo "  python3 agent.py stats         # view performance"
echo ""
echo "To persist across reboots (run ONCE after first deploy):"
echo "  pm2 startup"
echo "  <copy and run the printed command>"
echo "  pm2 save"
