#!/usr/bin/env python3
"""
options_strategy_inventor.py — FinanceAGI v17: AI Options Strategy Inventor & Manager
======================================================================================

Invents, evaluates, mutates, and manages NSE/BSE F&O options strategies using
Claude claude-sonnet-4-20250514. Covers NIFTY, BANKNIFTY, FINNIFTY index options and FNO stock
options across all strategy types.

Strategy Types Invented:
  SINGLE        — Naked CE/PE buy (directional)
  SPREAD        — Bull call / Bear put debit spreads
  IRON_CONDOR   — OTM put spread + OTM call spread (non-directional, credit)
  STRADDLE      — ATM CE+PE buy (volatility long)
  STRANGLE      — OTM CE+PE buy (wide volatility long)
  BUTTERFLY     — 3-leg defined risk (low cost, precise target)
  CALENDAR      — Same strike, different expiry (theta capture)
  RATIO         — Unequal legs (skew exploitation)
  JADE_LIZARD   — Short put + short call spread (premium collection)
  IRON_BUTTERFLY— ATM straddle sell + OTM wing buys (range-bound)
  COLLAR        — Long stock + protective put + covered call
  DIAGONAL      — Different strike + different expiry
  SYNTHETIC     — Synthetic long/short via options

Architecture:
  ┌──────────────────────────────────────────────────────────────────────┐
  │  OptionsStrategyInventor  (main class)                              │
  │   ├─ OptionsStrategyDB       — persist strategies to JSON + SQLite  │
  │   ├─ OptionsPerformance      — rolling WR / Sharpe / Greeks P&L     │
  │   ├─ OptionsLLMInventor      — Claude API invention engine          │
  │   ├─ OptionsEvolution        — kill / breed / mutate                │
  │   └─ GreeksAwareScorer       — IV / delta / theta scoring           │
  └──────────────────────────────────────────────────────────────────────┘

Integration with agent.py:
  1. Import: `from options_strategy_inventor import options_inventor`
  2. After each options trade closes:
       options_inventor.record_trade(strategy_name, won, pnl_pct, greeks_snapshot)
  3. Periodically (every N trades or hourly):
       new_strats = await options_inventor.maybe_invent(market_context)
  4. agent.py reads options_inventor.active_strategies() for live strategy list
  5. options_inventor.pick_strategy(option_chain, spot, cash) replaces pool.pick()

Usage (standalone):
  python3 options_strategy_inventor.py              # Print active strategies
  python3 options_strategy_inventor.py invent       # Force-invent via LLM
  python3 options_strategy_inventor.py status       # Performance table
  python3 options_strategy_inventor.py evolve       # Run evolution cycle

Environment:
  ANTHROPIC_API_KEY          — required for LLM invention
  OPT_INVENTOR_MAX_STRATS    — max live strategies (default 20)
  OPT_INVENTOR_KILL_WR       — kill threshold after min_trades (default 0.40)
  OPT_INVENTOR_MIN_TRADES    — min trades before kill eligible (default 6)
"""

import asyncio
import copy
import hashlib
import json
import logging
import math
import os
import random
import sqlite3
import sys
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

try:
    import httpx
    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False
    httpx = None

try:
    import numpy as np
    _HAS_NP = True
except ImportError:
    _HAS_NP = False

log = logging.getLogger("agi.opt_inventor")
IST = timezone(timedelta(hours=5, minutes=30))
BASE = Path(__file__).resolve().parent
DB   = str(BASE / "data" / "v10.db")
OPT_STRAT_FILE = BASE / "data" / "invented_options_strategies.json"

# ── Load environment ───────────────────────────────────────────────────────────
def _env(key: str, default: str = "") -> str:
    ef = BASE / ".env"
    if ef.exists():
        for ln in ef.read_text().splitlines():
            ln = ln.strip()
            if ln and not ln.startswith("#") and "=" in ln:
                k, v = ln.split("=", 1)
                if k.strip() == key:
                    return v.strip()
    return os.environ.get(key, default)

ANTHROPIC_API_KEY = _env("ANTHROPIC_API_KEY")
MAX_STRATS        = int(_env("OPT_INVENTOR_MAX_STRATS", "20"))
KILL_WR           = float(_env("OPT_INVENTOR_KILL_WR", "0.40"))
MIN_TRADES        = int(_env("OPT_INVENTOR_MIN_TRADES", "6"))

# ═══════════════════════ STRATEGY SCHEMA ═══════════════════════════════════════

OPTIONS_STRATEGY_TYPES = [
    "single", "spread", "iron_condor", "straddle", "strangle",
    "butterfly", "calendar", "ratio", "jade_lizard", "iron_butterfly",
    "collar", "diagonal", "synthetic",
]

OPTIONS_SIGNAL_TYPES = [
    "MOMENTUM_LONG",       # Buy CE/PE on trend continuation
    "MEAN_REVERT",         # Fade extremes
    "BREAKOUT_SCALP",      # Breakout from consolidation
    "IV_CRUSH_SELL",       # Sell premium before IV crush
    "IV_EXPANSION_BUY",    # Buy premium before vol expansion
    "THETA_HARVEST",       # Sell time decay (credit strategies)
    "GAMMA_SCALP",         # Buy near-ATM, ride gamma
    "DELTA_HEDGE",         # Delta-neutral with gamma edge
    "SKEW_EXPLOIT",        # Trade IV skew mispricing
    "EVENT_STRADDLE",      # Pre-event vol long
    "EXPIRY_DECAY",        # Sell weekly expiry theta
    "PCR_SIGNAL",          # Put-call ratio based
    "OI_BUILDUP",          # Open interest accumulation signal
    "FII_FLOW",            # FII/DII positioning signal
    "VWAP_CROSS",          # VWAP crossover momentum
    "CUSTOM_LLM",          # Pure LLM-invented signal
]

UNDERLYINGS = ["NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY",
               "RELIANCE", "TCS", "INFY", "HDFCBANK", "ICICIBANK",
               "SBIN", "TATASTEEL", "AXISBANK", "BAJFINANCE", "ITC"]

OPT_STRATEGY_DEFAULTS: dict = {
    "name":              "",
    "version":           1,
    "generation":        0,
    "created_at":        "",
    "asset_class":       "options",
    # Underlying targeting
    "underlyings":       ["NIFTY", "BANKNIFTY"],  # which underlyings to scan
    "prefer_underlying": "index",       # "index" | "stock" | "any"
    # Option selection
    "option_type":       "CE",          # "CE" | "PE" | "BOTH"
    "delta_min":         0.15,
    "delta_max":         0.40,
    "otm_min":           0.5,           # min OTM %
    "otm_max":           5.0,           # max OTM %
    "iv_pref":           "ANY",         # "ANY" | "HIGH" | "LOW"
    "iv_min":            0.0,           # min IV threshold
    "iv_max":            100.0,         # max IV threshold
    "vol_min":           500000,        # min volume
    # Strategy structure
    "strategy_type":     "single",      # one of OPTIONS_STRATEGY_TYPES
    "signal_type":       "MOMENTUM_LONG",
    "legs":              1,             # number of legs
    "leg_config":        [],            # detailed leg specifications for multi-leg
    # Risk parameters
    "target_pct":        5.0,
    "stoploss_pct":      7.0,
    "max_hold_min":      15,
    "trailing_sl":       True,
    "partial_exit":      True,
    "trailing_activation_pct": 3.0,     # activate trailing after this profit
    "trailing_distance_pct":   2.0,     # trailing SL distance
    # Timing
    "hour_start":        9,
    "hour_end":          15,
    "prefer_expiry":     "nearest",     # "nearest" | "next" | "any" | "calendar"
    "max_dte":           7,             # max days to expiry
    "min_dte":           0,
    # Capital & sizing
    "capital_pct":       0.25,          # fraction of options allocation
    "min_capital":       2000,          # minimum capital needed
    "max_lots":          5,             # max lot count
    # Trend / regime filters
    "trend_filter":      "NONE",        # "NONE" | "WITH" | "AGAINST"
    "regime_filter":     "ANY",         # "ANY" | "TRENDING" | "RANGING" | "VOLATILE"
    "vix_min":           0.0,
    "vix_max":           50.0,
    # Greeks targets (for multi-leg)
    "target_delta":      None,          # net delta target
    "target_theta":      None,          # daily theta target (₹)
    "max_vega_exposure":  None,         # max vega risk
    # Metadata
    "rationale":         "",
    "tags":              [],
    "parent_names":      [],
    "active":            True,
    "trades":            0,
    "wins":              0,
    "total_pnl":         0.0,
    "peak_pnl":          0.0,
    "max_drawdown":      0.0,
    "last_trade_ts":     "",
    "sharpe":            0.0,
    "avg_greeks_pnl":    0.0,          # avg P&L from greeks (delta/theta/vega)
}

# Mutable genes for evolution
OPT_MUTABLE_GENES = [
    "option_type", "delta_min", "delta_max", "otm_min", "otm_max",
    "iv_pref", "iv_min", "iv_max", "vol_min", "strategy_type",
    "signal_type", "target_pct", "stoploss_pct", "max_hold_min",
    "trailing_sl", "trailing_activation_pct", "trailing_distance_pct",
    "hour_start", "hour_end", "prefer_expiry", "max_dte",
    "capital_pct", "max_lots", "trend_filter", "regime_filter",
    "vix_min", "vix_max",
]


# ═══════════════════════ GREEKS-AWARE SCORER ═══════════════════════════════════

class GreeksAwareScorer:
    """
    Scores options opportunities using Greeks, IV surface, and strategy fit.
    Used by pick_strategy() to rank which strategy+option combo is best.
    """

    @staticmethod
    def score_option(opt: dict, strategy: dict, spot: float, vix: float = 15.0) -> float:
        """Score an option for a given strategy. Higher = better fit."""
        score = 0.0
        s = strategy

        delta = abs(opt.get("delta", 0))
        iv    = opt.get("iv", 20)
        vol   = opt.get("volume", 0)
        dte   = opt.get("dte", 3)
        theta = abs(opt.get("theta", 0))
        gamma = opt.get("gamma", 0)
        ltp   = opt.get("ltp", 0)
        otype = opt.get("type", "CE")

        # Delta fit
        if s["delta_min"] <= delta <= s["delta_max"]:
            score += 2.0
            # Bonus for center of range
            center = (s["delta_min"] + s["delta_max"]) / 2
            score += max(0, 1.0 - abs(delta - center) * 5)

        # IV fit
        if s["iv_pref"] == "HIGH" and iv > 25:
            score += 1.5
        elif s["iv_pref"] == "LOW" and iv < 18:
            score += 1.5
        elif s["iv_pref"] == "ANY":
            score += 0.5

        # Volume / liquidity
        if vol > s["vol_min"]:
            score += 1.0
            if vol > s["vol_min"] * 5:
                score += 0.5

        # Expiry fit
        if s["prefer_expiry"] == "nearest" and dte <= 3:
            score += 1.5
        elif s["prefer_expiry"] == "next" and 3 < dte <= 10:
            score += 1.5
        elif s["prefer_expiry"] == "calendar" and dte > 7:
            score += 1.0

        # Strategy-type specific scoring
        st = s["strategy_type"]
        if st == "single":
            # Prefer good gamma for single leg buys
            if gamma > 0.001:
                score += 1.0
        elif st in ("straddle", "strangle"):
            # Prefer low IV for buying straddles (cheaper entry)
            if iv < 18:
                score += 1.5
        elif st in ("iron_condor", "iron_butterfly", "jade_lizard"):
            # Prefer high IV for selling strategies (more premium)
            if iv > 22:
                score += 2.0
        elif st in ("calendar", "diagonal"):
            # Theta should be meaningful
            if theta > 0.5:
                score += 1.0
        elif st == "butterfly":
            # Prefer moderate IV
            if 15 < iv < 25:
                score += 1.0

        # VIX filter
        if s["vix_min"] <= vix <= s["vix_max"]:
            score += 0.5

        # Regime bonus
        regime = s.get("regime_filter", "ANY")
        if regime == "VOLATILE" and vix > 20:
            score += 1.0
        elif regime == "RANGING" and vix < 14:
            score += 1.0

        return round(score, 2)

    @staticmethod
    def score_spread(near_opt: dict, far_opt: dict, strategy: dict) -> float:
        """Score a spread combination (2 legs)."""
        base = GreeksAwareScorer.score_option(near_opt, strategy, 0)
        # Check spread width is reasonable
        strike_diff = abs(near_opt.get("strike", 0) - far_opt.get("strike", 0))
        near_ltp = near_opt.get("ltp", 0)
        far_ltp  = far_opt.get("ltp", 0)

        if near_ltp <= 0 or far_ltp <= 0:
            return 0.0

        # Debit spread: max loss = debit paid, max profit = width - debit
        debit = abs(near_ltp - far_ltp)
        if strike_diff > 0:
            reward_risk = (strike_diff - debit) / max(debit, 0.01)
            base += min(reward_risk, 3.0)  # cap bonus at 3

        return round(base, 2)


scorer = GreeksAwareScorer()


# ═══════════════════════ PERFORMANCE TRACKER ═══════════════════════════════════

class OptionsPerformanceTracker:
    """Per-strategy rolling performance with Greeks attribution."""

    def __init__(self, window: int = 40):
        self.window = window
        self._trades: dict[str, deque] = defaultdict(lambda: deque(maxlen=window))

    def record(self, strategy: str, won: bool, pnl_pct: float,
               greeks_pnl: dict = None):
        """Record a trade with optional Greeks P&L breakdown."""
        entry = {
            "won": won, "pnl": pnl_pct, "ts": time.time(),
            "delta_pnl": 0, "theta_pnl": 0, "vega_pnl": 0, "gamma_pnl": 0,
        }
        if greeks_pnl:
            entry.update({
                "delta_pnl": greeks_pnl.get("delta", 0),
                "theta_pnl": greeks_pnl.get("theta", 0),
                "vega_pnl":  greeks_pnl.get("vega", 0),
                "gamma_pnl": greeks_pnl.get("gamma", 0),
            })
        self._trades[strategy].append(entry)

    def win_rate(self, strategy: str) -> float:
        d = self._trades.get(strategy, [])
        return sum(1 for t in d if t["won"]) / max(len(d), 1)

    def avg_pnl(self, strategy: str) -> float:
        d = self._trades.get(strategy, [])
        return sum(t["pnl"] for t in d) / max(len(d), 1) if d else 0.0

    def sharpe(self, strategy: str) -> float:
        d = self._trades.get(strategy, [])
        if len(d) < 3:
            return 0.0
        pnls = [t["pnl"] for t in d]
        mean = sum(pnls) / len(pnls)
        std = math.sqrt(sum((p - mean) ** 2 for p in pnls) / len(pnls))
        return round(mean / max(std, 0.01), 3)

    def greeks_attribution(self, strategy: str) -> dict:
        """Breakdown P&L by Greek contribution."""
        d = self._trades.get(strategy, [])
        if not d:
            return {"delta": 0, "theta": 0, "vega": 0, "gamma": 0}
        n = len(d)
        return {
            "delta": round(sum(t["delta_pnl"] for t in d) / n, 3),
            "theta": round(sum(t["theta_pnl"] for t in d) / n, 3),
            "vega":  round(sum(t["vega_pnl"]  for t in d) / n, 3),
            "gamma": round(sum(t["gamma_pnl"] for t in d) / n, 3),
        }

    def trade_count(self, strategy: str) -> int:
        return len(self._trades.get(strategy, []))

    def should_kill(self, strategy: str) -> bool:
        n = self.trade_count(strategy)
        return n >= MIN_TRADES and self.win_rate(strategy) < KILL_WR

    def max_drawdown(self, strategy: str) -> float:
        d = self._trades.get(strategy, [])
        if len(d) < 2:
            return 0.0
        cumulative = 0.0
        peak = 0.0
        max_dd = 0.0
        for t in d:
            cumulative += t["pnl"]
            peak = max(peak, cumulative)
            dd = peak - cumulative
            max_dd = max(max_dd, dd)
        return round(max_dd, 3)

    def summary(self, strategy: str) -> dict:
        return {
            "n":         self.trade_count(strategy),
            "wr":        round(self.win_rate(strategy), 3),
            "avg_pnl":   round(self.avg_pnl(strategy), 3),
            "sharpe":    self.sharpe(strategy),
            "max_dd":    self.max_drawdown(strategy),
            "greeks":    self.greeks_attribution(strategy),
        }


opt_perf = OptionsPerformanceTracker()


# ═══════════════════════ STRATEGY DATABASE ═════════════════════════════════════

class OptionsStrategyDB:
    """Persist and load options strategies from JSON."""

    def __init__(self, path: Path = OPT_STRAT_FILE):
        self.path = path
        self._strategies: dict[str, dict] = {}
        self._load()

    def _load(self):
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text())
                self._strategies = {s["name"]: s for s in data if s.get("name")}
                log.info(f"  [OPT_INV] Loaded {len(self._strategies)} options strategies")
            except Exception as e:
                log.warning(f"  [OPT_INV] Load failed: {e}")

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(list(self._strategies.values()), indent=2, ensure_ascii=False)
        )

    def add(self, strat: dict) -> bool:
        name = strat.get("name", "")
        if not name:
            return False
        self._strategies[name] = strat
        self.save()
        log.info(f"  [OPT_INV] + Added: {name}")
        return True

    def update(self, name: str, **kwargs):
        if name in self._strategies:
            self._strategies[name].update(kwargs)
            self.save()

    def get(self, name: str) -> dict | None:
        return self._strategies.get(name)

    def all(self) -> list[dict]:
        return list(self._strategies.values())

    def active(self) -> list[dict]:
        return [s for s in self._strategies.values() if s.get("active", True)]

    def remove(self, name: str):
        self._strategies.pop(name, None)
        self.save()

    def active_count(self) -> int:
        return sum(1 for s in self._strategies.values() if s.get("active", True))

    def record_trade(self, name: str, won: bool, pnl_pct: float):
        if name not in self._strategies:
            return
        s = self._strategies[name]
        s["trades"] = s.get("trades", 0) + 1
        if won:
            s["wins"] = s.get("wins", 0) + 1
        s["total_pnl"] = round(s.get("total_pnl", 0.0) + pnl_pct, 4)
        s["peak_pnl"]  = round(max(s.get("peak_pnl", 0.0), s["total_pnl"]), 4)
        s["last_trade_ts"] = datetime.now(IST).isoformat()
        self.save()


opt_strat_db = OptionsStrategyDB()


# ═══════════════════════ LLM INVENTOR ═════════════════════════════════════════

class OptionsLLMInventor:
    """
    Calls Claude claude-sonnet-4-20250514 to invent new F&O options strategies.
    Understands NIFTY/BANKNIFTY chain structure, lot sizes, margin requirements.
    """

    MODEL = "claude-sonnet-4-20250514"
    MAX_TOKENS = 1200
    COOLDOWN_SEC = 240

    def __init__(self):
        self._last_call = 0.0
        self._call_count = 0

    def _is_ready(self) -> bool:
        return (
            bool(ANTHROPIC_API_KEY)
            and (time.time() - self._last_call) > self.COOLDOWN_SEC
        )

    async def invent(
        self,
        market_context: dict,
        existing_strategies: list[dict],
        trade_history_summary: str = "",
    ) -> dict | None:
        """Ask Claude to invent a new options strategy."""
        if not ANTHROPIC_API_KEY or not _HAS_HTTPX:
            return None
        if not self._is_ready():
            return None

        existing_names = [s.get("name", "") for s in existing_strategies]
        known_types = ", ".join(OPTIONS_STRATEGY_TYPES)
        known_signals = ", ".join(OPTIONS_SIGNAL_TYPES)
        known_underlyings = ", ".join(UNDERLYINGS)

        spot_lines = "\n".join(
            f"  {sym}: ₹{price:,.1f} ({market_context.get('day_changes', {}).get(sym, 0):+.2f}%)"
            for sym, price in market_context.get("spot_prices", {}).items()
        )

        system_prompt = (
            "You are a quantitative options strategist for NSE F&O (India). "
            "You invent intraday and short-term options strategies for NIFTY, BANKNIFTY, "
            "FINNIFTY, and FNO stocks. You understand lot sizes (NIFTY=25, BANKNIFTY=15), "
            "expiry structure (weekly Thursday), Greeks, IV surface, and Indian market microstructure. "
            "Return ONLY a valid JSON object — no explanation, no markdown, no code fences."
        )

        user_prompt = f"""
MARKET SNAPSHOT ({datetime.now(IST).strftime('%H:%M IST')}):
{spot_lines if spot_lines else "  (no live data)"}

India VIX: {market_context.get("india_vix", "unknown")}
PCR: {market_context.get("pcr", "unknown")}
Max Pain NIFTY: {market_context.get("max_pain_nifty", "unknown")}
Session: {market_context.get("session", "market_hours")}
Regime: {market_context.get("regime", "unknown")}

TRADE HISTORY:
{trade_history_summary or "No recent trades."}

WINNING TODAY: {market_context.get("winning_strats", [])}
LOSING TODAY:  {market_context.get("losing_strats", [])}

EXISTING (avoid duplicating): {existing_names}

AVAILABLE STRATEGY TYPES: {known_types}
AVAILABLE SIGNAL TYPES: {known_signals}
AVAILABLE UNDERLYINGS: {known_underlyings}

NIFTY lot=25, BANKNIFTY lot=15, FINNIFTY lot=25
Weekly expiry: Thursday. Monthly expiry: last Thursday.

TASK: Invent ONE new F&O options strategy different from all existing ones.
Consider current VIX, PCR, regime to pick the right strategy type.
For multi-leg strategies, specify leg_config with strike offsets and directions.

Return ONLY this JSON:
{{
  "name": "UniqueNameCamelCase",
  "underlyings": ["NIFTY"] or ["BANKNIFTY"] or ["NIFTY","BANKNIFTY"] or ["ALL"],
  "prefer_underlying": "index" or "stock" or "any",
  "option_type": "CE" or "PE" or "BOTH",
  "delta_min": <float 0.05-0.60>,
  "delta_max": <float 0.10-0.70>,
  "otm_min": <float 0.2-5.0>,
  "otm_max": <float 1.0-10.0>,
  "iv_pref": "ANY" or "HIGH" or "LOW",
  "iv_min": <float 0-50>,
  "iv_max": <float 10-100>,
  "vol_min": <int>,
  "strategy_type": "one_of_available_types",
  "signal_type": "one_of_available_signals",
  "legs": <int 1-4>,
  "leg_config": [
    {{"leg": 1, "type": "CE/PE", "action": "BUY/SELL", "strike_offset": 0, "delta_target": 0.30}},
    ...
  ],
  "target_pct": <float 2-20>,
  "stoploss_pct": <float 2-15>,
  "max_hold_min": <int 5-120>,
  "trailing_sl": true/false,
  "trailing_activation_pct": <float 1-10>,
  "trailing_distance_pct": <float 0.5-5>,
  "hour_start": <int 9-14>,
  "hour_end": <int 10-15>,
  "prefer_expiry": "nearest" or "next" or "any" or "calendar",
  "max_dte": <int 0-30>,
  "capital_pct": <float 0.10-0.40>,
  "min_capital": <int 2000-50000>,
  "max_lots": <int 1-10>,
  "trend_filter": "NONE" or "WITH" or "AGAINST",
  "regime_filter": "ANY" or "TRENDING" or "RANGING" or "VOLATILE",
  "vix_min": <float 0-30>,
  "vix_max": <float 5-50>,
  "target_delta": <float or null>,
  "target_theta": <float or null>,
  "rationale": "1-3 sentence explanation of the edge",
  "tags": ["tag1", "tag2", "tag3"]
}}
""".strip()

        try:
            self._last_call = time.time()
            self._call_count += 1

            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key":         ANTHROPIC_API_KEY,
                        "anthropic-version": "2023-06-01",
                        "content-type":      "application/json",
                    },
                    json={
                        "model":      self.MODEL,
                        "max_tokens": self.MAX_TOKENS,
                        "system":     system_prompt,
                        "messages":   [{"role": "user", "content": user_prompt}],
                    },
                )
                resp.raise_for_status()
                data = resp.json()

            raw_text = ""
            for block in data.get("content", []):
                if block.get("type") == "text":
                    raw_text += block.get("text", "")

            raw_text = raw_text.strip()
            if raw_text.startswith("```"):
                raw_text = raw_text.split("```")[1]
                if raw_text.startswith("json"):
                    raw_text = raw_text[4:]

            strat_dict = json.loads(raw_text.strip())
            validated  = self._validate(strat_dict, existing_names)
            log.info(f"  [OPT_INV] LLM invented: {validated['name']} — {validated.get('rationale', '')[:80]}")
            return validated

        except json.JSONDecodeError as e:
            log.error(f"  [OPT_INV] LLM invalid JSON: {e}")
        except Exception as e:
            log.error(f"  [OPT_INV] LLM call failed: {e}")

        return None

    def _validate(self, d: dict, existing_names: list) -> dict:
        """Merge with defaults, type-coerce, and ensure uniqueness."""
        strat = dict(OPT_STRATEGY_DEFAULTS)
        strat.update({k: v for k, v in d.items() if k in OPT_STRATEGY_DEFAULTS})

        # Type coercions
        for f in ["delta_min", "delta_max", "otm_min", "otm_max", "iv_min", "iv_max",
                   "target_pct", "stoploss_pct", "capital_pct", "vix_min", "vix_max",
                   "trailing_activation_pct", "trailing_distance_pct"]:
            if f in strat and strat[f] is not None:
                strat[f] = float(strat[f])

        for f in ["max_hold_min", "hour_start", "hour_end", "max_dte", "min_dte",
                   "vol_min", "min_capital", "max_lots", "legs"]:
            if f in strat and strat[f] is not None:
                strat[f] = int(strat[f])

        # Bounds
        strat["capital_pct"]  = min(max(strat["capital_pct"], 0.10), 0.40)
        strat["target_pct"]   = min(max(strat["target_pct"],  2.0), 25.0)
        strat["stoploss_pct"] = min(max(strat["stoploss_pct"], 2.0), 20.0)
        strat["delta_min"]    = min(max(strat["delta_min"], 0.05), 0.60)
        strat["delta_max"]    = min(max(strat["delta_max"], 0.10), 0.70)
        if strat["delta_min"] > strat["delta_max"]:
            strat["delta_min"], strat["delta_max"] = strat["delta_max"], strat["delta_min"]

        # Ensure strategy_type is valid
        if strat["strategy_type"] not in OPTIONS_STRATEGY_TYPES:
            strat["strategy_type"] = "single"
        if strat["signal_type"] not in OPTIONS_SIGNAL_TYPES:
            strat["signal_type"] = "CUSTOM_LLM"

        # Ensure unique name
        base_name = strat.get("name", "OptInvented")
        name = base_name
        i = 2
        while name in existing_names:
            name = f"{base_name}{i}"
            i += 1
        strat["name"]       = name
        strat["created_at"] = datetime.now(IST).isoformat()
        strat["generation"] = 1
        strat["active"]     = True
        strat["trades"]     = 0
        strat["wins"]       = 0
        strat["total_pnl"]  = 0.0

        return strat

    def status(self) -> str:
        return (
            f"[OPT_INV] LLM calls: {self._call_count} | "
            f"last: {int(time.time() - self._last_call)}s ago | "
            f"ready: {self._is_ready()}"
        )


opt_llm = OptionsLLMInventor()


# ═══════════════════════ EVOLUTION ENGINE ══════════════════════════════════════

class OptionsEvolutionEngine:
    """Kill / Breed / Mutate options strategies."""

    @staticmethod
    def _uid(strat: dict) -> str:
        seed = f"{strat['name']}{strat.get('generation', 0)}{time.time()}"
        return hashlib.md5(seed.encode()).hexdigest()[:6]

    @staticmethod
    def mutate(parent: dict, mutation_rate: float = 0.30) -> dict:
        child = copy.deepcopy(parent)
        child["parent_names"] = [parent["name"]]
        child["generation"]   = parent.get("generation", 0) + 1
        child["trades"] = child["wins"] = 0
        child["total_pnl"] = child["peak_pnl"] = child["max_drawdown"] = 0.0
        child["created_at"] = datetime.now(IST).isoformat()

        mutated = []
        for gene in OPT_MUTABLE_GENES:
            if random.random() > mutation_rate:
                continue
            val = parent.get(gene)
            if gene == "option_type":
                child[gene] = random.choice(["CE", "PE", "BOTH"])
            elif gene == "strategy_type":
                child[gene] = random.choice(OPTIONS_STRATEGY_TYPES)
            elif gene == "signal_type":
                child[gene] = random.choice(OPTIONS_SIGNAL_TYPES)
            elif gene == "iv_pref":
                child[gene] = random.choice(["ANY", "HIGH", "LOW"])
            elif gene == "trend_filter":
                child[gene] = random.choice(["NONE", "WITH", "AGAINST"])
            elif gene == "regime_filter":
                child[gene] = random.choice(["ANY", "TRENDING", "RANGING", "VOLATILE"])
            elif gene == "prefer_expiry":
                child[gene] = random.choice(["nearest", "next", "any", "calendar"])
            elif gene == "trailing_sl":
                child[gene] = not child.get(gene, True)
            elif isinstance(val, float):
                noise = random.uniform(0.75, 1.30)
                child[gene] = round(val * noise, 3)
            elif isinstance(val, int):
                noise = random.randint(-3, 3)
                child[gene] = max(1, val + noise)
            mutated.append(gene)

        # Apply bounds
        child["capital_pct"]  = min(max(child.get("capital_pct", 0.25), 0.10), 0.40)
        child["target_pct"]   = min(max(child.get("target_pct",  5.0),  2.0), 25.0)
        child["stoploss_pct"] = min(max(child.get("stoploss_pct", 7.0), 2.0), 20.0)
        if child.get("delta_min", 0) > child.get("delta_max", 1):
            child["delta_min"], child["delta_max"] = child["delta_max"], child["delta_min"]

        uid = OptionsEvolutionEngine._uid(child)
        base = parent["name"].rstrip("0123456789_")
        child["name"] = f"{base}_{uid}"
        child["rationale"] = (
            f"Mutation of {parent['name']} (gen{child['generation']}). "
            f"Mutated: {mutated}."
        )
        return child

    @staticmethod
    def crossbreed(a: dict, b: dict) -> dict:
        child = {}
        for gene in OPT_MUTABLE_GENES:
            child[gene] = a.get(gene) if random.random() < 0.5 else b.get(gene)

        child["name"]         = f"OptBred_{OptionsEvolutionEngine._uid({'name': a['name']+b['name']})}"
        child["generation"]   = max(a.get("generation", 0), b.get("generation", 0)) + 1
        child["parent_names"] = [a["name"], b["name"]]
        child["created_at"]   = datetime.now(IST).isoformat()
        child["active"]       = True
        child["trades"] = child["wins"] = 0
        child["total_pnl"] = child["peak_pnl"] = child["max_drawdown"] = 0.0
        child["rationale"] = f"Crossbreed of {a['name']} × {b['name']} (gen{child['generation']})."
        child["tags"] = list(set(a.get("tags", []) + b.get("tags", [])))

        merged = dict(OPT_STRATEGY_DEFAULTS)
        merged.update(child)
        merged["capital_pct"] = min(max(merged.get("capital_pct", 0.25), 0.10), 0.40)
        return merged

    def evolve(self, strategies: list[dict]) -> list[str]:
        """Run one evolution cycle. Returns action log strings."""
        actions = []

        # Kill weak
        to_kill = []
        for s in strategies:
            name = s.get("name", "")
            if not s.get("active", True):
                continue
            if opt_perf.should_kill(name):
                wr = opt_perf.win_rate(name)
                n  = opt_perf.trade_count(name)
                to_kill.append(name)
                actions.append(f"KILL {name} (WR={wr:.0%} n={n})")
                opt_strat_db.update(name, active=False)

        active = [s for s in strategies if s.get("active", True) and s["name"] not in to_kill]
        n_active = len(active)

        # Breed top 2
        if n_active >= 2 and n_active < MAX_STRATS:
            ranked = sorted(
                [s for s in active if opt_perf.trade_count(s["name"]) >= 3],
                key=lambda s: opt_perf.sharpe(s["name"]),
                reverse=True
            )
            if len(ranked) >= 2:
                child = self.crossbreed(ranked[0], ranked[1])
                opt_strat_db.add(child)
                actions.append(f"BREED {ranked[0]['name']} × {ranked[1]['name']} → {child['name']}")

        # Mutate random active
        if active and n_active < MAX_STRATS:
            parent = random.choice(active)
            mutant = self.mutate(parent)
            opt_strat_db.add(mutant)
            actions.append(f"MUTATE {parent['name']} → {mutant['name']}")

        return actions


opt_evolution = OptionsEvolutionEngine()


# ═══════════════════════ SEED STRATEGIES ═══════════════════════════════════════

SEED_OPTIONS_STRATEGIES: list[dict] = [
    {**OPT_STRATEGY_DEFAULTS,
     "name": "NiftyMomentumCE", "underlyings": ["NIFTY"], "option_type": "CE",
     "delta_min": 0.20, "delta_max": 0.40, "strategy_type": "single",
     "signal_type": "MOMENTUM_LONG", "target_pct": 5, "stoploss_pct": 7,
     "vol_min": 5000000, "max_hold_min": 15, "prefer_expiry": "nearest",
     "rationale": "Ride NIFTY CE momentum on trend days with 20-40 delta",
     "tags": ["nifty", "momentum", "ce", "intraday"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "BankNiftyScalpPE", "underlyings": ["BANKNIFTY"], "option_type": "PE",
     "delta_min": 0.15, "delta_max": 0.35, "strategy_type": "single",
     "signal_type": "BREAKOUT_SCALP", "target_pct": 4, "stoploss_pct": 5,
     "vol_min": 3000000, "max_hold_min": 10, "trailing_sl": False,
     "rationale": "Quick BankNifty PE scalp on breakdown from opening range",
     "tags": ["banknifty", "scalp", "pe", "intraday"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "NiftyBullSpread", "underlyings": ["NIFTY"], "option_type": "CE",
     "delta_min": 0.25, "delta_max": 0.50, "strategy_type": "spread",
     "signal_type": "MOMENTUM_LONG", "legs": 2, "target_pct": 8, "stoploss_pct": 6,
     "min_capital": 5000, "max_hold_min": 25,
     "leg_config": [
         {"leg": 1, "type": "CE", "action": "BUY", "strike_offset": 0, "delta_target": 0.40},
         {"leg": 2, "type": "CE", "action": "SELL", "strike_offset": 100, "delta_target": 0.20},
     ],
     "rationale": "Bull call spread: buy ATM CE, sell 100pt OTM CE for defined risk",
     "tags": ["nifty", "spread", "bullish", "defined_risk"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "IronCondorWeekly", "underlyings": ["NIFTY"], "option_type": "BOTH",
     "delta_min": 0.10, "delta_max": 0.25, "strategy_type": "iron_condor",
     "signal_type": "THETA_HARVEST", "legs": 4, "target_pct": 5, "stoploss_pct": 10,
     "iv_pref": "HIGH", "min_capital": 40000, "max_hold_min": 60,
     "regime_filter": "RANGING", "vix_min": 14, "vix_max": 25,
     "leg_config": [
         {"leg": 1, "type": "PE", "action": "SELL", "strike_offset": -200, "delta_target": 0.15},
         {"leg": 2, "type": "PE", "action": "BUY",  "strike_offset": -300, "delta_target": 0.08},
         {"leg": 3, "type": "CE", "action": "SELL", "strike_offset": 200,  "delta_target": 0.15},
         {"leg": 4, "type": "CE", "action": "BUY",  "strike_offset": 300,  "delta_target": 0.08},
     ],
     "rationale": "Iron condor on weekly NIFTY: sell 200pt wings, buy 300pt protection, harvest theta",
     "tags": ["nifty", "iron_condor", "theta", "non_directional"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "EventStraddle", "underlyings": ["NIFTY", "BANKNIFTY"], "option_type": "BOTH",
     "delta_min": 0.40, "delta_max": 0.60, "strategy_type": "straddle",
     "signal_type": "EVENT_STRADDLE", "legs": 2, "target_pct": 8, "stoploss_pct": 10,
     "iv_pref": "LOW", "min_capital": 15000, "max_hold_min": 30,
     "rationale": "Buy ATM straddle pre-event when IV is low; ride the vol expansion",
     "tags": ["event", "straddle", "volatility", "long_vol"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "OTMStrangleBuy", "underlyings": ["NIFTY"], "option_type": "BOTH",
     "delta_min": 0.10, "delta_max": 0.20, "otm_min": 3.0, "otm_max": 7.0,
     "strategy_type": "strangle", "signal_type": "IV_EXPANSION_BUY",
     "legs": 2, "target_pct": 15, "stoploss_pct": 10, "iv_pref": "LOW",
     "min_capital": 10000, "max_hold_min": 45,
     "rationale": "Buy OTM strangle when VIX is low; cheap wings for big moves",
     "tags": ["strangle", "cheap", "low_iv", "long_vol"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "BNFButterflyATM", "underlyings": ["BANKNIFTY"], "option_type": "CE",
     "delta_min": 0.15, "delta_max": 0.50, "strategy_type": "butterfly",
     "signal_type": "THETA_HARVEST", "legs": 3, "target_pct": 15, "stoploss_pct": 5,
     "iv_pref": "HIGH", "min_capital": 20000, "max_hold_min": 40,
     "leg_config": [
         {"leg": 1, "type": "CE", "action": "BUY",  "strike_offset": -100, "delta_target": 0.50},
         {"leg": 2, "type": "CE", "action": "SELL", "strike_offset": 0,    "delta_target": 0.35, "qty_multiplier": 2},
         {"leg": 3, "type": "CE", "action": "BUY",  "strike_offset": 100,  "delta_target": 0.20},
     ],
     "rationale": "BankNifty butterfly: low cost, high reward if index stays near ATM",
     "tags": ["banknifty", "butterfly", "defined_risk", "theta"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "CalendarNifty", "underlyings": ["NIFTY"], "option_type": "CE",
     "delta_min": 0.40, "delta_max": 0.55, "strategy_type": "calendar",
     "signal_type": "THETA_HARVEST", "legs": 2, "target_pct": 6, "stoploss_pct": 5,
     "iv_pref": "LOW", "min_capital": 10000, "max_hold_min": 60, "max_dte": 14,
     "prefer_expiry": "calendar",
     "leg_config": [
         {"leg": 1, "type": "CE", "action": "SELL", "strike_offset": 0, "delta_target": 0.45, "expiry": "near"},
         {"leg": 2, "type": "CE", "action": "BUY",  "strike_offset": 0, "delta_target": 0.45, "expiry": "far"},
     ],
     "rationale": "Calendar spread: sell near expiry, buy far expiry same strike for theta",
     "tags": ["nifty", "calendar", "theta", "time_spread"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "JadeLizardBNF", "underlyings": ["BANKNIFTY"], "option_type": "BOTH",
     "delta_min": 0.10, "delta_max": 0.30, "strategy_type": "jade_lizard",
     "signal_type": "THETA_HARVEST", "legs": 3, "target_pct": 4, "stoploss_pct": 8,
     "iv_pref": "HIGH", "min_capital": 30000, "max_hold_min": 60,
     "regime_filter": "RANGING",
     "leg_config": [
         {"leg": 1, "type": "PE", "action": "SELL", "strike_offset": -200, "delta_target": 0.20},
         {"leg": 2, "type": "CE", "action": "SELL", "strike_offset": 200,  "delta_target": 0.25},
         {"leg": 3, "type": "CE", "action": "BUY",  "strike_offset": 300,  "delta_target": 0.15},
     ],
     "rationale": "Jade lizard: short put + short call spread for premium with upside protection",
     "tags": ["banknifty", "jade_lizard", "premium", "credit"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "GammaScalpATM", "underlyings": ["NIFTY", "BANKNIFTY"], "option_type": "BOTH",
     "delta_min": 0.40, "delta_max": 0.55, "strategy_type": "single",
     "signal_type": "GAMMA_SCALP", "target_pct": 3, "stoploss_pct": 4,
     "vol_min": 10000000, "max_hold_min": 8, "trailing_sl": False,
     "rationale": "Buy near-ATM options with high gamma; scalp quick moves, exit fast",
     "tags": ["gamma", "scalp", "atm", "quick"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "PCRReversalCE", "underlyings": ["NIFTY"], "option_type": "CE",
     "delta_min": 0.20, "delta_max": 0.40, "strategy_type": "single",
     "signal_type": "PCR_SIGNAL", "target_pct": 6, "stoploss_pct": 5,
     "max_hold_min": 20, "trend_filter": "AGAINST",
     "rationale": "Buy CE when PCR > 1.3 (oversold puts = bullish reversal signal)",
     "tags": ["pcr", "reversal", "contrarian", "ce"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "FIIFlowMomentum", "underlyings": ["NIFTY", "BANKNIFTY"], "option_type": "BOTH",
     "delta_min": 0.20, "delta_max": 0.40, "strategy_type": "single",
     "signal_type": "FII_FLOW", "target_pct": 7, "stoploss_pct": 6,
     "max_hold_min": 25,
     "rationale": "Trade in direction of FII/DII net flow; strong institutional signal",
     "tags": ["fii", "institutional", "momentum", "flow"]},

    {**OPT_STRATEGY_DEFAULTS,
     "name": "IronButterflyNifty", "underlyings": ["NIFTY"], "option_type": "BOTH",
     "delta_min": 0.10, "delta_max": 0.55, "strategy_type": "iron_butterfly",
     "signal_type": "THETA_HARVEST", "legs": 4, "target_pct": 6, "stoploss_pct": 8,
     "iv_pref": "HIGH", "min_capital": 35000, "max_hold_min": 45,
     "regime_filter": "RANGING",
     "leg_config": [
         {"leg": 1, "type": "CE", "action": "SELL", "strike_offset": 0,    "delta_target": 0.50},
         {"leg": 2, "type": "PE", "action": "SELL", "strike_offset": 0,    "delta_target": 0.50},
         {"leg": 3, "type": "CE", "action": "BUY",  "strike_offset": 200,  "delta_target": 0.15},
         {"leg": 4, "type": "PE", "action": "BUY",  "strike_offset": -200, "delta_target": 0.15},
     ],
     "rationale": "Iron butterfly: sell ATM straddle, buy OTM wings for protection, max theta",
     "tags": ["nifty", "iron_butterfly", "theta", "ranging"]},
]


# ═══════════════════════ MAIN ORCHESTRATOR ═════════════════════════════════════

class OptionsStrategyInventor:
    """Main orchestrator: invent, evolve, manage options strategies."""

    def __init__(self):
        self._invention_count = 0
        self._evolution_count = 0
        self._ensure_seeds()

    def _ensure_seeds(self):
        if opt_strat_db.active_count() == 0:
            log.info("  [OPT_INV] Seeding initial options strategies...")
            for s in SEED_OPTIONS_STRATEGIES:
                s["created_at"] = datetime.now(IST).isoformat()
                opt_strat_db.add(s)
            log.info(f"  [OPT_INV] Seeded {len(SEED_OPTIONS_STRATEGIES)} strategies")

    def active_strategies(self) -> list[dict]:
        return opt_strat_db.active()

    def record_trade(self, strategy_name: str, won: bool, pnl_pct: float,
                     greeks_pnl: dict = None):
        """Record trade result for a strategy."""
        opt_perf.record(strategy_name, won, pnl_pct, greeks_pnl)
        opt_strat_db.record_trade(strategy_name, won, pnl_pct)

    async def maybe_invent(self, market_context: dict, force: bool = False) -> dict | None:
        """Maybe invent a new strategy based on context and cooldowns."""
        existing = opt_strat_db.active()
        if len(existing) >= MAX_STRATS and not force:
            self._run_evolution()
            return None

        trade_summary = self._trade_history_summary()
        result = await opt_llm.invent(market_context, existing, trade_summary)
        if result:
            opt_strat_db.add(result)
            self._invention_count += 1
            # Run evolution after invention
            self._run_evolution()
        return result

    def pick_strategy(self, options: list[dict], spot: float, cash: float,
                      vix: float = 15.0) -> tuple:
        """
        Pick the best (strategy, matching_options) pair from active strategies.
        Returns (strategy_dict, [matching_options]) or (None, []).
        """
        active = opt_strat_db.active()
        if not active:
            return None, []

        best_score = -1
        best_strat = None
        best_opts  = []

        for strat in active:
            # Check capital requirement
            if cash < strat.get("min_capital", 2000):
                continue

            # Check time window
            h = datetime.now(IST).hour
            if h < strat.get("hour_start", 9) or h > strat.get("hour_end", 15):
                continue

            # Check VIX filter
            if not (strat.get("vix_min", 0) <= vix <= strat.get("vix_max", 50)):
                continue

            # Score each option against this strategy
            matching = []
            for opt in options:
                s = scorer.score_option(opt, strat, spot, vix)
                if s > 2.0:
                    matching.append((s, opt))

            if not matching:
                continue

            matching.sort(key=lambda x: -x[0])
            top_score = matching[0][0]

            # Weight by strategy performance
            perf = opt_perf.summary(strat["name"])
            perf_bonus = perf["sharpe"] * 0.5 + perf["wr"] * 2.0
            combined = top_score + perf_bonus

            if combined > best_score:
                best_score = combined
                best_strat = strat
                best_opts  = [m[1] for m in matching[:5]]

        return best_strat, best_opts

    def status(self) -> str:
        active = opt_strat_db.active()
        n_active = len(active)
        total = len(opt_strat_db.all())
        lines = [
            f"[OPT_INV] Options Strategy Inventor",
            f"  Active: {n_active}/{total} | Invented: {self._invention_count} | Evolved: {self._evolution_count}",
        ]
        # Strategy type distribution
        type_counts = defaultdict(int)
        for s in active:
            type_counts[s.get("strategy_type", "single")] += 1
        dist = " | ".join(f"{t}:{c}" for t, c in sorted(type_counts.items()))
        lines.append(f"  Types: {dist}")
        lines.append(opt_llm.status())
        return "\n".join(lines)

    def print_table(self):
        active = opt_strat_db.active()
        print(f"\n{'─'*110}")
        print(f"{'NAME':<24} {'TYPE':<14} {'SIGNAL':<18} {'OPT':<5} {'TGT':>5} {'SL':>4} "
              f"{'N':>4} {'WR':>6} {'SHARPE':>7} {'DD':>6} {'AVG':>7}")
        print(f"{'─'*110}")
        for s in sorted(active, key=lambda x: x["name"]):
            nm = s["name"]
            p  = opt_perf.summary(nm)
            print(
                f"{nm:<24} {s.get('strategy_type','?'):<14} {s.get('signal_type','?'):<18} "
                f"{s.get('option_type','?'):<5} {s.get('target_pct',0):>5.1f} "
                f"{s.get('stoploss_pct',0):>4.1f} {p['n']:>4} {p['wr']:>6.0%} "
                f"{p['sharpe']:>7.2f} {p['max_dd']:>6.2f} {p['avg_pnl']:>7.3f}%"
            )
        print(f"{'─'*110}\n")

    def _run_evolution(self):
        active = opt_strat_db.active()
        actions = opt_evolution.evolve(active)
        if actions:
            self._evolution_count += 1
            log.info("  [OPT_INV] Evolution: " + " | ".join(actions))

    def _trade_history_summary(self) -> str:
        try:
            c = sqlite3.connect(DB)
            c.row_factory = sqlite3.Row
            rows = c.execute("""
                SELECT strategy, COUNT(*) n, SUM(won) wins,
                       ROUND(AVG(pnl_pct),2) avg_pnl
                FROM trades
                WHERE asset = 'option'
                  AND ts >= datetime('now', '-3 days')
                GROUP BY strategy
                ORDER BY avg_pnl DESC
                LIMIT 12
            """).fetchall()
            c.close()
            if not rows:
                return "No recent options trades."
            return "\n".join(
                f"{r['strategy']:24s} n={r['n']} wr={r['wins']/r['n']:.0%} avg={r['avg_pnl']:+.2f}%"
                for r in rows
            )
        except Exception:
            return "DB unavailable."


# ── Module-level singleton ──────────────────────────────────────────────────
options_inventor = OptionsStrategyInventor()


# ═══════════════════════ CLI ═══════════════════════════════════════════════════

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s", datefmt="%H:%M:%S",
                        handlers=[logging.StreamHandler()])

    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"

    if cmd == "status":
        options_inventor.print_table()
        print(options_inventor.status())

    elif cmd == "invent":
        print("Requesting LLM options strategy invention...")
        ctx = {
            "spot_prices": {"NIFTY": 22450, "BANKNIFTY": 48200},
            "day_changes": {"NIFTY": +0.3, "BANKNIFTY": -0.1},
            "india_vix": 14.5,
            "pcr": 1.15,
            "max_pain_nifty": 22500,
            "regime": "RANGING",
            "winning_strats": ["NiftyMomentumCE"],
            "losing_strats":  ["OTMStrangleBuy"],
        }
        result = asyncio.run(options_inventor.maybe_invent(ctx, force=True))
        if result:
            print(f"\n✅ Invented: {result['name']}")
            print(json.dumps(result, indent=2))
        else:
            print("❌ Invention failed (check ANTHROPIC_API_KEY)")

    elif cmd == "evolve":
        print("Running evolution cycle...")
        actions = opt_evolution.evolve(opt_strat_db.active())
        for a in actions:
            print(f"  {a}")
        options_inventor.print_table()

    elif cmd == "reset":
        confirm = input("Delete all invented options strategies? [y/N] ").strip().lower()
        if confirm == "y":
            OPT_STRAT_FILE.unlink(missing_ok=True)
            print("Cleared. Seeds re-load on next run.")

    else:
        print(f"Unknown: {cmd}")
        print("Usage: python3 options_strategy_inventor.py [status|invent|evolve|reset]")
