"""
llm_engine.py — FinanceAGI: Local Phi-3-mini GGUF inference engine
Replaces Qwen/Ollama. Runs fully in-process on CPU. No separate server needed.
"""
import json, logging, os, threading
from typing import Optional, Dict

log = logging.getLogger("agi.llm")

MODEL_PATH = os.getenv("LOCAL_MODEL_PATH", "./models/phi-3-mini-4k-instruct-q4_k_m.gguf")
MODEL_N_CTX = int(os.getenv("MODEL_N_CTX", "2048"))
MODEL_N_THREADS = int(os.getenv("MODEL_N_THREADS", "2"))
MODEL_MAX_TOKENS = int(os.getenv("MODEL_MAX_TOKENS", "512"))

_llm = None
_lock = threading.Lock()


def load_model():
    global _llm
    if _llm is not None:
        return _llm
    with _lock:
        if _llm is not None:
            return _llm
        if not os.path.exists(MODEL_PATH):
            log.warning("Local model not found at %s — LLM disabled", MODEL_PATH)
            return None
        try:
            from llama_cpp import Llama
            log.info("Loading Phi-3-mini from %s ...", MODEL_PATH)
            _llm = Llama(
                model_path=MODEL_PATH,
                n_ctx=MODEL_N_CTX,
                n_threads=MODEL_N_THREADS,
                n_gpu_layers=0,
                verbose=False,
                use_mlock=False,
                use_mmap=True,
            )
            log.info("Phi-3-mini loaded OK")
        except Exception as e:
            log.error("Model load failed: %s", e)
    return _llm


def _extract_json(text: str) -> Optional[Dict]:
    text = text.strip()
    if "{" in text:
        text = text[text.index("{"):]
    try:
        return json.loads(text)
    except Exception:
        pass
    for end in range(len(text), 0, -1):
        if text[end-1] == "}":
            try:
                return json.loads(text[:end])
            except Exception:
                continue
    return None


def infer(prompt: str, max_tokens: int = MODEL_MAX_TOKENS, temperature: float = 0.1) -> Optional[str]:
    """Raw text inference."""
    llm = load_model()
    if not llm:
        return None
    try:
        out = llm(prompt, max_tokens=max_tokens, temperature=temperature,
                  stop=["<|end|>", "<|user|>"], echo=False)
        return out["choices"][0]["text"].strip()
    except Exception as e:
        log.error("Inference error: %s", e)
        return None


def infer_json(prompt: str, max_tokens: int = MODEL_MAX_TOKENS) -> Optional[Dict]:
    """Inference with JSON extraction."""
    raw = infer(prompt, max_tokens=max_tokens)
    if not raw:
        return None
    result = _extract_json(raw)
    if not result:
        log.warning("Non-JSON output: %s", raw[:100])
    return result


def trade_commentary(entry_info: dict) -> str:
    """Quick trade commentary (replaces qwen_commentator)."""
    prompt = f"""<|system|>You are a trading analyst. Reply in 1 sentence.<|end|>
<|user|>Trade: {json.dumps(entry_info, default=str)}. Brief commentary:<|end|>
<|assistant|>"""
    return infer(prompt, max_tokens=80) or "Position opened."


def regime_classify(spot: float, vix: float, pcr: float) -> str:
    """Market regime classification (replaces qwen_regime)."""
    prompt = f"""<|system|>Reply with only one word: BULL, BEAR, or CHOP.<|end|>
<|user|>Nifty spot={spot}, VIX={vix}, PCR={pcr}. Market regime?<|end|>
<|assistant|>"""
    result = infer(prompt, max_tokens=10) or "CHOP"
    for regime in ["BULL", "BEAR", "CHOP"]:
        if regime in result.upper():
            return regime
    return "CHOP"


def daily_param_tune(stats: dict) -> dict:
    """Daily parameter suggestions (replaces qwen_tasks.daily_param_tune)."""
    prompt = f"""<|system|>You are a trading system optimizer. Reply ONLY with JSON.<|end|>
<|user|>Stats: {json.dumps(stats, default=str)}
Suggest adjustments. JSON format: {{"target_pct_adj": 0, "sl_pct_adj": 0, "position_size_adj": 0, "reasoning": ""}}<|end|>
<|assistant|>"""
    return infer_json(prompt) or {}
