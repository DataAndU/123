#!/usr/bin/env python3
"""
alpha_signals.py — FinanceAGI v13.2 Alpha Signals Module
All institutional-grade signals in one place.

Signals provided:
  1.  PCR          — Put-Call Ratio (contrarian direction signal)
  2.  IVP          — IV Percentile vs 52-week history
  3.  GEX          — Gamma Exposure (price pinning / dealer hedging)
  4.  OFI          — Order Flow Imbalance (bid-ask depth pressure)
  5.  VWAP         — Intraday Volume Weighted Average Price
  6.  Volume spike — 3x normal volume = informed trading signal
  7.  FII/DII      — Foreign/Domestic institutional flow from NSE
  8.  Gift Nifty   — Pre-market direction from SGX/Gift Nifty futures
  9.  Net Greeks   — Portfolio-level delta/gamma/theta across all positions
  10. Correlation  — Cross-asset correlation check before entry
  11. Slippage     — Track expected vs actual fill, feed back to NN
  12. Re-entry     — Re-enter if setup still valid after SL hit
  13. Per-segment  — Daily loss limit per segment (NSE/EQ/MCX)
  14. Walk-forward — Recent-data weighted training (newer trades count more)
  15. Post-trade   — Analyse what happened after exit (SL too tight?)
"""

import asyncio, json, logging, math, sqlite3, time
from datetime import datetime, timezone, timedelta, time as dtime
from pathlib import Path
from collections import deque

log = logging.getLogger("agi.alpha")
IST = timezone(timedelta(hours=5, minutes=30))
BASE = Path(__file__).resolve().parent
DB   = str(BASE / "data" / "v10.db")

# ═══════════════════════ 1. PUT-CALL RATIO ═══════════════════════

class PCRSignal:
    """
    PCR > 1.3  → market over-hedged → contrarian BULLISH (buy CE)
    PCR < 0.7  → market complacent  → contrarian BEARISH (buy PE)
    0.7–1.3    → neutral — let other signals decide
    """
    def __init__(self):
        self.pcr   = 1.0
        self.last  = 0.0
        self.hist  = deque(maxlen=20)  # rolling PCR for trend

    def update(self, chain_data: list):
        """Compute PCR from option chain OI data."""
        total_put_oi  = sum(
            item.get("put_options",  {}).get("market_data", {}).get("oi", 0)
            for item in chain_data
        )
        total_call_oi = sum(
            item.get("call_options", {}).get("market_data", {}).get("oi", 0)
            for item in chain_data
        )
        if total_call_oi > 0:
            self.pcr = round(total_put_oi / total_call_oi, 3)
            self.hist.append(self.pcr)
            self.last = time.time()
            log.info(f"  [PCR] {self.pcr:.3f} (put_oi={total_put_oi:,} call_oi={total_call_oi:,})")

    @property
    def signal(self) -> str:
        """Returns BULLISH / BEARISH / NEUTRAL"""
        if self.pcr > 1.3:  return "BULLISH"   # over-hedged → contrarian long
        if self.pcr < 0.7:  return "BEARISH"   # complacent  → contrarian short
        return "NEUTRAL"

    @property
    def bias(self) -> float:
        """Score adjustment: +0.1 for bullish, -0.1 for bearish, 0 neutral."""
        if self.pcr > 1.3:  return +0.10
        if self.pcr > 1.1:  return +0.05
        if self.pcr < 0.7:  return -0.10
        if self.pcr < 0.9:  return -0.05
        return 0.0

    def preferred_type(self) -> str:
        """Which option type PCR prefers."""
        if self.pcr > 1.2: return "CE"
        if self.pcr < 0.8: return "PE"
        return "BOTH"

pcr = PCRSignal()

# ═══════════════════════ 2. IV PERCENTILE ═══════════════════════

class IVPercentile:
    """
    IVP > 80% → IV historically high → sell/avoid buying premium
    IVP < 20% → IV historically low  → great time to buy options cheap
    """
    def __init__(self):
        self.iv_history = deque(maxlen=252)  # ~1 year of daily IV readings
        self.current_iv = 20.0
        self.ivp        = 50.0
        self._db_loaded = False

    def _load_history(self):
        """Load IV history from spots table."""
        if self._db_loaded:
            return
        try:
            c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
            rows = c.execute("SELECT iv FROM spots WHERE iv > 0 ORDER BY ts DESC LIMIT 252").fetchall()
            c.close()
            for r in rows:
                self.iv_history.appendleft(r["iv"])
            self._db_loaded = True
        except Exception:
            pass

    def update(self, current_iv: float):
        self._load_history()
        self.current_iv = current_iv
        if len(self.iv_history) >= 10:
            below = sum(1 for iv in self.iv_history if iv < current_iv)
            self.ivp = round(below / len(self.iv_history) * 100, 1)
        # Save to history
        self.iv_history.append(current_iv)
        try:
            c = sqlite3.connect(DB)
            c.execute("INSERT INTO spots(ts, spot, iv) VALUES(?,?,?)",
                      (datetime.now(IST).isoformat(), 0, current_iv))
            c.commit(); c.close()
        except Exception:
            pass
        log.info(f"  [IVP] {self.ivp:.0f}th percentile (IV={current_iv:.1f})")

    @property
    def is_cheap(self) -> bool:
        """True if options are historically cheap — good to buy."""
        return self.ivp < 30

    @property
    def is_expensive(self) -> bool:
        """True if options are historically expensive — avoid buying."""
        return self.ivp > 75

    @property
    def bias(self) -> float:
        """Adjust NN score: boost when cheap, penalise when expensive."""
        if self.ivp < 20:  return +0.12
        if self.ivp < 30:  return +0.06
        if self.ivp > 80:  return -0.12
        if self.ivp > 70:  return -0.06
        return 0.0

ivp_signal = IVPercentile()

# ═══════════════════════ 3. GAMMA EXPOSURE (GEX) ═══════════════════════

class GEXAnalysis:
    """
    Gamma Exposure: sum of (gamma × OI × lot_size × spot²) across all strikes.
    Positive GEX → dealers are long gamma → they BUY dips, SELL rallies → market mean-reverts
    Negative GEX → dealers are short gamma → they amplify moves → trending/volatile day
    Key strike: highest absolute GEX = price magnet (pin risk)
    """
    def __init__(self):
        self.total_gex  = 0.0
        self.pin_strike = 0.0
        self.gex_by_strike = {}

    def update(self, chain_data: list, spot: float, lot_size: int = 50):
        gex_map = {}
        for item in chain_data:
            strike = item.get("strike_price", 0)
            sp     = item.get("underlying_spot_price", spot)

            call = item.get("call_options", {})
            put  = item.get("put_options",  {})
            call_gk = call.get("option_greeks", {})
            put_gk  = put.get("option_greeks",  {})
            call_mk = call.get("market_data",   {})
            put_mk  = put.get("market_data",    {})

            call_gamma = abs(call_gk.get("gamma", 0))
            put_gamma  = abs(put_gk.get("gamma",  0))
            call_oi    = call_mk.get("oi", 0)
            put_oi     = put_mk.get("oi",  0)

            # GEX: calls add positive, puts subtract (dealers short put gamma → negative)
            gex = (call_gamma * call_oi - put_gamma * put_oi) * lot_size * sp * sp / 1e7
            gex_map[strike] = round(gex, 2)

        self.gex_by_strike = gex_map
        self.total_gex = round(sum(gex_map.values()), 2)

        # Pin strike = highest absolute GEX (price magnet)
        if gex_map:
            self.pin_strike = max(gex_map, key=lambda k: abs(gex_map[k]))

        log.info(f"  [GEX] total={self.total_gex:.1f} pin={self.pin_strike:.0f}")

    @property
    def regime(self) -> str:
        """MEAN_REVERT if positive GEX, TRENDING if negative."""
        return "MEAN_REVERT" if self.total_gex > 0 else "TRENDING"

    def distance_from_pin(self, spot: float) -> float:
        """% distance of current spot from GEX pin strike."""
        if self.pin_strike <= 0: return 999.0
        return abs(spot - self.pin_strike) / max(1, self.pin_strike) * 100

    @property
    def bias(self) -> float:
        """Negative GEX = trending = good for directional option buys."""
        if self.total_gex < -5:  return +0.08   # strong trend environment
        if self.total_gex > 10:  return -0.05   # mean-revert = hard to profit
        return 0.0

gex = GEXAnalysis()

# ═══════════════════════ 4. ORDER FLOW IMBALANCE ═══════════════════════

class OrderFlowImbalance:
    """
    OFI = (bid_qty - ask_qty) / (bid_qty + ask_qty)
    +1.0 = all buyers (bullish pressure)
    -1.0 = all sellers (bearish pressure)
    Uses Upstox /v2/market-quote/depth API.
    """
    def __init__(self):
        self.ofi   = 0.0
        self.last  = 0.0
        self._hist = deque(maxlen=10)

    async def update(self, broker, instrument_key: str):
        try:
            data = await broker._get(f"/v2/market-quote/depth?instrument_key={instrument_key}")
            depth = {}
            for v in data.get("data", {}).values():
                depth = v.get("depth", {})
                break

            bid_qty = sum(b.get("quantity", 0) for b in depth.get("buy",  [])[:5])
            ask_qty = sum(a.get("quantity", 0) for a in depth.get("sell", [])[:5])
            total   = bid_qty + ask_qty

            if total > 0:
                self.ofi = round((bid_qty - ask_qty) / total, 3)
                self._hist.append(self.ofi)
                self.last = time.time()
        except Exception as e:
            log.debug(f"  [OFI] fetch error: {e}")

    @property
    def signal(self) -> str:
        if self.ofi > 0.3:  return "BUY_PRESSURE"
        if self.ofi < -0.3: return "SELL_PRESSURE"
        return "BALANCED"

    @property
    def bias(self) -> float:
        return round(self.ofi * 0.08, 3)  # scale to ±0.08 max

ofi = OrderFlowImbalance()

# ═══════════════════════ 5. VWAP ═══════════════════════

class VWAPTracker:
    """
    Intraday VWAP for Nifty spot.
    Price > VWAP → bullish bias (institutional buyers active above)
    Price < VWAP → bearish bias
    Resets each trading day.
    """
    def __init__(self):
        self.vwap      = 0.0
        self._cum_pv   = 0.0   # cumulative price × volume
        self._cum_vol  = 0.0   # cumulative volume
        self._day      = None

    def update(self, price: float, volume: float):
        today = datetime.now(IST).date()
        if today != self._day:
            self._cum_pv  = 0.0
            self._cum_vol = 0.0
            self._day     = today
        self._cum_pv  += price * volume
        self._cum_vol += volume
        if self._cum_vol > 0:
            self.vwap = round(self._cum_pv / self._cum_vol, 2)

    def position(self, spot: float) -> str:
        """ABOVE / BELOW / AT vwap."""
        if self.vwap <= 0: return "AT"
        pct = (spot - self.vwap) / self.vwap * 100
        if pct >  0.15: return "ABOVE"
        if pct < -0.15: return "BELOW"
        return "AT"

    @property
    def bias(self) -> float:
        return 0.0  # VWAP used for direction filter, not score

vwap = VWAPTracker()

# ═══════════════════════ 6. VOLUME SPIKE DETECTION ═══════════════════════

class VolumeSpikeDetector:
    """
    Compare current option volume to its 5-day average.
    3x+ spike = informed buying/selling = strong signal.
    """
    def __init__(self):
        self._averages = {}  # instrument_key → avg daily volume

    def _load_averages(self):
        """Load historical averages from DB."""
        try:
            c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
            rows = c.execute("""
                SELECT symbol, AVG(entry_volume) avg_vol
                FROM trades WHERE entry_volume > 0
                GROUP BY symbol
            """).fetchall()
            c.close()
            for r in rows:
                self._averages[r["symbol"]] = r["avg_vol"] or 0
        except Exception:
            pass

    def spike_factor(self, symbol: str, current_volume: float) -> float:
        """Return ratio of current volume to average. >3 = spike."""
        avg = self._averages.get(symbol, 0)
        if avg <= 0: return 1.0
        return round(current_volume / avg, 2)

    def is_spike(self, symbol: str, current_volume: float, threshold: float = 3.0) -> bool:
        return self.spike_factor(symbol, current_volume) >= threshold

    def score_boost(self, symbol: str, volume: float) -> float:
        """Boost score proportional to spike factor, capped at +0.15."""
        factor = self.spike_factor(symbol, volume)
        if factor < 2.0: return 0.0
        return min(0.15, (factor - 1.0) * 0.03)

vol_spike = VolumeSpikeDetector()

# ═══════════════════════ 7. FII/DII DATA ═══════════════════════

class FIIDIISignal:
    """
    NSE publishes daily FII/DII cash market activity.
    FII net buyers → institutional money flowing in → bullish
    FII net sellers → smart money leaving → bearish
    Data available after 6 PM on NSE website (free).
    """
    def __init__(self):
        self.fii_net    = 0.0   # FII net buy/sell in crores
        self.dii_net    = 0.0
        self.combined   = 0.0
        self.last_date  = None
        self.signal_str = "NEUTRAL"

    async def refresh(self, broker=None):
        """Fetch FII/DII data from NSE."""
        today = datetime.now(IST).date()
        if self.last_date == today:
            return
        try:
            import httpx
            async with httpx.AsyncClient(timeout=10) as client:
                r = await client.get(
                    "https://www.nseindia.com/api/fiidiiTradeReact",
                    headers={
                        "User-Agent": "Mozilla/5.0",
                        "Accept": "application/json",
                        "Referer": "https://www.nseindia.com/",
                    }
                )
                data = r.json()
                # NSE returns list; find today's entry
                for entry in data:
                    if "FII" in str(entry.get("category", "")):
                        self.fii_net = float(entry.get("netAmount", 0))
                    if "DII" in str(entry.get("category", "")):
                        self.dii_net = float(entry.get("netAmount", 0))
                self.combined  = self.fii_net + self.dii_net
                self.last_date = today
                if self.combined > 500:
                    self.signal_str = "BULLISH"
                elif self.combined < -500:
                    self.signal_str = "BEARISH"
                else:
                    self.signal_str = "NEUTRAL"
                log.info(f"  [FII] FII={self.fii_net:.0f}Cr DII={self.dii_net:.0f}Cr → {self.signal_str}")
        except Exception as e:
            log.debug(f"  [FII] fetch failed: {e}")

    @property
    def bias(self) -> float:
        if self.combined > 2000:   return +0.10
        if self.combined > 500:    return +0.05
        if self.combined < -2000:  return -0.10
        if self.combined < -500:   return -0.05
        return 0.0

    def preferred_type(self) -> str:
        if self.signal_str == "BULLISH": return "CE"
        if self.signal_str == "BEARISH": return "PE"
        return "BOTH"

fii_dii = FIIDIISignal()

# ═══════════════════════ 8. GIFT NIFTY PRE-MARKET ═══════════════════════

class GiftNiftySignal:
    """
    Gift Nifty (SGX successor) trades from 6 AM IST.
    Predicts NSE opening direction before 9:15 AM.
    Gap up > 0.3% → expect bullish open → bias CE
    Gap down > 0.3% → expect bearish open → bias PE
    """
    def __init__(self):
        self.gift_price  = 0.0
        self.prev_close  = 0.0
        self.gap_pct     = 0.0
        self.last_fetch  = 0.0

    async def refresh(self):
        """Fetch Gift Nifty from Upstox or free source."""
        now = datetime.now(IST)
        # Only relevant pre-market (6–9:15 AM) — skip during trading hours
        if not (dtime(6, 0) <= now.time() <= dtime(9, 15)):
            return
        if time.time() - self.last_fetch < 300:  # 5 min cache
            return
        try:
            import httpx
            async with httpx.AsyncClient(timeout=8) as client:
                # NSE publishes pre-open Gift Nifty data
                r = await client.get(
                    "https://www.nseindia.com/api/giftNifty",
                    headers={"User-Agent": "Mozilla/5.0",
                             "Referer": "https://www.nseindia.com/"}
                )
                data = r.json()
                self.gift_price = float(data.get("lastPrice", 0))
                self.prev_close = float(data.get("previousClose", 0))
                if self.prev_close > 0 and self.gift_price > 0:
                    self.gap_pct = round((self.gift_price - self.prev_close) / self.prev_close * 100, 3)
                self.last_fetch = time.time()
                log.info(f"  [GIFT] Gift Nifty={self.gift_price:.0f} gap={self.gap_pct:+.2f}%")
        except Exception as e:
            log.debug(f"  [GIFT] fetch failed: {e}")

    @property
    def signal(self) -> str:
        if self.gap_pct > 0.3:  return "GAP_UP"
        if self.gap_pct < -0.3: return "GAP_DOWN"
        return "FLAT"

    @property
    def bias(self) -> float:
        if self.gap_pct > 0.5:  return +0.10
        if self.gap_pct > 0.3:  return +0.05
        if self.gap_pct < -0.5: return -0.10
        if self.gap_pct < -0.3: return -0.05
        return 0.0

    def preferred_type(self) -> str:
        if self.gap_pct > 0.3:  return "CE"
        if self.gap_pct < -0.3: return "PE"
        return "BOTH"

gift_nifty = GiftNiftySignal()

# ═══════════════════════ 9. PORTFOLIO GREEKS ═══════════════════════

class PortfolioGreeks:
    """
    Track net delta/gamma/theta across ALL open positions simultaneously.
    Prevents accidentally doubling up on correlated risk.
    """
    def __init__(self):
        self.positions = {}  # key → {delta, gamma, theta, qty, asset}

    def add(self, key: str, delta: float, gamma: float, theta: float,
            qty: int, asset: str = "option"):
        self.positions[key] = {
            "delta": delta, "gamma": gamma, "theta": theta,
            "qty": qty, "asset": asset
        }

    def remove(self, key: str):
        self.positions.pop(key, None)

    def clear(self):
        self.positions.clear()

    @property
    def net_delta(self) -> float:
        return round(sum(p["delta"] * p["qty"] for p in self.positions.values()), 3)

    @property
    def net_gamma(self) -> float:
        return round(sum(p["gamma"] * p["qty"] for p in self.positions.values()), 6)

    @property
    def net_theta(self) -> float:
        return round(sum(p["theta"] * p["qty"] for p in self.positions.values()), 3)

    @property
    def is_delta_neutral(self) -> bool:
        return abs(self.net_delta) < 0.1

    def would_overload(self, new_delta: float, new_qty: int,
                       max_net_delta: float = 2.0) -> bool:
        """True if adding this position would make net delta too large."""
        projected = abs(self.net_delta + new_delta * new_qty)
        return projected > max_net_delta

    def summary(self) -> str:
        return (f"Δ={self.net_delta:+.2f} Γ={self.net_gamma:.5f} "
                f"Θ={self.net_theta:+.2f} ({len(self.positions)} pos)")

port_greeks = PortfolioGreeks()

# ═══════════════════════ 10. CORRELATION GUARD ═══════════════════════

# Correlation matrix for Indian markets (approximate, well-known relationships)
# Values: +1 = perfectly correlated, -1 = perfectly inverse
CORRELATIONS = {
    # NSE indices
    ("Nifty 50",   "Nifty Bank"):    0.85,
    ("Nifty 50",   "HDFCBANK"):      0.72,
    ("Nifty 50",   "RELIANCE"):      0.68,
    ("Nifty 50",   "CRUDEOILM"):     0.30,
    ("Nifty Bank", "HDFCBANK"):      0.88,
    ("Nifty Bank", "ICICIBANK"):     0.85,
    ("Nifty Bank", "AXISBANK"):      0.82,
    # Commodities
    ("CRUDEOILM",  "NATGASMINI"):    0.55,
    ("CRUDEOILM",  "Nifty 50"):      0.30,
    ("GOLDPETAL",  "CRUDEOILM"):     0.20,
    ("GOLDPETAL",  "Nifty 50"):     -0.15,   # Gold is inverse hedge
}

def get_correlation(asset1: str, asset2: str) -> float:
    key = (asset1, asset2)
    rev = (asset2, asset1)
    return CORRELATIONS.get(key, CORRELATIONS.get(rev, 0.0))

def correlation_risk(new_underlying: str, open_positions: list) -> float:
    """
    Returns combined correlation score of new trade vs all open positions.
    Score > 0.7 means new trade is highly correlated with existing exposure.
    """
    if not open_positions:
        return 0.0
    scores = [abs(get_correlation(new_underlying, p)) for p in open_positions]
    return round(max(scores) if scores else 0.0, 3)

def should_skip_correlated(new_underlying: str, open_underlyings: list,
                            threshold: float = 0.75) -> bool:
    """True if new trade is too correlated with existing positions."""
    return correlation_risk(new_underlying, open_underlyings) >= threshold

# ═══════════════════════ 11. SLIPPAGE TRACKER ═══════════════════════

class SlippageTracker:
    """
    Track expected (LTP at scan) vs actual fill price.
    Feed real fill prices back to NN training data.
    Also adjusts entry score for instruments with high historical slippage.
    """
    def __init__(self):
        self._slippage = {}    # symbol → list of (expected, actual) tuples
        self._db_loaded = False

    def _load(self):
        if self._db_loaded: return
        try:
            c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
            rows = c.execute("""
                SELECT symbol, entry_price, cost, lot
                FROM trades WHERE entry_price > 0 AND cost > 0 AND lot > 0
                ORDER BY id DESC LIMIT 500
            """).fetchall()
            c.close()
            # We don't have actual fill separately stored, so initialise empty
            self._db_loaded = True
        except Exception:
            pass

    def record(self, symbol: str, expected: float, actual: float):
        """Record one fill. Positive slip = paid more than expected."""
        if symbol not in self._slippage:
            self._slippage[symbol] = deque(maxlen=50)
        slip_pct = (actual - expected) / max(0.01, expected) * 100
        self._slippage[symbol].append(slip_pct)

    def avg_slippage_pct(self, symbol: str) -> float:
        """Average slippage % for this symbol (positive = usually pays more)."""
        hist = self._slippage.get(symbol, [])
        if not hist: return 0.0
        return round(sum(hist) / len(hist), 3)

    def adjusted_cost(self, symbol: str, ltp: float, qty: int) -> float:
        """Estimated real cost including slippage."""
        slip = self.avg_slippage_pct(symbol)
        return round(ltp * (1 + slip / 100) * qty, 2)

    def score_penalty(self, symbol: str) -> float:
        """Penalise entries on instruments with high slippage history."""
        slip = self.avg_slippage_pct(symbol)
        if slip > 2.0:  return -0.10
        if slip > 1.0:  return -0.05
        return 0.0

slippage = SlippageTracker()

# ═══════════════════════ 12. RE-ENTRY LOGIC ═══════════════════════

class ReEntryTracker:
    """
    After a SL exit, track whether the setup is still valid.
    If spot is still in entry range 5–15 minutes later, re-enter.
    Prevents missing continuation moves after brief pullbacks.
    """
    def __init__(self):
        self._last_sl = {}   # symbol → {time, strike, type, spot, strat}

    def record_sl(self, symbol: str, strike: float, opt_type: str,
                  spot: float, strat_name: str):
        """Record a stoploss exit for potential re-entry."""
        self._last_sl[symbol] = {
            "time":   datetime.now(IST),
            "strike": strike,
            "type":   opt_type,
            "spot":   spot,
            "strat":  strat_name,
            "reentry_done": False,
        }

    def should_reenter(self, symbol: str, current_spot: float,
                       current_opts: list) -> dict | None:
        """
        Check if re-entry is warranted.
        Returns candidate option dict or None.
        Rules:
          - SL was hit 5–20 minutes ago (not immediate retry)
          - Current spot within 0.5% of SL entry spot (still same setup)
          - Haven't already re-entered this position
        """
        sl = self._last_sl.get(symbol)
        if not sl or sl["reentry_done"]:
            return None

        elapsed = (datetime.now(IST) - sl["time"]).total_seconds() / 60
        if not (5 <= elapsed <= 20):
            return None

        spot_drift = abs(current_spot - sl["spot"]) / max(1, sl["spot"]) * 100
        if spot_drift > 0.5:
            return None

        # Find matching option in current scan
        for opt in current_opts:
            if (opt.get("strike") == sl["strike"] and
                    opt.get("type") == sl["type"] and
                    opt.get("underlying", "").endswith(symbol)):
                sl["reentry_done"] = True
                log.info(f"  [REENTRY] {symbol} {sl['type']} {sl['strike']} — re-entering after SL ({elapsed:.0f}m ago)")
                return opt
        return None

    def clear(self, symbol: str):
        self._last_sl.pop(symbol, None)

reentry = ReEntryTracker()

# ═══════════════════════ 13. PER-SEGMENT DAILY LOSS LIMITS ═══════════════════════

class SegmentLimits:
    """
    Independent daily loss limits per segment.
    NSE options can blow up equity while MCX is fine.
    Each segment has its own circuit breaker.
    Default: 5% of segment capital per day.
    """
    def __init__(self):
        self._start   = {"options": 0.0, "equity": 0.0, "commodity": 0.0}
        self._current = {"options": 0.0, "equity": 0.0, "commodity": 0.0}
        self._halted  = {"options": False, "equity": False, "commodity": False}
        self._day     = None
        self.limit_pct = 0.05   # 5% of segment capital

    def reset_day(self, options_cash: float, equity_cash: float, commodity_cash: float):
        today = datetime.now(IST).date()
        if today != self._day:
            self._start   = {"options": options_cash, "equity": equity_cash, "commodity": commodity_cash}
            self._current = dict(self._start)
            self._halted  = {"options": False, "equity": False, "commodity": False}
            self._day     = today
            log.info(f"  [LIMITS] Day reset — Opt:₹{options_cash:.0f} EQ:₹{equity_cash:.0f} MCX:₹{commodity_cash:.0f}")

    def update_pnl(self, segment: str, pnl: float):
        if segment in self._current:
            self._current[segment] += pnl

    def is_halted(self, segment: str) -> bool:
        if self._halted.get(segment, False):
            return True
        start = self._start.get(segment, 0)
        cur   = self._current.get(segment, start)
        if start <= 0:
            return False
        loss_pct = (start - cur) / start
        if loss_pct >= self.limit_pct:
            self._halted[segment] = True
            log.warning(f"  [LIMITS] {segment.upper()} HALTED — daily loss {loss_pct:.1%} >= {self.limit_pct:.0%}")
            return True
        return False

    def remaining(self, segment: str) -> float:
        start = self._start.get(segment, 0)
        cur   = self._current.get(segment, start)
        return round(cur - (start * (1 - self.limit_pct)), 2)

seg_limits = SegmentLimits()

# ═══════════════════════ 14. WALK-FORWARD WEIGHTING ═══════════════════════

def get_weighted_training_data(feat_dim: int):
    """
    Walk-forward: recent trades get higher weight in NN training.
    Trades from last 7 days get 3x weight, last 30 days 2x, older 1x.
    This prevents the NN from over-fitting to old market conditions.
    Returns (X, y, weights) or (None, None, None).
    """
    try:
        import numpy as np
        c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
        rows = c.execute("""
            SELECT features_json, won, ts FROM trades
            WHERE features_json IS NOT NULL
            ORDER BY id ASC
        """).fetchall()
        c.close()

        if not rows:
            return None, None, None

        now_ts = datetime.now(IST)
        feats_list, won_list, weights = [], [], []

        for r in rows:
            try:
                f = json.loads(r["features_json"])
                if not isinstance(f, list) or len(f) == 0:
                    continue
                if len(f) < feat_dim:
                    f = f + [0.0] * (feat_dim - len(f))
                feats_list.append(f[:feat_dim])
                won_list.append([r["won"]])

                # Age-based weight
                try:
                    trade_dt = datetime.fromisoformat(r["ts"]).replace(tzinfo=IST)
                    age_days = (now_ts - trade_dt).days
                except Exception:
                    age_days = 999

                if age_days <= 7:    w = 3.0
                elif age_days <= 30: w = 2.0
                else:                w = 1.0
                weights.append(w)
            except Exception:
                continue

        if not feats_list:
            return None, None, None

        import numpy as np
        X = np.array(feats_list, dtype=np.float64)
        y = np.array(won_list,   dtype=np.float64)
        w = np.array(weights,    dtype=np.float64)
        return X, y, w
    except Exception as e:
        log.error(f"  [WF] Training data error: {e}")
        return None, None, None

# ═══════════════════════ 15. POST-TRADE ANALYSIS ═══════════════════════

class PostTradeAnalyser:
    """
    After each exit, analyse what happened next.
    Key insight: if SL was hit and price recovered within 10 minutes,
    the SL was too tight — recommend widening it.

    Stores analysis in DB config for daily_update.py to read.
    """
    def __init__(self):
        self._sl_recoveries = 0
        self._sl_correct    = 0
        self._timeout_missed = 0   # how many timeouts would have hit target
        self._total         = 0

    def record(self, exit_reason: str, exit_price: float,
               pnl_pct: float, peak_pnl: float):
        """Record outcome for analysis."""
        self._total += 1

        if exit_reason == "STOPLOSS":
            # If we were at peak > 1% before SL, it was likely a whipsaw
            if peak_pnl >= 1.0:
                self._sl_recoveries += 1
                log.info(f"  [PTA] SL after peak {peak_pnl:.1f}% — possible whipsaw")
            else:
                self._sl_correct += 1

        elif exit_reason == "TIMEOUT":
            # If timeout exit was at profit, trade had room to grow
            if pnl_pct > 0:
                self._timeout_missed += 1

    def recommendations(self) -> dict:
        """Generate parameter recommendations from post-trade patterns."""
        if self._total < 10:
            return {}

        recs = {}
        sl_whipsaw_rate = self._sl_recoveries / max(1, self._sl_recoveries + self._sl_correct)
        timeout_rate    = self._timeout_missed / max(1, self._total)

        # >40% of SL exits were whipsaws → SL is too tight
        if sl_whipsaw_rate > 0.40:
            recs["stoploss_pct"] = "WIDEN"
            log.info(f"  [PTA] SL whipsaw rate {sl_whipsaw_rate:.0%} → recommend wider SL")

        # >30% of timeout exits were profitable → hold time too short
        if timeout_rate > 0.30:
            recs["max_hold_min"] = "INCREASE"
            log.info(f"  [PTA] Timeout profit rate {timeout_rate:.0%} → recommend longer hold")

        return recs

    def save(self):
        """Save stats to DB for daily_update.py."""
        try:
            c = sqlite3.connect(DB)
            c.execute("INSERT OR REPLACE INTO config(key,val) VALUES(?,?)",
                      ("post_trade_analysis", json.dumps({
                          "total": self._total,
                          "sl_whipsaw_rate": round(self._sl_recoveries / max(1, self._total), 3),
                          "timeout_profit_rate": round(self._timeout_missed / max(1, self._total), 3),
                          "recommendations": self.recommendations(),
                      })))
            c.commit(); c.close()
        except Exception:
            pass

pta = PostTradeAnalyser()

# ═══════════════════════ COMBINED ALPHA SCORE ═══════════════════════

def compute_alpha_score(opt: dict, open_underlyings: list = None) -> float:
    """
    Combine all alpha signals into a single score adjustment.
    Returns a float to ADD to NN probability score.
    Range: typically -0.30 to +0.30
    """
    score = 0.0
    opt_type    = opt.get("type", "CE")
    underlying  = opt.get("underlying", "")
    symbol      = opt.get("symbol", underlying)
    volume      = opt.get("volume", 0)
    iv          = opt.get("iv", 20)

    # 1. PCR bias
    score += pcr.bias
    # Penalise if PCR prefers opposite type
    if pcr.preferred_type() not in (opt_type, "BOTH"):
        score -= 0.05

    # 2. IVP bias
    score += ivp_signal.bias
    ivp_signal.update(iv)  # update with current IV

    # 3. GEX bias
    score += gex.bias

    # 4. OFI bias
    score += ofi.bias

    # 5. VWAP — filter only, no score change here (handled in main loop)

    # 6. Volume spike boost
    score += vol_spike.score_boost(symbol, volume)

    # 7. FII/DII bias
    score += fii_dii.bias
    if fii_dii.preferred_type() not in (opt_type, "BOTH"):
        score -= 0.04

    # 8. Gift Nifty bias (only pre-market or first 30 min)
    now_t = datetime.now(IST).time()
    if now_t <= dtime(9, 45):
        score += gift_nifty.bias
        if gift_nifty.preferred_type() not in (opt_type, "BOTH"):
            score -= 0.04

    # 9. Portfolio Greeks — penalise if would create extreme net delta
    delta = opt.get("delta", 0.3)
    qty   = opt.get("lot_size", 50)
    if port_greeks.would_overload(delta, qty, max_net_delta=3.0):
        score -= 0.15
        log.info(f"  [ALPHA] Portfolio delta overload — penalising {symbol}")

    # 10. Correlation guard
    if open_underlyings:
        corr = correlation_risk(underlying, open_underlyings)
        if corr >= 0.75:
            score -= 0.12
            log.info(f"  [ALPHA] High correlation {corr:.2f} — penalising {symbol}")
        elif corr >= 0.50:
            score -= 0.06

    # 11. Slippage penalty
    score += slippage.score_penalty(symbol)

    return round(score, 4)
