#!/usr/bin/env python3
"""
FinanceAGI v12.0 - Local Command Center
http://localhost:8000

Changes in v12:
 1. Capital allocation per segment (equity/options/commodity) when mode=all/both
 2. Commodity included in asset mode selector
 3. MCX open/close status shown like NSE
 4. Agent logs tab replaced with Help (PM2 & system commands)
 5. Live mode capital prompt per segment
 6. Paper mode capital + allocation input
 7. Settings persisted to .env
"""
import json, os, sqlite3, pickle, sys, signal, subprocess, time
import urllib.parse, http.client, ssl
from datetime import datetime, timezone, timedelta
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
import threading

BASE = Path(__file__).resolve().parent
IST = timezone(timedelta(hours=5, minutes=30))

ENV = {}
_env = BASE / ".env"
if _env.exists():
    for ln in _env.read_text().splitlines():
        ln = ln.strip()
        if ln and not ln.startswith("#") and "=" in ln:
            k, v = ln.split("=", 1)
            ENV[k.strip()] = v.strip()
            os.environ.setdefault(k.strip(), v.strip())

DB  = str(BASE / "data" / "v10.db")
NN  = str(BASE / "data" / "nn.pkl") if os.path.exists(str(BASE / "data" / "nn.pkl")) else str(BASE / "data" / "v10_nn.pkl")
RL  = str(BASE / "data" / "rl.pkl") if os.path.exists(str(BASE / "data" / "rl.pkl")) else str(BASE / "data" / "v10_rl.pkl")
ST  = str(BASE / "data" / "strats.json") if os.path.exists(str(BASE / "data" / "strats.json")) else str(BASE / "data" / "v10_strats.json")

API_KEY    = ENV.get("UPSTOX_API_KEY", "")
API_SECRET = ENV.get("UPSTOX_API_SECRET", "")
REDIRECT   = ENV.get("UPSTOX_REDIRECT_URI", "http://localhost:8000/callback")

agent_process  = None
agent_log_path = str(BASE / "logs" / "agent.log")

# Capital allocation per segment (used when mode=all or both)
SETTINGS = {
    "paper_trading": ENV.get("PAPER_TRADING", "true").lower() == "true",
    "capital":       float(ENV.get("CAPITAL", "10000")),
    "asset_mode":    ENV.get("ASSET_MODE", "both"),  # options|equity|commodity|both|all
    # per-segment allocations (₹), 0 = use full capital
    "alloc_equity":    float(ENV.get("ALLOC_EQUITY",    "0")),
    "alloc_options":   float(ENV.get("ALLOC_OPTIONS",   "0")),
    "alloc_commodity": float(ENV.get("ALLOC_COMMODITY", "0")),
}

BROKER_CACHE = {"connected": False, "user_name": "", "user_id": "", "cash": 0, "margin": 0, "last_check": 0}


def _db():
    os.makedirs(BASE / "data", exist_ok=True)
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    c.execute("CREATE TABLE IF NOT EXISTS auth(id INTEGER PRIMARY KEY,provider TEXT,token TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS daily_balance(date TEXT PRIMARY KEY,opening REAL DEFAULT 0,closing REAL DEFAULT 0)")
    return c

def get_token():
    try:
        c = _db(); r = c.execute("SELECT token FROM auth WHERE provider='upstox' ORDER BY id DESC LIMIT 1").fetchone(); c.close()
        return r[0] if r else ""
    except Exception:  # BUG-EXCEPT-4 FIX: was bare except
        return ""

def save_token(token, user_name="", user_id=""):
    c = _db()
    c.execute("DELETE FROM auth WHERE provider='upstox'")
    c.execute("INSERT INTO auth(provider,token) VALUES('upstox',?)", (token,))
    c.commit(); c.close()
    BROKER_CACHE.update({"connected": True, "user_name": user_name, "user_id": user_id, "last_check": time.time()})
    lines = []; found = False
    if _env.exists():
        for ln in _env.read_text().splitlines():
            if ln.startswith("UPSTOX_ACCESS_TOKEN"): lines.append(f"UPSTOX_ACCESS_TOKEN={token}"); found = True
            else: lines.append(ln)
    if not found: lines.append(f"UPSTOX_ACCESS_TOKEN={token}")
    _env.write_text("\n".join(lines) + "\n")

def _upstox_get(path):
    token = get_token()
    if not token: return None
    ctx = ssl.create_default_context()
    conn = http.client.HTTPSConnection("api.upstox.com", timeout=10, context=ctx)
    conn.request("GET", path, headers={"Accept":"application/json","Authorization":f"Bearer {token}",
        "User-Agent":"Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36"})
    resp = conn.getresponse(); raw = resp.read().decode(); conn.close()
    return json.loads(raw) if resp.status == 200 else None

def exchange_code(code):
    print(f"[AUTH] Exchanging code: {code[:10]}...")
    body = urllib.parse.urlencode({"code":code,"client_id":API_KEY,"client_secret":API_SECRET,
                                   "redirect_uri":REDIRECT,"grant_type":"authorization_code"})
    try:
        ctx = ssl.create_default_context()
        conn = http.client.HTTPSConnection("api.upstox.com", timeout=15, context=ctx)
        conn.request("POST", "/v2/login/authorization/token", body=body, headers={
            "Content-Type":"application/x-www-form-urlencoded","Accept":"application/json",
            "User-Agent":"Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36"})
        resp = conn.getresponse(); raw = resp.read().decode(); conn.close()
        if resp.status == 200:
            result = json.loads(raw)
            if "access_token" in result:
                save_token(result["access_token"], result.get("user_name",""), result.get("user_id",""))
                check_broker(force=True)
                return {"success":True,"user":result.get("user_name",""),"user_id":result.get("user_id","")}
            return {"success":False,"error":result}
        return {"success":False,"error":f"HTTP {resp.status}: {raw[:200]}"}
    except Exception as e:
        return {"success":False,"error":str(e)}

def check_broker(force=False):
    now = time.time()
    if not force and BROKER_CACHE["connected"] and (now - BROKER_CACHE["last_check"]) < 30:
        return BROKER_CACHE
    token = get_token()
    if not token:
        BROKER_CACHE.update({"connected":False,"user_name":"","cash":0}); return BROKER_CACHE
    try:
        profile = _upstox_get("/v2/user/profile")
        if profile and profile.get("status") == "success":
            BROKER_CACHE.update({"connected":True,
                "user_name":profile.get("data",{}).get("user_name",""),
                "user_id":profile.get("data",{}).get("user_id","")})
        else:
            BROKER_CACHE.update({"connected":False,"user_name":"","last_check":now}); return BROKER_CACHE
        funds = _upstox_get("/v2/user/get-funds-and-margin")
        if funds and funds.get("data"):
            eq = funds["data"].get("equity",{})
            BROKER_CACHE["cash"]   = eq.get("available_margin", 0)
            BROKER_CACHE["margin"] = eq.get("used_margin", 0)
        BROKER_CACHE["last_check"] = now
    except Exception as e:
        print(f"[BROKER] {e}"); BROKER_CACHE["connected"] = False
    return BROKER_CACHE

def write_settings_to_env():
    if not _env.exists(): return
    lines = _env.read_text().splitlines()
    updates = {
        "PAPER_TRADING":    str(SETTINGS["paper_trading"]).lower(),
        "CAPITAL":          str(SETTINGS["capital"]),
        "ASSET_MODE":       SETTINGS["asset_mode"],
        "ALLOC_EQUITY":     str(SETTINGS["alloc_equity"]),
        "ALLOC_OPTIONS":    str(SETTINGS["alloc_options"]),
        "ALLOC_COMMODITY":  str(SETTINGS["alloc_commodity"]),
    }
    new_lines = []; written = set()
    for ln in lines:
        key = ln.split("=",1)[0].strip() if "=" in ln and not ln.startswith("#") else ""
        if key in updates: new_lines.append(f"{key}={updates[key]}"); written.add(key)
        else: new_lines.append(ln)
    for k,v in updates.items():
        if k not in written: new_lines.append(f"{k}={v}")
    _env.write_text("\n".join(new_lines) + "\n")

def _agent_already_running_externally() -> bool:
    """
    BUG-R fix: detect if agent.py is already running via PM2 or another process
    outside of this dashboard's subprocess handle.  If so, refuse to spawn another.
    """
    try:
        r = subprocess.run(["pgrep", "-f", "agent.py"], capture_output=True, text=True)
        pids = [p.strip() for p in r.stdout.strip().splitlines() if p.strip()]
        own_pid = str(agent_process.pid) if agent_process and agent_process.poll() is None else None
        # Any PID that is NOT our own child is an external instance
        external = [p for p in pids if p != own_pid]
        return len(external) > 0
    except Exception:
        return False

def start_agent():
    global agent_process
    if agent_process and agent_process.poll() is None:
        return {"running":True,"pid":agent_process.pid,"msg":"Already running (dashboard process)"}
    # BUG-R fix: refuse to start a second agent if one is already running (e.g. via PM2)
    if _agent_already_running_externally():
        return {"running":True,"pid":None,
                "msg":"⚠ Agent already running externally (PM2?). Stop it first to avoid duplicate orders."}
    os.makedirs(BASE/"logs", exist_ok=True)
    write_settings_to_env()
    agent_env = os.environ.copy()
    agent_env.update({
        "PAPER_TRADING":   str(SETTINGS["paper_trading"]).lower(),
        "CAPITAL":         str(SETTINGS["capital"]),
        "TRADING_ENABLED": "true",
        "ASSET_MODE":      SETTINGS["asset_mode"],
        "ALLOC_EQUITY":    str(SETTINGS["alloc_equity"]),
        "ALLOC_OPTIONS":   str(SETTINGS["alloc_options"]),
        "ALLOC_COMMODITY": str(SETTINGS["alloc_commodity"]),
        "COMMODITY_ENABLED": "true" if SETTINGS["asset_mode"] in ("commodity","both","all") else "false",
    })
    log_file = open(agent_log_path, "a")
    agent_process = subprocess.Popen([sys.executable, str(BASE/"agent.py")], cwd=str(BASE),
        stdout=log_file, stderr=subprocess.STDOUT, env=agent_env)
    mode = "PAPER" if SETTINGS["paper_trading"] else "LIVE"
    return {"running":True,"pid":agent_process.pid,"msg":f"Started {mode} | {SETTINGS['asset_mode'].upper()} | ₹{SETTINGS['capital']:,.0f}"}

def stop_agent():
    global agent_process
    if agent_process and agent_process.poll() is None:
        agent_process.terminate()
        try: agent_process.wait(timeout=5)
        except Exception: agent_process.kill()
        agent_process = None
    try: os.system("pkill -f agent.py 2>/dev/null")
    except Exception: pass
    agent_process = None
    return {"running":False,"msg":"Agent stopped"}

def agent_status():
    global agent_process
    running = agent_process is not None and agent_process.poll() is None
    if not running:
        try:
            r = subprocess.run(["pgrep","-f","agent.py"], capture_output=True, text=True)
            if r.stdout.strip(): running = True
        except Exception: pass
    return {"running":running, "pid":agent_process.pid if agent_process and agent_process.poll() is None else None}

def market_status():
    now = datetime.now(IST); wd = now.weekday()
    if wd >= 5:
        nxt = now + timedelta(days=(7-wd))
        return {"open":False,"label":"CLOSED","reason":"Weekend","next":f"Mon {nxt.strftime('%d %b')} 9:15 AM"}
    t = now.hour*60+now.minute
    if t < 9*60:   return {"open":False,"label":"PRE-MARKET","reason":"Opens at 9:15 AM","next":"9:15 AM today"}
    if t < 9*60+15: return {"open":False,"label":"PRE-OPEN","reason":"Pre-open session","next":"9:15 AM today"}
    if t <= 15*60+30:
        ml = 15*60+30-t; h,m = divmod(ml,60)
        return {"open":True,"label":"OPEN","reason":f"{h}h {m}m left","next":"Closes 3:30 PM"}
    nxt = "Mon 9:15 AM" if wd==4 else "Tomorrow 9:15 AM"
    return {"open":False,"label":"CLOSED","reason":"Market closed","next":nxt}

def mcx_status():
    """MCX is open 9:00 AM - 11:30 PM IST Mon-Fri. Agri: 9:00 AM - 5:00 PM."""
    now = datetime.now(IST); wd = now.weekday()
    if wd >= 5:
        return {"open":False,"label":"CLOSED","reason":"Weekend"}
    t = now.hour*60+now.minute
    open_t  = 9*60
    close_t = 23*60+30
    if t < open_t:  return {"open":False,"label":"CLOSED","reason":f"Opens at 9:00 AM"}
    if t <= close_t:
        ml = close_t-t; h,m = divmod(ml,60)
        session = "US Session" if t >= 18*60+30 else "Indian Session"
        return {"open":True,"label":"OPEN","reason":f"{session} | {h}h {m}m left"}
    return {"open":False,"label":"CLOSED","reason":"Closed (reopens 9 AM)"}

def get_data():
    d = {"ts": datetime.now(IST).isoformat()}
    d["market"] = market_status()
    d["mcx"]    = mcx_status()
    broker = check_broker()
    d["broker"] = broker; d["authenticated"] = broker["connected"]
    d["paper_trading"]    = SETTINGS["paper_trading"]
    d["capital"]          = SETTINGS["capital"]
    d["asset_mode"]       = SETTINGS["asset_mode"]
    d["alloc_equity"]     = SETTINGS["alloc_equity"]
    d["alloc_options"]    = SETTINGS["alloc_options"]
    d["alloc_commodity"]  = SETTINGS["alloc_commodity"]
    d["agent"] = agent_status()
    try:
        c = _db()
        r = c.execute("SELECT COUNT(*) t, COALESCE(SUM(won),0) w, COALESCE(SUM(pnl),0) p, COALESCE(SUM(charges),0) ch, COALESCE(SUM(net_pnl),0) np FROM trades").fetchone()
        d["stats"] = {"total":r["t"],"wins":int(r["w"]),"wr":round(r["w"]/max(1,r["t"])*100,1),
                      "pnl":round(r["p"],2),"charges":round(r["ch"] or 0,2),"net_pnl":round(r["np"] or 0,2)}
        today = datetime.now(IST).strftime("%Y-%m-%d")
        td = c.execute("SELECT COUNT(*) t, COALESCE(SUM(won),0) w, COALESCE(SUM(pnl),0) p, COALESCE(SUM(charges),0) ch, COALESCE(SUM(net_pnl),0) np FROM trades WHERE ts LIKE ?", (today+"%",)).fetchone()
        d["today"] = {"trades":td["t"],"wins":int(td["w"]),"gross":round(td["p"] or 0,2),"charges":round(td["ch"] or 0,2),"net":round(td["np"] or 0,2)}
        bal = c.execute("SELECT opening, closing FROM daily_balance WHERE date=?", (today,)).fetchone()
        d["balance"] = {"opening":round(bal["opening"],2),"closing":round(bal["closing"],2)} if bal else {"opening":0,"closing":0}
        if broker["connected"] and broker["cash"] > 0:
            cash = broker["cash"]
            existing = c.execute("SELECT opening FROM daily_balance WHERE date=?", (today,)).fetchone()
            if existing: c.execute("UPDATE daily_balance SET closing=? WHERE date=?", (cash,today))
            else: c.execute("INSERT OR REPLACE INTO daily_balance(date,opening,closing) VALUES(?,?,?)", (today,cash,cash))
            c.commit()
            d["balance"]["closing"] = cash
            d["balance"]["opening"] = existing["opening"] if existing else cash
        trades = c.execute("SELECT * FROM trades ORDER BY id DESC LIMIT 20").fetchall()
        d["trades"] = [dict(t) for t in trades]
        strats = c.execute("SELECT strategy, COUNT(*) t, SUM(won) w, SUM(pnl) p, AVG(pnl_pct) a, COALESCE(SUM(charges),0) ch, COALESCE(SUM(net_pnl),0) np FROM trades GROUP BY strategy").fetchall()
        d["strat_perf"] = {s["strategy"]:{"n":s["t"],"w":s["w"] or 0,"p":round(s["p"] or 0,2),"a":round(s["a"] or 0,2),"ch":round(s["ch"] or 0,2),"np":round(s["np"] or 0,2)} for s in strats}
        d["avg_win"]  = round(c.execute("SELECT AVG(pnl_pct) a FROM trades WHERE won=1").fetchone()["a"] or 0, 2)
        d["avg_loss"] = round(c.execute("SELECT AVG(pnl_pct) a FROM trades WHERE won=0").fetchone()["a"] or 0, 2)
        d["news_on"]  = bool(ENV.get("NEWS_API_KEY",""))
        c.close()
    except Exception as e:
        d["stats"] = {"total":0,"wins":0,"wr":0,"pnl":0,"charges":0,"net_pnl":0}
        d["today"] = {"trades":0,"wins":0,"gross":0,"charges":0,"net":0}
        d["balance"] = {"opening":0,"closing":0}
        d["trades"] = []; d["strat_perf"] = {}; d["avg_win"] = 0; d["avg_loss"] = 0; d["news_on"] = False
    if os.path.exists(ST):
        try:
            sd = json.load(open(ST))
            d["strategies"] = sd.get("alive",[])
            d["graveyard"]  = len(sd.get("dead",[]))
            d["dead_list"]  = sd.get("dead",[])[-5:]
        except Exception:  # BUG-EXCEPT-4 FIX: was bare except
            d["strategies"]=[]; d["graveyard"]=0; d["dead_list"]=[]
    else: d["strategies"]=[]; d["graveyard"]=0; d["dead_list"]=[]
    if os.path.exists(NN):
        try:
            import numpy as np
            pk = pickle.load(open(NN,"rb"))
            dims = pk.get("dims",[])
            params = sum(w.size+b.size for w,b in zip(pk["W"],pk["b"]))
            imp = np.abs(pk["W"][0]).sum(axis=1); imp = imp/imp.sum()*100
            # BUG #4 FIX: names aligned with agent.py FN list (FEAT_DIM=20)
            names = [
                "delta","gamma","theta","iv","log_vol","log_oi","otm","spot_mv",
                "h_sin","h_cos","prem","cost","dte_norm",
                "iv_rank","vol_oi_ratio","gamma_dollar","theta_pct","moneyness",
                "log_prem","spread_ratio",  # Bug4 fix: was incorrectly labelled pad
            ]
            # Trim/pad names to match actual W[0] rows
            n_feats = len(imp)
            names = (names + [f"feat_{i}" for i in range(n_feats)])[:n_feats]
            d["nn"] = {"dims":dims,"params":params,"samples":pk.get("cnt",0),"importance":dict(zip(names,[round(float(v),1) for v in imp]))}
        except Exception:  # BUG-EXCEPT-4 FIX: was bare except
            d["nn"]={}
    else: d["nn"]={}
    if os.path.exists(RL):
        try:
            pk = pickle.load(open(RL,"rb"))
            d["rl"] = {"episodes":pk.get("ep",0),"reward":round(pk.get("r",0),1),"states":len(pk.get("Q",{}))}
        except Exception:  # BUG-EXCEPT-4 FIX: was bare except
            d["rl"]={}
    else: d["rl"]={}
    return d

# ═══════════════════════════════════════════════════════════════
#  HTML DASHBOARD  v12.0
# ═══════════════════════════════════════════════════════════════

HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>FinanceAGI v12.0</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800&family=Space+Grotesk:wght@400;500;600;700&display=swap');
:root{
  --bg:#060a08;--surface:rgba(10,20,14,0.85);--border:rgba(0,255,120,0.07);
  --bh:rgba(0,255,120,0.14);--g:#00ff88;--gd:#00cc66;--r:#ff3355;--a:#ffbb33;
  --bl:#33aaff;--p:#aa88ff;--t:#88aa88;--td:#4a6a4a;--tb:#d0f0d0;
  --card-bg:linear-gradient(135deg,rgba(8,20,12,0.9),rgba(5,14,8,0.95));
}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'JetBrains Mono',monospace;background:var(--bg);color:var(--t);min-height:100vh;
  background-image:radial-gradient(ellipse at 15% 50%,rgba(0,255,120,0.02) 0%,transparent 60%),
  radial-gradient(ellipse at 85% 20%,rgba(0,180,255,0.01) 0%,transparent 50%)}
::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:#1a3a1a;border-radius:2px}
.hdr{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;
  background:rgba(6,10,8,0.97);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:100;
  flex-wrap:wrap;gap:8px;backdrop-filter:blur(12px)}
.logo{display:flex;align-items:baseline;gap:6px}
h1{font-family:'Space Grotesk',sans-serif;color:var(--g);font-size:17px;font-weight:800;letter-spacing:-0.5px}
h1 span{color:var(--tb);font-weight:400}
.version{color:var(--td);font-size:8px;letter-spacing:2px;text-transform:uppercase}
.broker-banner{padding:10px 16px;display:flex;align-items:center;gap:10px;font-size:10px;
  border-bottom:1px solid var(--border);flex-wrap:wrap}
.broker-banner.ok{background:rgba(0,255,120,0.04)}
.broker-banner.off{background:rgba(255,51,85,0.04)}
.broker-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
.broker-dot.on{background:var(--g);box-shadow:0 0 8px rgba(0,255,120,0.5);animation:pulse 2s ease infinite}
.broker-dot.off{background:var(--r);box-shadow:0 0 8px rgba(255,51,85,0.3)}
@keyframes pulse{0%,100%{box-shadow:0 0 4px rgba(0,255,120,0.3)}50%{box-shadow:0 0 12px rgba(0,255,120,0.6)}}
.broker-info{flex:1;color:var(--tb);font-weight:500}
.broker-cash{color:var(--g);font-weight:700;font-size:12px}
.btn{padding:6px 14px;border-radius:6px;font-family:'JetBrains Mono',monospace;font-size:9px;
  cursor:pointer;border:1px solid;font-weight:600;transition:all .15s ease;letter-spacing:0.5px}
.btn:active{transform:scale(0.97)}
.btn-g{background:rgba(0,255,120,0.08);border-color:rgba(0,255,120,0.25);color:var(--g)}
.btn-g:hover{background:rgba(0,255,120,0.16);border-color:rgba(0,255,120,0.4)}
.btn-r{background:rgba(255,51,85,0.08);border-color:rgba(255,51,85,0.25);color:var(--r)}
.btn-r:hover{background:rgba(255,51,85,0.16)}
.btn-b{background:rgba(51,170,255,0.08);border-color:rgba(51,170,255,0.25);color:var(--bl)}
.btn-b:hover{background:rgba(51,170,255,0.16)}
.btn-lg{padding:10px 20px;font-size:11px;border-radius:8px}
.btn:disabled{opacity:0.3;cursor:not-allowed}
.toggle-wrap{display:flex;align-items:center;gap:8px;font-size:9px}
.toggle-label{color:var(--td);font-weight:500;text-transform:uppercase;letter-spacing:1px}
.toggle-label.active{color:var(--tb)}
.toggle{width:40px;height:20px;background:rgba(255,51,85,0.2);border:1px solid rgba(255,51,85,0.3);
  border-radius:10px;cursor:pointer;position:relative;transition:all .2s ease;flex-shrink:0}
.toggle.paper{background:rgba(0,255,120,0.15);border-color:rgba(0,255,120,0.3)}
.toggle-knob{width:16px;height:16px;border-radius:50%;position:absolute;top:1px;transition:all .2s ease}
.toggle.paper .toggle-knob{left:1px;background:var(--g)}
.toggle:not(.paper) .toggle-knob{left:21px;background:var(--r)}
.agent-panel{padding:14px 16px;background:var(--surface);border-bottom:1px solid var(--border);
  display:flex;gap:14px;align-items:center;flex-wrap:wrap}
.cap-input{display:flex;align-items:center;gap:6px}
.cap-input label{font-size:8px;color:var(--td);text-transform:uppercase;letter-spacing:1.5px}
.cap-input input{background:rgba(0,255,120,0.04);border:1px solid var(--border);border-radius:6px;
  padding:6px 10px;color:var(--tb);font-family:'JetBrains Mono',monospace;font-size:11px;width:110px;
  outline:none;transition:border-color .2s}
.cap-input input:focus{border-color:rgba(0,255,120,0.3)}
.cap-input .rupee{color:var(--g);font-size:12px;font-weight:700}
.status-bar{display:flex;gap:14px;padding:8px 16px;background:rgba(6,10,8,0.7);
  border-bottom:1px solid var(--border);font-size:9px;flex-wrap:wrap;align-items:center}
.si{display:flex;align-items:center;gap:4px}
.si .lbl{color:var(--td)}.si .val{color:var(--tb);font-weight:600}
.main{padding:14px 16px;max-width:1200px;margin:0 auto}
.grid{display:grid;gap:10px;margin-bottom:12px}
.g2{grid-template-columns:1fr 1fr}.g3{grid-template-columns:1fr 1fr 1fr}.g4{grid-template-columns:repeat(4,1fr)}
.card{background:var(--card-bg);border:1px solid var(--border);border-radius:10px;padding:14px;transition:border-color .2s}
.card:hover{border-color:var(--bh)}
.card h3{font-family:'Space Grotesk',sans-serif;font-size:11px;color:#a8d0a8;margin-bottom:10px;font-weight:600}
.badge{display:inline-block;padding:2px 7px;border-radius:5px;font-size:7px;font-weight:700;letter-spacing:0.5px}
.bg{background:rgba(0,255,120,0.1);color:var(--g)}.br{background:rgba(255,51,85,0.1);color:var(--r)}
.bp{background:rgba(170,136,255,0.1);color:var(--p)}.ba{background:rgba(255,187,51,0.1);color:var(--a)}
.bbl{background:rgba(51,170,255,0.1);color:var(--bl)}
.stat-l{font-size:7px;color:var(--td);text-transform:uppercase;letter-spacing:2px;margin-bottom:5px}
.stat-v{font-family:'Space Grotesk',sans-serif;font-size:20px;font-weight:700;color:var(--tb)}
.stat-s{font-size:8px;margin-top:3px;color:var(--td)}
.green{color:var(--g)}.red{color:var(--r)}.amber{color:var(--a)}.blue{color:var(--bl)}
table{width:100%;border-collapse:collapse;font-size:9px}
th{text-align:left;padding:6px;border-bottom:1px solid rgba(0,255,120,0.06);color:var(--td);font-size:7px;text-transform:uppercase;letter-spacing:1.5px}
td{padding:6px;border-bottom:1px solid rgba(0,255,120,0.02)}
.strat{padding:10px;margin-bottom:6px;border-radius:7px;background:rgba(0,255,120,0.015);border:1px solid var(--border)}
.imp-row{display:flex;align-items:center;gap:6px;margin-bottom:4px;font-size:8px}
.imp-bar{flex:1;height:8px;background:rgba(0,255,120,0.04);border-radius:4px;overflow:hidden}
.imp-fill{height:100%;border-radius:4px;background:linear-gradient(90deg,var(--gd),var(--g));opacity:0.8}
.tabs{display:flex;gap:2px;margin-bottom:12px;background:rgba(0,255,120,0.02);border-radius:8px;padding:3px;flex-wrap:wrap}
.tbtn{background:none;border:none;color:var(--td);padding:7px 12px;border-radius:6px;
  font-family:'JetBrains Mono',monospace;font-size:9px;cursor:pointer;transition:all .15s}
.tbtn.on{background:rgba(0,255,120,0.08);color:var(--g);font-weight:600}
.tbtn:hover:not(.on){color:var(--t)}
.tp{display:none}.tp.on{display:block}
.toast{position:fixed;top:60px;right:16px;padding:10px 18px;border-radius:8px;font-size:10px;
  z-index:999;opacity:0;transform:translateY(-8px);transition:all .2s ease;pointer-events:none}
.toast.show{opacity:1;transform:translateY(0);pointer-events:auto}
.toast.ok{background:rgba(0,255,120,0.12);border:1px solid rgba(0,255,120,0.3);color:var(--g)}
.toast.err{background:rgba(255,51,85,0.12);border:1px solid rgba(255,51,85,0.3);color:var(--r)}
/* MODAL */
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,0.75);z-index:200;display:none;
  align-items:center;justify-content:center;backdrop-filter:blur(4px)}
.modal-bg.show{display:flex}
.modal{background:linear-gradient(135deg,#0a160e,#060d08);border:1px solid rgba(0,255,120,0.15);
  border-radius:14px;padding:24px;width:90%;max-width:440px}
.modal h2{font-family:'Space Grotesk',sans-serif;color:var(--g);font-size:16px;margin-bottom:6px;text-align:center}
.modal p{color:var(--td);font-size:10px;margin-bottom:16px;text-align:center}
.modal .big-input{background:rgba(0,255,120,0.04);border:1px solid rgba(0,255,120,0.15);
  border-radius:10px;padding:12px;color:var(--g);font-family:'Space Grotesk',sans-serif;
  font-size:22px;font-weight:700;width:100%;text-align:center;outline:none;margin-bottom:8px}
.modal .big-input:focus{border-color:rgba(0,255,120,0.35)}
.modal-mode{display:flex;align-items:center;justify-content:center;gap:12px;margin-bottom:14px}
.modal-actions{display:flex;gap:8px}
.modal-actions .btn{flex:1}
.live-warn{display:none;background:rgba(255,51,85,0.08);border:1px solid rgba(255,51,85,0.2);
  border-radius:8px;padding:8px;margin-bottom:10px;font-size:9px;color:var(--r);text-align:center}
/* ALLOCATION GRID */
.alloc-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:12px}
.alloc-item{display:flex;flex-direction:column;gap:4px}
.alloc-item label{font-size:8px;color:var(--td);text-transform:uppercase;letter-spacing:1px}
.alloc-item input{background:rgba(0,255,120,0.04);border:1px solid var(--border);border-radius:7px;
  padding:8px;color:var(--g);font-family:'Space Grotesk',sans-serif;font-size:15px;font-weight:700;
  text-align:center;outline:none;width:100%}
.alloc-item input:focus{border-color:rgba(0,255,120,0.35)}
.alloc-sum{text-align:center;font-size:9px;margin-bottom:10px;padding:6px;border-radius:6px}
.alloc-sum.ok{background:rgba(0,255,120,0.06);color:var(--g)}
.alloc-sum.over{background:rgba(255,51,85,0.08);color:var(--r)}
/* HELP / PM2 TAB */
.cmd-block{background:#030604;border:1px solid var(--border);border-radius:8px;padding:12px;
  margin-bottom:10px;font-size:9px;line-height:1.9;color:var(--td);font-family:'JetBrains Mono',monospace}
.cmd-block .cmd{color:var(--g);cursor:pointer;border-bottom:1px dotted rgba(0,255,120,0.2)}
.cmd-block .cmd:hover{color:#fff;border-color:var(--g)}
.cmd-section{margin-bottom:18px}
.cmd-section h4{font-family:'Space Grotesk',sans-serif;color:var(--tb);font-size:12px;margin-bottom:8px;
  padding-bottom:4px;border-bottom:1px solid var(--border)}
@media(max-width:600px){
  .g2,.g3,.g4{grid-template-columns:1fr 1fr}
  .stat-v{font-size:16px}
  .agent-panel{flex-direction:column;align-items:stretch}
  .alloc-grid{grid-template-columns:1fr}
}
</style>
</head>
<body>
<div id="toast" class="toast"></div>

<!-- ═══ START MODAL ═══ -->
<div class="modal-bg" id="startModal">
<div class="modal">
  <h2>🚀 Start Trading Agent</h2>
  <p id="mSubtitle">Configure capital before launching</p>
  <div class="modal-mode">
    <span class="toggle-label" id="mLbl1" style="color:var(--g)">PAPER</span>
    <div class="toggle paper" id="mToggle" onclick="toggleModalMode()"><div class="toggle-knob"></div></div>
    <span class="toggle-label" id="mLbl2">LIVE</span>
  </div>

  <!-- Single-segment capital (shown when specific segment) -->
  <div id="singleCapDiv">
    <div style="font-size:8px;color:var(--td);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:6px;text-align:center">TOTAL CAPITAL (₹)</div>
    <input class="big-input" id="mCapital" type="number" value="10000" min="100" step="500">
    <div id="maxHint" style="font-size:8px;color:var(--td);margin-bottom:8px;text-align:center"></div>
  </div>

  <!-- Multi-segment allocation (shown when both/all) -->
  <div id="multiCapDiv" style="display:none">
    <div style="font-size:8px;color:var(--td);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:8px;text-align:center">ALLOCATE CAPITAL PER SEGMENT (₹)</div>
    <div class="alloc-grid">
      <div class="alloc-item"><label>📈 Options</label><input type="number" id="mAllocOpt" min="0" step="500" placeholder="0" oninput="updateAllocSum()"></div>
      <div class="alloc-item"><label>📊 Equity</label><input type="number" id="mAllocEq"  min="0" step="500" placeholder="0" oninput="updateAllocSum()"></div>
      <div class="alloc-item"><label>🛢️ Commodity</label><input type="number" id="mAllocCom" min="0" step="500" placeholder="0" oninput="updateAllocSum()"></div>
    </div>
    <div class="alloc-sum ok" id="allocSumDiv">Total: ₹0 | Available: ₹0</div>
  </div>

  <div class="live-warn" id="liveWarning">⚠ LIVE MODE — Real money will be used for trading</div>
  <div class="modal-actions">
    <button class="btn btn-r" onclick="closeModal()">Cancel</button>
    <button class="btn btn-g btn-lg" onclick="confirmStart()" id="mStartBtn">Start Paper Trading</button>
  </div>
</div>
</div>

<!-- ═══ HEADER ═══ -->
<div class="hdr">
  <div class="logo">
    <h1>FINANCE<span>AGI</span></h1>
    <span class="version">v12.0 Command Center</span>
  </div>
  <div style="display:flex;align-items:center;gap:10px">
    <span id="clk" style="font-size:10px;color:var(--td)">--:--</span>
  </div>
</div>

<!-- ═══ BROKER BANNER ═══ -->
<div class="broker-banner off" id="brokerBanner">
  <div class="broker-dot off" id="brDot"></div>
  <div class="broker-info" id="brInfo">Broker not connected <small>— Click Connect to authorize Upstox</small></div>
  <div class="broker-cash" id="brCash"></div>
  <button class="btn btn-b" onclick="connectBroker()" id="connectBtn">Connect Upstox</button>
</div>

<!-- ═══ AGENT CONTROL PANEL ═══ -->
<div class="agent-panel">
  <div style="display:flex;align-items:center;gap:8px">
    <div class="broker-dot off" id="agDot" style="width:8px;height:8px"></div>
    <span style="font-size:10px;color:var(--tb);font-weight:600" id="agSt">Agent: Stopped</span>
  </div>

  <div class="toggle-wrap">
    <span class="toggle-label active" id="tLbl1">PAPER</span>
    <div class="toggle paper" id="modeToggle" onclick="toggleMode()"><div class="toggle-knob"></div></div>
    <span class="toggle-label" id="tLbl2">LIVE</span>
  </div>

  <div class="cap-input">
    <span class="rupee">₹</span>
    <input type="number" id="capitalInput" value="10000" min="100" step="500" onchange="updateCapital(this.value)">
    <label>Capital</label>
  </div>

  <!-- ASSET MODE BUTTONS -->
  <div style="display:flex;gap:3px;align-items:center;flex-wrap:wrap">
    <span style="font-size:7px;color:var(--td);letter-spacing:1px;margin-right:2px">TRADE:</span>
    <button class="btn btn-g"  id="amOpt" onclick="setAssetMode('options')"   style="padding:4px 8px;font-size:8px">Options</button>
    <button class="btn btn-b"  id="amEq"  onclick="setAssetMode('equity')"    style="padding:4px 8px;font-size:8px">Equity</button>
    <button class="btn btn-g"  id="amCom" onclick="setAssetMode('commodity')" style="padding:4px 8px;font-size:8px">Commodity</button>
    <button class="btn btn-g"  id="amBoth" onclick="setAssetMode('both')"     style="padding:4px 8px;font-size:8px">Both</button>
    <button class="btn btn-g"  id="amAll"  onclick="setAssetMode('all')"      style="padding:4px 9px;font-size:8px">All 3</button>
  </div>

  <div style="margin-left:auto;display:flex;gap:6px">
    <button class="btn btn-g" id="startBtn" onclick="openStartModal()">▶ Start Agent</button>
    <button class="btn btn-r" id="stopBtn"  onclick="stopAgent()" style="display:none">■ Stop Agent</button>
  </div>
</div>

<!-- ═══ STATUS BAR ═══ -->
<div class="status-bar">
  <span class="si"><span class="broker-dot off" id="mktDot" style="width:6px;height:6px"></span>&nbsp;<span class="val" id="mktSi" style="font-weight:700">NSE --</span>&nbsp;<span class="lbl" id="mktInfo"></span></span>
  <span class="si"><span class="broker-dot off" id="mcxDot" style="width:6px;height:6px"></span>&nbsp;<span class="val" id="mcxSi" style="font-weight:700">MCX --</span>&nbsp;<span class="lbl" id="mcxInfo"></span></span>
  <span class="si"><span class="lbl">Mode:</span>&nbsp;<span class="val" id="modeSi">PAPER</span></span>
  <span class="si"><span class="lbl">Capital:</span>&nbsp;<span class="val" id="capSi">₹10,000</span></span>
  <span class="si"><span class="lbl">News:</span>&nbsp;<span class="val" id="newsSi">OFF</span></span>
  <span class="si"><span class="lbl">NN:</span>&nbsp;<span class="val" id="nnSi">0</span></span>
  <span class="si"><span class="lbl">RL:</span>&nbsp;<span class="val" id="rlSi">0</span></span>
  <span class="si"><span class="lbl">Strats:</span>&nbsp;<span class="val" id="stSi">0</span></span>
  <span class="si"><span class="lbl">Assets:</span>&nbsp;<span class="val" id="assetSi">--</span></span>
</div>

<!-- ═══ DAILY BALANCE BAR ═══ -->
<div class="status-bar" style="background:rgba(0,255,120,0.02)">
  <span class="si"><span class="lbl">Opening:</span>&nbsp;<span class="val" id="balOpen">--</span></span>
  <span class="si"><span class="lbl">Current:</span>&nbsp;<span class="val" id="balClose" style="font-weight:700">--</span></span>
  <span class="si"><span class="lbl">Day P&L:</span>&nbsp;<span class="val" id="balDayPnl" style="font-weight:700">--</span></span>
  <span class="si"><span class="lbl">Charges:</span>&nbsp;<span class="val red" id="balDayCh">--</span></span>
  <span class="si"><span class="lbl">Net:</span>&nbsp;<span class="val" id="balDayNet" style="font-weight:700">--</span></span>
  <span class="si"><span class="lbl">Today:</span>&nbsp;<span class="val" id="balDayTrades">0T 0W</span></span>
</div>

<!-- ═══ ALLOCATION STRIP (visible when both/all) ═══ -->
<div id="allocStrip" style="display:none;padding:8px 16px;background:rgba(0,80,40,0.08);border-bottom:1px solid var(--border);font-size:9px;display:flex;gap:16px;flex-wrap:wrap;align-items:center">
  <span style="color:var(--td);letter-spacing:1px;text-transform:uppercase;font-size:7px">ALLOCATIONS:</span>
  <span class="si"><span class="lbl">Options:</span>&nbsp;<span class="val green" id="asSiOpt">--</span></span>
  <span class="si"><span class="lbl">Equity:</span>&nbsp;<span class="val green" id="asSiEq">--</span></span>
  <span class="si"><span class="lbl">Commodity:</span>&nbsp;<span class="val green" id="asSiCom">--</span></span>
</div>

<div class="main">
<div class="tabs">
  <button class="tbtn on" onclick="tab(this,'dash')">Dashboard</button>
  <button class="tbtn" onclick="tab(this,'strats')">Strategies</button>
  <button class="tbtn" onclick="tab(this,'brain')">AI Brain</button>
  <button class="tbtn" onclick="tab(this,'trades')">Trades</button>
  <button class="tbtn" onclick="tab(this,'help')">Help / Commands</button>
</div>

<!-- DASHBOARD -->
<div class="tp on" id="p-dash">
  <div class="grid g4">
    <div class="card"><div class="stat-l">Gross P&L</div><div class="stat-v" id="sPnl">₹0</div><div class="stat-s" id="sWr">WR: 0%</div></div>
    <div class="card"><div class="stat-l">Charges Paid</div><div class="stat-v red" id="sCh">₹0</div><div class="stat-s" id="sTot">0 trades</div></div>
    <div class="card"><div class="stat-l">NET P&L</div><div class="stat-v" id="sNet">₹0</div><div class="stat-s" id="sWin">0 wins</div></div>
    <div class="card"><div class="stat-l">Avg Win / Loss</div><div class="stat-v green" id="aW">+0.0%</div><div class="stat-s red" id="aL">0.0% loss</div></div>
  </div>
  <div class="grid g2">
    <div class="card"><h3>Strategy Performance</h3><div id="spD" style="color:var(--td);font-size:9px">No trades yet</div></div>
    <div class="card"><h3>Recent Trades</h3><div style="max-height:280px;overflow-y:auto"><table><thead><tr><th>Time</th><th>Strategy</th><th>UL</th><th>Type</th><th>P&L</th><th>Ch</th><th>Net</th><th>Exit</th></tr></thead><tbody id="rtB"><tr><td colspan="8" style="text-align:center;color:var(--td)">Waiting for trades...</td></tr></tbody></table></div></div>
  </div>
  <div class="grid g2">
    <div class="card"><h3>Feature Importance <span class="badge bp">Neural Net</span></h3><div id="impD" style="color:var(--td);font-size:9px">Needs training data</div></div>
    <div class="card"><h3>AI Systems</h3><div id="brD" style="font-size:9px;line-height:1.9"></div></div>
  </div>
</div>

<!-- STRATEGIES -->
<div class="tp" id="p-strats">
  <div class="card"><h3>Living Strategies <span class="badge bg" id="sc">0</span></h3><div id="sdna">No strategies yet</div></div>
  <div class="card" style="margin-top:8px"><h3>Graveyard <span class="badge br" id="dc">0</span></h3><div id="dead" style="font-size:9px;color:var(--td)">None</div></div>
</div>

<!-- BRAIN -->
<div class="tp" id="p-brain">
  <div class="grid g3">
    <div class="card"><h3>Neural Net <span class="badge bp">ML</span></h3><div id="nnD"></div></div>
    <div class="card"><h3>Q-Learning <span class="badge bbl">RL</span></h3><div id="rlD"></div></div>
    <div class="card"><h3>Genetic Engine <span class="badge ba">Evo</span></h3><div id="geD"></div></div>
  </div>
  <div class="card"><h3>Full Feature Importance</h3><div id="impF"></div></div>
</div>

<!-- TRADES -->
<div class="tp" id="p-trades">
  <div class="card"><h3>Trade History</h3><div style="overflow-x:auto"><table><thead><tr><th>Time</th><th>Strategy</th><th>Symbol</th><th>D</th><th>IV</th><th>P%</th><th>PnL%</th><th>Rs</th><th>Peak</th><th>Exit</th><th>Hold</th></tr></thead><tbody id="atB"><tr><td colspan="11" style="text-align:center;color:var(--td)">No trades</td></tr></tbody></table></div></div>
</div>

<!-- HELP / COMMANDS -->
<div class="tp" id="p-help">
<div class="grid g2">
<div>
  <div class="cmd-section">
    <h4>⚙️ PM2 Process Management</h4>
    <div class="cmd-block">
<span class="cmd" onclick="copyCmd(this)">pm2 start ecosystem.config.js</span>   # Start all processes<br>
<span class="cmd" onclick="copyCmd(this)">pm2 stop all</span>                      # Stop all<br>
<span class="cmd" onclick="copyCmd(this)">pm2 restart all</span>                   # Restart all<br>
<span class="cmd" onclick="copyCmd(this)">pm2 restart financeagi-agent</span>      # Restart agent only<br>
<span class="cmd" onclick="copyCmd(this)">pm2 restart financeagi-dashboard</span>  # Restart dashboard only<br>
<span class="cmd" onclick="copyCmd(this)">pm2 status</span>                        # Show process status<br>
<span class="cmd" onclick="copyCmd(this)">pm2 list</span>                          # List all apps<br>
<span class="cmd" onclick="copyCmd(this)">pm2 save</span>                          # Save process list<br>
<span class="cmd" onclick="copyCmd(this)">pm2 startup</span>                       # Generate startup script<br>
<span class="cmd" onclick="copyCmd(this)">pm2 delete financeagi-agent</span>       # Remove from pm2<br>
    </div>
  </div>
  <div class="cmd-section">
    <h4>📋 PM2 Logs</h4>
    <div class="cmd-block">
<span class="cmd" onclick="copyCmd(this)">pm2 logs financeagi-agent</span>         # Live agent logs<br>
<span class="cmd" onclick="copyCmd(this)">pm2 logs financeagi-agent --lines 100</span> # Last 100 lines<br>
<span class="cmd" onclick="copyCmd(this)">pm2 logs --nostream</span>               # All logs (no follow)<br>
<span class="cmd" onclick="copyCmd(this)">pm2 flush</span>                         # Clear all pm2 logs<br>
<span class="cmd" onclick="copyCmd(this)">cat logs/agent.log | tail -50</span>     # Direct log tail<br>
<span class="cmd" onclick="copyCmd(this)">tail -f logs/agent.log</span>            # Follow agent log<br>
    </div>
  </div>
  <div class="cmd-section">
    <h4>📊 PM2 Monitoring</h4>
    <div class="cmd-block">
<span class="cmd" onclick="copyCmd(this)">pm2 monit</span>                         # Real-time CPU/RAM monitor<br>
<span class="cmd" onclick="copyCmd(this)">pm2 show financeagi-agent</span>         # Detailed process info<br>
<span class="cmd" onclick="copyCmd(this)">pm2 describe financeagi-agent</span>     # Full description<br>
    </div>
  </div>
</div>
<div>
  <div class="cmd-section">
    <h4>🐍 Agent CLI Commands</h4>
    <div class="cmd-block">
<span class="cmd" onclick="copyCmd(this)">python3 agent.py stats</span>           # Performance summary<br>
<span class="cmd" onclick="copyCmd(this)">python3 agent.py reset</span>           # Wipe all memory/trades<br>
<span class="cmd" onclick="copyCmd(this)">python3 agent.py</span>                  # Run agent directly<br>
    </div>
  </div>
  <div class="cmd-section">
    <h4>🤖 Qwen2.5 Local LLM (Daily Update)</h4>
    <div class="cmd-block">
<span class="cmd" onclick="copyCmd(this)">ollama list</span>                       # Show loaded models<br>
<span class="cmd" onclick="copyCmd(this)">ollama run qwen2.5:3b</span>             # Interactive chat<br>
<span class="cmd" onclick="copyCmd(this)">ollama pull qwen2.5:3b</span>            # Download/update model<br>
<span class="cmd" onclick="copyCmd(this)">ollama ps</span>                         # Show running models<br>
<span class="cmd" onclick="copyCmd(this)">python3 daily_update.py</span>           # Run daily LLM update<br>
<span class="cmd" onclick="copyCmd(this)">crontab -e</span>                        # Edit cron (add daily job)<br>
<div style="margin-top:6px;color:var(--td)">Cron entry (daily at 6 AM):<br>
<span class="cmd" onclick="copyCmd(this)">0 6 * * * cd /path/to/financeagi && python3 daily_update.py >> logs/llm_update.log 2>&1</span></div>
    </div>
  </div>
  <div class="cmd-section">
    <h4>🛢️ SQLite Database</h4>
    <div class="cmd-block">
<span class="cmd" onclick="copyCmd(this)">sqlite3 data/v10.db "SELECT COUNT(*) FROM trades"</span><br>
<span class="cmd" onclick="copyCmd(this)">sqlite3 data/v10.db "SELECT strategy,COUNT(*),SUM(won) FROM trades GROUP BY strategy"</span><br>
<span class="cmd" onclick="copyCmd(this)">sqlite3 data/v10.db "DELETE FROM trades"</span>  # Wipe trades<br>
    </div>
  </div>
  <div class="cmd-section">
    <h4>🔧 Maintenance</h4>
    <div class="cmd-block">
<span class="cmd" onclick="copyCmd(this)">pip install -r requirements.txt</span>  # Install deps<br>
<span class="cmd" onclick="copyCmd(this)">pkill -f agent.py</span>                 # Force kill agent<br>
<span class="cmd" onclick="copyCmd(this)">rm data/nn.pkl data/rl.pkl data/strats.json</span>  # Reset AI models<br>
<span class="cmd" onclick="copyCmd(this)">ls -lh data/</span>                      # Check data files<br>
<span class="cmd" onclick="copyCmd(this)">du -sh logs/</span>                      # Check log size<br>
    </div>
  </div>
</div>
</div>
</div>

</div><!-- /main -->

<script>
var $=function(s){return document.querySelector(s)};
var isPaper=true,capital=10000,assetMode='both';
var allocOpt=0,allocEq=0,allocCom=0;
var availCash=0;

function fmt(n){return n==null||isNaN(n)?'--':Number(n).toLocaleString('en-IN',{maximumFractionDigits:0})}
function fR(n){return'\u20B9'+fmt(n)}
function pc(n){return n>=0?'var(--g)':'var(--r)'}
function ps(n){return n>=0?'+':''}

function toast(msg,ok){
  var t=$('#toast');t.textContent=msg;t.className='toast show '+(ok?'ok':'err');
  setTimeout(function(){t.className='toast'},3500);
}

function tab(btn,id){
  document.querySelectorAll('.tbtn').forEach(function(b){b.classList.remove('on')});
  document.querySelectorAll('.tp').forEach(function(p){p.classList.remove('on')});
  btn.classList.add('on');$('#p-'+id).classList.add('on');
}

function copyCmd(el){
  var t=el.textContent.trim();
  if(navigator.clipboard){navigator.clipboard.writeText(t).then(function(){toast('Copied: '+t.substr(0,40),true)});}
  else{toast(t,true);}
}

setInterval(function(){$('#clk').textContent=new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true})},1000);

function connectBroker(){
  fetch('/api/broker/login').then(function(r){return r.json()}).then(function(d){
    if(d.url)window.location.href=d.url;
  });
}

function toggleMode(){
  isPaper=!isPaper;updateModeUI();
  fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({paper_trading:isPaper,capital:capital})});
}

function toggleModalMode(){
  isPaper=!isPaper;updateModalModeUI();
}

function updateModeUI(){
  var t=$('#modeToggle');t.className=isPaper?'toggle paper':'toggle';
  $('#tLbl1').className='toggle-label'+(isPaper?' active':'');
  $('#tLbl2').className='toggle-label'+(isPaper?'':' active');
  $('#modeSi').textContent=isPaper?'PAPER':'LIVE';
  $('#modeSi').style.color=isPaper?'var(--g)':'var(--r)';
}

function updateModalModeUI(){
  var t=$('#mToggle');t.className=isPaper?'toggle paper':'toggle';
  $('#mLbl1').style.color=isPaper?'var(--g)':'var(--td)';
  $('#mLbl2').style.color=isPaper?'var(--td)':'var(--r)';
  $('#liveWarning').style.display=isPaper?'none':'block';
  $('#mStartBtn').textContent=isPaper?'Start Paper Trading':'⚡ Start LIVE Trading';
  $('#mStartBtn').className=isPaper?'btn btn-g btn-lg':'btn btn-r btn-lg';
  // hint
  var multi=(assetMode==='both'||assetMode==='all');
  if(!isPaper){
    $('#maxHint').textContent=availCash>0?'Available: '+fR(availCash):'Connect broker to see available funds';
  } else {
    $('#maxHint').textContent='';
  }
  // update alloc sum display
  if(multi) updateAllocSum();
}

function updateCapital(v){
  capital=parseFloat(v)||10000;
  $('#capSi').textContent=fR(capital);
  fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({paper_trading:isPaper,capital:capital,asset_mode:assetMode})});
}

function setAssetMode(m){
  assetMode=m;updateAssetUI();
  fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({paper_trading:isPaper,capital:capital,asset_mode:assetMode})});
  toast('Trading: '+m.toUpperCase(),true);
}

function updateAssetUI(){
  ['amOpt','amEq','amCom','amBoth','amAll'].forEach(function(id){
    var el=$('#'+id);if(!el)return;
    el.style.opacity='0.4';el.style.borderColor='rgba(0,255,120,0.1)';
  });
  var map={options:'amOpt',equity:'amEq',commodity:'amCom',both:'amBoth',all:'amAll'};
  var active=map[assetMode]||'amBoth';
  var el=$('#'+active);if(el){el.style.opacity='1';el.style.borderColor='var(--g)';}
  // Show allocation strip for both/all
  var multi=(assetMode==='both'||assetMode==='all');
  var strip=$('#allocStrip');
  if(strip) strip.style.display=multi?'flex':'none';
  $('#assetSi').textContent=assetMode.toUpperCase();
}

/* ─── ALLOCATION HELPERS ─── */
function updateAllocSum(){
  var o=parseFloat($('#mAllocOpt').value)||0;
  var e=parseFloat($('#mAllocEq').value)||0;
  var c=parseFloat($('#mAllocCom').value)||0;
  var total=o+e+c;
  var avail=isPaper?capital:availCash;
  var sd=$('#allocSumDiv');
  sd.textContent='Total allocated: '+fR(total)+' | Available: '+fR(avail);
  sd.className='alloc-sum '+(total<=avail||avail===0?'ok':'over');
}

/* ─── START MODAL ─── */
function openStartModal(){
  var multi=(assetMode==='both'||assetMode==='all');
  $('#singleCapDiv').style.display=multi?'none':'block';
  $('#multiCapDiv').style.display=multi?'block':'none';
  $('#mCapital').value=capital;
  if(multi){
    $('#mAllocOpt').value=allocOpt||'';
    $('#mAllocEq').value=allocEq||'';
    $('#mAllocCom').value=allocCom||'';
    updateAllocSum();
    var modeStr=assetMode==='all'?'Options + Equity + Commodity':'Options + Equity';
    $('#mSubtitle').textContent='Allocate capital per segment: '+modeStr;
  } else {
    var segName={options:'Options',equity:'Equity',commodity:'Commodity'}[assetMode]||assetMode;
    $('#mSubtitle').textContent='Set capital for '+segName+' segment';
    if(!isPaper&&availCash>0){
      $('#maxHint').textContent='Available: '+fR(availCash)+' (max)';
      $('#mCapital').max=availCash;
    }
  }
  updateModalModeUI();
  $('#startModal').classList.add('show');
}

function closeModal(){$('#startModal').classList.remove('show')}

function confirmStart(){
  var multi=(assetMode==='both'||assetMode==='all');
  if(multi){
    allocOpt=parseFloat($('#mAllocOpt').value)||0;
    allocEq =parseFloat($('#mAllocEq').value)||0;
    allocCom=parseFloat($('#mAllocCom').value)||0;
    // validate
    var avail=isPaper?capital:availCash;
    if(avail>0&&(allocOpt+allocEq+allocCom)>avail){
      toast('Allocation exceeds available funds!',false);return;
    }
    // Update capital to total of allocations if paper
    if(isPaper&&(allocOpt+allocEq+allocCom)>0){
      capital=allocOpt+allocEq+allocCom;
      $('#capitalInput').value=capital;
    }
  } else {
    capital=parseFloat($('#mCapital').value)||10000;
    if(!isPaper&&availCash>0&&capital>availCash){
      toast('Cannot exceed available funds: '+fR(availCash),false);return;
    }
    $('#capitalInput').value=capital;
  }
  $('#capSi').textContent=fR(capital);
  closeModal();
  updateModeUI();
  fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({paper_trading:isPaper,capital:capital,asset_mode:assetMode,
      alloc_options:allocOpt,alloc_equity:allocEq,alloc_commodity:allocCom})
  }).then(function(){return fetch('/api/agent/start',{method:'POST'})})
    .then(function(r){return r.json()})
    .then(function(d){toast(d.msg||'Started',true);})
    .catch(function(e){toast('Error: '+e,false)});
}

function stopAgent(){
  fetch('/api/agent/stop',{method:'POST'}).then(function(r){return r.json()})
    .then(function(d){toast(d.msg||'Stopped',true);})
    .catch(function(e){toast('Error: '+e,false)});
}

/* ─── RENDER ─── */
function render(d){
  // Broker
  var br=d.broker||{};var conn=br.connected;
  availCash=br.cash||0;
  var banner=$('#brokerBanner');
  banner.className='broker-banner '+(conn?'ok':'off');
  $('#brDot').className='broker-dot '+(conn?'on':'off');
  if(conn){
    $('#brInfo').innerHTML='<span style="color:var(--g);font-weight:700">Connected</span> — '+(br.user_name||'')+(br.user_id?' <small>('+br.user_id+')</small>':'');
    $('#brCash').textContent=br.cash?fR(br.cash):'';
    $('#connectBtn').textContent='Reconnect';$('#connectBtn').className='btn btn-g';
  } else {
    $('#brInfo').innerHTML='Broker not connected <small>— Click Connect to authorize Upstox</small>';
    $('#brCash').textContent='';$('#connectBtn').textContent='Connect Upstox';$('#connectBtn').className='btn btn-b';
  }

  // Settings
  isPaper=d.paper_trading!==false;
  capital=d.capital||10000;
  assetMode=d.asset_mode||'both';
  allocOpt=d.alloc_options||0;
  allocEq =d.alloc_equity||0;
  allocCom=d.alloc_commodity||0;
  $('#capitalInput').value=capital;
  updateModeUI();updateAssetUI();
  $('#capSi').textContent=fR(capital);

  // Allocation strip
  var multi=(assetMode==='both'||assetMode==='all');
  if(multi){
    $('#asSiOpt').textContent=allocOpt>0?fR(allocOpt):'--';
    $('#asSiEq').textContent =allocEq>0?fR(allocEq):'--';
    $('#asSiCom').textContent=allocCom>0?fR(allocCom):'--';
  }

  // NSE Market status
  var mkt=d.market||{};var mOpen=mkt.open;
  $('#mktDot').className='broker-dot '+(mOpen?'on':'off');
  $('#mktSi').textContent='NSE '+(mkt.label||'--');
  $('#mktSi').style.color=mOpen?'var(--g)':mkt.label==='PRE-OPEN'?'var(--a)':'var(--r)';
  $('#mktInfo').textContent=mkt.reason||'';

  // MCX status
  var mcx=d.mcx||{};var mcxOpen=mcx.open;
  $('#mcxDot').className='broker-dot '+(mcxOpen?'on':'off');
  $('#mcxSi').textContent='MCX '+(mcx.label||'--');
  $('#mcxSi').style.color=mcxOpen?'var(--g)':'var(--r)';
  $('#mcxInfo').textContent=mcx.reason||'';

  // Agent status
  var ag=d.agent||{};
  $('#agDot').className='broker-dot '+(ag.running?'on':'off');
  $('#agSt').textContent=ag.running?'Agent: Running'+(ag.pid?' (PID '+ag.pid+')':''):'Agent: Stopped';
  $('#startBtn').style.display=ag.running?'none':'inline-block';
  $('#stopBtn').style.display=ag.running?'inline-block':'none';

  // Stats
  var s=d.stats||{};
  $('#sPnl').innerHTML='<span style="color:'+pc(s.pnl)+'">'+ps(s.pnl)+fR(s.pnl)+'</span>';
  $('#sWr').textContent='WR: '+(s.wr||0)+'% | '+(s.total||0)+' trades';
  $('#sCh').textContent=fR(s.charges||0);$('#sTot').textContent=(s.total||0)+' trades';
  var np=s.net_pnl||0;
  $('#sNet').innerHTML='<span style="color:'+pc(np)+'">'+ps(np)+fR(np)+'</span>';
  $('#sWin').textContent=(s.wins||0)+' wins';
  $('#aW').textContent='+'+(d.avg_win||0).toFixed(1)+'%';
  $('#aL').textContent=(d.avg_loss||0).toFixed(1)+'% loss';

  // Daily balance
  var bal=d.balance||{};
  $('#balOpen').textContent=bal.opening?fR(bal.opening):'--';
  $('#balClose').textContent=bal.closing?fR(bal.closing):'--';
  var dayChange=bal.closing&&bal.opening?(bal.closing-bal.opening):0;
  if(bal.opening>0&&bal.closing>0)$('#balClose').style.color=pc(dayChange);
  var tdy=d.today||{};
  $('#balDayPnl').textContent=tdy.gross?ps(tdy.gross)+fR(tdy.gross):'₹0';
  $('#balDayPnl').style.color=pc(tdy.gross||0);
  $('#balDayCh').textContent=tdy.charges?fR(tdy.charges):'₹0';
  $('#balDayNet').textContent=tdy.net?ps(tdy.net)+fR(tdy.net):'₹0';
  $('#balDayNet').style.color=pc(tdy.net||0);
  $('#balDayTrades').textContent=(tdy.trades||0)+'T '+(tdy.wins||0)+'W';
  $('#newsSi').textContent=d.news_on?'ON':'OFF';
  $('#newsSi').style.color=d.news_on?'var(--g)':'var(--td)';

  var nn=d.nn||{},rl=d.rl||{},strats=d.strategies||[];
  $('#nnSi').textContent=(nn.samples||0)+' samples';
  $('#rlSi').textContent=(rl.episodes||0)+' ep';
  var lv=strats.filter(function(s){return s.alive&&!s.testing}).length;
  $('#stSi').textContent=lv+' live';

  // Strategy perf
  var sp=d.strat_perf||{};var h='';
  Object.entries(sp).sort(function(a,b){return (b[1].np||b[1].p)-(a[1].np||a[1].p)}).forEach(function(e){
    var n=e[0],v=e[1];var wr=v.n>0?(v.w/v.n*100).toFixed(0):0;var np=v.np||v.p;var c=np>=0?'var(--g)':'var(--r)';
    h+='<div class="strat"><div style="display:flex;justify-content:space-between"><span style="color:var(--tb);font-size:10px">'+n+'</span><span style="font-size:10px;color:'+c+'">net '+ps(np)+fR(np)+'</span></div><div style="font-size:8px;color:var(--td);margin-top:3px">'+v.n+'T '+v.w+'W '+wr+'%WR | gross='+fR(v.p)+' ch='+fR(v.ch||0)+'</div></div>';
  });
  $('#spD').innerHTML=h||'<div style="color:var(--td);font-size:9px">No trades yet</div>';

  // Recent trades
  var trades=d.trades||[];
  $('#rtB').innerHTML=trades.slice(0,10).map(function(t){
    var np=t.net_pnl||t.pnl||0;var c=np>=0?'var(--g)':'var(--r)';
    var ul=(t.underlying||'').split('|').pop().substr(0,8);
    return '<tr><td>'+(t.ts?t.ts.substr(11,5):'')+'</td><td style="color:var(--tb);font-size:8px">'+(t.strategy||'').substr(0,12)+'</td><td style="font-size:8px">'+ul+'</td><td>'+(t.otype||'')+'</td><td style="color:'+c+'">'+ps(t.pnl_pct)+(t.pnl_pct||0).toFixed(1)+'%</td><td style="color:var(--r);font-size:8px">'+(t.charges?fR(t.charges):'')+'</td><td style="color:'+c+';font-weight:600">'+fR(np)+'</td><td style="font-size:7px"><span class="badge '+(t.exit_reason=="TARGET"?"bg":"br")+'">'+(t.exit_reason||'')+'</span></td></tr>';
  }).join('')||'<tr><td colspan="8" style="text-align:center;color:var(--td)">Waiting for trades...</td></tr>';

  // Feature importance
  var imp=nn.importance||{};var ih='';
  Object.entries(imp).sort(function(a,b){return b[1]-a[1]}).forEach(function(e){
    ih+='<div class="imp-row"><span style="min-width:55px;color:var(--td)">'+e[0]+'</span><div class="imp-bar"><div class="imp-fill" style="width:'+e[1]+'%"></div></div><span style="min-width:28px;text-align:right">'+e[1]+'%</span></div>';
  });
  $('#impD').innerHTML=ih||'<div style="color:var(--td);font-size:9px">Needs training data</div>';
  $('#impF').innerHTML=ih;

  // AI Systems
  $('#brD').innerHTML='<span class="green">NN</span>: '+(nn.dims||[]).join('\u2192')+' | '+(nn.params||0)+' params | '+(nn.samples||0)+' samples<br><span class="blue">RL</span>: '+(rl.episodes||0)+' episodes | reward: '+(rl.reward||0)+'<br><span class="amber">GEN</span>: '+strats.filter(function(s){return s.alive}).length+' alive | '+(d.graveyard||0)+' dead | gen'+strats.reduce(function(m,s){return Math.max(m,s.generation||0)},0);

  $('#nnD').innerHTML='<div style="font-size:9px;line-height:2">Arch: <b>'+(nn.dims||[]).join('\u2192')+'</b><br>Params: <b>'+(nn.params||0)+'</b><br>Samples: <b>'+(nn.samples||0)+'</b></div>';
  $('#rlD').innerHTML='<div style="font-size:9px;line-height:2">Episodes: <b>'+(rl.episodes||0)+'</b><br>Reward: <b style="color:'+pc(rl.reward)+'">'+ps(rl.reward)+(rl.reward||0).toFixed(1)+'</b><br>States: <b>'+(rl.states||0)+'</b></div>';
  var mg=strats.reduce(function(m,s){return Math.max(m,s.generation||0)},0);
  $('#geD').innerHTML='<div style="font-size:9px;line-height:2">Gen: <b>'+mg+'</b><br>Alive: <b>'+strats.filter(function(s){return s.alive}).length+'</b><br>Testing: <b>'+strats.filter(function(s){return s.testing}).length+'</b><br>Dead: <b>'+(d.graveyard||0)+'</b></div>';

  $('#sc').textContent=strats.filter(function(s){return s.alive}).length+' alive';
  $('#dc').textContent=(d.graveyard||0)+' dead';
  var dh='';
  strats.filter(function(s){return s.alive}).forEach(function(s){
    var wr=s.trades>0?(s.wins/s.trades*100).toFixed(0):0;
    dh+='<div class="strat"><div style="display:flex;justify-content:space-between;margin-bottom:3px"><span style="font-size:10px;color:var(--tb)">'+(s.testing?'[TEST] ':'')+s.name+'</span><span class="badge '+(wr>=50?'bg':wr>=30?'ba':'br')+'">'+s.trades+'T '+wr+'%</span></div><div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1px 8px;font-size:8px;color:var(--td)"><span>'+(s.asset||'opt')+'</span><span>'+s.option_type+'</span><span>gen'+s.generation+'</span><span>D:'+s.delta_min+'-'+s.delta_max+'</span><span>OTM:'+s.otm_min+'-'+s.otm_max+'</span><span>IV:'+s.iv_pref+'</span><span class="green">T:+'+s.target_pct+'%</span><span class="red">SL:-'+s.stoploss_pct+'%</span><span>'+s.max_hold_min+'m</span><span>Trail:'+(s.use_trailing?'Y':'N')+'</span><span>Part:'+(s.use_partial?'Y':'N')+'</span><span>'+(s.parent||'seed').substr(0,12)+'</span></div></div>';
  });
  $('#sdna').innerHTML=dh||'No strategies yet';
  var dl=d.dead_list||[];
  $('#dead').innerHTML=dl.map(function(x){return x.name+' '+x.trades+'T - killed'}).join('<br>')||'None';

  $('#atB').innerHTML=trades.map(function(t){
    var c=t.won?'var(--g)':'var(--r)';
    return '<tr><td>'+(t.ts?t.ts.substr(11,8):'')+'</td><td style="color:var(--tb);font-size:8px">'+(t.strategy||'')+'</td><td>'+(t.symbol||'')+'</td><td>'+(t.entry_delta||0).toFixed(2)+'</td><td>'+(t.entry_iv||0).toFixed(0)+'</td><td>'+(t.nn_prob?(t.nn_prob*100).toFixed(0)+'%':'')+'</td><td style="color:'+c+'">'+ps(t.pnl_pct)+(t.pnl_pct||0).toFixed(1)+'%</td><td style="color:'+c+'">'+fR(t.pnl)+'</td><td>'+(t.peak_pnl||0).toFixed(1)+'%</td><td><span class="badge '+(t.exit_reason=='TARGET'?'bg':'br')+'">'+(t.exit_reason||'')+'</span></td><td>'+(t.hold_sec?Math.round(t.hold_sec/60)+'m':'')+'</td></tr>';
  }).join('')||'<tr><td colspan="11" style="text-align:center;color:var(--td)">No trades</td></tr>';
}

function load(){fetch('/api/data').then(function(r){return r.json()}).then(render).catch(function(e){console.error(e)})}

var urlp=new URLSearchParams(window.location.search);
if(urlp.get('msg')==='connected'){toast('Upstox connected!',true);history.replaceState(null,'','/');}
if(urlp.get('auth_error')){toast('Auth failed: '+urlp.get('auth_error'),false);history.replaceState(null,'','/');}

load();setInterval(load,5000);
</script>
</body>
</html>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _json(self, data, code=200):
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        self.send_header("Access-Control-Allow-Origin","*")
        self.end_headers()
        try: self.wfile.write(json.dumps(data, default=str).encode())
        except BrokenPipeError: pass

    def _html(self, html):
        self.send_response(200); self.send_header("Content-Type","text/html"); self.end_headers()
        try: self.wfile.write(html.encode())
        except BrokenPipeError: pass

    def _redirect(self, url):
        self.send_response(302); self.send_header("Location",url); self.end_headers()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path   = parsed.path
        params = urllib.parse.parse_qs(parsed.query)

        if path == "/api/data":
            self._json(get_data())
        elif path == "/api/broker/check":
            self._json(check_broker(force=True))
        elif path == "/api/broker/login":
            url = f"https://api.upstox.com/v2/login/authorization/dialog?response_type=code&client_id={API_KEY}&redirect_uri={urllib.parse.quote(REDIRECT, safe='')}"
            self._json({"url": url})
        elif path == "/callback":
            code  = params.get("code",[None])[0]
            error = params.get("error",[None])[0]
            if error: self._redirect(f"/?auth_error={error}")
            elif code:
                result = exchange_code(code)
                self._redirect("/?msg=connected" if result.get("success") else f"/?auth_error={urllib.parse.quote(str(result.get('error','unknown'))[:50])}")
            else: self._redirect("/?auth_error=no_code")
        elif path == "/api/agent/status":
            self._json(agent_status())
        else:
            self._html(HTML)

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        cl   = int(self.headers.get("Content-Length",0))
        body = self.rfile.read(cl) if cl > 0 else b""

        if path == "/api/agent/start":
            self._json(start_agent())
        elif path == "/api/agent/stop":
            self._json(stop_agent())
        elif path == "/api/settings":
            try:
                data = json.loads(body) if body else {}
                if "paper_trading" in data: SETTINGS["paper_trading"] = bool(data["paper_trading"])
                if "capital"       in data: SETTINGS["capital"] = max(100, float(data["capital"]))
                if "asset_mode"    in data and data["asset_mode"] in ("options","equity","commodity","both","all"):
                    SETTINGS["asset_mode"] = data["asset_mode"]
                if "alloc_equity"    in data: SETTINGS["alloc_equity"]    = max(0, float(data["alloc_equity"]))
                if "alloc_options"   in data: SETTINGS["alloc_options"]   = max(0, float(data["alloc_options"]))
                if "alloc_commodity" in data: SETTINGS["alloc_commodity"] = max(0, float(data["alloc_commodity"]))
                write_settings_to_env()
                self._json({"ok":True,"settings":SETTINGS})
            except Exception as e: self._json({"error":str(e)}, 400)
        elif path == "/api/broker/check":
            self._json(check_broker(force=True))
        else:
            self._json({"error":"Not found"}, 404)


def run(port=8000):
    os.makedirs(BASE/"data", exist_ok=True)
    os.makedirs(BASE/"logs", exist_ok=True)
    global REDIRECT
    if "127.0.0.1" not in REDIRECT and "localhost" not in REDIRECT:
        REDIRECT = f"http://localhost:{port}/callback"
    server = HTTPServer(("0.0.0.0", port), Handler)
    threading.Thread(target=lambda: check_broker(force=True), daemon=True).start()
    print()
    print("="*52)
    print("  FinanceAGI v12.0 - Local Command Center")
    print("="*52)
    print(f"  Dashboard:  http://localhost:{port}")
    print(f"  Mode:       {'PAPER' if SETTINGS['paper_trading'] else 'LIVE'}")
    print(f"  Capital:    ₹{SETTINGS['capital']:,.0f}")
    print(f"  Asset Mode: {SETTINGS['asset_mode'].upper()}")
    print(f"  Allocations: Opt=₹{SETTINGS['alloc_options']:.0f} Eq=₹{SETTINGS['alloc_equity']:.0f} Com=₹{SETTINGS['alloc_commodity']:.0f}")
    print("  Ctrl+C to stop")
    print()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Shutting down...")
        stop_agent()
        server.server_close()

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    run(port)
