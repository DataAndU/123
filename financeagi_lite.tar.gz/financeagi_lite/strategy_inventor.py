#!/usr/bin/env python3
"""
strategy_inventor.py — FinanceAGI v16: AI Commodity Strategy Inventor & Manager
================================================================================

Uses the Anthropic API (claude-sonnet-4-20250514) to:

  INVENT   — Generate brand-new commodity strategies based on live market
             conditions, asset class characteristics, and trade history.

  EVALUATE — Score live strategies against recent win-rate, Sharpe, and
             drawdown data stored in v10.db.

  MUTATE   — Cross-breed two high-performing strategies and spawn variants.

  KILL     — Retire underperforming strategies that fall below kill_wr
             threshold after min_trades.

  EXPLAIN  — Return a plain-English rationale for each strategy decision.

Architecture:
  ┌─────────────────────────────────────────────────────────────────────┐
  │  StrategyInventor  (main class)                                     │
  │   ├─ StrategyDB          — persist/load strategies to JSON + SQLite │
  │   ├─ PerformanceTracker  — track WR / Sharpe per strategy           │
  │   ├─ LLMInventor         — calls Claude API to invent new strategies │
  │   └─ EvolutionEngine     — kill / breed / mutate existing strategies │
  └─────────────────────────────────────────────────────────────────────┘

Integration with agent.py:
  1. Import: `from strategy_inventor import inventor`
  2. In run_commodity_loop(), after each trade closes:
       inventor.record_trade(sym, strategy_name, won, pnl_pct)
  3. In the scan loop (every N trades or hourly):
       new_strats = await inventor.maybe_invent(broker, market_context)
  4. agent.py reads inventor.active_strategies() for the live strategy list.

Usage (standalone):
  python3 strategy_inventor.py            # Run demo / print active strategies
  python3 strategy_inventor.py invent     # Force-invent new strategy via LLM
  python3 strategy_inventor.py status     # Print performance table

Environment variables:
  ANTHROPIC_API_KEY  — required for LLM invention
  INVENTOR_MAX_STRATS  — max live strategies (default 12)
  INVENTOR_KILL_WR     — kill if WR < this after min_trades (default 0.40)
  INVENTOR_MIN_TRADES  — minimum trades before kill eligible (default 8)
"""

import asyncio
import hashlib
import json
import logging
import math
import os
import random
import sqlite3
import sys
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

try:
    import httpx
    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False
    httpx = None

log = logging.getLogger("agi.inventor")
IST = timezone(timedelta(hours=5, minutes=30))
BASE = Path(__file__).resolve().parent
DB   = str(BASE / "data" / "v10.db")
STRAT_FILE = BASE / "data" / "invented_strategies.json"

# ── Load environment ───────────────────────────────────────────────────────────
def _env(key: str, default: str = "") -> str:
    ef = BASE / ".env"
    if ef.exists():
        for ln in ef.read_text().splitlines():
            ln = ln.strip()
            if ln and not ln.startswith("#") and "=" in ln:
                k, v = ln.split("=", 1)
                if k.strip() == key:
                    return v.strip()
    return os.environ.get(key, default)

ANTHROPIC_API_KEY = _env("ANTHROPIC_API_KEY")
MAX_STRATS        = int(_env("INVENTOR_MAX_STRATS", "12"))
KILL_WR           = float(_env("INVENTOR_KILL_WR", "0.40"))
MIN_TRADES        = int(_env("INVENTOR_MIN_TRADES", "8"))

# ── Known commodity assets ─────────────────────────────────────────────────────
KNOWN_ASSETS = [
    "GOLDPETAL", "GOLD", "SILVER", "CRUDEOILM", "NATGASMINI",
    "COPPER", "ZINC", "ALUMINIUM", "LEAD", "NICKEL",
]

# ═══════════════════════ STRATEGY SCHEMA ═══════════════════════════════════════

STRATEGY_DEFAULTS: dict = {
    "name":              "",           # Unique strategy name
    "version":           1,            # Incremented on mutation
    "generation":        0,            # 0 = seed, 1+ = invented/evolved
    "created_at":        "",           # ISO timestamp
    "symbols":           ["ALL"],      # List of KNOWN_ASSETS or ["ALL"]
    "direction":         "BOTH",       # "BUY" | "SELL" | "BOTH"
    "session":           "both",       # "indian" | "us" | "eod" | "both"
    "signal_type":       "TREND_FOLLOW",  # maps to STRATEGY_CATALOGUE key
    "min_range_pct":     0.5,
    "max_range_pos":     0.80,
    "min_range_pos":     0.20,
    "target_pct":        1.0,
    "sl_pct":            0.6,
    "max_hold_min":      45,
    "min_score":         3,
    "capital_pct":       0.25,
    "trend_filter":      "WITH",       # "WITH" | "AGAINST"
    "iv_pref":           "ANY",        # "ANY" | "HIGH_VOLATILITY" | "LOW_VOLATILITY"
    "is_spread":         False,        # True = opens 2 legs simultaneously
    "spread_legs":       [],
    "spread_directions": [],
    "rationale":         "",           # LLM explanation
    "tags":              [],           # e.g. ["momentum", "us_session", "crude"]
    "parent_names":      [],           # Names of parent strategies if bred
    "active":            True,
    "trades":            0,
    "wins":              0,
    "total_pnl":         0.0,
    "peak_pnl":          0.0,
    "max_drawdown":      0.0,
    "last_trade_ts":     "",
}

# Mutable genes that can be evolved
MUTABLE_GENES = [
    "direction", "session", "signal_type", "min_range_pct",
    "max_range_pos", "min_range_pos", "target_pct", "sl_pct",
    "max_hold_min", "capital_pct", "trend_filter", "iv_pref",
]

SIGNAL_TYPES = [
    "TREND_FOLLOW", "MEAN_REVERT", "BREAKOUT_VOL", "US_MOMENTUM",
    "GOLD_HEDGE", "SEASONAL_NATGAS", "INVENTORY_CRUDE", "VIX_SPIKE_GOLD",
    "METAL_COMPLEX", "CARRY_ROLL", "VOLATILITY_CRUSH", "SPREAD_INTER",
    "CUSTOM_LLM",  # Pure LLM-invented signal
]

# ═══════════════════════ PERFORMANCE TRACKER ═══════════════════════════════════

class PerformanceTracker:
    """Per-strategy rolling performance metrics."""

    def __init__(self, window: int = 30):
        self.window = window
        self._trades: dict[str, deque] = defaultdict(lambda: deque(maxlen=window))

    def record(self, strategy: str, won: bool, pnl_pct: float):
        self._trades[strategy].append({"won": won, "pnl": pnl_pct, "ts": time.time()})

    def win_rate(self, strategy: str) -> float:
        d = self._trades.get(strategy, [])
        if len(d) < 2:
            return 0.5
        return sum(1 for t in d if t["won"]) / len(d)

    def avg_pnl(self, strategy: str) -> float:
        d = self._trades.get(strategy, [])
        if not d:
            return 0.0
        return sum(t["pnl"] for t in d) / len(d)

    def sharpe(self, strategy: str) -> float:
        d = self._trades.get(strategy, [])
        if len(d) < 3:
            return 0.0
        pnls = [t["pnl"] for t in d]
        mean = sum(pnls) / len(pnls)
        std  = math.sqrt(sum((p - mean) ** 2 for p in pnls) / len(pnls))
        return round(mean / max(std, 0.01), 3)

    def trade_count(self, strategy: str) -> int:
        return len(self._trades.get(strategy, []))

    def should_kill(self, strategy: str) -> bool:
        n = self.trade_count(strategy)
        if n < MIN_TRADES:
            return False
        return self.win_rate(strategy) < KILL_WR

    def summary(self, strategy: str) -> dict:
        return {
            "n":      self.trade_count(strategy),
            "wr":     round(self.win_rate(strategy), 3),
            "avg_pnl":round(self.avg_pnl(strategy), 3),
            "sharpe": self.sharpe(strategy),
        }


perf_tracker = PerformanceTracker()


# ═══════════════════════ STRATEGY DATABASE ═════════════════════════════════════

class StrategyDB:
    """Persist and load strategies from JSON file + SQLite."""

    def __init__(self, path: Path = STRAT_FILE):
        self.path = path
        self._strategies: dict[str, dict] = {}
        self._load()

    def _load(self):
        if self.path.exists():
            try:
                data = json.loads(self.path.read_text())
                self._strategies = {s["name"]: s for s in data if s.get("name")}
                log.info(f"  [INVENTOR] Loaded {len(self._strategies)} strategies from {self.path.name}")
            except Exception as e:
                log.warning(f"  [INVENTOR] Load failed: {e}")

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps(list(self._strategies.values()), indent=2, ensure_ascii=False)
        )

    def add(self, strat: dict) -> bool:
        name = strat.get("name", "")
        if not name:
            return False
        self._strategies[name] = strat
        self.save()
        log.info(f"  [INVENTOR] + Added strategy: {name}")
        return True

    def update(self, name: str, **kwargs):
        if name in self._strategies:
            self._strategies[name].update(kwargs)
            self.save()

    def get(self, name: str) -> dict | None:
        return self._strategies.get(name)

    def all(self) -> list[dict]:
        return list(self._strategies.values())

    def active(self) -> list[dict]:
        return [s for s in self._strategies.values() if s.get("active", True)]

    def remove(self, name: str):
        self._strategies.pop(name, None)
        self.save()
        log.info(f"  [INVENTOR] - Removed strategy: {name}")

    def count(self) -> int:
        return len(self._strategies)

    def active_count(self) -> int:
        return sum(1 for s in self._strategies.values() if s.get("active", True))

    def record_trade(self, name: str, won: bool, pnl_pct: float):
        if name not in self._strategies:
            return
        s = self._strategies[name]
        s["trades"] = s.get("trades", 0) + 1
        if won:
            s["wins"] = s.get("wins", 0) + 1
        s["total_pnl"] = round(s.get("total_pnl", 0.0) + pnl_pct, 4)
        s["peak_pnl"]  = round(max(s.get("peak_pnl", 0.0), pnl_pct), 4)
        s["last_trade_ts"] = datetime.now(IST).isoformat()
        self.save()


strat_db = StrategyDB()


# ═══════════════════════ LLM INVENTOR ═════════════════════════════════════════

class LLMInventor:
    """
    Calls Claude claude-sonnet-4-20250514 to invent new commodity strategies.

    Prompt strategy:
      - Provides current market snapshot (LTP, range, session, recent P&L)
      - Provides current strategy list so LLM avoids duplication
      - Instructs LLM to return ONLY a JSON strategy dict
      - Validates and type-checks the returned dict
    """

    MODEL = "claude-sonnet-4-20250514"
    MAX_TOKENS = 1000
    COOLDOWN_SEC = 300  # 5 minutes between invention calls

    def __init__(self):
        self._last_call = 0.0
        self._call_count = 0

    def _is_ready(self) -> bool:
        return (
            bool(ANTHROPIC_API_KEY)
            and (time.time() - self._last_call) > self.COOLDOWN_SEC
        )

    async def invent(
        self,
        market_context: dict,
        existing_strategies: list[dict],
        trade_history_summary: str = "",
    ) -> dict | None:
        """
        Ask Claude to invent a new strategy.

        market_context: dict with keys like:
          - "spot_prices": {"CRUDEOILM": 6520, ...}
          - "day_changes": {"CRUDEOILM": +1.2, ...}
          - "session": "us" | "indian" | "eod"
          - "india_vix": 14.5
          - "recent_macro": "EIA crude draw; USD/INR rising"
          - "winning_strats": ["CrudeBreakout", ...]
          - "losing_strats": ["OldStrat", ...]

        Returns a validated strategy dict, or None on failure.
        """
        if not ANTHROPIC_API_KEY:
            log.warning("  [INVENTOR] ANTHROPIC_API_KEY not set — skipping LLM invention")
            return None

        if not _HAS_HTTPX:
            log.warning("  [INVENTOR] httpx not installed — LLM calls disabled")
            return None

        if not self._is_ready():
            log.debug("  [INVENTOR] LLM cooldown active")
            return None

        existing_names = [s.get("name", "") for s in existing_strategies]
        spot_lines = "\n".join(
            f"  {sym}: ₹{price:,.1f} ({market_context.get('day_changes', {}).get(sym, 0):+.2f}%)"
            for sym, price in market_context.get("spot_prices", {}).items()
        )

        known_signals = ", ".join(SIGNAL_TYPES)
        known_assets  = ", ".join(KNOWN_ASSETS)

        system_prompt = (
            "You are a quant strategy designer for MCX commodity futures (India). "
            "Your job is to invent a new intraday trading strategy for MCX. "
            "You must return ONLY a valid JSON object — no explanation, no markdown, "
            "no code fences. The JSON must match the schema exactly."
        )

        user_prompt = f"""
CURRENT MARKET SNAPSHOT ({datetime.now(IST).strftime('%H:%M IST')}):
{spot_lines if spot_lines else "  (no live data)"}

Session: {market_context.get("session", "unknown")}
India VIX: {market_context.get("india_vix", "unknown")}
Recent macro: {market_context.get("recent_macro", "none")}

TRADE HISTORY SUMMARY:
{trade_history_summary or "No recent trades yet."}

WINNING STRATEGIES TODAY: {market_context.get("winning_strats", [])}
LOSING STRATEGIES TODAY:  {market_context.get("losing_strats", [])}

EXISTING STRATEGY NAMES (avoid duplicating):
{existing_names}

AVAILABLE ASSETS: {known_assets}
AVAILABLE SIGNAL_TYPES: {known_signals}

TASK: Invent ONE new intraday MCX commodity strategy that is DIFFERENT from all existing ones.

Return ONLY this JSON (fill every field with real values, no placeholders):
{{
  "name": "ShortUniqueNameCamelCase",
  "symbols": ["ASSET1"] or ["ALL"],
  "direction": "BUY" or "SELL" or "BOTH",
  "session": "indian" or "us" or "eod" or "both",
  "signal_type": "ONE_OF_{known_signals}",
  "min_range_pct": <float 0.2–3.0>,
  "max_range_pos": <float 0.5–0.95>,
  "min_range_pos": <float 0.05–0.5>,
  "target_pct": <float 0.4–3.0>,
  "sl_pct": <float 0.2–1.5>,
  "max_hold_min": <int 10–120>,
  "min_score": <int 2–6>,
  "capital_pct": <float 0.10–0.35>,
  "trend_filter": "WITH" or "AGAINST",
  "iv_pref": "ANY" or "HIGH_VOLATILITY" or "LOW_VOLATILITY",
  "is_spread": false,
  "spread_legs": [],
  "spread_directions": [],
  "rationale": "1-2 sentence explanation of the edge",
  "tags": ["tag1", "tag2"]
}}
""".strip()

        try:
            self._last_call = time.time()
            self._call_count += 1

            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key":         ANTHROPIC_API_KEY,
                        "anthropic-version": "2023-06-01",
                        "content-type":      "application/json",
                    },
                    json={
                        "model":      self.MODEL,
                        "max_tokens": self.MAX_TOKENS,
                        "system":     system_prompt,
                        "messages":   [{"role": "user", "content": user_prompt}],
                    },
                )
                resp.raise_for_status()
                data = resp.json()

            raw_text = ""
            for block in data.get("content", []):
                if block.get("type") == "text":
                    raw_text += block.get("text", "")

            # Strip any accidental markdown fences
            raw_text = raw_text.strip()
            if raw_text.startswith("```"):
                raw_text = raw_text.split("```")[1]
                if raw_text.startswith("json"):
                    raw_text = raw_text[4:]

            strat_dict = json.loads(raw_text.strip())
            validated  = self._validate(strat_dict, existing_names)
            log.info(f"  [INVENTOR] LLM invented: {validated['name']} — {validated.get('rationale', '')[:80]}")
            return validated

        except json.JSONDecodeError as e:
            log.error(f"  [INVENTOR] LLM returned invalid JSON: {e}\nRaw: {raw_text[:200]}")
        except Exception as e:
            log.error(f"  [INVENTOR] LLM call failed: {e}")

        return None

    def _validate(self, d: dict, existing_names: list) -> dict:
        """Merge with defaults, type-coerce, and ensure uniqueness."""
        strat = dict(STRATEGY_DEFAULTS)
        strat.update({k: v for k, v in d.items() if k in STRATEGY_DEFAULTS})

        # Type coercions
        strat["min_range_pct"] = float(strat["min_range_pct"])
        strat["max_range_pos"] = float(strat["max_range_pos"])
        strat["min_range_pos"] = float(strat["min_range_pos"])
        strat["target_pct"]    = float(strat["target_pct"])
        strat["sl_pct"]        = float(strat["sl_pct"])
        strat["max_hold_min"]  = int(strat["max_hold_min"])
        strat["capital_pct"]   = float(strat["capital_pct"])
        strat["min_score"]     = int(strat["min_score"])

        # Bounds
        strat["capital_pct"] = min(max(strat["capital_pct"], 0.10), 0.40)
        strat["target_pct"]  = min(max(strat["target_pct"],  0.30), 5.0)
        strat["sl_pct"]      = min(max(strat["sl_pct"],      0.15), 2.0)

        # Ensure unique name
        base_name = strat.get("name", "Invented")
        name = base_name
        i = 2
        while name in existing_names:
            name = f"{base_name}{i}"
            i += 1
        strat["name"]       = name
        strat["created_at"] = datetime.now(IST).isoformat()
        strat["generation"] = 1
        strat["active"]     = True
        strat["trades"]     = 0
        strat["wins"]       = 0
        strat["total_pnl"]  = 0.0

        return strat

    def status(self) -> str:
        return (
            f"[INVENTOR] LLM calls: {self._call_count} | "
            f"last: {int(time.time() - self._last_call)}s ago | "
            f"ready: {self._is_ready()}"
        )


llm_inventor = LLMInventor()


# ═══════════════════════ EVOLUTION ENGINE ══════════════════════════════════════

class EvolutionEngine:
    """
    Kill / Breed / Mutate strategies using perf_tracker data.
    Mirrors the StrategyPool logic in agent.py but for commodities.
    """

    @staticmethod
    def _uid(strat: dict) -> str:
        seed = f"{strat['name']}{strat.get('generation', 0)}{time.time()}"
        return hashlib.md5(seed.encode()).hexdigest()[:6]

    @staticmethod
    def mutate(parent: dict, mutation_rate: float = 0.35) -> dict:
        """Create a mutated child from a single parent."""
        child = dict(parent)
        child["parent_names"] = [parent["name"]]
        child["generation"]   = parent.get("generation", 0) + 1
        child["trades"] = child["wins"] = 0
        child["total_pnl"] = child["peak_pnl"] = child["max_drawdown"] = 0.0
        child["created_at"] = datetime.now(IST).isoformat()

        mutated = []
        for gene in MUTABLE_GENES:
            if random.random() > mutation_rate:
                continue
            val = parent.get(gene)
            if gene == "direction":
                child[gene] = random.choice(["BUY", "SELL", "BOTH"])
            elif gene == "session":
                child[gene] = random.choice(["indian", "us", "eod", "both"])
            elif gene == "signal_type":
                child[gene] = random.choice(SIGNAL_TYPES)
            elif gene == "trend_filter":
                child[gene] = random.choice(["WITH", "AGAINST"])
            elif gene == "iv_pref":
                child[gene] = random.choice(["ANY", "HIGH_VOLATILITY", "LOW_VOLATILITY"])
            elif isinstance(val, float):
                noise = random.uniform(0.75, 1.30)
                child[gene] = round(val * noise, 3)
            elif isinstance(val, int):
                noise = random.randint(-5, 5)
                child[gene] = max(1, val + noise)
            mutated.append(gene)

        # Apply bounds after mutation
        child["capital_pct"] = min(max(child.get("capital_pct", 0.25), 0.10), 0.40)
        child["target_pct"]  = min(max(child.get("target_pct",  1.0),  0.30), 5.0)
        child["sl_pct"]      = min(max(child.get("sl_pct",      0.6),  0.15), 2.0)
        child["max_hold_min"]= max(child.get("max_hold_min", 45), 10)

        uid  = EvolutionEngine._uid(child)
        base = parent["name"].rstrip("0123456789")
        child["name"] = f"{base}_{uid}"
        child["rationale"] = (
            f"Mutation of {parent['name']} (gen{child['generation']}). "
            f"Mutated genes: {mutated}."
        )
        return child

    @staticmethod
    def crossbreed(a: dict, b: dict) -> dict:
        """Create a child that inherits genes from two parents."""
        child = {}
        for gene in MUTABLE_GENES:
            child[gene] = a.get(gene) if random.random() < 0.5 else b.get(gene)

        child["name"]         = f"Bred_{EvolutionEngine._uid({'name': a['name']+b['name']})}"
        child["generation"]   = max(a.get("generation", 0), b.get("generation", 0)) + 1
        child["parent_names"] = [a["name"], b["name"]]
        child["symbols"]      = a.get("symbols", ["ALL"])
        child["is_spread"]    = False
        child["spread_legs"]  = []
        child["spread_directions"] = []
        child["created_at"]   = datetime.now(IST).isoformat()
        child["active"]       = True
        child["trades"] = child["wins"] = 0
        child["total_pnl"] = child["peak_pnl"] = child["max_drawdown"] = 0.0
        child["rationale"] = (
            f"Crossbreed of {a['name']} × {b['name']} (gen{child['generation']})."
        )
        child["tags"] = list(set(a.get("tags", []) + b.get("tags", [])))

        # Merge defaults for any missing fields
        merged = dict(STRATEGY_DEFAULTS)
        merged.update(child)
        merged["capital_pct"] = min(max(merged.get("capital_pct", 0.25), 0.10), 0.40)
        return merged

    def evolve(self, strategies: list[dict], max_strats: int = MAX_STRATS) -> list[str]:
        """
        Run one evolution cycle.
        Returns list of action strings for logging / Telegram.
        """
        actions = []

        # 1. Kill weak strategies
        to_kill = []
        for s in strategies:
            name = s.get("name", "")
            if not s.get("active", True):
                continue
            if perf_tracker.should_kill(name):
                wr = perf_tracker.win_rate(name)
                n  = perf_tracker.trade_count(name)
                to_kill.append(name)
                actions.append(f"KILL {name} (WR={wr:.0%} n={n} < threshold)")
                log.warning(f"  [INVENTOR] KILL {name} — WR={wr:.0%} after {n} trades")
                strat_db.update(name, active=False)

        active_strats = [s for s in strategies if s.get("active", True) and s["name"] not in to_kill]
        n_active = len(active_strats)

        # 2. Breed top 2 performers
        if n_active >= 2 and n_active < max_strats:
            sorted_strats = sorted(
                [s for s in active_strats if perf_tracker.trade_count(s["name"]) >= 3],
                key=lambda s: perf_tracker.sharpe(s["name"]),
                reverse=True
            )
            if len(sorted_strats) >= 2:
                a, b = sorted_strats[0], sorted_strats[1]
                child = self.crossbreed(a, b)
                strat_db.add(child)
                actions.append(f"BREED {a['name']} × {b['name']} → {child['name']}")
                log.info(f"  [INVENTOR] BREED {a['name']} × {b['name']} → {child['name']}")

        # 3. Mutate a random active strategy
        if active_strats and n_active < max_strats:
            parent = random.choice(active_strats)
            mutant = self.mutate(parent)
            strat_db.add(mutant)
            actions.append(f"MUTATE {parent['name']} → {mutant['name']}")
            log.info(f"  [INVENTOR] MUTATE {parent['name']} → {mutant['name']}")

        return actions


evolution_engine = EvolutionEngine()


# ═══════════════════════ SEED STRATEGIES ══════════════════════════════════════

SEED_STRATEGIES: list[dict] = [
    # 1. Crude US Breakout
    {**STRATEGY_DEFAULTS,
     "name": "CrudeUSBreakout",
     "symbols": ["CRUDEOILM"],
     "direction": "BOTH",
     "session": "us",
     "signal_type": "US_MOMENTUM",
     "min_range_pct": 1.0,
     "target_pct": 1.5,
     "sl_pct": 0.8,
     "max_hold_min": 40,
     "min_score": 4,
     "capital_pct": 0.30,
     "trend_filter": "WITH",
     "generation": 0,
     "rationale": "Ride Crude Oil momentum 15 min after US open when range already > 1%",
     "tags": ["crude", "momentum", "us_session"]},

    # 2. Gold Mean Reversion
    {**STRATEGY_DEFAULTS,
     "name": "GoldMeanRev",
     "symbols": ["GOLDPETAL"],
     "direction": "BOTH",
     "session": "both",
     "signal_type": "MEAN_REVERT",
     "min_range_pct": 0.4,
     "target_pct": 0.5,
     "sl_pct": 0.35,
     "max_hold_min": 45,
     "min_score": 3,
     "capital_pct": 0.25,
     "trend_filter": "AGAINST",
     "generation": 0,
     "rationale": "Gold intraday extremes tend to mean-revert; fade day highs/lows",
     "tags": ["gold", "mean_reversion", "scalp"]},

    # 3. NatGas EIA Momentum
    {**STRATEGY_DEFAULTS,
     "name": "NatGasEIA",
     "symbols": ["NATGASMINI"],
     "direction": "BOTH",
     "session": "us",
     "signal_type": "INVENTORY_CRUDE",
     "min_range_pct": 2.0,
     "target_pct": 2.0,
     "sl_pct": 1.2,
     "max_hold_min": 30,
     "min_score": 5,
     "capital_pct": 0.20,
     "trend_filter": "WITH",
     "generation": 0,
     "rationale": "Post-EIA/NOAA weather spike momentum in NatGas US session",
     "tags": ["natgas", "news_driven", "us_session"]},

    # 4. Morning ORB All Commodities
    {**STRATEGY_DEFAULTS,
     "name": "MorningORB",
     "symbols": ["ALL"],
     "direction": "BOTH",
     "session": "indian",
     "signal_type": "BREAKOUT_VOL",
     "min_range_pct": 0.5,
     "target_pct": 0.8,
     "sl_pct": 0.5,
     "max_hold_min": 25,
     "min_score": 3,
     "capital_pct": 0.28,
     "trend_filter": "WITH",
     "generation": 0,
     "rationale": "Open Range Breakout 9–9:30 AM IST sets intraday bias",
     "tags": ["orb", "morning", "all_assets"]},

    # 5. Crude-Gold Divergence Spread
    {**STRATEGY_DEFAULTS,
     "name": "CrudeGoldSpread",
     "symbols": ["CRUDEOILM", "GOLDPETAL"],
     "direction": "BOTH",
     "session": "both",
     "signal_type": "SPREAD_INTER",
     "min_range_pct": 0.8,
     "target_pct": 1.0,
     "sl_pct": 0.6,
     "max_hold_min": 60,
     "min_score": 4,
     "capital_pct": 0.20,
     "is_spread": True,
     "spread_legs": ["CRUDEOILM", "GOLDPETAL"],
     "spread_directions": ["BUY", "SELL"],
     "trend_filter": "WITH",
     "generation": 0,
     "rationale": "Long Crude / Short Gold when risk-on divergence exceeds 2σ",
     "tags": ["spread", "divergence", "risk_on"]},

    # 6. End-of-Session Fade
    {**STRATEGY_DEFAULTS,
     "name": "EODFade",
     "symbols": ["ALL"],
     "direction": "BOTH",
     "session": "eod",
     "signal_type": "MEAN_REVERT",
     "min_range_pct": 1.0,
     "target_pct": 0.6,
     "sl_pct": 0.4,
     "max_hold_min": 20,
     "min_score": 3,
     "capital_pct": 0.22,
     "trend_filter": "AGAINST",
     "generation": 0,
     "rationale": "MIS squareoff before 11:30 PM creates predictable fade at day extremes",
     "tags": ["eod", "fade", "mean_reversion"]},

    # 7. VIX Gold Safe Haven
    {**STRATEGY_DEFAULTS,
     "name": "VIXGoldHedge",
     "symbols": ["GOLDPETAL"],
     "direction": "BUY",
     "session": "both",
     "signal_type": "VIX_SPIKE_GOLD",
     "min_range_pct": 0.3,
     "target_pct": 0.7,
     "sl_pct": 0.4,
     "max_hold_min": 60,
     "min_score": 3,
     "capital_pct": 0.20,
     "trend_filter": "WITH",
     "iv_pref": "HIGH_VOLATILITY",
     "generation": 0,
     "rationale": "Long Gold when VIX spikes above 18 — safe haven premium capture",
     "tags": ["gold", "vix", "hedge", "safe_haven"]},

    # 8. NatGas Seasonal Long
    {**STRATEGY_DEFAULTS,
     "name": "NatGasSeasonal",
     "symbols": ["NATGASMINI"],
     "direction": "BUY",
     "session": "us",
     "signal_type": "SEASONAL_NATGAS",
     "min_range_pct": 1.0,
     "target_pct": 1.5,
     "sl_pct": 1.0,
     "max_hold_min": 60,
     "min_score": 3,
     "capital_pct": 0.18,
     "trend_filter": "WITH",
     "generation": 0,
     "rationale": "Calendar month seasonal bias in NatGas (winter/summer demand peaks)",
     "tags": ["natgas", "seasonal", "calendar"]},
]


def _ensure_seeds():
    """Add seed strategies to DB if they don't exist yet."""
    existing = {s["name"] for s in strat_db.all()}
    added = 0
    for seed in SEED_STRATEGIES:
        if seed["name"] not in existing:
            s = {**STRATEGY_DEFAULTS, **seed}
            s.setdefault("created_at", datetime.now(IST).isoformat())
            strat_db.add(s)
            added += 1
    if added:
        log.info(f"  [INVENTOR] Seeded {added} initial strategies")


# ═══════════════════════ MAIN INVENTOR CLASS ═══════════════════════════════════

class StrategyInventor:
    """
    Top-level class wiring DB + LLM + Evolution together.
    agent.py interacts with the module-level `inventor` instance.
    """

    def __init__(self):
        _ensure_seeds()
        self._trades_since_evo = 0
        self._evo_every        = 10
        self._last_invent_ts   = 0.0

    # ── Public API ─────────────────────────────────────────────────────────────

    def active_strategies(self) -> list[dict]:
        """Return all active strategies for agent.py to use."""
        return strat_db.active()

    def get_strategy(self, name: str) -> dict | None:
        return strat_db.get(name)

    def record_trade(self, symbol: str, strategy_name: str, won: bool, pnl_pct: float):
        """Call after each commodity trade closes."""
        perf_tracker.record(strategy_name, won, pnl_pct)
        strat_db.record_trade(strategy_name, won, pnl_pct)
        self._trades_since_evo += 1

        if self._trades_since_evo >= self._evo_every:
            self._trades_since_evo = 0
            self._run_evolution()

    def best_strategy_for(self, symbol: str, direction: str, session: str) -> dict | None:
        """
        Return the highest-Sharpe active strategy that covers this symbol,
        direction, and session.  Falls back to first match.
        """
        candidates = []
        for strat in strat_db.active():
            syms = strat.get("symbols", ["ALL"])
            if "ALL" not in syms and symbol not in syms:
                continue
            sess = strat.get("session", "both")
            if sess != "both" and sess != session:
                continue
            d = strat.get("direction", "BOTH")
            if d != "BOTH" and d != direction:
                continue
            candidates.append(strat)

        if not candidates:
            return None

        return max(candidates, key=lambda s: perf_tracker.sharpe(s["name"]))

    async def maybe_invent(
        self,
        market_context: dict | None = None,
        force: bool = False,
    ) -> dict | None:
        """
        Invent a new strategy if conditions are met.
        Called periodically from agent.py's commodity loop.
        Returns the new strategy dict if invented, else None.
        """
        if strat_db.active_count() >= MAX_STRATS and not force:
            log.debug("  [INVENTOR] Max strategies reached — not inventing")
            return None

        if not force and (time.time() - self._last_invent_ts) < 3600:
            return None   # Max once per hour unless forced

        ctx = market_context or {}
        trade_summary = self._trade_history_summary()
        existing      = strat_db.all()

        new_strat = await llm_inventor.invent(ctx, existing, trade_summary)
        if new_strat:
            strat_db.add(new_strat)
            self._last_invent_ts = time.time()
            return new_strat

        return None

    def status(self) -> str:
        """One-line status for agent.py logs and Telegram."""
        active = strat_db.active()
        lines  = [f"[INVENTOR] {len(active)} active strategies"]
        for s in sorted(active, key=lambda x: perf_tracker.sharpe(x["name"]), reverse=True)[:5]:
            n    = s["name"]
            perf = perf_tracker.summary(n)
            lines.append(
                f"  {n:20s} WR={perf['wr']:.0%} n={perf['n']} "
                f"avg={perf['avg_pnl']:+.2f}% sharpe={perf['sharpe']:+.2f}"
            )
        lines.append(llm_inventor.status())
        return "\n".join(lines)

    def print_table(self):
        """Pretty-print strategy performance table to stdout."""
        active = strat_db.active()
        print(f"\n{'─'*90}")
        print(f"{'NAME':<22} {'SIGNAL':<18} {'DIR':<5} {'SES':<7} {'TGT':>5} {'SL':>4} "
              f"{'N':>4} {'WR':>6} {'SHARPE':>7} {'AVG PNL':>8}")
        print(f"{'─'*90}")
        for s in sorted(active, key=lambda x: x["name"]):
            nm = s["name"]
            p  = perf_tracker.summary(nm)
            print(
                f"{nm:<22} {s.get('signal_type','?'):<18} {s.get('direction','?'):<5} "
                f"{s.get('session','?'):<7} {s.get('target_pct',0):>5.2f} "
                f"{s.get('sl_pct',0):>4.2f} {p['n']:>4} {p['wr']:>6.0%} "
                f"{p['sharpe']:>7.2f} {p['avg_pnl']:>8.3f}%"
            )
        print(f"{'─'*90}\n")

    # ── Private helpers ────────────────────────────────────────────────────────

    def _run_evolution(self):
        active = strat_db.active()
        actions = evolution_engine.evolve(active)
        if actions:
            log.info("  [INVENTOR] Evolution: " + " | ".join(actions))

    def _trade_history_summary(self) -> str:
        """Summarise recent DB trades for the LLM prompt."""
        try:
            c = sqlite3.connect(DB)
            c.row_factory = sqlite3.Row
            rows = c.execute("""
                SELECT strategy, COUNT(*) n, SUM(won) wins,
                       ROUND(AVG(pnl_pct),2) avg_pnl
                FROM trades
                WHERE asset = 'commodity'
                  AND ts >= datetime('now', '-3 days')
                GROUP BY strategy
                ORDER BY avg_pnl DESC
                LIMIT 10
            """).fetchall()
            c.close()
            if not rows:
                return "No recent commodity trades."
            lines = [f"{r['strategy']:20s} n={r['n']} wr={r['wins']/r['n']:.0%} avg={r['avg_pnl']:+.2f}%"
                     for r in rows]
            return "\n".join(lines)
        except Exception:
            return "DB unavailable."


# ── Module-level singleton ──────────────────────────────────────────────────
inventor = StrategyInventor()


# ═══════════════════════ CLI ENTRY POINT ═══════════════════════════════════════

if __name__ == "__main__":
    import sys

    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s", datefmt="%H:%M:%S",
                        handlers=[logging.StreamHandler()])

    cmd = sys.argv[1] if len(sys.argv) > 1 else "status"

    if cmd == "status":
        inventor.print_table()
        print(inventor.status())

    elif cmd == "invent":
        print("Requesting LLM strategy invention...")
        ctx = {
            "spot_prices": {"CRUDEOILM": 6520, "GOLDPETAL": 7150, "NATGASMINI": 305},
            "day_changes": {"CRUDEOILM": +1.2, "GOLDPETAL": -0.3, "NATGASMINI": +2.8},
            "session": "us",
            "india_vix": 15.2,
            "recent_macro": "EIA crude draw 3.2 mmbbl; NOAA cold snap forecast",
            "winning_strats": ["CrudeUSBreakout"],
            "losing_strats":  ["NatGasEIA"],
        }
        result = asyncio.run(inventor.maybe_invent(ctx, force=True))
        if result:
            print(f"\n✅ Invented: {result['name']}")
            print(json.dumps(result, indent=2))
        else:
            print("❌ Invention failed (check ANTHROPIC_API_KEY or logs)")

    elif cmd == "evolve":
        print("Running one evolution cycle...")
        actions = evolution_engine.evolve(strat_db.active())
        if actions:
            for a in actions:
                print(f"  {a}")
        else:
            print("  No actions taken (not enough trades yet)")
        inventor.print_table()

    elif cmd == "reset":
        confirm = input("Delete all invented strategies? [y/N] ").strip().lower()
        if confirm == "y":
            STRAT_FILE.unlink(missing_ok=True)
            print("Cleared. Seeds will re-load on next run.")

    else:
        print(f"Unknown command: {cmd}")
        print("Usage: python3 strategy_inventor.py [status|invent|evolve|reset]")
