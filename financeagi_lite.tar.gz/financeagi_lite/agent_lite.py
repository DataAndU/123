#!/usr/bin/env python3
"""
FinanceAGI LITE — Mobile-Optimised Trading Agent
=================================================
Stripped from v17.2 for Termux/Android.

REMOVED (heavy load):
  ✗  trading_economics.py  — TradingEconomics API (optional macro)
  ✗  self_improve.py       — hyperparameter search, synthetic data aug
  ✗  web_search.py         — DuckDuckGo scraper (optional)
  ✗  alpha_signals.py      — FII/DII, GEX, OFI, PCR (optional signals)
  ✗  qwen_engine.py        — Ollama/Qwen local LLM (optional)
  ✗  strategy_inventor.py  — genetic strategy evolution (optional)
  ✗  options_strategy_inventor.py — same
  ✗  equity_strategy_inventor.py  — same
  ✗  strategy_master.py    — meta-controller (optional)
  ✗  ensemble_scorer.py    — LightGBM ensemble (optional)
  ✗  contextual_bandits.py — LinUCB (optional)
  ✗  regime_hmm.py         — HMM regime (optional)
  ✗  multileg.py           — already a stub, removed
  ✗  equity_intraday.py    — NSE equity module (disabled by default)
  ✗  commodity_options.py  — MCX energy options (disabled by default)
  ✗  backtest_inject.py    — backtest runner
  ✗  v14/v15/v16/v17 patch files

KEPT (core):
  ✓  commodity_futures.py  — MCX futures (GOLDPETAL, GOLD, SILVER, etc.)
  ✓  Pure-numpy NN         — 3-layer MLP, <200KB RAM
  ✓  RL Q-table            — simple tabular Q-learning
  ✓  Strategy pool         — JSON-backed, win-rate pruning
  ✓  Upstox v2 broker      — OAuth2 + paper mode
  ✓  Telegram alerts       — optional
  ✓  SQLite DB             — trade log + token store

REQUIREMENTS (lite):
  pip install httpx numpy upstox-python-sdk --break-system-packages

Usage:
  python3 agent_lite.py           # run (commodity mode)
  python3 agent_lite.py stats     # show performance
  python3 agent_lite.py reset     # wipe memory
"""

import asyncio, json, logging, math, os, pickle, random, re, sqlite3, sys, copy, time
from datetime import datetime, timezone, timedelta, time as dtime
from pathlib import Path
from collections import defaultdict

import numpy as np
import httpx

# ─────────────────────────── PATHS ───────────────────────────────────────────

BASE = Path(__file__).resolve().parent
IST  = timezone(timedelta(hours=5, minutes=30))
DB   = str(BASE / "data" / "v10.db")
NN_COM_F = str(BASE / "data" / "nn_commodity.pkl")
RL_F     = str(BASE / "data" / "rl.pkl")
ST_F     = str(BASE / "data" / "strats.json")

for d in ["data", "logs"]:
    (BASE / d).mkdir(parents=True, exist_ok=True)

# ─────────────────────────── .env LOADER ─────────────────────────────────────

ENV = {}
ef = BASE / ".env"
if ef.exists():
    for ln in ef.read_text().splitlines():
        ln = ln.strip()
        if ln and not ln.startswith("#") and "=" in ln:
            k, v = ln.split("=", 1)
            ENV[k.strip()] = v.strip()
            os.environ.setdefault(k.strip(), v.strip())

# ─────────────────────────── LOGGING ─────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(message)s",
    datefmt="%H:%M:%S",
    handlers=[logging.FileHandler(BASE / "logs" / "agent_lite.log")],
)
if sys.stdout.isatty():
    logging.getLogger().addHandler(logging.StreamHandler())
log = logging.getLogger("agi_lite")

VERSION = "lite-1.0"

# ─────────────────────────── CONFIG ──────────────────────────────────────────

PAPER  = ENV.get("PAPER_TRADING", "true").lower() == "true"
CAPITAL_OVERRIDE = float(ENV.get("CAPITAL", "0"))

C = {
    "target": 6.0, "sl": 5.0, "max_hold": 20, "max_trades": 10,
    "cool_n": 2, "cool_min": 5,
    "nn_thr": 0.50, "kelly": 0.20, "min_bet": 0.25, "max_bet": 0.60,
    "trail_on": 2.0, "trail_dist": 1.5,
    "rl_eps": 0.20, "rl_a": 0.15, "rl_g": 0.95,
    "evo_every": 15, "kill_wr": 65, "kill_n": 10, "max_strats": 12,
    "nn_retrain_every": 1, "nn_epochs_full": 300,
}

# ─────────────────────────── TELEGRAM ────────────────────────────────────────

TG_TOKEN = ENV.get("TG_BOT_TOKEN", ENV.get("TELEGRAM_TOKEN", ""))
TG_CHAT  = ENV.get("TG_CHAT_ID", ENV.get("TELEGRAM_CHAT_ID", ""))

async def tg(msg: str):
    if not TG_TOKEN or not TG_CHAT:
        return
    try:
        async with httpx.AsyncClient(timeout=8) as c:
            await c.post(
                f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
                json={"chat_id": TG_CHAT, "text": msg[:4000], "parse_mode": "HTML"},
            )
    except Exception as e:
        log.warning(f"TG error: {e}")

# ─────────────────────────── DATABASE ────────────────────────────────────────

def _db():
    c = sqlite3.connect(DB, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS trades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, instrument TEXT, direction TEXT,
        entry REAL, exit REAL, qty INTEGER,
        pnl REAL, won INTEGER, features TEXT,
        strategy TEXT, hold_min REAL, paper INTEGER
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS auth (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        provider TEXT, token TEXT, ts TEXT
    )""")
    c.commit()
    return c

# ─────────────────────────── FEATURE VECTOR ──────────────────────────────────

FN = [
    "price_pct_day", "volume_ratio", "atr_pct", "rsi_14",
    "ema5_ema20_ratio", "time_sin", "time_cos",
    "session_energy",   # morning(1) / afternoon(0.5) / evening(0) session weight
    "spread_pct",       # (high-low)/close % — intraday range proxy
    "log_volume",       # log(volume+1)
    "strategy_wr",      # strategy historical win rate
    "recent_dd",        # recent drawdown fraction
]
FEAT_DIM = len(FN)

def build_feats(inst: dict, pool_wr: float = 0.5, recent_dd: float = 0.0) -> np.ndarray:
    """Build FEAT_DIM feature vector from a commodity instrument snapshot."""
    now   = datetime.now(IST)
    h     = now.hour + now.minute / 60.0
    ltp   = inst.get("ltp", 0.0) or 1.0
    open_ = inst.get("open", ltp) or ltp
    high  = inst.get("high", ltp) or ltp
    low   = inst.get("low",  ltp) or ltp
    vol   = max(1, inst.get("volume", 1))
    avg_vol = max(1, inst.get("avg_volume", vol))
    atr   = inst.get("atr", ltp * 0.01)
    rsi   = inst.get("rsi", 50.0)
    ema5  = inst.get("ema5", ltp)
    ema20 = inst.get("ema20", ltp)

    # which MCX session: morning 09-12, afternoon 12-17, evening 17-23:30
    if   9  <= now.hour < 12: sess = 1.0
    elif 12 <= now.hour < 17: sess = 0.6
    else:                      sess = 0.3

    return np.array([
        (ltp - open_) / open_ * 100,           # price_pct_day
        math.log(vol / avg_vol + 1e-6),         # volume_ratio
        atr / ltp * 100,                        # atr_pct
        (rsi - 50) / 50,                        # rsi_14 normalised
        ema5 / max(ema20, 0.001) - 1.0,         # ema5/ema20 ratio
        math.sin(2 * math.pi * h / 24),         # time_sin
        math.cos(2 * math.pi * h / 24),         # time_cos
        sess,                                   # session_energy
        (high - low) / ltp * 100,               # spread_pct
        math.log(vol + 1),                      # log_volume
        pool_wr,                                # strategy win rate
        recent_dd,                              # drawdown
    ], dtype=np.float64)

# ─────────────────────────── NEURAL NET (pure numpy) ─────────────────────────

class NN:
    def __init__(self, dims=None):
        dims = dims or (FEAT_DIM, 24, 12, 1)
        self.dims = list(dims); self.nl = len(dims) - 1
        self.W = [np.random.randn(dims[i], dims[i+1]) * np.sqrt(2/dims[i]) for i in range(self.nl)]
        self.b = [np.zeros((1, dims[i+1])) for i in range(self.nl)]
        self.mW = [np.zeros_like(w) for w in self.W]; self.mb = [np.zeros_like(b) for b in self.b]
        self.vW = [np.zeros_like(w) for w in self.W]; self.vb = [np.zeros_like(b) for b in self.b]
        self.lr = 0.001; self.b1 = 0.9; self.b2 = 0.999; self.step = 0
        self.mu = np.zeros(dims[0]); self.var = np.ones(dims[0]); self.cnt = 0

    def _n(self, X): return (X - self.mu) / (np.sqrt(self.var) + 1e-8)
    def _us(self, X):
        for x in X:
            self.cnt += 1; d = x - self.mu; self.mu += d / self.cnt
            self.var += (d * (x - self.mu) - self.var) / self.cnt

    def predict(self, f) -> float:
        a = self._n(f.reshape(1, -1))
        for i in range(self.nl):
            z = a @ self.W[i] + self.b[i]
            a = np.maximum(0, z) if i < self.nl-1 else 1/(1+np.exp(-np.clip(z,-500,500)))
        return float(a[0, 0])

    def train(self, X, y, ep=100):
        self._us(X); Xn = self._n(X); m = len(X); loss = 0
        for _ in range(ep):
            a = Xn; acts = [Xn]; zs = []
            for i in range(self.nl):
                z = a @ self.W[i] + self.b[i]; zs.append(z)
                a = np.maximum(0, z) if i < self.nl-1 else 1/(1+np.exp(-np.clip(z,-500,500)))
                acts.append(a)
            p = np.clip(acts[-1], 1e-7, 1-1e-7)
            loss = -np.mean(y * np.log(p) + (1-y) * np.log(1-p))
            d = p - y
            for i in range(self.nl-1, -1, -1):
                dW = acts[i].T @ d / m; db = d.mean(0, keepdims=True); self.step += 1
                self.mW[i] = self.b1*self.mW[i]+(1-self.b1)*dW; self.mb[i] = self.b1*self.mb[i]+(1-self.b1)*db
                self.vW[i] = self.b2*self.vW[i]+(1-self.b2)*dW**2; self.vb[i] = self.b2*self.vb[i]+(1-self.b2)*db**2
                mh = self.mW[i]/(1-self.b1**self.step); bh = self.mb[i]/(1-self.b1**self.step)
                vh = self.vW[i]/(1-self.b2**self.step); vbh = self.vb[i]/(1-self.b2**self.step)
                self.W[i] -= self.lr*mh/(np.sqrt(vh)+1e-8); self.b[i] -= self.lr*bh/(np.sqrt(vbh)+1e-8)
                if i > 0: d = (d @ self.W[i].T) * (zs[i-1] > 0).astype(float)
        return loss

    def train1(self, f, outcome: float):
        self.train(f.reshape(1, -1), np.array([[outcome]]), ep=30)

    def save(self):
        pickle.dump({k: getattr(self, k) for k in
            ["W","b","mW","mb","vW","vb","mu","var","cnt","step","dims"]},
            open(NN_COM_F, "wb"))

    def load(self) -> bool:
        if not os.path.exists(NN_COM_F): return False
        try:
            d = pickle.load(open(NN_COM_F, "rb"))
            if d.get("dims") != list(self.dims): return False
            for k, v in d.items(): setattr(self, k, v)
            self.nl = len(self.dims) - 1
            return True
        except Exception as e:
            log.warning(f"NN load failed: {e}"); return False

# ─────────────────────────── RL Q-TABLE ──────────────────────────────────────

class RL:
    def __init__(self):
        self.Q: dict = {}; self.ep = 0; self.eps = C["rl_eps"]

    def _k(self, s, a): return (round(s,1), a)

    def act(self, score: float) -> str:
        if random.random() < self.eps: return random.choice(["buy","skip"])
        s = round(score, 1)
        return "buy" if self.Q.get((s,"buy"),0) >= self.Q.get((s,"skip"),0) else "skip"

    def update(self, score: float, action: str, reward: float):
        k = self._k(score, action); old = self.Q.get(k, 0)
        self.Q[k] = old + C["rl_a"] * (reward + C["rl_g"] * 0 - old)
        self.ep += 1
        self.eps = max(0.05, self.eps * 0.999)

    def save(self): pickle.dump({"Q": self.Q, "ep": self.ep, "eps": self.eps}, open(RL_F, "wb"))
    def load(self):
        if not os.path.exists(RL_F): return
        try:
            d = pickle.load(open(RL_F, "rb"))
            self.Q = d["Q"]; self.ep = d["ep"]; self.eps = d["eps"]
        except Exception as e:
            log.warning(f"RL load failed: {e}")

# ─────────────────────────── STRATEGY POOL ───────────────────────────────────

DEFAULT_STRATEGIES = [
    {"name": "TREND_FOLLOW",   "params": {"fast_ema": 5,  "slow_ema": 20, "rsi_lo": 40, "rsi_hi": 60}, "wins": 0, "trades": 0},
    {"name": "MEAN_REVERT",    "params": {"rsi_lo": 30,   "rsi_hi": 70,  "bb_mult": 2.0},              "wins": 0, "trades": 0},
    {"name": "BREAKOUT_VOL",   "params": {"vol_mult": 1.5,"ema_cross": 5},                              "wins": 0, "trades": 0},
    {"name": "VIX_SPIKE_GOLD", "params": {"vix_thr": 18, "instrument": "GOLDPETAL"},                   "wins": 0, "trades": 0},
    {"name": "US_MOMENTUM",    "params": {"session": "evening","instruments": ["CRUDEOILM","NATGASMINI"]}, "wins": 0, "trades": 0},
]

class StrategyPool:
    def __init__(self):
        self.strats: list = []
        self._load()

    def _load(self):
        if os.path.exists(ST_F):
            try:
                self.strats = json.loads(Path(ST_F).read_text())
                return
            except Exception: pass
        self.strats = copy.deepcopy(DEFAULT_STRATEGIES)
        self._save()

    def _save(self):
        Path(ST_F).write_text(json.dumps(self.strats, indent=2))

    def alive(self) -> list:
        return [s for s in self.strats if s.get("alive", True)]

    def record(self, name: str, won: bool):
        for s in self.strats:
            if s["name"] == name:
                s["trades"] += 1
                if won: s["wins"] += 1
                break
        self._prune(); self._save()

    def _prune(self):
        kill_wr = C["kill_wr"]; kill_n = C["kill_n"]
        for s in self.strats:
            if s["trades"] >= kill_n:
                wr = s["wins"] / s["trades"] * 100
                if wr < kill_wr: s["alive"] = False

    def best(self) -> dict | None:
        candidates = self.alive()
        if not candidates: return None
        scored = [(s["wins"]/max(1,s["trades"]), s) for s in candidates]
        scored.sort(key=lambda x: x[0], reverse=True)
        # explore with probability rl_eps
        if random.random() < C["rl_eps"]:
            return random.choice(candidates)
        return scored[0][1]

    def win_rate(self, name: str) -> float:
        for s in self.strats:
            if s["name"] == name:
                return s["wins"] / max(1, s["trades"])
        return 0.5

# ─────────────────────────── BROKER (Upstox v2) ──────────────────────────────

API = "https://api.upstox.com"

class Broker:
    def __init__(self):
        self.token = ENV.get("UPSTOX_ACCESS_TOKEN", "")
        self._client: httpx.AsyncClient | None = None
        try:
            c = _db()
            r = c.execute("SELECT token FROM auth WHERE provider='upstox' ORDER BY id DESC LIMIT 1").fetchone()
            if r and r[0]: self.token = r[0]
            c.close()
        except Exception as e:
            log.warning(f"Broker init: {e}")

    def _cli(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=API, headers={"Authorization": f"Bearer {self.token}"},
                timeout=10, http2=True,
            )
        return self._client

    async def close(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    async def get_funds(self) -> float:
        if PAPER:
            return CAPITAL_OVERRIDE or float(ENV.get("CAPITAL", "50000"))
        try:
            r = await self._cli().get("/v2/user/get-funds-and-margin?segment=COM")
            r.raise_for_status()
            d = r.json()
            return float(d.get("data", {}).get("commodity", {}).get("available_margin", 0))
        except Exception as e:
            log.warning(f"get_funds: {e}"); return 0.0

    async def get_ltp(self, instrument_key: str) -> float:
        if PAPER:
            # return a plausible simulated LTP (the system won't have real data in paper mode
            # unless Upstox market data is allowed without live trading)
            pass
        try:
            r = await self._cli().get(f"/v2/market-quote/ltp?instrument_key={instrument_key}")
            r.raise_for_status()
            data = r.json().get("data", {})
            key  = list(data.keys())[0] if data else None
            return float(data[key]["last_price"]) if key else 0.0
        except Exception as e:
            log.debug(f"get_ltp {instrument_key}: {e}"); return 0.0

    async def place_order(self, instrument_key: str, qty: int, side: str,
                          order_type="MARKET", paper=True) -> dict:
        if paper or PAPER:
            return {"status": "success", "data": {"order_id": f"P-{int(time.time())}"}}
        try:
            payload = {
                "quantity": qty, "product": "D", "validity": "DAY",
                "price": 0, "tag": "agi_lite", "instrument_token": instrument_key,
                "order_type": order_type, "transaction_type": side,
                "disclosed_quantity": 0, "trigger_price": 0, "is_amo": False,
                "slice": False,
            }
            r = await self._cli().post("/v2/order/place", json=payload)
            return r.json()
        except Exception as e:
            log.error(f"place_order: {e}"); return {"status": "error"}

# ─────────────────────────── STRATEGY INVENTOR ───────────────────────────────

try:
    from strategy_inventor import inventor, evolution_engine, strat_db, perf_tracker
    _INVENTOR = True
    log.info("strategy_inventor.py loaded — LLM evolution active")
except ImportError as _e:
    log.warning(f"strategy_inventor not loaded: {_e}")
    _INVENTOR = False
    inventor = None

# ─────────────────────────── MCX INSTRUMENT LOADER ───────────────────────────

try:
    from commodity_futures import (
        scan_commodities, buy_commodity, exit_commodity,
        mcx_is_open, mcx_force_exit_time, mcx_entry_allowed, mcx_inst,
    )
    COMMODITY_ENABLED = True
    log.info("commodity_futures.py loaded")
except ImportError as _e:
    log.warning(f"commodity_futures.py not found — MCX scan disabled ({_e})")
    COMMODITY_ENABLED = False

    # Minimal stubs so the rest of the file still imports cleanly
    async def scan_commodities(broker, cash): return []
    async def buy_commodity(broker, pick, paper=True): return {}
    async def exit_commodity(broker, key, qty, direction, paper=True): return {}
    def mcx_is_open() -> bool:
        now = datetime.now(IST); t = now.time()
        return dtime(9, 0) <= t <= dtime(23, 30) and now.weekday() < 5
    def mcx_force_exit_time() -> bool:
        return datetime.now(IST).time() >= dtime(23, 20)
    def mcx_entry_allowed() -> bool:
        t = datetime.now(IST).time()
        return dtime(9, 10) <= t <= dtime(22, 30)
    mcx_inst = {}

# ─────────────────────────── TRADE LOG ───────────────────────────────────────

def log_trade(inst: str, direction: str, entry: float, exit_p: float,
              qty: int, pnl: float, feats: np.ndarray, strat: str,
              hold_min: float):
    won = 1 if pnl > 0 else 0
    try:
        c = _db()
        c.execute("""INSERT INTO trades
            (ts,instrument,direction,entry,exit,qty,pnl,won,features,strategy,hold_min,paper)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", (
            datetime.now(IST).isoformat(), inst, direction, entry, exit_p,
            qty, pnl, won, json.dumps(feats.tolist()), strat, hold_min, int(PAPER)))
        c.commit(); c.close()
    except Exception as e:
        log.warning(f"log_trade: {e}")

def get_training_data():
    try:
        c = _db()
        rows = c.execute("SELECT features, won FROM trades WHERE features IS NOT NULL ORDER BY id DESC LIMIT 500").fetchall()
        c.close()
        feats, won = [], []
        for r in rows:
            f = json.loads(r["features"])
            if len(f) == FEAT_DIM:
                feats.append(f); won.append([r["won"]])
        if not feats: return None, None
        return np.array(feats, dtype=np.float64), np.array(won, dtype=np.float64)
    except Exception as e:
        log.warning(f"get_training_data: {e}"); return None, None

# ─────────────────────────── POSITION SIZING ─────────────────────────────────

def kelly_lots(cash: float, confidence: float, lot_margin: float) -> int:
    """Half-Kelly lot sizing, capped by config."""
    if lot_margin <= 0: return 0
    fraction = confidence * C["kelly"]
    fraction = max(C["min_bet"], min(C["max_bet"], fraction))
    budget   = cash * fraction
    lots     = int(budget / lot_margin)
    return max(1, lots)

# ─────────────────────────── MAIN AGENT LOOP ─────────────────────────────────

# Global state
nn        = NN()
rl        = RL()
pool      = StrategyPool()
position  = {}   # key → {pick, entry, qty, entry_time, strategy, feats, direction}
day_trades = 0
day_pnl   = 0.0
day_start_cash = 0.0

async def _retrain_nn():
    X, y = get_training_data()
    if X is None or len(X) < 5: return
    loss = nn.train(X, y, ep=C["nn_epochs_full"])
    nn.save()
    log.info(f"NN retrained on {len(X)} trades — loss={loss:.4f}")

async def _monitor_positions(broker: Broker):
    global day_pnl
    if not position: return
    for key in list(position.keys()):
        pos = position[key]
        ltp = await broker.get_ltp(key)
        if ltp <= 0: continue
        entry  = pos["entry"]
        direction = pos["direction"]
        pnl_pct = (ltp - entry) / entry * 100 * (1 if direction == "BUY" else -1)
        hold_min = (time.time() - pos["entry_time"]) / 60

        # Determine exit
        reason = None
        if pnl_pct >= C["target"]:                   reason = "TARGET"
        elif pnl_pct <= -C["sl"]:                    reason = "SL"
        elif hold_min >= C["max_hold"]:               reason = "MAX_HOLD"
        elif mcx_force_exit_time():                   reason = "EOD"

        if reason:
            qty = pos["qty"]
            exit_side = "SELL" if direction == "BUY" else "BUY"
            await exit_commodity(broker, key, qty, direction, paper=PAPER)
            lot_size = pos.get("lot_size", 1)
            pnl_rs   = (ltp - entry) * qty * lot_size * (1 if direction == "BUY" else -1)
            day_pnl += pnl_rs
            won      = pnl_rs > 0
            pool.record(pos["strategy"], won)
            if _INVENTOR:
                pnl_pct = pnl_rs / max(1, pos["entry"] * pos["qty"] * pos.get("lot_size", 1)) * 100
                inventor.record_trade(
                    pos.get("pick", {}).get("symbol", key.split("|")[-1]),
                    pos["strategy"], won, pnl_pct,
                )
            rl.update(pos["nn_score"], "buy", 1.0 if won else -1.0); rl.save()
            nn.train1(pos["feats"], 1.0 if won else 0.0); nn.save()
            log_trade(
                key.split("|")[-1], direction, entry, ltp, qty, pnl_rs,
                pos["feats"], pos["strategy"], hold_min,
            )
            del position[key]
            emoji = "✅" if won else "❌"
            await tg(
                f"{emoji} EXIT [{reason}] {key.split('|')[-1]} {direction}\n"
                f"Entry={entry:.2f} Exit={ltp:.2f} PnL=₹{pnl_rs:+.0f} "
                f"({'PAPER' if PAPER else 'LIVE'})"
            )
            log.info(f"EXIT {reason} {key} pnl=₹{pnl_rs:+.0f}")

async def _scan_and_enter(broker: Broker, cash: float):
    global day_trades, position
    if day_trades >= C["max_trades"]: return
    if not mcx_entry_allowed(): return
    if len(position) >= 2: return  # max 2 concurrent positions (mobile-safe)

    # Use inventor's active strategies if available, else fall back to pool
    if _INVENTOR:
        now_h = datetime.now(IST).hour
        session = "indian" if now_h < 12 else ("us" if now_h >= 17 else "indian")
        strat = inventor.pick_strategy(symbol=None, direction="BOTH", session=session)
        if strat is None:
            strat = pool.best()   # fallback if inventor has no match
    else:
        strat = pool.best()
    if not strat: return

    try:
        picks = await scan_commodities(broker, cash)
    except Exception as e:
        log.warning(f"scan_commodities: {e}"); return

    if not picks: return

    # score each pick with NN
    best_pick = None; best_score = -1.0
    for pick in picks[:5]:
        if pick.get("instrument_key") in position: continue
        wr   = pool.win_rate(strat["name"])
        dd_f = max(0.0, -day_pnl) / max(1.0, day_start_cash)
        fvec = build_feats(pick, wr, dd_f)
        score = nn.predict(fvec)
        if score > best_score:
            best_score = score; best_pick = pick
            best_pick["_fvec"] = fvec

    if best_pick is None or best_score < C["nn_thr"]: return

    action = rl.act(round(best_score, 1))
    if action != "buy":
        log.info(f"RL skip {best_pick.get('symbol','?')} score={best_score:.2f}")
        return

    lot_margin = best_pick.get("margin_per_lot", 8000)
    qty        = kelly_lots(cash, best_score, lot_margin)
    if qty <= 0: return

    direction  = best_pick.get("direction", "BUY")
    key        = best_pick["instrument_key"]

    result = await buy_commodity(broker, best_pick, paper=PAPER)
    if result.get("status") != "success":
        log.warning(f"Entry failed: {result}"); return

    ltp = best_pick.get("ltp", 0.0)
    position[key] = {
        "pick": best_pick, "entry": ltp, "qty": qty,
        "entry_time": time.time(), "strategy": strat["name"],
        "feats": best_pick["_fvec"], "nn_score": best_score,
        "direction": direction, "lot_size": best_pick.get("lot_size", 1),
    }
    day_trades += 1
    await tg(
        f"🔵 ENTRY {best_pick.get('symbol','?')} {direction} x{qty} lots\n"
        f"Price={ltp:.2f} NN={best_score:.0%} Strat={strat['name']} "
        f"({'PAPER' if PAPER else 'LIVE'})"
    )
    log.info(f"ENTRY {key} {direction} qty={qty} score={best_score:.2f} strat={strat['name']}")

async def _daily_reset():
    global day_trades, day_pnl, day_start_cash
    now = datetime.now(IST)
    if now.hour == 9 and now.minute < 5:
        broker_tmp = Broker()
        day_start_cash = await broker_tmp.get_funds()
        await broker_tmp.close()
        day_trades = 0; day_pnl = 0.0
        log.info(f"Daily reset — capital=₹{day_start_cash:,.0f}")
        await tg(f"🌅 FinanceAGI Lite {VERSION} started | Capital=₹{day_start_cash:,.0f} | {'PAPER' if PAPER else 'LIVE'}")

async def _show_stats():
    try:
        c = _db()
        rows = c.execute("""
            SELECT COUNT(*) total, SUM(won) wins, SUM(pnl) total_pnl,
                   AVG(pnl) avg_pnl, MAX(pnl) best, MIN(pnl) worst
            FROM trades WHERE paper=?
        """, (int(PAPER),)).fetchone()
        c.close()
        if not rows or not rows[0]: print("No trades yet."); return
        total, wins, tpnl, apnl, best, worst = rows
        wr = (wins or 0) / max(1, total) * 100
        print(f"\n{'='*40}")
        print(f"FinanceAGI Lite {VERSION} — {'PAPER' if PAPER else 'LIVE'}")
        print(f"{'='*40}")
        print(f"Trades : {total}  Wins: {int(wins or 0)} ({wr:.1f}%)")
        print(f"Total PnL : ₹{(tpnl or 0):+,.0f}")
        print(f"Avg PnL   : ₹{(apnl or 0):+,.0f}")
        print(f"Best      : ₹{(best or 0):+,.0f}")
        print(f"Worst     : ₹{(worst or 0):+,.0f}")
        print(f"{'='*40}\n")
        print("Strategy pool:")
        for s in pool.strats:
            wr_s = s["wins"]/max(1,s["trades"])*100
            flag = "✓" if s.get("alive", True) else "✗"
            print(f"  {flag} {s['name']:25s}  {s['trades']:3d}T  {wr_s:5.1f}%WR")
        if _INVENTOR:
            print()
            inventor.print_table()
    except Exception as e:
        print(f"Stats error: {e}")

async def main():
    global day_start_cash

    if len(sys.argv) > 1:
        if sys.argv[1] == "stats":   await _show_stats(); return
        if sys.argv[1] == "reset":
            for f in [NN_COM_F, RL_F, ST_F, DB]:
                if os.path.exists(f): os.remove(f)
            print("Reset complete."); return

    nn.load(); rl.load()
    broker = Broker()
    day_start_cash = await broker.get_funds()

    log.info(f"FinanceAGI Lite {VERSION} | PAPER={PAPER} | Capital=₹{day_start_cash:,.0f}")
    await tg(f"🚀 FinanceAGI Lite {VERSION} | Capital=₹{day_start_cash:,.0f} | {'PAPER' if PAPER else 'LIVE'}")

    trade_count_since_retrain = 0

    while True:
        try:
            await _daily_reset()
            now = datetime.now(IST)

            if not mcx_is_open():
                log.debug("MCX closed — sleeping 5 min")
                await asyncio.sleep(300)
                continue

            cash = await broker.get_funds()
            await _monitor_positions(broker)
            await _scan_and_enter(broker, cash)

            # retrain NN periodically
            trade_count_since_retrain += 1
            if trade_count_since_retrain >= C["nn_retrain_every"] * 5:
                await _retrain_nn()
                trade_count_since_retrain = 0

            # run strategy inventor / evolution every 30 minutes
            if _INVENTOR and int(time.time()) % 1800 < 60:
                # evolve (kill/breed/mutate) — pure local, no API call
                evolution_engine.evolve(strat_db.active())
                # maybe invent a new strategy via Claude API (only if key set, once/hour)
                ctx = {
                    "session": "indian" if datetime.now(IST).hour < 12 else "us",
                    "winning_strats": [s["name"] for s in strat_db.active()
                                       if perf_tracker.win_rate(s["name"]) > 0.6],
                    "losing_strats":  [s["name"] for s in strat_db.active()
                                       if perf_tracker.win_rate(s["name"]) < 0.4],
                }
                new_s = await inventor.maybe_invent(ctx)
                if new_s:
                    await tg(f"🧬 New strategy invented: <b>{new_s['name']}</b>\n"
                             f"{new_s.get('rationale','')}")

            await asyncio.sleep(60)  # 1-minute tick (mobile-friendly)

        except KeyboardInterrupt:
            break
        except Exception as e:
            log.exception(f"Main loop error: {e}")
            await asyncio.sleep(30)

    await broker.close()
    log.info("Agent stopped.")

if __name__ == "__main__":
    asyncio.run(main())
