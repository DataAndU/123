"""
commodity_futures.py — MCX Commodity Futures Module for FinanceAGI v17.2
Trades NEXT expiry futures only — never enters near expiry.

Scope: FUTURES ONLY (all 8 commodities)
For MCX options on CRUDEOILM / NATGASMINI → see commodity_options.py

Supported commodities (v17.2):
  GOLDPETAL  — Gold Petal      (10g/lot,  ~₹6,000-8,000 margin)
  GOLD       — Gold 1kg        (1kg/lot,  ~₹45,000-60,000 margin)
  SILVER     — Silver Mini     (5kg/lot,  ~₹30,000-40,000 margin)
  CRUDEOILM  — Crude Oil Mini  (10 bbl,   ~₹7,000-12,000 margin)
  NATGASMINI — Nat Gas Mini    (250 mmBtu,~₹3,000-5,000 margin)
  COPPER     — Copper Mini     (2.5kg,    ~₹8,000-12,000 margin)
  ALUMINIUM  — Aluminium Mini  (5kg,      ~₹4,000-6,000 margin)
  ZINC       — Zinc Mini       (1MT,      ~₹5,000-8,000 margin)

Strategy Catalogue (v17.2 — 12 strategies):
  1.  TREND_FOLLOW      — 5/20 EMA crossover intraday momentum
  2.  MEAN_REVERT       — RSI extremes + Bollinger Band touch
  3.  BREAKOUT_VOL      — Open Range Breakout (first 30 min) + volume confirm
  4.  US_MOMENTUM       — Crude/NatGas first-15min US session momentum
  5.  GOLD_HEDGE        — Long gold on VIX spike or USD/INR weakness
  6.  SPREAD_INTER      — GOLD vs CRUDEOILM ratio trade on 2σ deviation
  7.  SEASONAL_NATGAS   — Calendar month weather-driven NatGas bias
  8.  INVENTORY_CRUDE   — EIA inventory surprise reversal (Wednesday)
  9.  VIX_SPIKE_GOLD    — Long GOLDPETAL when India VIX spikes > 18
  10. METAL_COMPLEX     — Unified Copper/Zinc/Al base-metal basket trade
  11. CARRY_ROLL        — Calendar spread carry capture (near vs next)
  12. VOLATILITY_CRUSH  — Fade ≥2% single-candle extreme spike

Rules:
  - NEXT expiry only — avoids rollover squeeze and expiry volatility
  - Minimum DTE = 5 days; force exit if DTE ≤ 3 days
  - MIS intraday — all positions squared off by MCX close (11:30 PM IST)
  - Long AND Short — trend-following both ways
  - Capital-adaptive lot sizing — never > 60% on one trade

MCX Options (CRUDEOILM + NATGASMINI):
  → Handled by commodity_options.py (10 strategies, BS pricing, Greeks)
  → Import: from commodity_options import scan_energy_options, mcx_opt_inst
"""

import asyncio, gzip, json, logging, math, time, random
from datetime import datetime, timezone, timedelta, time as dtime
from pathlib import Path
from collections import deque

log = logging.getLogger("agi.commodity")
IST = timezone(timedelta(hours=5, minutes=30))

# ═══════════════════════ COMMODITY DEFINITIONS ═══════════════════════

COMMODITY_META = {
    "GOLDPETAL": {
        "name": "Gold Petal",
        "lot_size": 10,
        "tick_size": 1.0,
        "min_capital": 6000,
        "max_capital": 40000,
        "volatility_pct": 0.8,
        "target_pct": 0.6,
        "sl_pct": 0.4,
        "max_hold_min": 60,
        "session": "both",
        "corr_asset": "USD",
        "strategies": ["TREND_FOLLOW", "MEAN_REVERT", "VIX_SPIKE_GOLD", "GOLD_HEDGE"],
        "asset_class": "precious_metal",
    },
    "GOLD": {
        "name": "Gold 1kg",
        "lot_size": 1,
        "tick_size": 1.0,
        "min_capital": 45000,
        "max_capital": 200000,
        "volatility_pct": 0.8,
        "target_pct": 0.5,
        "sl_pct": 0.35,
        "max_hold_min": 90,
        "session": "both",
        "corr_asset": "USD",
        "strategies": ["TREND_FOLLOW", "GOLD_HEDGE", "SPREAD_INTER", "CARRY_ROLL"],
        "asset_class": "precious_metal",
    },
    "SILVER": {
        "name": "Silver Mini",
        "lot_size": 5,
        "tick_size": 1.0,
        "min_capital": 30000,
        "max_capital": 150000,
        "volatility_pct": 1.5,
        "target_pct": 0.9,
        "sl_pct": 0.55,
        "max_hold_min": 60,
        "session": "both",
        "corr_asset": "USD",
        "strategies": ["TREND_FOLLOW", "MEAN_REVERT", "GOLD_HEDGE"],
        "asset_class": "precious_metal",
    },
    "CRUDEOILM": {
        "name": "Crude Oil Mini",
        "lot_size": 10,
        "tick_size": 1.0,
        "min_capital": 7000,
        "max_capital": 50000,
        "volatility_pct": 2.0,
        "target_pct": 1.0,
        "sl_pct": 0.6,
        "max_hold_min": 45,
        "session": "both",
        "corr_asset": "USD",
        "strategies": ["TREND_FOLLOW", "BREAKOUT_VOL", "US_MOMENTUM",
                       "INVENTORY_CRUDE", "SPREAD_INTER", "VOLATILITY_CRUSH"],
        "asset_class": "energy",
    },
    "NATGASMINI": {
        "name": "Nat Gas Mini",
        "lot_size": 250,
        "tick_size": 0.1,
        "min_capital": 3000,
        "max_capital": 25000,
        "volatility_pct": 3.0,
        "target_pct": 1.5,
        "sl_pct": 0.8,
        "max_hold_min": 40,
        "session": "us",
        "corr_asset": "WEATHER",
        "strategies": ["US_MOMENTUM", "SEASONAL_NATGAS", "VOLATILITY_CRUSH", "MEAN_REVERT"],
        "asset_class": "energy",
    },
    "COPPER": {
        "name": "Copper Mini",
        "lot_size": 2500,
        "tick_size": 0.05,
        "min_capital": 8000,
        "max_capital": 60000,
        "volatility_pct": 1.2,
        "target_pct": 0.7,
        "sl_pct": 0.45,
        "max_hold_min": 60,
        "session": "both",
        "corr_asset": "CHINA_PMI",
        "strategies": ["TREND_FOLLOW", "BREAKOUT_VOL", "METAL_COMPLEX", "MEAN_REVERT"],
        "asset_class": "base_metal",
    },
    "ALUMINIUM": {
        "name": "Aluminium Mini",
        "lot_size": 5000,
        "tick_size": 0.05,
        "min_capital": 4000,
        "max_capital": 30000,
        "volatility_pct": 1.0,
        "target_pct": 0.6,
        "sl_pct": 0.40,
        "max_hold_min": 75,
        "session": "both",
        "corr_asset": "CHINA_PMI",
        "strategies": ["TREND_FOLLOW", "METAL_COMPLEX", "MEAN_REVERT"],
        "asset_class": "base_metal",
    },
    "ZINC": {
        "name": "Zinc Mini",
        "lot_size": 1000,
        "tick_size": 0.05,
        "min_capital": 5000,
        "max_capital": 35000,
        "volatility_pct": 1.3,
        "target_pct": 0.75,
        "sl_pct": 0.50,
        "max_hold_min": 60,
        "session": "both",
        "corr_asset": "CHINA_PMI",
        "strategies": ["TREND_FOLLOW", "METAL_COMPLEX", "BREAKOUT_VOL"],
        "asset_class": "base_metal",
    },
}

MCX_OPEN         = dtime(9, 0)
MCX_CLOSE        = dtime(23, 25)
MCX_NO_ENTRY     = dtime(23, 10)
US_SESSION_START = dtime(18, 30)
ORB_WINDOW_END   = dtime(9, 30)

MIN_DTE_ENTRY  = 5
FORCE_EXIT_DTE = 3

# Seasonal NatGas monthly bias: +1 long, -1 short, 0 neutral
NATGAS_SEASONAL = {1:+1, 2:+1, 3:-1, 4:-1, 5:0, 6:+1,
                   7:+1, 8:+1, 9:-1, 10:0, 11:+1, 12:+1}

# ═══════════════════════ STRATEGY CATALOGUE ═══════════════════════

STRATEGY_CATALOGUE = {
    "TREND_FOLLOW": {
        "name": "EMA Trend Follow",
        "description": "5/20 EMA crossover intraday momentum — long when fast>slow, short when fast<slow",
        "min_capital": 3000,
        "preferred_assets": ["GOLDPETAL", "CRUDEOILM", "COPPER", "ZINC"],
        "session": "both",
        "hold_min": 45,
        "target_multiplier": 1.0,
        "sl_multiplier": 1.0,
        "score_bonus": 0,
    },
    "MEAN_REVERT": {
        "name": "RSI Mean Reversion",
        "description": "RSI ≤25 → BUY; RSI ≥75 → SELL; confirmed by Bollinger Band touch",
        "min_capital": 3000,
        "preferred_assets": ["GOLDPETAL", "SILVER", "NATGASMINI", "COPPER", "ALUMINIUM"],
        "session": "both",
        "hold_min": 30,
        "target_multiplier": 0.7,
        "sl_multiplier": 0.8,
        "score_bonus": 1,
    },
    "BREAKOUT_VOL": {
        "name": "Open Range Breakout",
        "description": "First 30-min high/low defines range. Break with volume>1.5x avg required",
        "min_capital": 5000,
        "preferred_assets": ["CRUDEOILM", "COPPER", "ZINC"],
        "session": "morning",
        "hold_min": 60,
        "target_multiplier": 1.5,
        "sl_multiplier": 1.0,
        "score_bonus": 2,
    },
    "US_MOMENTUM": {
        "name": "US Session Momentum",
        "description": "Crude/NatGas directional trade 15 min after US open (6:30 PM IST)",
        "min_capital": 5000,
        "preferred_assets": ["CRUDEOILM", "NATGASMINI"],
        "session": "us",
        "hold_min": 40,
        "target_multiplier": 1.2,
        "sl_multiplier": 1.0,
        "score_bonus": 2,
    },
    "GOLD_HEDGE": {
        "name": "Gold Safe-Haven Hedge",
        "description": "Long GOLD/GOLDPETAL when India VIX > 16 OR USD/INR rises > 0.3%",
        "min_capital": 6000,
        "preferred_assets": ["GOLDPETAL", "GOLD", "SILVER"],
        "session": "both",
        "hold_min": 90,
        "target_multiplier": 0.8,
        "sl_multiplier": 0.6,
        "score_bonus": 1,
    },
    "SPREAD_INTER": {
        "name": "Inter-Commodity Spread",
        "description": "GOLD vs CRUDEOILM ratio trade — fade when ratio deviates >2σ from 30-day mean",
        "min_capital": 15000,
        "preferred_assets": ["GOLD", "CRUDEOILM"],
        "session": "both",
        "hold_min": 120,
        "target_multiplier": 0.6,
        "sl_multiplier": 0.8,
        "score_bonus": 0,
    },
    "SEASONAL_NATGAS": {
        "name": "NatGas Seasonal Bias",
        "description": "Weather-driven directional bias by calendar month. Winter long, spring short.",
        "min_capital": 3000,
        "preferred_assets": ["NATGASMINI"],
        "session": "us",
        "hold_min": 60,
        "target_multiplier": 1.0,
        "sl_multiplier": 1.0,
        "score_bonus": 1,
    },
    "INVENTORY_CRUDE": {
        "name": "EIA Inventory Reversal",
        "description": "Wednesday ~8:30 PM IST: EIA crude draw→long, build→short",
        "min_capital": 7000,
        "preferred_assets": ["CRUDEOILM"],
        "session": "us",
        "hold_min": 30,
        "target_multiplier": 1.5,
        "sl_multiplier": 1.2,
        "score_bonus": 3,
    },
    "VIX_SPIKE_GOLD": {
        "name": "VIX Spike Gold Long",
        "description": "Long GOLDPETAL when India VIX spikes intraday above 18 — fear premium capture",
        "min_capital": 6000,
        "preferred_assets": ["GOLDPETAL"],
        "session": "both",
        "hold_min": 45,
        "target_multiplier": 0.9,
        "sl_multiplier": 0.7,
        "score_bonus": 2,
    },
    "METAL_COMPLEX": {
        "name": "Base Metal Complex",
        "description": "Unified Cu/Zn/Al trade when basket moves >0.8%. China macro driven.",
        "min_capital": 8000,
        "preferred_assets": ["COPPER", "ZINC", "ALUMINIUM"],
        "session": "both",
        "hold_min": 60,
        "target_multiplier": 1.1,
        "sl_multiplier": 1.0,
        "score_bonus": 1,
    },
    "CARRY_ROLL": {
        "name": "Calendar Roll Carry",
        "description": "Capture basis between near and far contract on abnormal spread",
        "min_capital": 45000,
        "preferred_assets": ["GOLD"],
        "session": "both",
        "hold_min": 180,
        "target_multiplier": 0.4,
        "sl_multiplier": 0.5,
        "score_bonus": 0,
    },
    "VOLATILITY_CRUSH": {
        "name": "Intraday Volatility Crush",
        "description": "Mean-revert after ≥2% single-candle spike on thin liquidity",
        "min_capital": 5000,
        "preferred_assets": ["CRUDEOILM", "NATGASMINI"],
        "session": "both",
        "hold_min": 20,
        "target_multiplier": 0.5,
        "sl_multiplier": 0.6,
        "score_bonus": 1,
    },
}

# ═══════════════════════ CHARGES ═══════════════════════

class CommodityCharges:
    @staticmethod
    def calculate(buy_price, sell_price, qty):
        buy_val  = buy_price * qty
        sell_val = sell_price * qty
        turnover = buy_val + sell_val
        brokerage = 40
        ctt       = sell_val * 0.0001
        exchange  = turnover * 0.000026
        sebi      = turnover * 0.000001
        stamp     = buy_val  * 0.00002
        gst       = (brokerage + exchange + sebi) * 0.18
        total = brokerage + ctt + exchange + gst + sebi + stamp
        gross = (sell_price - buy_price) * qty
        return {
            "total_charges": round(total, 2),
            "gross_pnl":     round(gross, 2),
            "net_pnl":       round(gross - total, 2),
            "breakeven_pct": round(total / max(1, buy_val) * 100, 3),
            "brokerage":     brokerage,
            "ctt":           round(ctt, 2),
        }

    @staticmethod
    def breakeven_pct(price, qty):
        val = price * qty
        total  = 40 + val * 0.0001 + val * 2 * 0.000026 + val * 0.00002
        total += (40 + val * 2 * 0.000026) * 0.18
        return round(total / max(1, val) * 100, 3)

    @staticmethod
    def is_profitable(price, target_pct, qty):
        sell = price * (1 + target_pct / 100)
        r = CommodityCharges.calculate(price, sell, qty)
        return r["net_pnl"] > 0, r

comm_charges = CommodityCharges()

# ═══════════════════════ STRATEGY SIGNAL LIBRARY ═══════════════════════

class StrategySignals:

    @staticmethod
    def ema(series, period):
        if len(series) < period:
            return series[-1] if series else 0.0
        k = 2.0 / (period + 1)
        e = series[0]
        for v in series[1:]:
            e = v * k + e * (1 - k)
        return e

    @staticmethod
    def rsi(closes, period=14):
        if len(closes) < period + 1:
            return 50.0
        gains, losses = [], []
        for i in range(1, len(closes)):
            d = closes[i] - closes[i-1]
            gains.append(max(d, 0)); losses.append(max(-d, 0))
        ag = sum(gains[-period:]) / period
        al = sum(losses[-period:]) / period
        if al == 0: return 100.0
        return round(100 - (100 / (1 + ag / al)), 2)

    @staticmethod
    def bollinger(closes, period=20, mult=2.0):
        if len(closes) < period:
            m = closes[-1]; return {"upper": m*1.01, "mid": m, "lower": m*0.99}
        w = closes[-period:]
        m = sum(w) / period
        std = math.sqrt(sum((x-m)**2 for x in w) / period)
        return {"upper": m + mult*std, "mid": m, "lower": m - mult*std}

    @staticmethod
    def trend_follow_signal(candles):
        if len(candles) < 20: return {"direction": "SKIP", "strength": 0}
        closes = [c["close"] for c in candles]
        e5  = StrategySignals.ema(closes[-30:], 5)
        e20 = StrategySignals.ema(closes[-30:], 20)
        sp  = abs(e5 - e20) / max(e20, 1) * 100
        direction = "BUY" if e5 > e20 else "SELL"
        strength = 1 + (1 if sp > 0.3 else 0) + (1 if sp > 0.6 else 0)
        return {"direction": direction, "strength": strength, "ema5": e5, "ema20": e20}

    @staticmethod
    def mean_revert_signal(candles):
        if len(candles) < 20: return {"direction": "SKIP", "strength": 0}
        closes = [c["close"] for c in candles]
        rsi_val = StrategySignals.rsi(closes[-20:])
        bb  = StrategySignals.bollinger(closes[-20:])
        ltp = closes[-1]
        if rsi_val <= 25 and ltp <= bb["lower"] * 1.005:
            return {"direction": "BUY",  "strength": 3, "rsi": rsi_val}
        if rsi_val <= 30 and ltp <= bb["lower"] * 1.01:
            return {"direction": "BUY",  "strength": 2, "rsi": rsi_val}
        if rsi_val >= 75 and ltp >= bb["upper"] * 0.995:
            return {"direction": "SELL", "strength": 3, "rsi": rsi_val}
        if rsi_val >= 70 and ltp >= bb["upper"] * 0.990:
            return {"direction": "SELL", "strength": 2, "rsi": rsi_val}
        return {"direction": "SKIP", "strength": 0, "rsi": rsi_val}

    @staticmethod
    def breakout_vol_signal(candles, orb_high, orb_low, current_vol, avg_vol):
        ltp = candles[-1]["close"] if candles else 0
        if ltp <= 0 or orb_high <= orb_low: return {"direction": "SKIP", "strength": 0}
        vol_ratio = current_vol / max(avg_vol, 1)
        if ltp > orb_high and vol_ratio >= 1.5:
            return {"direction": "BUY",  "strength": min(3, int(vol_ratio)), "vol_ratio": vol_ratio}
        if ltp < orb_low  and vol_ratio >= 1.5:
            return {"direction": "SELL", "strength": min(3, int(vol_ratio)), "vol_ratio": vol_ratio}
        return {"direction": "SKIP", "strength": 0}

    @staticmethod
    def us_momentum_signal(candles):
        now = datetime.now(IST); t = now.time()
        if not (dtime(18, 30) <= t <= dtime(19, 0)):
            return {"direction": "SKIP", "strength": 0, "reason": "outside_us_window"}
        if len(candles) < 5: return {"direction": "SKIP", "strength": 0}
        closes = [c["close"] for c in candles[-10:]]
        mom = (closes[-1] - closes[0]) / max(closes[0], 1) * 100
        if mom > 0.4:  return {"direction": "BUY",  "strength": 2 + (1 if mom > 0.8 else 0)}
        if mom < -0.4: return {"direction": "SELL", "strength": 2 + (1 if mom < -0.8 else 0)}
        return {"direction": "SKIP", "strength": 0}

    @staticmethod
    def gold_hedge_signal(vix, usd_inr_chg_pct):
        score = 0
        if vix > 18:              score += 2
        elif vix > 16:            score += 1
        if usd_inr_chg_pct > 0.3: score += 2
        elif usd_inr_chg_pct > 0.1: score += 1
        if score >= 2: return {"direction": "BUY", "strength": min(score, 3)}
        return {"direction": "SKIP", "strength": 0}

    @staticmethod
    def seasonal_natgas_signal():
        month = datetime.now(IST).month
        bias  = NATGAS_SEASONAL.get(month, 0)
        if bias == 0: return {"direction": "SKIP", "strength": 0}
        return {"direction": "BUY" if bias > 0 else "SELL", "strength": 1, "month": month}

    @staticmethod
    def inventory_crude_signal(eia_draw_mmbbl):
        now = datetime.now(IST)
        if now.weekday() != 2:
            return {"direction": "SKIP", "strength": 0, "reason": "not_wednesday"}
        t = now.time()
        if not (dtime(20, 15) <= t <= dtime(20, 45)):
            return {"direction": "SKIP", "strength": 0, "reason": "outside_eia_window"}
        if abs(eia_draw_mmbbl) < 1.0:
            return {"direction": "SKIP", "strength": 0, "reason": "small_surprise"}
        direction = "BUY" if eia_draw_mmbbl > 0 else "SELL"
        strength  = 2 if abs(eia_draw_mmbbl) > 3 else 1
        return {"direction": direction, "strength": strength, "eia_draw": eia_draw_mmbbl}

    @staticmethod
    def vix_spike_gold_signal(vix, prev_vix):
        if vix > 18 and vix - prev_vix > 1.0:
            return {"direction": "BUY", "strength": 2 + (1 if vix > 22 else 0)}
        return {"direction": "SKIP", "strength": 0}

    @staticmethod
    def metal_complex_signal(copper_chg, zinc_chg, aluminium_chg):
        basket = (copper_chg + zinc_chg + aluminium_chg) / 3
        if basket > 0.8:  return {"direction": "BUY",  "strength": 2 + (1 if basket > 1.5 else 0)}
        if basket < -0.8: return {"direction": "SELL", "strength": 2 + (1 if basket < -1.5 else 0)}
        return {"direction": "SKIP", "strength": 0}

    @staticmethod
    def volatility_crush_signal(candles):
        if len(candles) < 3: return {"direction": "SKIP", "strength": 0}
        pc = candles[-2]["close"]; cc = candles[-1]["close"]
        spike_pct = (cc - pc) / max(pc, 1) * 100
        if spike_pct >= 2.0:  return {"direction": "SELL", "strength": 2, "spike_pct": spike_pct}
        if spike_pct <= -2.0: return {"direction": "BUY",  "strength": 2, "spike_pct": spike_pct}
        return {"direction": "SKIP", "strength": 0}

sig_lib = StrategySignals()

# ═══════════════════════ INSTRUMENT KEY MANAGER ═══════════════════════

class MCXInstruments:
    INSTRUMENTS_URL = "https://assets.upstox.com/market-quote/instruments/exchange/MCX.json.gz"

    def __init__(self):
        self.keys = {}; self.expiry = {}; self.dte = {}
        self.lot  = {}; self.tick   = {}; self.last_refresh = 0
        self._cache_path = Path(__file__).resolve().parent / "data" / "mcx_keys.json"

    async def refresh(self, broker):
        now_ts = time.time()
        if now_ts - self.last_refresh < 3600 * 8: return
        try:
            import httpx
            async with httpx.AsyncClient(timeout=20) as client:
                r   = await client.get(self.INSTRUMENTS_URL, headers={"User-Agent": "Mozilla/5.0"})
                raw = gzip.decompress(r.content)
                data = json.loads(raw)
            self._cache_path.parent.mkdir(parents=True, exist_ok=True)
            json.dump(data, open(self._cache_path, "w"))
            log.info(f"  MCX: Downloaded {len(data)} instruments")
            self._parse(data); self.last_refresh = now_ts
        except Exception as e:
            log.error(f"  MCX instruments download failed: {e}")
            self._load_cache()

    def _load_cache(self):
        try:
            if self._cache_path.exists():
                self._parse(json.load(open(self._cache_path)))
        except Exception as e:
            log.error(f"  MCX cache load failed: {e}")

    def _parse(self, data):
        today_ms   = datetime.now(IST).timestamp() * 1000
        today      = datetime.now(IST).replace(hour=0, minute=0, second=0, microsecond=0)
        min_dte_ms = (today + timedelta(days=MIN_DTE_ENTRY)).timestamp() * 1000
        by_symbol  = {}
        for inst in data:
            if inst.get("instrument_type") != "FUT": continue
            if inst.get("segment") != "MCX_FO": continue
            sym = inst.get("underlying_symbol", "")
            if sym not in COMMODITY_META: continue
            if inst.get("expiry", 0) <= today_ms: continue
            by_symbol.setdefault(sym, []).append(inst)
        for sym, contracts in by_symbol.items():
            contracts.sort(key=lambda x: x["expiry"])
            eligible = [c for c in contracts if c["expiry"] > min_dte_ms]
            if not eligible:
                log.warning(f"  MCX {sym}: No eligible contract"); continue
            chosen = eligible[0]
            exp_dt_check = datetime.fromtimestamp(chosen["expiry"]/1000, tz=IST)
            dte_check = (exp_dt_check.date() - datetime.now(IST).date()).days
            if dte_check <= MIN_DTE_ENTRY + 2 and len(eligible) >= 2:
                chosen = eligible[1]
            exp_dt   = datetime.fromtimestamp(chosen["expiry"]/1000, tz=IST)
            dte_days = (exp_dt.date() - datetime.now(IST).date()).days
            self.keys[sym]   = chosen["instrument_key"]
            self.expiry[sym] = exp_dt
            self.dte[sym]    = dte_days
            self.lot[sym]    = chosen.get("lot_size", COMMODITY_META[sym]["lot_size"])
            self.tick[sym]   = chosen.get("tick_size", COMMODITY_META[sym]["tick_size"])
            log.info(f"  MCX {sym}: {chosen['trading_symbol']} DTE={dte_days}")

    def get_key(self, sym): return self.keys.get(sym, "")
    def get_dte(self, sym): return self.dte.get(sym, 999)
    def is_tradeable(self, sym): return self.get_dte(sym) > FORCE_EXIT_DTE
    def available(self): return [s for s in self.keys if self.keys[s] and self.is_tradeable(s)]

mcx_inst = MCXInstruments()

# ═══════════════════════ STRATEGY-AWARE MARKET SCANNER ═══════════════════════

async def scan_commodities(broker, cash, batch_size=5,
                            vix=14.0, usd_inr_chg_pct=0.0,
                            eia_draw_mmbbl=0.0, candle_cache=None):
    """
    Strategy-aware MCX commodity scanner (v16).
    Evaluates all applicable strategies per symbol, picks highest-scoring.
    """
    available = mcx_inst.available()
    if not available:
        log.warning("  MCX: No instruments loaded — call mcx_inst.refresh() first")
        return []

    now        = datetime.now(IST)
    us_session = now.time() >= US_SESSION_START
    is_morning = now.time() <= ORB_WINDOW_END
    candle_cache = candle_cache or {}
    opportunities = []

    for sym in available[:batch_size]:
        key  = mcx_inst.get_key(sym)
        if not key: continue
        meta = COMMODITY_META.get(sym, {})
        lot_size = mcx_inst.lot.get(sym, meta.get("lot_size", 1))
        min_cap  = meta.get("min_capital", 10000)
        if cash < min_cap: continue

        try:
            ltp_data = await broker._get(f"/v2/market-quote/ltp?instrument_key={key}")
            ltp = 0
            for v in ltp_data.get("data", {}).values():
                ltp = v.get("last_price", 0)
                if ltp > 0: break
            if ltp <= 0: continue

            ohlc_data = await broker._get(f"/v2/market-quote/ohlc?instrument_key={key}&interval=1d")
            ohlc = {}
            for v in ohlc_data.get("data", {}).values():
                ohlc = v.get("ohlc", {})
                if ohlc: break

            day_open  = ohlc.get("open", ltp)
            day_high  = ohlc.get("high", ltp)
            day_low   = ohlc.get("low",  ltp)
            day_range = day_high - day_low if day_high > day_low else 0.01

            day_chg_pct    = (ltp - day_open) / max(0.01, day_open) * 100
            range_pct      = day_range / max(0.01, ltp) * 100
            range_position = (ltp - day_low) / max(0.01, day_range)

            contract_value = ltp * lot_size
            margin_needed  = round(contract_value * 0.12, 2)
            if cash * 0.30 < margin_needed: continue

            be_pct = comm_charges.breakeven_pct(ltp, lot_size)
            if be_pct > meta.get("volatility_pct", 1.0) * 0.60: continue

            # ── Evaluate all strategies ───────────────────────────────
            candles = candle_cache.get(sym, [])
            best_strat = None; best_dir = "SKIP"; best_score = 0; best_sig = {}

            for sid in meta.get("strategies", ["TREND_FOLLOW"]):
                strat = STRATEGY_CATALOGUE.get(sid, {})
                if cash < strat.get("min_capital", 3000): continue
                ss = strat.get("session", "both")
                if ss == "morning" and not is_morning: continue
                if ss == "us"      and not us_session: continue

                sig = {"direction": "SKIP", "strength": 0}

                if   sid == "TREND_FOLLOW":    sig = sig_lib.trend_follow_signal(candles)
                elif sid == "MEAN_REVERT":     sig = sig_lib.mean_revert_signal(candles)
                elif sid == "BREAKOUT_VOL":
                    vol = ohlc.get("volume", 1000)
                    sig = sig_lib.breakout_vol_signal(candles, day_high, day_low, vol, vol*0.7)
                elif sid == "US_MOMENTUM":     sig = sig_lib.us_momentum_signal(candles)
                elif sid == "GOLD_HEDGE":      sig = sig_lib.gold_hedge_signal(vix, usd_inr_chg_pct)
                elif sid == "SEASONAL_NATGAS": sig = sig_lib.seasonal_natgas_signal()
                elif sid == "INVENTORY_CRUDE": sig = sig_lib.inventory_crude_signal(eia_draw_mmbbl)
                elif sid == "VIX_SPIKE_GOLD":  sig = sig_lib.vix_spike_gold_signal(vix, vix*0.95)
                elif sid == "METAL_COMPLEX":
                    sig = sig_lib.metal_complex_signal(day_chg_pct, day_chg_pct*0.9, day_chg_pct*0.8)
                elif sid == "VOLATILITY_CRUSH": sig = sig_lib.volatility_crush_signal(candles)

                if sig["direction"] == "SKIP": continue
                ss_score = sig["strength"] + strat.get("score_bonus", 0)
                if ss_score > best_score:
                    best_score = ss_score; best_strat = sid
                    best_dir   = sig["direction"]; best_sig = sig

            # Fallback heuristic
            if not best_strat or best_dir == "SKIP":
                if day_chg_pct > 0.3 and range_position < 0.70:  best_dir = "BUY"
                elif day_chg_pct < -0.3 and range_position > 0.30: best_dir = "SELL"
                elif range_position < 0.35: best_dir = "BUY"
                elif range_position > 0.65: best_dir = "SELL"
                else: best_dir = "BUY"
                best_strat = "TREND_FOLLOW"

            score = best_score
            if range_pct > 0.5: score += 1
            if range_pct > 1.0: score += 1
            if abs(day_chg_pct) > 0.3: score += 1
            if be_pct < 0.15: score += 2
            if score < 3: continue

            strat_info = STRATEGY_CATALOGUE.get(best_strat, {})
            opportunities.append({
                "symbol":        sym,
                "name":          meta.get("name", sym),
                "key":           key,
                "ltp":           ltp,
                "lot_size":      lot_size,
                "direction":     best_dir,
                "score":         score,
                "strategy":      best_strat,
                "strategy_name": strat_info.get("name", best_strat),
                "signal_data":   best_sig,
                "day_change_pct":round(day_chg_pct, 2),
                "range_pct":     round(range_pct, 2),
                "range_position":round(range_position, 2),
                "margin_needed": margin_needed,
                "contract_value":round(contract_value, 2),
                "breakeven_pct": be_pct,
                "dte":           mcx_inst.get_dte(sym),
                "asset":         "commodity",
                "asset_class":   meta.get("asset_class", "unknown"),
                "target_pct":    meta.get("target_pct", 1.0) * strat_info.get("target_multiplier", 1.0),
                "sl_pct":        meta.get("sl_pct", 0.6) * strat_info.get("sl_multiplier", 1.0),
                "max_hold_min":  strat_info.get("hold_min", meta.get("max_hold_min", 45)),
                "session":       meta.get("session", "both"),
            })

        except Exception as e:
            log.error(f"  MCX scan {sym}: {e}")

    opportunities.sort(key=lambda x: x["score"], reverse=True)
    return opportunities

# ═══════════════════════ ORDER EXECUTION ═══════════════════════

async def buy_commodity(broker, pick, paper=True):
    if paper:
        return {"status": "success", "data": {"order_ids": [f"P-COMM-{int(time.time())}"]}}
    return await broker._post("/v3/order/place", {
        "quantity":         pick.get("qty", pick["lot_size"]),
        "product":          "I", "validity": "DAY", "price": 0,
        "instrument_token": pick["key"], "order_type": "MARKET",
        "transaction_type": pick["direction"],
        "disclosed_quantity": 0, "trigger_price": 0, "is_amo": False, "slice": True,
    })

async def exit_commodity(broker, key, qty, entry_direction, paper=True):
    exit_dir = "SELL" if entry_direction == "BUY" else "BUY"
    if paper:
        return {"status": "success", "data": {"order_ids": [f"P-COMM-X-{int(time.time())}"]}}
    return await broker._post("/v3/order/place", {
        "quantity":         qty, "product": "I", "validity": "DAY", "price": 0,
        "instrument_token": key, "order_type": "MARKET",
        "transaction_type": exit_dir,
        "disclosed_quantity": 0, "trigger_price": 0, "is_amo": False, "slice": True,
    })

# ═══════════════════════ SESSION HELPERS ═══════════════════════

def mcx_is_open():
    now = datetime.now(IST)
    if now.weekday() >= 5: return False
    return MCX_OPEN <= now.time() <= MCX_CLOSE

def mcx_entry_allowed():
    now = datetime.now(IST)
    if now.weekday() >= 5: return False
    return MCX_OPEN <= now.time() < MCX_NO_ENTRY

def mcx_force_exit_time():
    return datetime.now(IST).time() >= dtime(23, 20)

def mcx_best_session(symbol):
    meta    = COMMODITY_META.get(symbol, {})
    session = meta.get("session", "both")
    if session == "both": return True
    if session == "us":   return datetime.now(IST).time() >= US_SESSION_START
    return True

# ═══════════════════════ INFO HELPERS ═══════════════════════

def describe_options_module() -> str:
    """Cross-reference to commodity_options.py."""
    return (
        "MCX Options (CRUDEOILM + NATGASMINI): see commodity_options.py\n"
        "  Import: from commodity_options import scan_energy_options, mcx_opt_inst\n"
        "  10 strategies: strangle, bull/bear spread, straddle, IV crush, seasonal, ratio"
    )


def describe_commodity(cash):
    lines = [f"\nMCX Commodity Futures v16 — Capital: ₹{cash:,.0f}",
             f"Loaded instruments: {list(mcx_inst.keys.keys())}",
             f"Active strategies: {len(STRATEGY_CATALOGUE)}"]
    for sym, meta in COMMODITY_META.items():
        key    = mcx_inst.get_key(sym)
        dte    = mcx_inst.get_dte(sym)
        status = "✓" if cash >= meta["min_capital"] and key else ("✗ No key" if not key else "✗ Low cap")
        strats = ",".join(meta.get("strategies", []))
        lines.append(f"  {status} {sym:12s} {meta['name']:18s} min=₹{meta['min_capital']:>7,} [{strats}]")
    lines.append("")
    lines.append(describe_options_module())
    return "\n".join(lines)

def list_strategies():
    lines = ["\nCommodity Strategies (v16):"]
    for sid, s in STRATEGY_CATALOGUE.items():
        lines.append(f"  [{sid}] {s['name']}")
        lines.append(f"    {s['description']}")
        lines.append(f"    Assets: {', '.join(s['preferred_assets'])} | Session: {s['session']} | Hold: {s['hold_min']}min")
    return "\n".join(lines)


if __name__ == "__main__":
    print("MCX Commodity Futures Module v16")
    print(f"Symbols: {list(COMMODITY_META.keys())}")
    print(list_strategies())
