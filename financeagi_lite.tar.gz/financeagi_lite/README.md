# FinanceAGI Lite

Stripped-down version of FinanceAGI v17.2 optimised for **Termux / Android**.

## What was removed

| Module | Why removed | RAM saved |
|---|---|---|
| `trading_economics.py` | External macro API, rarely decisive | ~5 MB |
| `self_improve.py` | Hyperparameter search, synthetic data | ~3 MB |
| `web_search.py` | DuckDuckGo scraper | ~1 MB |
| `alpha_signals.py` | FII/DII, GEX, OFI (needs API keys) | ~2 MB |
| `qwen_engine.py` | Ollama/Qwen LLM (needs 4 GB RAM) | **~4 GB** |
| `strategy_inventor.py` + variants | Genetic evolution (CPU heavy) | ~20 MB |
| `strategy_master.py` | Meta-controller (adds latency) | ~5 MB |
| `ensemble_scorer.py` | LightGBM (large C library) | ~50 MB |
| `contextual_bandits.py` | LinUCB (merged into RL) | ~2 MB |
| `regime_hmm.py` | hmmlearn (needs scikit-learn) | ~40 MB |
| `equity_intraday.py` | NSE equity (keep if needed) | optional |
| `commodity_options.py` | MCX options (keep if needed) | optional |
| `backtest_inject.py` | Offline only | ~5 MB |
| `v14/v15/v16/v17 patches` | Already merged | — |
| `multileg.py` | Already a stub | — |

## What is kept

- **`agent_lite.py`** — full trading loop (MCX commodity futures)
- **`commodity_futures.py`** — 12 strategies, 8 instruments
- **Pure-numpy NN** — 3-layer MLP, <200 KB RAM
- **RL Q-table** — tabular Q-learning, instant on mobile
- **Strategy pool** — JSON-backed, win-rate pruning
- **Upstox v2 broker** — OAuth2 + paper mode
- **Telegram alerts** — optional

## Install (Termux)

```bash
pkg update && pkg install python git
pip install httpx[http2] numpy upstox-python-sdk --break-system-packages

# Optional speedups
pip install uvloop --break-system-packages
```

## Setup

```bash
cp .env.example .env
nano .env   # fill in UPSTOX_ACCESS_TOKEN, TG_BOT_TOKEN, TG_CHAT_ID
```

## Run

```bash
python agent_lite.py          # start trading
python agent_lite.py stats    # performance report
python agent_lite.py reset    # wipe memory and restart fresh
```

## Memory footprint

| | Full v17.2 | Lite |
|---|---|---|
| Python deps | ~450 MB | ~45 MB |
| Peak RAM | ~800 MB | ~80 MB |
| Startup time | ~12 s | ~2 s |

## Re-adding modules

If you want to re-add a module, just copy it from the v17.2 archive and import
it in `agent_lite.py`. All modules from v17.2 remain compatible since the DB
schema and broker interface are unchanged.
