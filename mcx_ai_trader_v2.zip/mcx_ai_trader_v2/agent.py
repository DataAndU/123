"""
agent.py — MCX AI Trading Agent v2
Orchestrates: broker → instruments (live master) → v17 strategies → regime →
              bandits → ensemble learning → risk (ATR+Kelly) → orders → notifier

New from v17.2:
  - MCXInstruments live gzip download → real instrument keys
  - 9-strategy catalogue with session awareness
  - HMM regime detection (BULL/BEAR/CHOP) → adaptive SL/TP/size
  - LinUCB contextual bandits → strategy arm selection
  - LightGBM + Rolling WR ensemble scorer
  - ATR-based dynamic stops
  - VIX-Kelly position sizing
  - AI strategy inventor (Claude API) — invents/kills strategies automatically
  - MCX charge calculation in PnL
  - DTE safety: skip if DTE ≤ 3, prefer next expiry
"""

import logging
import math
import os
import sys
import threading
import time
from datetime import datetime, timezone, timedelta
from typing import Dict, Optional

import schedule

import config
from core.broker     import UpstoxClient
from core.instruments import InstrumentRegistry
from core.risk        import RiskManager, Position
from core.learning    import LearningEngine, signals_to_features, FEATURE_NAMES
from core.regime      import regime_detector, get_atr_tracker
from core.bandits     import bandit, build_context
from core.notifier    import (notify_trade_entry, notify_trade_exit,
                               notify_signal, notify_daily_summary, notify_error)
from data.market_data  import MarketDataAggregator
from strategies.signals import evaluate_strategies, full_ta_summary
from strategies.options_strategies import OptionsStrategyEngine
from strategies.inventor import inventor

os.makedirs("logs", exist_ok=True)
os.makedirs("data", exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s  %(message)s",
    handlers=[
        logging.FileHandler("logs/agent.log"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("agent")

IST = timezone(timedelta(hours=5, minutes=30))


class MCXTradingAgent:
    """
    Autonomous MCX Commodity Trading Agent v2.
    Trades GOLDPETAL, CRUDEOILM, NATGASMINI futures + energy options.
    """

    def __init__(self):
        logger.info("=" * 60)
        logger.info("MCX AI Trading Agent v2 initializing ...")
        logger.info(f"Paper: {config.PAPER_TRADING}  Capital: ₹{config.CAPITAL:,.0f}")
        logger.info("=" * 60)

        self.broker    = UpstoxClient()
        self.registry  = InstrumentRegistry()
        self.risk      = RiskManager(config.CAPITAL)
        self.learning  = LearningEngine()
        self.mdata     = MarketDataAggregator()
        self.opt_eng   = OptionsStrategyEngine(self.registry)

        self._running      = False
        self._tick_lock    = threading.Lock()
        self._open_fvecs: Dict[str, object] = {}  # trade_id → feature_vec
        self._prev_ltps:  Dict[str, float]  = {}  # for regime update
        self._candle_cache: Dict[str, list] = {}   # symbol → candles

        # Load persisted models
        bandit.load()
        try:
            from core.regime import regime_detector as rd
            rd.load()
        except Exception: pass

    # ── Startup ───────────────────────────────────────────────────────────────

    def start(self):
        if not self.broker.login():
            logger.error("Login failed.")
            return

        logger.info("Refreshing instrument master ...")
        self.registry.refresh(config.FUTURES_SYMBOLS)

        schedule.every(config.TICK_INTERVAL).seconds.do(self._on_tick)
        schedule.every().day.at("08:55").do(self._on_pre_market)
        schedule.every().day.at("09:00").do(self._on_market_open)
        schedule.every().day.at("23:30").do(self._on_market_close)
        schedule.every(4).hours.do(lambda: self.registry.refresh(config.FUTURES_SYMBOLS))

        self._running = True
        logger.info("Agent running.")
        while self._running:
            schedule.run_pending()
            time.sleep(1)

    def stop(self):
        self._running = False
        bandit.save()
        try: regime_detector.save()
        except Exception: pass
        logger.info("Agent stopped.")

    # ── Market lifecycle ──────────────────────────────────────────────────────

    def _on_pre_market(self):
        logger.info("Pre-market: refreshing instruments + resetting day.")
        self.registry.refresh(config.FUTURES_SYMBOLS)
        self.risk.reset_day()

    def _on_market_open(self):
        logger.info("Market open.")

    def _on_market_close(self):
        logger.info("Market close — closing all positions.")
        self._close_all_positions("EOD")
        stats = self.learning.get_stats()
        notify_daily_summary(stats)
        bandit.save()
        logger.info(bandit.status_line())
        try:
            logger.info(regime_detector.status_line())
        except Exception: pass

    # ── Main tick ─────────────────────────────────────────────────────────────

    def _on_tick(self):
        now = datetime.now(IST)
        h, m = now.hour, now.minute
        open_  = (h > config.MCX_OPEN_HOUR or
                  (h == config.MCX_OPEN_HOUR and m >= config.MCX_OPEN_MIN))
        closed = (h > config.MCX_CLOSE_HOUR or
                  (h == config.MCX_CLOSE_HOUR and m >= config.MCX_CLOSE_MIN))
        if not open_ or closed:
            return

        with self._tick_lock:
            self._monitor_positions()
            for symbol in config.FUTURES_SYMBOLS:
                try:
                    self._evaluate_symbol(symbol)
                except Exception as e:
                    logger.error(f"Error evaluating {symbol}: {e}")
                    notify_error(f"Eval {symbol}: {e}")

    # ── Position monitoring ───────────────────────────────────────────────────

    def _monitor_positions(self):
        for symbol, pos in list(self.risk.open_positions.items()):
            ltp = self.broker.get_ltp(pos.instrument_key)
            if not ltp: continue

            # Feed regime detector
            prev = self._prev_ltps.get(symbol, ltp)
            regime_detector.update(ltp, prev)
            self._prev_ltps[symbol] = ltp

            # Feed ATR tracker
            atr_t = get_atr_tracker(symbol)
            atr_t.feed(ltp)
            candles = self._candle_cache.get(symbol, [])
            if candles:
                from strategies.signals import _atr_series
                atr_vals = _atr_series(candles, 14)
                atr_val  = atr_vals[-1] if atr_vals and not math.isnan(atr_vals[-1]) else ltp * 0.01
                self.risk.update_trailing_stop(symbol, ltp, atr_val)

            trigger = self.risk.check_stops(symbol, ltp)
            if trigger:
                logger.info(f"{symbol} hit {trigger} @ {ltp}")
                self._execute_exit(symbol, ltp, reason=trigger)

    # ── Symbol evaluation ─────────────────────────────────────────────────────

    def _evaluate_symbol(self, symbol: str):
        if not self.risk.can_trade(symbol):
            return
        if not self.registry.is_tradeable(symbol):
            logger.debug(f"{symbol}: DTE too low — skipping")
            return

        instr_key = self.registry.futures_key(symbol)
        candles   = self._get_candles(instr_key)
        if not candles or len(candles) < 30:
            return
        self._candle_cache[symbol] = candles

        ltp = float(candles[-1][4])

        # Day OHLC
        day_high = max(float(c[2]) for c in candles[-30:])
        day_low  = min(float(c[3]) for c in candles[-30:])
        day_open = float(candles[-30][1]) if len(candles) >= 30 else ltp
        volume   = sum(float(c[5]) for c in candles[-5:])

        # v17 multi-strategy evaluation
        strat_eval = evaluate_strategies(
            symbol=symbol, candles=candles,
            ltp=ltp, day_high=day_high, day_low=day_low, day_open=day_open,
            volume=volume,
            available_capital=self.risk.available,
        )

        # Full TA for AI + LGBM features
        ta = full_ta_summary(candles)

        # LinUCB strategy selection
        now     = datetime.now(IST)
        context = build_context(
            spots=[ltp], last_iv=20.0, news_score=0.0,
            losses=max(0, self.risk.daily_pnl < 0),
            start_cash=self.risk._day_start_cap, cur_cash=self.risk.available,
            hour=now.hour + now.minute / 60.0, weekday=now.weekday(),
        )
        applicable_strats = config.COMMODITY_META.get(symbol, {}).get("strategies", ["TREND_FOLLOW"])
        bandit_strategy, _, _ = bandit.select(context, applicable_strats)

        # Use bandit strategy if score from it is lower — fall back to multi-strategy winner
        chosen_strategy = bandit_strategy or strat_eval["strategy"]

        # Feature vector for LGBM
        feat_vec = signals_to_features(
            signals=ta["signals"],
            strategy=chosen_strategy,
            extra={
                "ltp": ltp, "score": ta["score"],
                "day_chg_pct": strat_eval["day_change_pct"],
                "range_pct": strat_eval["range_pct"],
                "range_pos": strat_eval["range_position"],
                "strength": strat_eval["signal_data"].get("strength", 1),
                "is_morning": now.time().hour < 10,
                "is_us": now.time().hour >= 18,
                "prev_wr": self.learning._rolling.wr(chosen_strategy),
                "hour": now.hour + now.minute / 60.0,
            },
            regime=regime_detector.current_regime,
        )

        # Ensemble probability
        ensemble_p = self.learning.ensemble_score(feat_vec, chosen_strategy, ta["score"])

        # AI opinion (every 5th tick to save API calls)
        ai_op = "NEUTRAL"
        if ta["score"] >= 3 or ta["score"] <= -3:
            ctx   = self.mdata.get_context(symbol)
            ai_op = self.mdata.ai_opinion(symbol, ctx, ta["summary"])

        final_dir = self._combine(ta, ai_op, ensemble_p)
        logger.info(f"{symbol}: strategy={chosen_strategy} dir={final_dir} "
                    f"ens={ensemble_p:.2f} regime={regime_detector.current_regime} "
                    f"score={ta['score']} ai={ai_op}")

        if final_dir in ("STRONG_BUY", "BUY", "STRONG_SELL", "SELL"):
            notify_signal(symbol, final_dir, ta["score"],
                          f"{chosen_strategy} | ens={ensemble_p:.2f}")

        if final_dir in ("STRONG_BUY", "BUY"):
            self._execute_futures(symbol, instr_key, "BUY", ltp, ta["atr"],
                                  chosen_strategy, feat_vec, strat_eval)
            if symbol in config.OPTIONS_SYMBOLS:
                self._execute_options(symbol, "BUY", ltp, ta, ta["atr"])

        elif final_dir in ("STRONG_SELL", "SELL"):
            self._execute_futures(symbol, instr_key, "SELL", ltp, ta["atr"],
                                  chosen_strategy, feat_vec, strat_eval)
            if symbol in config.OPTIONS_SYMBOLS:
                self._execute_options(symbol, "SELL", ltp, ta, ta["atr"])

    # ── Signal combination ────────────────────────────────────────────────────

    def _combine(self, ta: Dict, ai_op: str, ensemble_p: float) -> str:
        ai_map = {"STRONG_BUY": 4, "BUY": 2, "NEUTRAL": 0, "SELL": -2, "STRONG_SELL": -4}
        ai_s   = ai_map.get(ai_op, 0)
        # Ensemble prob: 0.5=neutral, 1.0=full buy, 0.0=full sell → map to -5..+5
        ens_s  = (ensemble_p - 0.5) * 10

        combined = ta["score"] * 0.5 + ai_s * 0.2 + ens_s * 0.3

        if combined >= 6:    return "STRONG_BUY"
        if combined >= 2.5:  return "BUY"
        if combined <= -6:   return "STRONG_SELL"
        if combined <= -2.5: return "SELL"
        return "NEUTRAL"

    # ── Futures execution ─────────────────────────────────────────────────────

    def _execute_futures(self, symbol: str, instr_key: str, direction: str,
                         ltp: float, atr: float, strategy: str,
                         feat_vec, strat_eval: Dict):
        meta     = config.COMMODITY_META.get(symbol, {})
        lot_size = self.registry.get_lot(symbol)
        qty      = self.risk.position_size(symbol, ltp, atr, config.ALLOC_COMMODITY)
        if qty < lot_size: return

        sl, tp = self.risk.compute_sl_tp(symbol, ltp, direction, atr, strategy)
        order_id = self.broker.place_order(
            instrument_key=instr_key, qty=qty,
            side=direction, product="D",
        )
        if not order_id: return

        trade_id = self.learning.record_entry(
            symbol=symbol, direction=direction, strategy=strategy,
            entry_price=ltp, qty=qty,
            features={"strategy": strategy, "regime": regime_detector.current_regime},
        )
        pos = Position(
            symbol=symbol, instrument_key=instr_key,
            direction=direction, entry_price=ltp,
            qty=qty, stop_loss=sl, target=tp,
            strategy=strategy, trade_id=trade_id, order_id=order_id,
        )
        pos.feature_vec = feat_vec
        self.risk.open_position(pos)
        self._open_fvecs[str(trade_id)] = feat_vec

        # Record with inventor
        # (will be updated on exit with actual PnL)

        notify_trade_entry(symbol, direction, qty, ltp, sl, tp,
                           strategy, paper=config.PAPER_TRADING)

    # ── Options execution ─────────────────────────────────────────────────────

    def _execute_options(self, symbol: str, bias: str,
                         atm: float, ta: Dict, atr: float):
        iv  = min(max(atr / max(atm, 1) * math.sqrt(252), 0.15), 0.80)
        strategy = self.opt_eng.select_strategy(symbol, ta, bias, iv)
        if not strategy: return
        logger.info(f"{symbol} Options → {strategy.name} ({strategy.rationale})")
        for leg in strategy.legs:
            opt_key = self.registry.option_key(symbol, leg.strike, leg.opt_type)
            self.broker.place_order(
                instrument_key=opt_key, qty=leg.qty,
                side=leg.action, product="D",
            )

    # ── Exit ──────────────────────────────────────────────────────────────────

    def _execute_exit(self, symbol: str, ltp: float, reason: str = "SIGNAL"):
        pos = self.risk.open_positions.get(symbol)
        if not pos: return

        exit_side = "SELL" if pos.direction == "BUY" else "BUY"
        self.broker.place_order(
            instrument_key=pos.instrument_key, qty=pos.qty, side=exit_side,
        )

        net_pnl = self.risk.close_position(symbol, ltp)
        if net_pnl is None: return

        feat_vec = self._open_fvecs.pop(str(pos.trade_id), None)
        self.learning.record_exit(
            trade_id=pos.trade_id, exit_price=ltp,
            holding_min=pos.holding_min, feature_vec=feat_vec,
        )

        # Bandit reward update
        try:
            won    = net_pnl > 0
            reward = (net_pnl / max(pos.entry_price * pos.qty, 1) * 100) / 10 + (0.5 if won else -0.3)
            now    = datetime.now(IST)
            context = build_context(
                spots=[ltp], last_iv=20.0, news_score=0.0,
                losses=0, start_cash=self.risk._day_start_cap,
                cur_cash=self.risk.available,
                hour=now.hour + now.minute / 60.0, weekday=now.weekday(),
            )
            bandit.update(pos.strategy, context, reward)
        except Exception: pass

        # Inventor record
        try:
            won  = net_pnl > 0
            gross = net_pnl  # approximate
            inventor.record_trade(pos.strategy, symbol, won, gross, net_pnl, pos.holding_min)
        except Exception: pass

        outcome = "WIN" if net_pnl > 0 else "LOSS"
        notify_trade_exit(symbol, net_pnl, outcome, ltp, paper=config.PAPER_TRADING)

    def _close_all_positions(self, reason: str = "MANUAL"):
        for symbol in list(self.risk.open_positions.keys()):
            pos = self.risk.open_positions[symbol]
            ltp = self.broker.get_ltp(pos.instrument_key) or pos.entry_price
            self._execute_exit(symbol, ltp, reason)

    # ── Candle fetcher ────────────────────────────────────────────────────────

    def _get_candles(self, instr_key: str, interval: str = "5minute") -> list:
        try:
            return self.broker.get_ohlc(instr_key, interval)
        except Exception as e:
            logger.warning(f"get_candles: {e}")
            return []

    # ── Status ────────────────────────────────────────────────────────────────

    def get_status(self) -> Dict:
        try:
            regime_line = regime_detector.status_line()
        except Exception:
            regime_line = ""
        try:
            bandit_line = bandit.status_line()
        except Exception:
            bandit_line = ""
        return {
            "risk":    self.risk.summary(),
            "learn":   self.learning.get_stats(),
            "trades":  self.learning.get_recent_trades(10),
            "paper":   config.PAPER_TRADING,
            "running": self._running,
            "regime":  regime_line,
            "bandit":  bandit_line,
            "instruments": {
                sym: {
                    "key": self.registry.futures_key(sym),
                    "dte": self.registry.get_dte(sym),
                    "lot": self.registry.get_lot(sym),
                }
                for sym in config.FUTURES_SYMBOLS
            },
        }
