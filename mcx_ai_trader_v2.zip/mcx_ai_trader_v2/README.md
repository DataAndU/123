# MCX AI Trader v2

Merged from `mcx_ai_trader` + `FinanceAGI v17.2`.  
Targets: **GOLDPETAL · CRUDEOILM · NATGASMINI** futures (+ energy options).

---

## What was ported from v17.2

### Instruments
| Old | v2 |
|---|---|
| Pattern key fallback only | Live gzip master download from Upstox CDN → real `instrument_key` every session |
| Near-expiry contract | **Next-expiry** always (DTE safety: skip if ≤3, force exit if ≤3) |
| Static lot sizes | Parsed from live master per contract |

### Strategy Engine
| Old | v2 |
|---|---|
| Single composite TA score | **9-strategy catalogue** with per-symbol applicability |
| Fixed tick interval scan | Session-aware: `morning` (9–9:30), `us` (18:30+), `both` |
| No strategy rotation | **LinUCB contextual bandits** — learns which strategy works per market regime |

**Strategies ported:**

| ID | Name | Best for |
|---|---|---|
| `TREND_FOLLOW` | EMA 5/20 crossover | GOLDPETAL, CRUDEOILM |
| `MEAN_REVERT` | RSI ≤25/≥75 + BB touch | GOLDPETAL, NATGASMINI |
| `BREAKOUT_VOL` | Open Range Breakout + volume confirm | CRUDEOILM (morning) |
| `US_MOMENTUM` | First 30 min of US session | CRUDEOILM, NATGASMINI |
| `GOLD_HEDGE` | Long gold on VIX>16 or USD/INR weakness | GOLDPETAL |
| `SEASONAL_NATGAS` | Calendar month winter/spring bias | NATGASMINI |
| `INVENTORY_CRUDE` | Wednesday EIA release reversal | CRUDEOILM |
| `VIX_SPIKE_GOLD` | Long GOLDPETAL when VIX spikes >18 | GOLDPETAL |
| `VOLATILITY_CRUSH` | Mean-revert after ≥2% candle spike | CRUDEOILM, NATGASMINI |

### Regime Detection (`core/regime.py`)
- **HMM 3-state**: BULL / BEAR / CHOP (hmmlearn if installed, else rule-based)
- Regime multipliers: SL × 0.8 (chop) → 1.2 (trend), size × 0.6 (chop) → 1.0 (trend)
- Per-symbol **ATR tracker** → dynamic SL & target scaled by IV level
- Persists to `data/hmm_model.pkl`

### Position Sizing (`core/risk.py`)
- **VIX-scaled half-Kelly**: full size (IV<13) → 25% (IV>22)
- **Drawdown governor**: 100% → 10% as daily DD deepens to 15%
- **Time decay**: full before 11:30, ramps to 25% by EOD
- Regime size_mult from HMM applied on top
- Lot-boundary rounding using live lot size from instrument master

### Learning Engine (`core/learning.py`)
- **LightGBM binary classifier** (optional, graceful fallback)
  - 20-dim feature vector from TA signals + strategy + regime + context
  - Retrains every 10 closed trades; incremental via `init_model`
  - Persists to `data/lgbm_model.pkl`
- **Rolling win rate** per strategy (last 20 trades)
- **Ensemble**: `LGBM × 0.50 + Rule × 0.35 + RollingWR × 0.15`
- Adaptive weight rebalancing after each retrain
- MCX charges (CTT + brokerage + GST + stamp) deducted from PnL

### AI Strategy Inventor (`strategies/inventor.py`)
- Calls Claude API every 15 closed trades
- Invents 2 new strategies for our 3 symbols; falls back to mutation if no API key
- Tracks per-strategy WR, PnL in SQLite
- **Kills** strategies: WR < 35% after 8+ trades
- **Promotes** strategies: WR ≥ 60% after 8+ trades
- Saves to `data/invented_strategies.json`

### Charges (`core/charges.py`)
Exact MCX round-trip: brokerage ₹40 flat + CTT (0.01% sell) + exchange + SEBI + stamp + 18% GST

---

## File layout

```
mcx_ai_trader_v2/
├── main.py                    # Entry point (unchanged)
├── agent.py                   # Orchestrator (fully rewritten)
├── config.py                  # All config + COMMODITY_META + STRATEGY_CATALOGUE
├── server.py                  # FastAPI dashboard (unchanged)
├── core/
│   ├── broker.py              # Upstox client (unchanged)
│   ├── instruments.py         # Live master download (NEW)
│   ├── risk.py                # ATR + Kelly sizing (NEW)
│   ├── learning.py            # LGBM ensemble (NEW)
│   ├── regime.py              # HMM + ATR stops + Kelly (NEW)
│   ├── bandits.py             # LinUCB (NEW)
│   ├── charges.py             # MCX charges (NEW)
│   └── notifier.py            # Telegram (unchanged)
├── data/
│   └── market_data.py         # News + Finnhub + Ollama/Claude (unchanged)
└── strategies/
    ├── signals.py             # 9-strategy library + full TA (NEW)
    ├── options_strategies.py  # 15+ options strategies (unchanged)
    └── inventor.py            # AI strategy inventor (NEW)
```

---

## Run

```bash
cd mcx_ai_trader_v2
pip install -r requirements.txt --break-system-packages

# Paper mode
python main.py --paper

# Dashboard only
python main.py --server

# Live (⚠)
python main.py
```

### Optional ML (Termux/UserLAnd)
```bash
pip install lightgbm --break-system-packages   # LightGBM ensemble
pip install hmmlearn  --break-system-packages   # HMM regime detection
pip install uvloop    --break-system-packages   # faster event loop
```

---

## .env keys needed

```
UPSTOX_API_KEY=277dd477-1033-4449-b3bc-7aa77571afb1
UPSTOX_API_SECRET=u5a5hw1j5i
UPSTOX_REDIRECT_URI=http://localhost:8000/callback
UPSTOX_ACCESS_TOKEN=          # filled after first login
ANTHROPIC_API_KEY=            # needed for AI strategy invention
TG_BOT_TOKEN=8257552338:...
TG_CHAT_ID=6555518428
NEWS_API_KEY=fd5477ecaa824b3fa521b9a385513b8a
PAPER_TRADING=true
CAPITAL=200000
```

---

## Capital note

MCX SPAN margins per lot:

| Symbol | Approx margin |
|---|---|
| GOLDPETAL | ₹6,000–8,000 |
| CRUDEOILM | ₹7,000–12,000 |
| NATGASMINI | ₹3,000–5,000 |

With ₹2,00,000 capital, 3–6 concurrent positions are feasible in paper mode.
Live trading requires sufficient margin — Kelly sizing will auto-reduce below thresholds.
