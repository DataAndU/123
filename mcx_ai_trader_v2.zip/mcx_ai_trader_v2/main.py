#!/usr/bin/env python3
"""
MCX AI Trading Agent — Entry Point
Usage:
  python main.py          # Start full agent (login + trade)
  python main.py --paper  # Force paper trading mode
  python main.py --server # Dashboard only (no trading)
"""

import os
import sys
import argparse
import threading
import logging

# Set working directory to script location
os.chdir(os.path.dirname(os.path.abspath(__file__)))
os.makedirs("data", exist_ok=True)
os.makedirs("logs", exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="MCX AI Trading Agent")
    parser.add_argument("--paper",  action="store_true", help="Force paper trading")
    parser.add_argument("--server", action="store_true", help="Dashboard only")
    parser.add_argument("--port",   type=int, default=8000)
    args = parser.parse_args()

    if args.paper:
        os.environ["PAPER_TRADING"] = "true"

    import config

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s  %(message)s",
        handlers=[
            logging.FileHandler("logs/agent.log"),
            logging.StreamHandler(sys.stdout),
        ],
    )
    logger = logging.getLogger("main")

    logger.info("=" * 60)
    logger.info("  MCX AI COMMODITY TRADING AGENT")
    logger.info(f"  Capital  : ₹{config.CAPITAL:,.0f}")
    logger.info(f"  Mode     : {'PAPER' if config.PAPER_TRADING else '⚠ LIVE'}")
    logger.info(f"  Symbols  : {config.FUTURES_SYMBOLS}")
    logger.info(f"  Dashboard: http://localhost:{args.port}")
    logger.info("=" * 60)

    from server import run_server, set_agent

    if args.server:
        logger.info("Server-only mode. No trading.")
        run_server(port=args.port)
        return

    # Start the dashboard server in a background thread
    server_thread = threading.Thread(
        target=run_server,
        kwargs={"port": args.port},
        daemon=True,
        name="DashboardServer",
    )
    server_thread.start()
    logger.info(f"Dashboard started at http://localhost:{args.port}")

    # Start the trading agent (blocks until stopped)
    from agent import MCXTradingAgent
    agent = MCXTradingAgent()
    set_agent(agent)

    try:
        agent.start()
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt – shutting down.")
        agent.stop()


if __name__ == "__main__":
    main()
