"""
core/risk.py — Risk Manager v2
Merges mcx_ai_trader RiskManager with v17 ATR stops + Kelly sizing + regime scaling.
"""

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional

import config
from core.charges import comm_charges

logger = logging.getLogger("risk")
IST = timezone(timedelta(hours=5, minutes=30))


@dataclass
class Position:
    symbol:         str
    instrument_key: str
    direction:      str          # BUY | SELL
    entry_price:    float
    qty:            int
    stop_loss:      float
    target:         float
    strategy:       str
    trade_id:       int
    order_id:       Optional[str] = None
    entry_time:     float = field(default_factory=time.time)
    is_option:      bool  = False
    option_legs:    List  = field(default_factory=list)
    feature_vec     = None        # numpy array stored at entry for LGBM

    @property
    def value(self) -> float:
        return self.entry_price * self.qty

    @property
    def holding_min(self) -> int:
        return int((time.time() - self.entry_time) / 60)


class RiskManager:
    def __init__(self, capital: float = config.CAPITAL):
        self.capital          = capital
        self.available        = capital
        self.daily_pnl        = 0.0
        self.daily_trades     = 0
        self.open_positions:  Dict[str, Position] = {}
        self._day_start_cap   = capital

    # ── Gate checks ───────────────────────────────────────────────────────────

    def can_trade(self, symbol: str) -> bool:
        if not config.TRADING_ENABLED:
            logger.warning("Trading disabled."); return False
        if self.daily_trades >= config.MAX_TRADES_PER_DAY:
            logger.warning(f"Max daily trades ({config.MAX_TRADES_PER_DAY}) reached."); return False
        if len(self.open_positions) >= config.MAX_OPEN_POSITIONS:
            logger.warning("Max open positions reached."); return False
        if symbol in self.open_positions:
            return False
        drawdown_pct = abs(self.daily_pnl) / max(self._day_start_cap, 1) * 100
        if self.daily_pnl < 0 and drawdown_pct >= config.MAX_DRAWDOWN_PCT:
            logger.warning(f"Max drawdown {config.MAX_DRAWDOWN_PCT}% hit."); return False
        return True

    # ── Position sizing (v17 Kelly-aware) ────────────────────────────────────

    def position_size(self, symbol: str, price: float, atr: float,
                      allocation: float, use_kelly: bool = True) -> int:
        """
        ATR-based sizing. If Kelly stats available, use AdaptiveKelly.
        Always capped by allocation and min lot size.
        """
        meta     = config.COMMODITY_META.get(symbol, {})
        lot_size = meta.get("lot_size", 1)

        # Check charges viability
        be_pct = comm_charges.breakeven_pct(price, lot_size)
        if be_pct > meta.get("volatility_pct", 2.0) * 0.60:
            logger.warning(f"{symbol}: breakeven {be_pct:.3f}% too high vs vol")
            return 0

        if use_kelly:
            try:
                from core.regime import adaptive_kelly, regime_detector
                from core.learning import LearningEngine  # forward ref; agent passes stats
                hour = datetime.now(IST).hour + datetime.now(IST).minute / 60
                regime_params = regime_detector.strategy_params
                budget = adaptive_kelly.compute(
                    wr=0.50, avg_win=1.0, avg_loss=0.6,
                    cash=self.available, iv=20.0,
                    start_cash=self._day_start_cap, cur_cash=self.available,
                    hour=hour, regime_size_mult=regime_params.get("size_mult", 1.0),
                )
                qty = int(budget / max(price, 1))
            except Exception:
                qty = int(self.available * (config.MAX_POSITION_SIZE_PCT / 100) / max(price, 1))
        else:
            risk_per_trade = self.available * (config.MAX_POSITION_SIZE_PCT / 100)
            stop_dist = max(atr * 1.5, price * 0.01)
            qty = int(risk_per_trade / stop_dist)

        qty = max(lot_size, qty)                       # at least 1 lot
        qty = (qty // lot_size) * lot_size             # round to lot boundary
        max_by_alloc = int(allocation / price)
        max_by_alloc = (max_by_alloc // lot_size) * lot_size
        return min(qty, max(lot_size, max_by_alloc))

    # ── SL/TP (regime + ATR-aware) ────────────────────────────────────────────

    def compute_sl_tp(self, symbol: str, price: float, direction: str,
                      atr: float, strategy: str = "TREND_FOLLOW") -> tuple:
        """
        v17: Use strategy-specific target_pct/sl_pct and regime multipliers.
        Falls back to fixed ATR-based if strategy not found.
        """
        try:
            from core.regime import regime_detector, get_atr_tracker
            regime_params = regime_detector.strategy_params
            sl_mult    = regime_params.get("sl_mult", 1.0)
            tp_mult    = regime_params.get("target_mult", 1.0)
        except Exception:
            sl_mult, tp_mult = 1.0, 1.0

        meta       = config.COMMODITY_META.get(symbol, {})
        strat_info = config.STRATEGY_CATALOGUE.get(strategy, {})
        sl_pct     = meta.get("sl_pct", 0.6) * strat_info.get("sl_mult", 1.0) * sl_mult / 100
        tp_pct     = meta.get("target_pct", 1.0) * strat_info.get("target_mult", 1.0) * tp_mult / 100

        if direction == "BUY":
            sl = price * (1 - sl_pct)
            tp = price * (1 + tp_pct)
        else:
            sl = price * (1 + sl_pct)
            tp = price * (1 - tp_pct)

        return round(sl, 2), round(tp, 2)

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def open_position(self, pos: Position):
        self.open_positions[pos.symbol] = pos
        self.available   -= pos.value
        self.daily_trades += 1
        logger.info(f"Opened: {pos.direction} {pos.qty}×{pos.symbol} @ {pos.entry_price} "
                    f"| SL={pos.stop_loss} TP={pos.target} strat={pos.strategy}")

    def close_position(self, symbol: str, exit_price: float) -> Optional[float]:
        pos = self.open_positions.pop(symbol, None)
        if not pos: return None
        pnl = ((exit_price - pos.entry_price) if pos.direction == "BUY"
               else (pos.entry_price - exit_price)) * pos.qty
        charges = comm_charges.calculate(pos.entry_price, exit_price, pos.qty)
        net_pnl = pnl - charges["total_charges"]
        self.available += pos.value + net_pnl
        self.daily_pnl += net_pnl
        logger.info(f"Closed: {symbol} | gross={pnl:.2f} charges={charges['total_charges']:.2f} "
                    f"net={net_pnl:.2f} | daily_pnl={self.daily_pnl:.2f}")
        return net_pnl

    def check_stops(self, symbol: str, ltp: float) -> Optional[str]:
        pos = self.open_positions.get(symbol)
        if not pos: return None
        if pos.direction == "BUY":
            if ltp <= pos.stop_loss: return "SL"
            if ltp >= pos.target:    return "TP"
        else:
            if ltp >= pos.stop_loss: return "SL"
            if ltp <= pos.target:    return "TP"
        # Max hold time (from strategy)
        meta       = config.COMMODITY_META.get(symbol, {})
        strat_info = config.STRATEGY_CATALOGUE.get(pos.strategy, {})
        max_hold   = strat_info.get("hold_min", meta.get("max_hold_min", 60))
        if pos.holding_min >= max_hold:
            return "TIME"
        return None

    def update_trailing_stop(self, symbol: str, ltp: float, atr: float):
        pos = self.open_positions.get(symbol)
        if not pos: return
        if pos.direction == "BUY":
            new_sl = ltp - atr * 1.5
            if new_sl > pos.stop_loss:
                pos.stop_loss = round(new_sl, 2)
        else:
            new_sl = ltp + atr * 1.5
            if new_sl < pos.stop_loss:
                pos.stop_loss = round(new_sl, 2)

    def reset_day(self):
        self._day_start_cap = self.available
        self.daily_pnl      = 0.0
        self.daily_trades   = 0

    def summary(self) -> Dict:
        return {
            "capital":        self.capital,
            "available":      round(self.available, 2),
            "open_positions": len(self.open_positions),
            "daily_pnl":      round(self.daily_pnl, 2),
            "daily_trades":   self.daily_trades,
            "drawdown_pct":   round(abs(min(self.daily_pnl, 0)) / max(self._day_start_cap, 1) * 100, 2),
        }
