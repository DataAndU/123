"""
Telegram Notification Service
Sends trade signals, PnL updates, and daily summaries.
Gracefully handles failures.
"""

import logging
import requests
import config

logger = logging.getLogger("telegram")

TG_URL = f"https://api.telegram.org/bot{config.TG_BOT_TOKEN}/sendMessage"


def _send(text: str, parse_mode: str = "HTML") -> bool:
    try:
        resp = requests.post(TG_URL, json={
            "chat_id":    config.TG_CHAT_ID,
            "text":       text,
            "parse_mode": parse_mode,
        }, timeout=10)
        return resp.ok
    except Exception as e:
        logger.warning(f"Telegram send failed: {e}")
        return False


def notify_trade_entry(symbol: str, direction: str, qty: int,
                       price: float, sl: float, tp: float,
                       strategy: str, paper: bool = True):
    emoji = "🟢" if direction == "BUY" else "🔴"
    mode  = "📄 PAPER" if paper else "🔴 LIVE"
    _send(
        f"{emoji} <b>ENTRY [{mode}]</b>\n"
        f"Symbol:   <b>{symbol}</b>\n"
        f"Action:   <b>{direction}</b> × {qty}\n"
        f"Price:    ₹{price:,.2f}\n"
        f"SL:       ₹{sl:,.2f}\n"
        f"Target:   ₹{tp:,.2f}\n"
        f"Strategy: {strategy}"
    )


def notify_trade_exit(symbol: str, pnl: float, outcome: str,
                      exit_price: float, paper: bool = True):
    emoji = "✅" if pnl > 0 else "❌"
    mode  = "📄 PAPER" if paper else "🔴 LIVE"
    _send(
        f"{emoji} <b>EXIT [{mode}]</b>\n"
        f"Symbol:   <b>{symbol}</b>\n"
        f"PnL:      ₹{pnl:+,.2f}  ({outcome})\n"
        f"Exit @    ₹{exit_price:,.2f}"
    )


def notify_signal(symbol: str, signal: str, score: int, source: str = "TA"):
    _send(
        f"📊 <b>SIGNAL</b>  {symbol}\n"
        f"Signal: <b>{signal}</b>  (score={score})\n"
        f"Source: {source}"
    )


def notify_daily_summary(stats: Dict):
    wr   = stats.get("win_rate", 0)
    pnl  = stats.get("today_pnl", 0)
    tot  = stats.get("total_trades", 0)
    emoji = "📈" if pnl >= 0 else "📉"
    _send(
        f"{emoji} <b>Daily Summary</b>\n"
        f"Today PnL:   ₹{pnl:+,.2f}\n"
        f"Win Rate:    {wr:.1f}%\n"
        f"Total Trades:{tot}"
    )


def notify_error(msg: str):
    _send(f"⚠️ <b>Agent Error</b>\n{msg}")


# Type hint
from typing import Dict
