"""
core/bandits.py — LinUCB Contextual Bandits for Strategy Selection
Ported from FinanceAGI v17.2 contextual_bandits.py.

Replaces the round-robin strategy picker with UCB-based exploration.
Context: [IV, trend, volume, VIX, hour, loss_streak, drawdown, day_of_week, ...]
"""

import logging
import os
import pickle
from pathlib import Path

import numpy as np

logger = logging.getLogger("bandits")
BASE     = Path("data")
BANDIT_F = str(BASE / "linucb.pkl")


class LinUCB:
    """
    LinUCB (disjoint) contextual bandit.
    Each strategy arm has its own linear model (A, b matrices).
    """

    CONTEXT_DIM = 10

    def __init__(self, alpha: float = 1.5):
        self.alpha       = alpha
        self.arms        = {}
        self.total_pulls = 0

    def _init_arm(self, name: str):
        d = self.CONTEXT_DIM
        self.arms[name] = {
            "A":       np.eye(d),
            "b":       np.zeros((d, 1)),
            "pulls":   0,
            "rewards": 0.0,
        }

    def select(self, context: np.ndarray, arm_names: list, explore: bool = False):
        if not arm_names:
            return None, 0, 0.0
        x = self._prep(context)
        for name in arm_names:
            if name not in self.arms:
                self._init_arm(name)

        best_name, best_idx, best_ucb = arm_names[0], 0, -999.0
        for idx, name in enumerate(arm_names):
            arm = self.arms[name]
            try:
                A_inv = np.linalg.solve(arm["A"], np.eye(arm["A"].shape[0]))
            except np.linalg.LinAlgError:
                A_inv = np.linalg.pinv(arm["A"])
            theta   = A_inv @ arm["b"]
            exploit = float((theta.T @ x).item())
            bonus   = self.alpha * float(np.sqrt((x.T @ A_inv @ x).item()))
            if explore: bonus *= 2.0
            ucb = exploit + bonus
            if ucb > best_ucb:
                best_ucb, best_name, best_idx = ucb, name, idx

        return best_name, best_idx, best_ucb

    def update(self, arm_name: str, context: np.ndarray, reward: float):
        if arm_name not in self.arms:
            self._init_arm(arm_name)
        x = self._prep(context)
        arm = self.arms[arm_name]
        arm["A"] += x @ x.T
        arm["b"] += reward * x
        arm["pulls"]   += 1
        arm["rewards"] += reward
        self.total_pulls += 1

    def _prep(self, context: np.ndarray) -> np.ndarray:
        c = np.array(context, dtype=np.float64).flatten()
        if len(c) < self.CONTEXT_DIM:
            c = np.concatenate([c, np.zeros(self.CONTEXT_DIM - len(c))])
        return np.clip(c[:self.CONTEXT_DIM], -5.0, 5.0).reshape(-1, 1)

    def decay_alpha(self, min_alpha: float = 0.3):
        if self.total_pulls > 100:
            self.alpha = max(min_alpha, 1.5 * (0.995 ** (self.total_pulls - 100)))

    def arm_stats(self) -> dict:
        return {
            name: {"pulls": a["pulls"],
                   "avg_reward": round(a["rewards"] / max(1, a["pulls"]), 3)}
            for name, a in self.arms.items()
        }

    def save(self):
        try:
            data = {"alpha": self.alpha, "total_pulls": self.total_pulls, "arms": {}}
            for name, arm in self.arms.items():
                data["arms"][name] = {
                    "A": arm["A"].tolist(), "b": arm["b"].tolist(),
                    "pulls": arm["pulls"], "rewards": arm["rewards"],
                }
            pickle.dump(data, open(BANDIT_F, "wb"))
        except Exception as e:
            logger.debug(f"[BANDIT] save error: {e}")

    def load(self):
        if not os.path.exists(BANDIT_F): return False
        try:
            data = pickle.load(open(BANDIT_F, "rb"))
            self.alpha       = data.get("alpha", 1.5)
            self.total_pulls = data.get("total_pulls", 0)
            for name, ad in data.get("arms", {}).items():
                self.arms[name] = {
                    "A": np.array(ad["A"]), "b": np.array(ad["b"]),
                    "pulls": ad["pulls"], "rewards": ad["rewards"],
                }
            logger.info(f"[BANDIT] Loaded: {len(self.arms)} arms, {self.total_pulls} pulls")
            return True
        except Exception as e:
            logger.warning(f"[BANDIT] load failed: {e}"); return False

    def status_line(self) -> str:
        top = sorted(self.arms.items(),
                     key=lambda x: x[1]["rewards"] / max(1, x[1]["pulls"]),
                     reverse=True)[:3]
        top_str = " | ".join(
            f"{n}:{a['pulls']}T {a['rewards']/max(1,a['pulls']):+.2f}R" for n, a in top)
        return f"[BANDIT] {self.total_pulls}pulls alpha={self.alpha:.2f} | {top_str}"


# ── Context builder ───────────────────────────────────────────────────────────

def build_context(
    spots: list,
    last_iv: float,
    news_score: float,
    losses: int,
    start_cash: float,
    cur_cash: float,
    hour: float,
    weekday: int,
    vol_total: float = 0,
    vol_mean: float = 1,
) -> np.ndarray:
    """Build 10-dim context vector for LinUCB from current market state."""
    iv_regime  = (last_iv - 20) / 10.0
    if len(spots) >= 3:
        trend = (spots[-1] - spots[-3]) / max(1, spots[-3]) * 100
    elif len(spots) >= 2:
        trend = (spots[-1] - spots[-2]) / max(1, spots[-2]) * 100
    else:
        trend = 0.0
    trend      = float(np.clip(trend / 0.5, -2, 2))
    vol_ratio  = min(3, vol_total / max(1, vol_mean)) - 1.0
    vix_proxy  = float(np.clip((last_iv - 15) / 8.0, -1, 2))
    time_norm  = (hour - 12) / 3.0
    news_norm  = float(np.clip(news_score / 5.0, -1, 1))
    loss_norm  = min(2.0, losses / 2.0)
    dow_norm   = (weekday - 2) / 2.0
    dd         = 0.0
    if start_cash > 0:
        dd = (start_cash - cur_cash) / start_cash * 100
    dd_norm    = min(2.0, dd / 5.0)
    pcr_norm   = 0.0  # placeholder; PCR not available for MCX futures

    return np.array([iv_regime, trend, vol_ratio, vix_proxy, time_norm,
                     pcr_norm, news_norm, loss_norm, dow_norm, dd_norm],
                    dtype=np.float64)


# ── Singleton ──────────────────────────────────────────────────────────────────
bandit = LinUCB(alpha=1.5)
