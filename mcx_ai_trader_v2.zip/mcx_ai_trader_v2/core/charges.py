"""
core/charges.py — MCX Commodity Charges Calculator
Ported from FinanceAGI v17.2 CommodityCharges.
CTT + brokerage + GST + SEBI + stamp.
"""


class CommodityCharges:
    """Exact MCX charge breakdown for futures trades."""

    @staticmethod
    def calculate(buy_price: float, sell_price: float, qty: int) -> dict:
        buy_val  = buy_price * qty
        sell_val = sell_price * qty
        turnover = buy_val + sell_val

        brokerage = 40.0                        # flat ₹40 per trade
        ctt       = sell_val * 0.0001           # 0.01% on sell turnover
        exchange  = turnover * 0.000026         # MCX exchange fee
        sebi      = turnover * 0.000001         # SEBI turnover fee
        stamp     = buy_val  * 0.00002          # 0.002% on buy
        gst       = (brokerage + exchange + sebi) * 0.18

        total = brokerage + ctt + exchange + gst + sebi + stamp
        gross = (sell_price - buy_price) * qty
        return {
            "total_charges":  round(total, 2),
            "gross_pnl":      round(gross, 2),
            "net_pnl":        round(gross - total, 2),
            "breakeven_pct":  round(total / max(1, buy_val) * 100, 3),
            "brokerage":      brokerage,
            "ctt":            round(ctt, 2),
            "exchange":       round(exchange, 2),
            "gst":            round(gst, 2),
        }

    @staticmethod
    def breakeven_pct(price: float, qty: int) -> float:
        """Minimum move % needed to cover all charges (round trip)."""
        val    = price * qty
        total  = 40 + val * 0.0001 + val * 2 * 0.000026 + val * 0.00002
        total += (40 + val * 2 * 0.000026) * 0.18
        return round(total / max(1, val) * 100, 3)

    @staticmethod
    def is_profitable(price: float, target_pct: float, qty: int) -> tuple:
        sell = price * (1 + target_pct / 100)
        r = CommodityCharges.calculate(price, sell, qty)
        return r["net_pnl"] > 0, r


comm_charges = CommodityCharges()
