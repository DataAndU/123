"""
core/regime.py — HMM Regime Detection + ATR Stops + VIX-Kelly Sizing
Ported directly from FinanceAGI v17.2 regime_hmm.py.
Drop-in module — no changes to agent.py required.

Three components:
  1. RegimeDetector   — BULL / BEAR / CHOP via HMM or rule-based fallback
  2. ATRStopCalc      — Volatility-adaptive SL/TP multipliers
  3. AdaptiveKelly    — Half-Kelly sizing scaled by VIX + drawdown + time
"""

import logging
import math
import os
import pickle
import time
from collections import deque
from pathlib import Path
from typing import Dict

import numpy as np

logger = logging.getLogger("regime")
BASE   = Path("data")
HMM_F  = str(BASE / "hmm_model.pkl")

# Optional hmmlearn
_HAS_HMM = False
try:
    from hmmlearn.hmm import GaussianHMM
    _HAS_HMM = True
    logger.info("[REGIME] hmmlearn available")
except ImportError:
    logger.info("[REGIME] hmmlearn not installed — using rule-based")


# ─────────────────────────────────────────────────────────────────────────────
# 1. HMM Regime Detection
# ─────────────────────────────────────────────────────────────────────────────

class RegimeDetector:
    """3-state HMM: BULL / BEAR / CHOP. Falls back to rule-based."""

    MIN_SAMPLES = 30

    def __init__(self):
        self.model          = None
        self.current_regime = "CHOP"
        self.regime_prob    = 0.5
        self._history       = deque(maxlen=500)
        self._returns       = deque(maxlen=50)
        self._fitted        = False
        self._last_fit      = 0

    def update(self, spot: float, prev_spot: float, iv: float = 20.0):
        if prev_spot <= 0 or spot <= 0:
            return
        log_ret = math.log(spot / prev_spot)
        self._returns.append(log_ret)
        rvol    = float(np.std(list(self._returns)[-5:])) if len(self._returns) >= 5 else abs(log_ret)
        range_pct = iv / 100.0
        self._history.append([log_ret, rvol, range_pct])

    def detect(self) -> str:
        if _HAS_HMM and len(self._history) >= self.MIN_SAMPLES:
            return self._hmm_detect()
        return self._rule_detect()

    def _hmm_detect(self) -> str:
        try:
            X = np.array(list(self._history))
            should_fit = (not self._fitted
                          or len(self._history) - self._last_fit > 50
                          or time.time() - self._last_fit > 1800)
            if should_fit:
                self.model = GaussianHMM(n_components=3, covariance_type="full",
                                         n_iter=100, random_state=42)
                self.model.fit(X)
                self._fitted   = True
                self._last_fit = len(self._history)
            if self.model:
                states   = self.model.predict(X)
                cur      = states[-1]
                means    = self.model.means_
                s_ret    = {i: means[i][0] for i in range(3)}
                sorted_s = sorted(s_ret.items(), key=lambda x: x[1])
                mapping  = {sorted_s[2][0]: "BULL", sorted_s[0][0]: "BEAR", sorted_s[1][0]: "CHOP"}
                self.current_regime = mapping.get(cur, "CHOP")
                post = self.model.predict_proba(X[-1:])
                self.regime_prob = float(post[0][cur])
                return self.current_regime
        except Exception as e:
            logger.debug(f"[REGIME] HMM error: {e}")
        return self._rule_detect()

    def _rule_detect(self) -> str:
        if len(self._returns) < 5:
            self.current_regime = "CHOP"; self.regime_prob = 0.5; return "CHOP"
        rets = list(self._returns)[-10:]
        cum  = sum(rets)
        vol  = float(np.std(rets))
        if cum > 0.003 and vol < 0.005:   self.current_regime = "BULL"; self.regime_prob = 0.7
        elif cum < -0.003 and vol < 0.005:self.current_regime = "BEAR"; self.regime_prob = 0.7
        else:                              self.current_regime = "CHOP"; self.regime_prob = 0.5
        return self.current_regime

    @property
    def strategy_params(self) -> Dict:
        """SL / target / size multipliers by regime."""
        if self.current_regime == "BULL":
            return {"sl_mult": 1.2, "target_mult": 1.3, "size_mult": 1.0, "prefer_type": "CE"}
        if self.current_regime == "BEAR":
            return {"sl_mult": 1.2, "target_mult": 1.3, "size_mult": 1.0, "prefer_type": "PE"}
        return {"sl_mult": 0.8, "target_mult": 0.8, "size_mult": 0.6, "prefer_type": "BOTH"}

    def save(self):
        try:
            pickle.dump({"history": list(self._history),
                         "returns": list(self._returns),
                         "regime":  self.current_regime}, open(HMM_F, "wb"))
        except Exception: pass

    def load(self):
        if not os.path.exists(HMM_F): return
        try:
            d = pickle.load(open(HMM_F, "rb"))
            self._history       = deque(d.get("history", []), maxlen=500)
            self._returns       = deque(d.get("returns", []), maxlen=50)
            self.current_regime = d.get("regime", "CHOP")
        except Exception: pass

    def status_line(self) -> str:
        return (f"[REGIME] {self.current_regime} ({self.regime_prob:.0%}) "
                f"samples={len(self._history)} {'HMM' if _HAS_HMM and self._fitted else 'RULE'}")


# ─────────────────────────────────────────────────────────────────────────────
# 2. ATR-Based Dynamic Stop Calculator
# ─────────────────────────────────────────────────────────────────────────────

class ATRStopCalc:
    """
    Volatility-adaptive SL and target using ATR.
    Replaces fixed SL% with: SL = VIX_multiplier × ATR_pct
    """

    def __init__(self, lookback: int = 14):
        self._bars = deque(maxlen=lookback + 1)

    def feed(self, price: float):
        self._bars.append(price)

    def atr_pct(self) -> float:
        bars = list(self._bars)
        if len(bars) < 3: return 3.0
        trs = [abs(bars[i] - bars[i - 1]) / bars[i] * 100
               for i in range(1, len(bars)) if bars[i] > 0]
        return float(np.mean(trs)) if trs else 3.0

    @staticmethod
    def vix_mult(iv: float) -> float:
        if iv < 13: return 1.5
        if iv < 17: return 2.0
        if iv < 22: return 2.5
        return 3.0

    def dynamic_sl(self, iv: float, strategy_sl_pct: float) -> float:
        atr   = self.atr_pct()
        mult  = self.vix_mult(iv)
        sl    = atr * mult
        floor = strategy_sl_pct * 0.5
        ceil  = strategy_sl_pct * 2.0
        return round(max(floor, min(ceil, sl)), 2)

    def dynamic_target(self, iv: float, strategy_target_pct: float) -> float:
        mult   = self.vix_mult(iv)
        scale  = 0.6 + (mult - 1.5) * 0.6
        scale  = max(0.7, min(1.5, scale))
        return round(strategy_target_pct * scale, 2)


# ─────────────────────────────────────────────────────────────────────────────
# 3. VIX-Scaled Half-Kelly Sizing
# ─────────────────────────────────────────────────────────────────────────────

class AdaptiveKelly:
    """
    Half-Kelly fraction × VIX scale × drawdown governor × time decay.
    Regime multiplier applied from RegimeDetector.
    """

    @staticmethod
    def vix_scale(iv: float) -> float:
        if iv < 13: return 1.0
        if iv < 17: return 0.75
        if iv < 22: return 0.5
        return 0.25

    @staticmethod
    def dd_scale(start_cash: float, cur_cash: float) -> float:
        if start_cash <= 0: return 1.0
        dd = (start_cash - cur_cash) / start_cash * 100
        if dd < 3:  return 1.0
        if dd < 5:  return 0.8
        if dd < 10: return 0.5
        if dd < 15: return 0.25
        return 0.1

    @staticmethod
    def time_scale(hour: float) -> float:
        if hour < 11.5: return 1.0
        if hour < 13.5: return 0.8
        if hour < 14.5: return 0.5
        return 0.25

    @staticmethod
    def half_kelly(wr: float, avg_win: float, avg_loss: float) -> float:
        avg_loss = abs(avg_loss)
        if avg_loss == 0 or wr == 0: return 0.25
        b = avg_win / avg_loss
        f = (b * wr - (1 - wr)) / b * 0.5
        return max(0.10, min(0.60, f))

    def compute(self, wr: float, avg_win: float, avg_loss: float,
                cash: float, iv: float, start_cash: float, cur_cash: float,
                hour: float, regime_size_mult: float = 1.0) -> float:
        hk   = self.half_kelly(wr, avg_win, avg_loss)
        vs   = self.vix_scale(iv)
        ds   = self.dd_scale(start_cash, cur_cash)
        ts   = self.time_scale(hour)
        frac = hk * vs * ds * ts * regime_size_mult
        budget = cash * frac
        logger.info(f"[KELLY] hk={hk:.2f} vix={vs:.2f} dd={ds:.2f} time={ts:.2f} "
                    f"regime={regime_size_mult:.2f} → {frac:.2f} → ₹{budget:.0f}")
        return budget


# ── Singletons ────────────────────────────────────────────────────────────────
regime_detector  = RegimeDetector()
adaptive_kelly   = AdaptiveKelly()

# Per-symbol ATR trackers
_atr_trackers: Dict[str, ATRStopCalc] = {}

def get_atr_tracker(symbol: str) -> ATRStopCalc:
    if symbol not in _atr_trackers:
        _atr_trackers[symbol] = ATRStopCalc()
    return _atr_trackers[symbol]
