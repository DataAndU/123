"""
core/learning.py — Self-Learning Engine v2
Merges mcx_ai_trader LearningEngine with FinanceAGI v17.2 EnsembleScorer.

Additions from v17:
  - LightGBM binary classifier (optional, graceful fallback)
  - Rolling win-rate per strategy (RollingWR)
  - EnsembleScorer: LGBM + NN-proxy + RollingWR weighted blend
  - Feature vector construction from strategy signals
  - Adaptive weight rebalancing after each retrain
"""

import json
import logging
import math
import os
import pickle
import sqlite3
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

import config

logger = logging.getLogger("learning")
BASE   = Path("data")

LGBM_MODEL_F   = str(BASE / "lgbm_model.pkl")
LGBM_HISTORY_F = str(BASE / "lgbm_history.pkl")

# Optional LightGBM
_HAS_LGBM = False
try:
    import lightgbm as lgb
    _HAS_LGBM = True
    logger.info("[ENSEMBLE] LightGBM available")
except ImportError:
    logger.info("[ENSEMBLE] LightGBM not installed — NN-proxy + rolling WR only")


# ─────────────────────────────────────────────────────────────────────────────
# LightGBM Wrapper (from v17 ensemble_scorer.py)
# ─────────────────────────────────────────────────────────────────────────────

class LGBMScorer:
    PARAMS = {
        "objective": "binary", "metric": "binary_logloss",
        "num_leaves": 31, "learning_rate": 0.05, "n_estimators": 200,
        "max_depth": 6, "min_child_samples": 10,
        "reg_alpha": 0.1, "reg_lambda": 0.1,
        "subsample": 0.8, "colsample_bytree": 0.8,
        "verbose": -1, "n_jobs": 1, "force_col_wise": True,
    }

    def __init__(self, feat_dim: int = 20):
        self.feat_dim         = feat_dim
        self.model            = None
        self.train_count      = 0
        self._feature_names   = None

    def predict(self, features: np.ndarray) -> float:
        if not _HAS_LGBM or self.model is None: return 0.5
        try:
            x = features.reshape(1, -1)[:, :self.feat_dim]
            p = self.model.predict(x)[0]
            return float(np.clip(p, 0.01, 0.99))
        except Exception: return 0.5

    def train(self, X: np.ndarray, y: np.ndarray, feature_names: list = None):
        if not _HAS_LGBM or X is None or len(X) < 15: return
        try:
            X = X[:, :self.feat_dim]
            y = y.ravel()
            self._feature_names = feature_names or [f"f{i}" for i in range(X.shape[1])]
            split = max(10, int(len(X) * 0.8))
            dt = lgb.Dataset(X[:split], label=y[:split], feature_name=self._feature_names[:X.shape[1]])
            dv = lgb.Dataset(X[split:], label=y[split:], reference=dt)
            cb = [lgb.early_stopping(30, verbose=False), lgb.log_evaluation(0)]
            self.model = lgb.train(self.PARAMS, dt, valid_sets=[dv],
                                   num_boost_round=200, init_model=self.model, callbacks=cb)
            self.train_count = len(X)
            logger.info(f"[LGBM] Trained on {len(X)} samples, trees={self.model.num_trees()}")
            self._save()
        except Exception as e:
            logger.error(f"[LGBM] Train error: {e}")

    def _save(self):
        if not _HAS_LGBM or not self.model: return
        try:
            pickle.dump({"model": self.model, "train_count": self.train_count,
                         "feature_names": self._feature_names}, open(LGBM_MODEL_F, "wb"))
        except Exception: pass

    def load(self):
        if not _HAS_LGBM or not os.path.exists(LGBM_MODEL_F): return False
        try:
            d = pickle.load(open(LGBM_MODEL_F, "rb"))
            self.model, self.train_count = d["model"], d.get("train_count", 0)
            self._feature_names = d.get("feature_names")
            logger.info(f"[LGBM] Loaded ({self.train_count} samples)")
            return True
        except Exception: return False


# ─────────────────────────────────────────────────────────────────────────────
# Rolling Win Rate per strategy
# ─────────────────────────────────────────────────────────────────────────────

class RollingWR:
    def __init__(self, window: int = 20):
        self.window = window
        self._data: Dict[str, deque] = {}

    def record(self, strategy: str, won: bool):
        self._data.setdefault(strategy, deque(maxlen=self.window))
        self._data[strategy].append(won)

    def wr(self, strategy: str) -> float:
        d = self._data.get(strategy)
        if not d or len(d) < 3: return 0.5
        return sum(d) / len(d)

    def save(self):
        try:
            pickle.dump({k: list(v) for k, v in self._data.items()},
                        open(LGBM_HISTORY_F, "wb"))
        except Exception: pass

    def load(self):
        if not os.path.exists(LGBM_HISTORY_F): return
        try:
            d = pickle.load(open(LGBM_HISTORY_F, "rb"))
            self._data = {k: deque(v, maxlen=self.window) for k, v in d.items()}
        except Exception: pass


# ─────────────────────────────────────────────────────────────────────────────
# Feature builder — maps signal dicts → numeric feature vector for LGBM
# ─────────────────────────────────────────────────────────────────────────────

FEATURE_NAMES = [
    "ema_trend", "rsi_val", "macd", "bb", "supertrend", "vwap",
    "atr_norm", "score_norm", "strategy_idx", "hour_norm",
    "day_chg_pct", "range_pct", "range_pos",
    "is_morning", "is_us_session",
    "strength", "prev_wr",
    "regime_bull", "regime_bear", "regime_chop",
]

_DIRECTION_MAP = {"BUY": 1.0, "SELL": -1.0, "NEUTRAL": 0.0, "STRONG_BUY": 2.0, "STRONG_SELL": -2.0}
_STRAT_LIST    = list(config.STRATEGY_CATALOGUE.keys())

def signals_to_features(
    signals: Dict,
    strategy: str = "",
    extra: Dict = None,
    regime: str = "CHOP",
) -> np.ndarray:
    """Convert signal dict + context → fixed-dim float feature vector."""
    extra = extra or {}
    def _d(k): return _DIRECTION_MAP.get(str(signals.get(k, "NEUTRAL")), 0.0)

    feats = [
        _d("ema_trend"),
        float(signals.get("rsi_val", 50)) / 100.0,
        _d("macd"),
        _d("bb"),
        1.0 if signals.get("supertrend") == "BUY" else -1.0,
        1.0 if signals.get("vwap") == "BUY" else -1.0,
        float(signals.get("atr", 0)) / max(1.0, float(extra.get("ltp", 1000))),
        float(extra.get("score", 0)) / 15.0,
        float(_STRAT_LIST.index(strategy) if strategy in _STRAT_LIST else 0) / max(1, len(_STRAT_LIST)),
        float(extra.get("hour", 12)) / 24.0,
        float(extra.get("day_chg_pct", 0)) / 5.0,
        float(extra.get("range_pct", 0)) / 5.0,
        float(extra.get("range_pos", 0.5)),
        1.0 if extra.get("is_morning") else 0.0,
        1.0 if extra.get("is_us") else 0.0,
        float(extra.get("strength", 1)) / 3.0,
        float(extra.get("prev_wr", 0.5)),
        1.0 if regime == "BULL" else 0.0,
        1.0 if regime == "BEAR" else 0.0,
        1.0 if regime == "CHOP" else 0.0,
    ]
    return np.array(feats, dtype=np.float64)


# ─────────────────────────────────────────────────────────────────────────────
# Main Learning Engine (merged)
# ─────────────────────────────────────────────────────────────────────────────

class LearningEngine:
    """
    SQLite trade history + LightGBM ensemble scorer.
    Replaces mcx_ai_trader's simple weight dict with LGBM + Rolling WR.
    """

    RETRAIN_N = config.MODEL_RETRAIN_EVERY_N_TRADES

    def __init__(self):
        self.db_path     = config.LEARNING_DB
        self._lgbm       = LGBMScorer(feat_dim=len(FEATURE_NAMES))
        self._rolling    = RollingWR()
        self._trade_count = 0

        # Adaptive ensemble weights
        self.w_lgbm = 0.50 if _HAS_LGBM else 0.0
        self.w_rule = 0.35 if _HAS_LGBM else 0.85
        self.w_rwr  = 0.15

        self._new_since_train = 0
        self._X: List[np.ndarray] = []
        self._y: List[float]      = []

        self._init_db()
        self._lgbm.load()
        self._rolling.load()
        self._trade_count = self._count_trades()

    # ── DB setup ─────────────────────────────────────────────────────────────

    def _init_db(self):
        os.makedirs("data", exist_ok=True)
        with sqlite3.connect(self.db_path) as conn:
            conn.executescript("""
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS trades (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ts          TEXT,
                symbol      TEXT,
                direction   TEXT,
                strategy    TEXT,
                entry_price REAL,
                exit_price  REAL,
                qty         INTEGER,
                pnl         REAL,
                pnl_pct     REAL,
                features    TEXT,
                outcome     TEXT,
                holding_min INTEGER
            );
            CREATE TABLE IF NOT EXISTS daily_stats (
                date        TEXT PRIMARY KEY,
                total_pnl   REAL,
                win_count   INTEGER,
                loss_count  INTEGER,
                win_rate    REAL
            );
            """)

    # ── Record ───────────────────────────────────────────────────────────────

    def record_entry(self, symbol: str, direction: str, strategy: str,
                     entry_price: float, qty: int, features: Dict,
                     feature_vec: Optional[np.ndarray] = None) -> int:
        ts = datetime.utcnow().isoformat()
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute(
                """INSERT INTO trades
                   (ts,symbol,direction,strategy,entry_price,qty,features,outcome)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (ts, symbol, direction, strategy, entry_price, qty,
                 json.dumps(features), "OPEN")
            )
            tid = cur.lastrowid
        return tid

    def record_exit(self, trade_id: int, exit_price: float,
                    holding_min: int = 0,
                    feature_vec: Optional[np.ndarray] = None):
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT entry_price,qty,direction,strategy,features FROM trades WHERE id=?",
                (trade_id,)
            ).fetchone()
            if not row: return
            entry, qty, direction, strategy, feat_json = row
            pnl = (exit_price - entry) * qty if direction == "BUY" else (entry - exit_price) * qty
            pnl_pct = (pnl / max(1, entry * qty)) * 100
            outcome = "WIN" if pnl > 0 else ("LOSS" if pnl < 0 else "BREAKEVEN")
            conn.execute(
                "UPDATE trades SET exit_price=?,pnl=?,pnl_pct=?,outcome=?,holding_min=? WHERE id=?",
                (exit_price, pnl, pnl_pct, outcome, holding_min, trade_id)
            )

        # Ensemble update
        won = pnl > 0
        self._rolling.record(strategy, won)
        self._new_since_train += 1
        self._trade_count     += 1

        # Store for LGBM batch training
        if feature_vec is not None:
            self._X.append(feature_vec)
            self._y.append(1.0 if won else 0.0)
            if self._new_since_train >= self.RETRAIN_N:
                self._retrain()

        self._update_daily(pnl, outcome)

        # Update bandit reward
        try:
            from core.bandits import bandit, build_context
            reward = pnl_pct / 10.0 + (0.5 if won else -0.3)
            bandit.decay_alpha()
        except Exception:
            pass

    # ── Ensemble score ────────────────────────────────────────────────────────

    def ensemble_score(self, feature_vec: np.ndarray, strategy: str,
                       rule_score: float) -> float:
        """
        Weighted blend of LGBM + rule-based score + rolling WR.
        Returns a probability-like float [0,1].
        """
        rule_prob = (rule_score + 15) / 30.0  # map -15..+15 → 0..1
        rule_prob = float(np.clip(rule_prob, 0.01, 0.99))

        lgbm_p = self._lgbm.predict(feature_vec)
        rwr_p  = self._rolling.wr(strategy)

        p = self.w_lgbm * lgbm_p + self.w_rule * rule_prob + self.w_rwr * rwr_p
        return float(np.clip(p, 0.01, 0.99))

    def adjust_score(self, base_score: int, features: Dict) -> float:
        """Legacy API — kept for agent.py compatibility."""
        return float(base_score)

    # ── Retrain ───────────────────────────────────────────────────────────────

    def _retrain(self):
        if not _HAS_LGBM or len(self._X) < 15: return
        X = np.array(self._X)
        y = np.array(self._y)
        self._lgbm.train(X, y, feature_names=FEATURE_NAMES)
        self._rolling.save()
        self._new_since_train = 0
        self._adapt_weights()

    def _adapt_weights(self):
        if not _HAS_LGBM or self._lgbm.model is None: return
        recent_y = np.array(self._y[-50:])
        X50      = np.array(self._X[-50:])
        lgbm_acc = float(np.mean((self._lgbm.predict(X50[i:i+1]) > 0.5) == (recent_y[i] > 0.5)
                                  for i in range(len(X50))))
        total    = lgbm_acc + 0.5 + 0.5
        self.w_lgbm = max(0.15, lgbm_acc / total)
        self.w_rule = max(0.15, 0.5 / total)
        self.w_rwr  = max(0.10, 0.5 / total)
        t = self.w_lgbm + self.w_rule + self.w_rwr
        self.w_lgbm /= t; self.w_rule /= t; self.w_rwr /= t
        logger.info(f"[ENSEMBLE] Weights: LGBM={self.w_lgbm:.2f} Rule={self.w_rule:.2f} RWR={self.w_rwr:.2f}")

    def _update_daily(self, pnl: float, outcome: str):
        today = datetime.utcnow().date().isoformat()
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT total_pnl,win_count,loss_count FROM daily_stats WHERE date=?", (today,)
            ).fetchone()
            if row:
                tp, wc, lc = row[0] + pnl, row[1] + (1 if outcome == "WIN" else 0), row[2] + (1 if outcome == "LOSS" else 0)
                conn.execute("UPDATE daily_stats SET total_pnl=?,win_count=?,loss_count=?,win_rate=? WHERE date=?",
                             (tp, wc, lc, wc / max(wc + lc, 1) * 100, today))
            else:
                wc = 1 if outcome == "WIN" else 0
                lc = 1 if outcome == "LOSS" else 0
                conn.execute("INSERT INTO daily_stats VALUES (?,?,?,?,?)",
                             (today, pnl, wc, lc, wc / max(wc + lc, 1) * 100))

    # ── Stats ──────────────────────────────────────────────────────────────────

    def get_stats(self) -> Dict:
        with sqlite3.connect(self.db_path) as conn:
            total = conn.execute("SELECT COUNT(*) FROM trades WHERE outcome!='OPEN'").fetchone()[0]
            wins  = conn.execute("SELECT COUNT(*) FROM trades WHERE outcome='WIN'").fetchone()[0]
            pnl   = conn.execute("SELECT SUM(pnl) FROM trades WHERE outcome!='OPEN'").fetchone()[0] or 0
            today = datetime.utcnow().date().isoformat()
            daily = conn.execute("SELECT total_pnl,win_rate FROM daily_stats WHERE date=?",
                                 (today,)).fetchone()
            # Per-strategy win rates from rolling WR
            strat_wr = {s: round(self._rolling.wr(s) * 100, 1)
                        for s in self._rolling._data}
        avg_win = avg_loss = 0.0
        with sqlite3.connect(self.db_path) as conn:
            wr = conn.execute("SELECT AVG(pnl_pct) FROM trades WHERE outcome='WIN'").fetchone()[0] or 0
            lr = conn.execute("SELECT AVG(pnl_pct) FROM trades WHERE outcome='LOSS'").fetchone()[0] or 0
            avg_win, avg_loss = wr, lr
        return {
            "total_trades": total,
            "wins":         wins,
            "losses":       total - wins,
            "win_rate":     round(wins / max(total, 1) * 100, 1),
            "total_pnl":    round(pnl, 2),
            "today_pnl":    round(daily[0], 2) if daily else 0,
            "today_wr":     round(daily[1], 1) if daily else 0,
            "avg_win_pct":  round(avg_win, 2),
            "avg_loss_pct": round(avg_loss, 2),
            "strategy_wr":  strat_wr,
            "ensemble":     f"LGBM={self.w_lgbm:.2f} Rule={self.w_rule:.2f} RWR={self.w_rwr:.2f}",
        }

    def get_recent_trades(self, limit: int = 20) -> List[Dict]:
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                """SELECT ts,symbol,direction,strategy,entry_price,exit_price,pnl,pnl_pct,outcome
                   FROM trades WHERE outcome!='OPEN' ORDER BY id DESC LIMIT ?""",
                (limit,)
            ).fetchall()
        cols = ["ts","symbol","direction","strategy","entry","exit","pnl","pnl_pct","outcome"]
        return [dict(zip(cols, r)) for r in rows]

    def _count_trades(self) -> int:
        with sqlite3.connect(self.db_path) as conn:
            r = conn.execute("SELECT COUNT(*) FROM trades WHERE outcome!='OPEN'").fetchone()
            return r[0] if r else 0
