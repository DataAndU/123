"""
core/instruments.py — MCX Instrument Registry v2
Ported live instrument master download from FinanceAGI v17.2 MCXInstruments.
Replaces the pattern-key fallback with real Upstox instrument keys.
"""

import gzip
import json
import logging
import time
from datetime import datetime, timedelta, timezone, date
from pathlib import Path
from typing import Dict, List, Optional

import requests

import config

logger = logging.getLogger("instruments")

IST = timezone(timedelta(hours=5, minutes=30))

MONTH_CODES = {
    1: "JAN", 2: "FEB", 3: "MAR", 4: "APR",
    5: "MAY", 6: "JUN", 7: "JUL", 8: "AUG",
    9: "SEP", 10: "OCT", 11: "NOV", 12: "DEC",
}


class InstrumentRegistry:
    """
    Downloads MCX instrument master from Upstox CDN (gzip JSON),
    parses it to find the correct next-expiry FUT keys for our 3 symbols,
    and exposes option key construction.

    v17 improvement: uses live master → real instrument_key every time.
    Fallback: pattern key if download fails.
    Cache: data/mcx_keys.json — refreshed every 8 hours.
    """

    INSTRUMENTS_URL = config.MCX_INSTRUMENTS_URL
    CACHE_PATH      = Path("data/mcx_keys.json")
    REFRESH_EVERY   = 3600 * 8   # 8 hours

    def __init__(self):
        self._futures:  Dict[str, str] = {}
        self._options:  Dict[str, Dict] = {}  # not pre-loaded, built on demand
        self._expiry:   Dict[str, datetime] = {}
        self._dte:      Dict[str, int] = {}
        self._lot:      Dict[str, int] = {}
        self._tick:     Dict[str, float] = {}
        self._near_exp  = self._label_near()
        self._next_exp  = self._label_next()
        self._last_refresh = 0.0

    # ── Expiry label helpers ─────────────────────────────────────────────────

    def _label_near(self) -> str:
        today = date.today()
        m, y = today.month, today.year % 100
        if today.day > 20:
            m += 1
            if m > 12: m, y = 1, y + 1
        return f"{MONTH_CODES[m]}{y:02d}"

    def _label_next(self) -> str:
        today = date.today()
        m = today.month + 1
        y = today.year % 100
        if m > 12: m, y = 1, y + 1
        return f"{MONTH_CODES[m]}{y:02d}"

    # ── Pattern key fallback ─────────────────────────────────────────────────

    def _fut_pattern(self, symbol: str, expiry: str) -> str:
        return f"MCX_FO|{symbol}{expiry}FUT"

    def _opt_pattern(self, symbol: str, expiry: str, strike: int, opt_type: str) -> str:
        return f"MCX_FO|{symbol}{expiry}{strike}{opt_type}"

    # ── Live download & parse (v17 logic) ────────────────────────────────────

    def refresh(self, symbols: List[str] = None):
        """Download and parse MCX instrument master. Runs at startup + every 8h."""
        now = time.time()
        if now - self._last_refresh < self.REFRESH_EVERY:
            return

        symbols = symbols or config.FUTURES_SYMBOLS
        self._near_exp = self._label_near()
        self._next_exp = self._label_next()

        raw_data = self._download_master()
        if raw_data:
            self._parse_master(raw_data, symbols)
            self._last_refresh = now
        else:
            logger.warning("Master download failed — loading cache")
            self._load_cache(symbols)

        # Fallback pattern keys for any missing symbol
        for sym in symbols:
            if sym not in self._futures:
                key = self._fut_pattern(sym, self._next_exp)
                self._futures[sym] = key
                logger.warning(f"  Fallback pattern key [{sym}]: {key}")
            else:
                logger.info(f"  Instrument [{sym}]: {self._futures[sym]}  DTE={self._dte.get(sym,'?')}")

    def _download_master(self) -> Optional[list]:
        try:
            r = requests.get(
                self.INSTRUMENTS_URL,
                headers={"User-Agent": "Mozilla/5.0"},
                timeout=20,
            )
            raw = gzip.decompress(r.content)
            data = json.loads(raw)
            self.CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
            self.CACHE_PATH.write_text(json.dumps(data))
            logger.info(f"  MCX master: {len(data)} instruments downloaded")
            return data
        except Exception as e:
            logger.error(f"  MCX master download failed: {e}")
            return None

    def _load_cache(self, symbols: List[str]):
        try:
            if self.CACHE_PATH.exists():
                self._parse_master(json.loads(self.CACHE_PATH.read_text()), symbols)
                logger.info("  Loaded cached MCX instrument master")
        except Exception as e:
            logger.error(f"  Cache load failed: {e}")

    def _parse_master(self, data: list, symbols: List[str]):
        """
        v17 logic: pick NEXT expiry contract with DTE > MIN_DTE_ENTRY.
        Falls back to further contract if too close to expiry.
        """
        today_ist = datetime.now(IST)
        today_ms  = today_ist.timestamp() * 1000
        min_dte_ms = (today_ist + timedelta(days=config.MIN_DTE_ENTRY)).timestamp() * 1000

        by_symbol: Dict[str, list] = {}
        for inst in data:
            if inst.get("instrument_type") != "FUT": continue
            if inst.get("segment") != "MCX_FO": continue
            sym = inst.get("underlying_symbol", inst.get("name", ""))
            if sym not in symbols: continue
            if inst.get("expiry", 0) <= today_ms: continue
            by_symbol.setdefault(sym, []).append(inst)

        for sym, contracts in by_symbol.items():
            contracts.sort(key=lambda x: x["expiry"])
            eligible = [c for c in contracts if c["expiry"] > min_dte_ms]
            if not eligible:
                logger.warning(f"  MCX {sym}: No eligible contract")
                continue

            # Pick first eligible; if too close, pick second
            chosen = eligible[0]
            exp_dt = datetime.fromtimestamp(chosen["expiry"] / 1000, tz=IST)
            dte    = (exp_dt.date() - today_ist.date()).days
            if dte <= config.MIN_DTE_ENTRY + 2 and len(eligible) >= 2:
                chosen = eligible[1]
                exp_dt = datetime.fromtimestamp(chosen["expiry"] / 1000, tz=IST)
                dte    = (exp_dt.date() - today_ist.date()).days

            self._futures[sym]  = chosen["instrument_key"]
            self._expiry[sym]   = exp_dt
            self._dte[sym]      = dte
            self._lot[sym]      = chosen.get("lot_size", config.COMMODITY_META[sym]["lot_size"])
            self._tick[sym]     = chosen.get("tick_size", config.COMMODITY_META[sym]["tick_size"])

    # ── Public API ───────────────────────────────────────────────────────────

    def futures_key(self, symbol: str) -> str:
        return self._futures.get(symbol, self._fut_pattern(symbol, self._next_exp))

    def option_key(self, symbol: str, strike: int, opt_type: str,
                   expiry: Optional[str] = None) -> str:
        exp = expiry or self._near_exp
        return self._opt_pattern(symbol, exp, strike, opt_type)

    def get_dte(self, symbol: str) -> int:
        return self._dte.get(symbol, 999)

    def get_lot(self, symbol: str) -> int:
        return self._lot.get(symbol, config.COMMODITY_META.get(symbol, {}).get("lot_size", 1))

    def is_tradeable(self, symbol: str) -> bool:
        return self.get_dte(symbol) > config.FORCE_EXIT_DTE

    def near_expiry(self) -> str:
        return self._near_exp

    def available(self) -> List[str]:
        return [s for s in self._futures if self._futures[s] and self.is_tradeable(s)]

    def option_chain(self, symbol: str, expiry: Optional[str] = None) -> Dict:
        """Thin wrapper — actual fetch done via broker."""
        from core.broker import UpstoxClient
        # The agent passes broker in; here we just return the key needed
        exp = expiry or self._near_exp
        return {"underlying_key": self.futures_key(symbol), "expiry": exp}
