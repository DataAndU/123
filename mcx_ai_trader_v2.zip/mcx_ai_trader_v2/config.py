"""
MCX AI Trader v2 — Configuration
Merged from mcx_ai_trader + FinanceAGI v17.2
"""

import os
from dotenv import load_dotenv

load_dotenv()

# ── Upstox ──────────────────────────────────────────────────────────────────
UPSTOX_API_KEY        = os.getenv("UPSTOX_API_KEY",      "277dd477-1033-4449-b3bc-7aa77571afb1")
UPSTOX_API_SECRET     = os.getenv("UPSTOX_API_SECRET",   "u5a5hw1j5i")
UPSTOX_REDIRECT_URI   = os.getenv("UPSTOX_REDIRECT_URI", "http://localhost:8000/callback")
UPSTOX_ACCESS_TOKEN   = os.getenv("UPSTOX_ACCESS_TOKEN", "")

# ── Trading controls ─────────────────────────────────────────────────────────
PAPER_TRADING     = os.getenv("PAPER_TRADING",    "true").lower() == "true"
TRADING_ENABLED   = os.getenv("TRADING_ENABLED",  "true").lower() == "true"
CAPITAL           = float(os.getenv("CAPITAL",    "200000"))
ALLOC_COMMODITY   = float(os.getenv("ALLOC_COMMODITY", "150000"))
ALLOC_OPTIONS     = float(os.getenv("ALLOC_OPTIONS",   "50000"))

# ── Instruments (3 symbols — futures focus) ──────────────────────────────────
FUTURES_SYMBOLS = ["GOLDPETAL", "CRUDEOILM", "NATGASMINI"]
OPTIONS_SYMBOLS = ["CRUDEOILM", "NATGASMINI"]

MCX_EXCHANGE = "MCX"
MCX_SEGMENT  = "MCX_FO"

# Instruments URL for live master download (from v17)
MCX_INSTRUMENTS_URL = "https://assets.upstox.com/market-quote/instruments/exchange/MCX.json.gz"

# ── External APIs ─────────────────────────────────────────────────────────────
TG_BOT_TOKEN      = os.getenv("TG_BOT_TOKEN",      "8257552338:AAH84Paoe7bDgIcv50w6aG_-jWHnswork2s")
TG_CHAT_ID        = os.getenv("TG_CHAT_ID",        "6555518428")
NEWS_API_KEY      = os.getenv("NEWS_API_KEY",       "fd5477ecaa824b3fa521b9a385513b8a")
OLLAMA_HOST       = os.getenv("OLLAMA_HOST",        "http://localhost:11434")
OLLAMA_MODEL      = os.getenv("OLLAMA_MODEL",       "qwen2.5:3b")
FINNHUB_TOKEN     = os.getenv("FINNHUB_TOKEN",      "d6ul4h1r01qig544vkb0d6ul4h1r01qig544vkbg")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY",  "")
CLAUDE_MODEL      = "claude-sonnet-4-20250514"

# ── Risk management ───────────────────────────────────────────────────────────
MAX_DRAWDOWN_PCT       = 5.0
MAX_POSITION_SIZE_PCT  = 10.0
STOP_LOSS_PCT          = 1.5
TARGET_PCT             = 3.0
MAX_OPEN_POSITIONS     = 6
MAX_TRADES_PER_DAY     = 20

# v17: DTE safety
MIN_DTE_ENTRY  = 5       # Never enter within 5 days of expiry
FORCE_EXIT_DTE = 3       # Force exit if DTE ≤ 3

# ── Strategy tuning (from v17 commodity_futures.py) ──────────────────────────
# Per-symbol meta — lot_size, tick, min_capital, target/sl pct
COMMODITY_META = {
    "GOLDPETAL": {
        "lot_size": 10, "tick_size": 1.0,
        "min_capital": 6000, "max_capital": 40000,
        "volatility_pct": 0.8, "target_pct": 0.6, "sl_pct": 0.4,
        "max_hold_min": 60, "session": "both",
        "strategies": ["TREND_FOLLOW", "MEAN_REVERT", "VIX_SPIKE_GOLD", "GOLD_HEDGE"],
        "asset_class": "precious_metal",
    },
    "CRUDEOILM": {
        "lot_size": 10, "tick_size": 1.0,
        "min_capital": 7000, "max_capital": 50000,
        "volatility_pct": 2.0, "target_pct": 1.0, "sl_pct": 0.6,
        "max_hold_min": 45, "session": "both",
        "strategies": ["TREND_FOLLOW", "BREAKOUT_VOL", "US_MOMENTUM",
                       "INVENTORY_CRUDE", "VOLATILITY_CRUSH"],
        "asset_class": "energy",
    },
    "NATGASMINI": {
        "lot_size": 250, "tick_size": 0.1,
        "min_capital": 3000, "max_capital": 25000,
        "volatility_pct": 3.0, "target_pct": 1.5, "sl_pct": 0.8,
        "max_hold_min": 40, "session": "us",
        "strategies": ["US_MOMENTUM", "SEASONAL_NATGAS", "VOLATILITY_CRUSH", "MEAN_REVERT"],
        "asset_class": "energy",
    },
}

# Strategy catalogue (ported from v17)
STRATEGY_CATALOGUE = {
    "TREND_FOLLOW":     {"name": "EMA Trend Follow",       "min_capital": 3000, "session": "both",    "hold_min": 45,  "target_mult": 1.0, "sl_mult": 1.0, "score_bonus": 0},
    "MEAN_REVERT":      {"name": "RSI Mean Reversion",     "min_capital": 3000, "session": "both",    "hold_min": 30,  "target_mult": 0.7, "sl_mult": 0.8, "score_bonus": 1},
    "BREAKOUT_VOL":     {"name": "Open Range Breakout",    "min_capital": 5000, "session": "morning", "hold_min": 60,  "target_mult": 1.5, "sl_mult": 1.0, "score_bonus": 2},
    "US_MOMENTUM":      {"name": "US Session Momentum",    "min_capital": 5000, "session": "us",      "hold_min": 40,  "target_mult": 1.2, "sl_mult": 1.0, "score_bonus": 2},
    "GOLD_HEDGE":       {"name": "Gold Safe-Haven Hedge",  "min_capital": 6000, "session": "both",    "hold_min": 90,  "target_mult": 0.8, "sl_mult": 0.6, "score_bonus": 1},
    "SEASONAL_NATGAS":  {"name": "NatGas Seasonal Bias",   "min_capital": 3000, "session": "us",      "hold_min": 60,  "target_mult": 1.0, "sl_mult": 1.0, "score_bonus": 1},
    "INVENTORY_CRUDE":  {"name": "EIA Inventory Reversal", "min_capital": 7000, "session": "us",      "hold_min": 30,  "target_mult": 1.5, "sl_mult": 1.2, "score_bonus": 3},
    "VIX_SPIKE_GOLD":   {"name": "VIX Spike Gold Long",    "min_capital": 6000, "session": "both",    "hold_min": 45,  "target_mult": 0.9, "sl_mult": 0.7, "score_bonus": 2},
    "VOLATILITY_CRUSH": {"name": "Intraday Vol Crush",     "min_capital": 5000, "session": "both",    "hold_min": 20,  "target_mult": 0.5, "sl_mult": 0.6, "score_bonus": 1},
}

# Seasonal NatGas monthly bias: +1 long, -1 short, 0 neutral
NATGAS_SEASONAL = {1:+1, 2:+1, 3:-1, 4:-1, 5:0, 6:+1, 7:+1, 8:+1, 9:-1, 10:0, 11:+1, 12:+1}

# ── Learning engine ───────────────────────────────────────────────────────────
LEARNING_DB              = "data/learning.db"
MODEL_RETRAIN_EVERY_N_TRADES = 10

# AI strategy invention (from v17 commodity_strategy_manager.py)
INVENT_EVERY_N_TRADES    = 15
MAX_STRATEGIES           = 20
KILL_WIN_RATE            = 35   # kill if WR < 35% after min trades
PROMOTE_WIN_RATE         = 60
MIN_TRADES_TO_JUDGE      = 8

# ── Scheduler ─────────────────────────────────────────────────────────────────
MCX_OPEN_HOUR    = 9
MCX_OPEN_MIN     = 0
MCX_CLOSE_HOUR   = 23
MCX_CLOSE_MIN    = 30
MCX_NO_ENTRY_HOUR = 23
MCX_NO_ENTRY_MIN  = 10
US_SESSION_HOUR  = 18
US_SESSION_MIN   = 30
TICK_INTERVAL    = 30   # seconds
