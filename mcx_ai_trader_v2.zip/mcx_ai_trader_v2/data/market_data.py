"""
Market Data Aggregator
Pulls price, news, and macro data from multiple sources.
Each source is wrapped in a try/except – if it fails the agent continues.
"""

import logging
import time
import json
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

import requests
import config

logger = logging.getLogger("market_data")


class _SafeSource:
    """Mixin: any failed call logs a warning and returns a sentinel."""
    def _safe(self, fn, *a, fallback=None, **kw):
        try:
            return fn(*a, **kw)
        except Exception as e:
            logger.warning(f"[{self.__class__.__name__}] {fn.__name__} failed: {e}")
            return fallback


# ─────────────────────────────────────────────────────────────────────────────
# News / Sentiment
# ─────────────────────────────────────────────────────────────────────────────

class NewsDataSource(_SafeSource):
    """NewsAPI – commodity-related headlines + basic sentiment."""
    BASE = "https://newsapi.org/v2"

    KEYWORDS = {
        "GOLDPETAL":   "gold price OR gold futures India",
        "CRUDEOILM":   "crude oil price OR WTI Brent",
        "NATGASMINI":  "natural gas price OR LNG",
    }

    def __init__(self):
        self._cache: Dict[str, Any] = {}
        self._cache_ts: Dict[str, float] = {}
        self._ttl = 300  # 5 min cache

    def get_sentiment(self, symbol: str) -> Dict:
        now = time.time()
        if symbol in self._cache and now - self._cache_ts.get(symbol, 0) < self._ttl:
            return self._cache[symbol]

        result = self._safe(self._fetch, symbol, fallback={"score": 0, "articles": []})
        self._cache[symbol] = result
        self._cache_ts[symbol] = now
        return result

    def _fetch(self, symbol: str) -> Dict:
        q = self.KEYWORDS.get(symbol, symbol)
        resp = requests.get(f"{self.BASE}/everything", params={
            "q":        q,
            "apiKey":   config.NEWS_API_KEY,
            "pageSize": 5,
            "sortBy":   "publishedAt",
            "language": "en",
        }, timeout=8)
        articles = resp.json().get("articles", [])
        score = self._score(articles)
        return {"score": score, "articles": [a["title"] for a in articles[:3]]}

    def _score(self, articles: List[Dict]) -> float:
        """Very simple keyword sentiment: +1 bullish, -1 bearish per headline."""
        bull = {"rise", "surge", "rally", "gain", "up", "high", "bull", "strong"}
        bear = {"fall", "drop", "crash", "decline", "down", "low", "bear", "weak"}
        score = 0
        for a in articles:
            title = (a.get("title") or "").lower()
            for w in title.split():
                if w in bull: score += 1
                if w in bear: score -= 1
        return max(-5, min(5, score))


# ─────────────────────────────────────────────────────────────────────────────
# Finnhub – Macro / commodity quotes
# ─────────────────────────────────────────────────────────────────────────────

class FinnhubSource(_SafeSource):
    BASE = "https://finnhub.io/api/v1"

    # Finnhub commodity symbol map
    SYM_MAP = {
        "GOLDPETAL":  "OANDA:XAU_USD",
        "CRUDEOILM":  "OANDA:BCO_USD",
        "NATGASMINI": "NYMEX:NG1!",
    }

    def __init__(self):
        self._cache: Dict[str, Any] = {}
        self._ts:    Dict[str, float] = {}

    def get_quote(self, symbol: str) -> Optional[Dict]:
        now = time.time()
        if symbol in self._cache and now - self._ts.get(symbol, 0) < 60:
            return self._cache[symbol]

        fsym = self.SYM_MAP.get(symbol)
        if not fsym:
            return None

        result = self._safe(self._fetch, fsym, fallback=None)
        if result:
            self._cache[symbol] = result
            self._ts[symbol] = now
        return result

    def _fetch(self, fsym: str) -> Dict:
        resp = requests.get(f"{self.BASE}/quote", params={
            "symbol": fsym,
            "token":  config.FINNHUB_TOKEN,
        }, timeout=8)
        data = resp.json()
        return {
            "price":   data.get("c"),
            "change":  data.get("d"),
            "pct_chg": data.get("dp"),
            "high":    data.get("h"),
            "low":     data.get("l"),
        }


# ─────────────────────────────────────────────────────────────────────────────
# TradingEconomics – macro indicators
# ─────────────────────────────────────────────────────────────────────────────

class TradingEconomicsSource(_SafeSource):
    BASE = "https://api.tradingeconomics.com"

    INDICATORS = ["crude oil", "natural gas", "gold"]

    def __init__(self):
        self._cache: Optional[List] = None
        self._ts: float = 0

    def get_indicators(self) -> List[Dict]:
        if self._cache and time.time() - self._ts < 600:
            return self._cache
        result = self._safe(self._fetch, fallback=[])
        self._cache = result
        self._ts = time.time()
        return result

    def _fetch(self) -> List:
        key, secret = config.TE_API_KEY.split(":")
        resp = requests.get(f"{self.BASE}/commodity", params={
            "c": f"{key}:{secret}",
        }, timeout=10)
        return resp.json()[:10] if resp.ok else []


# ─────────────────────────────────────────────────────────────────────────────
# Ollama LLM – local AI analysis
# ─────────────────────────────────────────────────────────────────────────────

class OllamaAnalyzer(_SafeSource):
    def __init__(self):
        self.host  = config.OLLAMA_HOST
        self.model = config.OLLAMA_MODEL

    def analyze(self, prompt: str) -> str:
        return self._safe(self._call, prompt, fallback="")

    def _call(self, prompt: str) -> str:
        resp = requests.post(f"{self.host}/api/generate", json={
            "model":  self.model,
            "prompt": prompt,
            "stream": False,
        }, timeout=30)
        return resp.json().get("response", "")


# ─────────────────────────────────────────────────────────────────────────────
# Anthropic Claude – premium AI analysis
# ─────────────────────────────────────────────────────────────────────────────

class AnthropicAnalyzer(_SafeSource):
    BASE = "https://api.anthropic.com/v1/messages"

    def analyze(self, prompt: str) -> str:
        return self._safe(self._call, prompt, fallback="")

    def _call(self, prompt: str) -> str:
        resp = requests.post(self.BASE, json={
            "model":      "claude-sonnet-4-20250514",
            "max_tokens": 512,
            "messages":   [{"role": "user", "content": prompt}],
        }, headers={
            "x-api-key":         config.ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type":      "application/json",
        }, timeout=20)
        data = resp.json()
        return data.get("content", [{}])[0].get("text", "")


# ─────────────────────────────────────────────────────────────────────────────
# Aggregated Market Context
# ─────────────────────────────────────────────────────────────────────────────

class MarketDataAggregator:
    def __init__(self):
        self.news      = NewsDataSource()
        self.finnhub   = FinnhubSource()
        self.te        = TradingEconomicsSource()
        self.ollama    = OllamaAnalyzer()
        self.anthropic = AnthropicAnalyzer()

    def get_context(self, symbol: str) -> Dict:
        """Return aggregated context for a symbol. Failures are silently ignored."""
        sentiment = self.news.get_sentiment(symbol)
        quote     = self.finnhub.get_quote(symbol)
        macro     = self.te.get_indicators()

        return {
            "symbol":     symbol,
            "sentiment":  sentiment,
            "global_q":   quote,
            "macro":      macro[:3],
            "timestamp":  datetime.utcnow().isoformat(),
        }

    def ai_opinion(self, symbol: str, context: Dict, chart_summary: str) -> str:
        """
        Ask AI for a trading opinion. Tries Anthropic first, falls back to Ollama.
        Returns a short signal string or empty string.
        """
        prompt = (
            f"You are an expert MCX commodity trader. "
            f"Analyze {symbol} and respond with EXACTLY one of: "
            f"STRONG_BUY | BUY | NEUTRAL | SELL | STRONG_SELL\n\n"
            f"Chart: {chart_summary}\n"
            f"News sentiment score: {context.get('sentiment',{}).get('score',0)}\n"
            f"Global quote: {context.get('global_q')}\n"
            f"Respond with only the signal word."
        )
        opinion = ""
        if config.ANTHROPIC_API_KEY:
            opinion = self.anthropic.analyze(prompt).strip().upper()
        if opinion not in {"STRONG_BUY","BUY","NEUTRAL","SELL","STRONG_SELL"}:
            opinion = self.ollama.analyze(prompt).strip().upper()
        if opinion not in {"STRONG_BUY","BUY","NEUTRAL","SELL","STRONG_SELL"}:
            opinion = "NEUTRAL"
        return opinion
