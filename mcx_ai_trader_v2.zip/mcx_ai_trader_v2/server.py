"""
FastAPI Dashboard Server
Serves the trading dashboard and exposes REST endpoints.
Also handles Upstox OAuth callback.
"""

import os
import sys
import threading
import logging
from datetime import datetime
from typing import Dict, Any

sys.path.insert(0, os.path.dirname(__file__))

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

import config

logger = logging.getLogger("server")

app = FastAPI(title="MCX AI Trader", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])

# Global reference to agent (set after agent.start() in background)
_agent = None

def set_agent(agent):
    global _agent
    _agent = agent


# ─────────────────────────────────────────────────────────────────────────────
# Upstox OAuth callback
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/callback")
async def oauth_callback(code: str = "", error: str = ""):
    if error:
        return HTMLResponse(f"<h2>Auth error: {error}</h2>", status_code=400)
    # Pass code to broker's global _auth_code
    from core.broker import _auth_code
    import core.broker as broker_mod
    broker_mod._auth_code = code
    return HTMLResponse("""
    <html><body style="font-family:monospace;background:#0a0a0a;color:#00ff88;
    display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
    <div style="text-align:center">
    <h1>✅ Upstox Login Successful</h1>
    <p>You can close this tab. The agent is now authenticated.</p>
    </div></body></html>
    """)


# ─────────────────────────────────────────────────────────────────────────────
# API endpoints
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/status")
async def api_status():
    if _agent:
        return JSONResponse(_agent.get_status())
    return JSONResponse({"error": "agent not running"}, 503)

@app.get("/api/trades")
async def api_trades(limit: int = 50):
    if _agent:
        trades = _agent.learning.get_recent_trades(limit)
        return JSONResponse({"trades": trades})
    return JSONResponse({"trades": []})

@app.get("/api/stats")
async def api_stats():
    if _agent:
        return JSONResponse(_agent.learning.get_stats())
    return JSONResponse({})

@app.post("/api/stop")
async def api_stop():
    if _agent:
        _agent._close_all_positions("MANUAL")
        _agent.stop()
        return {"status": "stopped"}
    raise HTTPException(404, "Agent not running")

@app.post("/api/close_all")
async def api_close_all():
    if _agent:
        _agent._close_all_positions("MANUAL")
        return {"status": "all positions closed"}
    raise HTTPException(404, "Agent not running")


# ─────────────────────────────────────────────────────────────────────────────
# Dashboard HTML
# ─────────────────────────────────────────────────────────────────────────────

DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MCX AI Trader</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:      #070b0f;
    --panel:   #0d1219;
    --border:  #1a2535;
    --accent:  #00e5a0;
    --accent2: #ff6b35;
    --red:     #ff3b5c;
    --green:   #00e5a0;
    --blue:    #38b6ff;
    --text:    #c8d8e8;
    --dim:     #4a6070;
    --glow:    0 0 20px rgba(0,229,160,0.3);
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: var(--bg);
    color: var(--text);
    font-family: 'Rajdhani', sans-serif;
    min-height: 100vh;
    overflow-x: hidden;
  }
  /* Scanline overlay */
  body::after {
    content: '';
    position: fixed; inset: 0; pointer-events: none; z-index: 9999;
    background: repeating-linear-gradient(0deg,
      transparent, transparent 2px,
      rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px);
  }

  /* ── Header ── */
  header {
    display: flex; align-items: center; justify-content: space-between;
    padding: 16px 32px;
    border-bottom: 1px solid var(--border);
    background: linear-gradient(90deg, #070b0f, #0d1a24);
    position: sticky; top: 0; z-index: 100;
  }
  .logo {
    font-family: 'Share Tech Mono', monospace;
    font-size: 1.5rem; color: var(--accent);
    text-shadow: var(--glow);
    letter-spacing: 2px;
  }
  .logo span { color: var(--accent2); }
  .status-badge {
    display: flex; align-items: center; gap: 8px;
    font-family: 'Share Tech Mono', monospace;
    font-size: 0.75rem;
  }
  .dot {
    width: 8px; height: 8px; border-radius: 50%;
    background: var(--green);
    box-shadow: 0 0 8px var(--green);
    animation: pulse 2s infinite;
  }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
  .mode-badge {
    padding: 4px 12px; border-radius: 20px;
    font-size: 0.7rem; font-weight: 700; letter-spacing: 1px;
    background: rgba(255,107,53,0.15); color: var(--accent2);
    border: 1px solid rgba(255,107,53,0.4);
  }

  /* ── Layout ── */
  .container { max-width: 1400px; margin: 0 auto; padding: 24px 32px; }
  .grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
  .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }

  /* ── Stat cards ── */
  .card {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 20px 24px;
    position: relative; overflow: hidden;
    transition: border-color 0.3s;
  }
  .card:hover { border-color: var(--accent); }
  .card::before {
    content: ''; position: absolute; top: 0; left: 0;
    width: 3px; height: 100%;
    background: var(--accent);
  }
  .card.red::before { background: var(--red); }
  .card.blue::before { background: var(--blue); }
  .card.orange::before { background: var(--accent2); }

  .card-label {
    font-size: 0.7rem; letter-spacing: 2px; text-transform: uppercase;
    color: var(--dim); margin-bottom: 8px;
    font-family: 'Share Tech Mono', monospace;
  }
  .card-value {
    font-size: 1.8rem; font-weight: 700;
    font-family: 'Share Tech Mono', monospace;
    color: var(--accent);
    text-shadow: var(--glow);
  }
  .card-value.red   { color: var(--red);   text-shadow: 0 0 12px rgba(255,59,92,0.4); }
  .card-value.blue  { color: var(--blue);  text-shadow: 0 0 12px rgba(56,182,255,0.3); }
  .card-value.orange{ color: var(--accent2); }
  .card-sub { font-size: 0.75rem; color: var(--dim); margin-top: 4px; }

  /* ── Table ── */
  .table-card {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 12px;
    overflow: hidden;
  }
  .table-header {
    padding: 16px 24px;
    border-bottom: 1px solid var(--border);
    font-size: 0.7rem; letter-spacing: 2px;
    color: var(--dim); text-transform: uppercase;
    font-family: 'Share Tech Mono', monospace;
    display: flex; align-items: center; gap: 10px;
  }
  .table-header::before {
    content: ''; width: 6px; height: 6px;
    border-radius: 50%; background: var(--accent);
    box-shadow: var(--glow);
  }
  table { width: 100%; border-collapse: collapse; }
  th {
    padding: 12px 16px; text-align: left;
    font-size: 0.65rem; letter-spacing: 1.5px;
    color: var(--dim); text-transform: uppercase;
    border-bottom: 1px solid var(--border);
    font-family: 'Share Tech Mono', monospace;
  }
  td {
    padding: 12px 16px;
    font-size: 0.85rem; color: var(--text);
    border-bottom: 1px solid rgba(26,37,53,0.5);
    font-family: 'Share Tech Mono', monospace;
  }
  tr:hover td { background: rgba(255,255,255,0.02); }
  .win  { color: var(--green); }
  .loss { color: var(--red); }
  .pnl-pos { color: var(--green); font-weight: 700; }
  .pnl-neg { color: var(--red);   font-weight: 700; }

  /* ── Instruments ── */
  .instruments {
    display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px;
    margin-bottom: 24px;
  }
  .instr-card {
    background: var(--panel);
    border: 1px solid var(--border);
    border-radius: 12px; padding: 20px;
    transition: all 0.3s;
  }
  .instr-card:hover { border-color: var(--accent); transform: translateY(-2px); }
  .instr-name {
    font-size: 1rem; font-weight: 700; letter-spacing: 2px;
    color: var(--accent); font-family: 'Share Tech Mono', monospace;
    margin-bottom: 4px;
  }
  .instr-price {
    font-size: 1.6rem; font-weight: 700;
    font-family: 'Share Tech Mono', monospace;
    color: var(--text);
  }
  .instr-signal {
    display: inline-block; margin-top: 8px;
    padding: 3px 10px; border-radius: 20px;
    font-size: 0.7rem; font-weight: 700; letter-spacing: 1px;
  }
  .sig-buy  { background: rgba(0,229,160,0.15); color: var(--green); border: 1px solid rgba(0,229,160,0.4); }
  .sig-sell { background: rgba(255,59,92,0.15);  color: var(--red);   border: 1px solid rgba(255,59,92,0.4); }
  .sig-neutral { background: rgba(56,182,255,0.1); color: var(--blue); border: 1px solid rgba(56,182,255,0.3); }

  /* ── Controls ── */
  .controls { display: flex; gap: 12px; margin-bottom: 24px; }
  .btn {
    padding: 10px 24px; border-radius: 8px;
    font-family: 'Rajdhani', sans-serif; font-weight: 700;
    font-size: 0.85rem; letter-spacing: 1px;
    cursor: pointer; border: none; transition: all 0.2s;
  }
  .btn-danger {
    background: rgba(255,59,92,0.15); color: var(--red);
    border: 1px solid var(--red);
  }
  .btn-danger:hover { background: var(--red); color: white; }
  .btn-warn {
    background: rgba(255,107,53,0.15); color: var(--accent2);
    border: 1px solid var(--accent2);
  }
  .btn-warn:hover { background: var(--accent2); color: white; }

  /* ── Chart placeholder ── */
  .chart-area {
    background: var(--panel); border: 1px solid var(--border);
    border-radius: 12px; padding: 20px; height: 200px;
    display: flex; align-items: center; justify-content: center;
    color: var(--dim); font-family: 'Share Tech Mono', monospace;
    font-size: 0.8rem;
  }

  /* ── Responsive ── */
  @media (max-width: 900px) {
    .grid-4 { grid-template-columns: repeat(2,1fr); }
    .grid-2 { grid-template-columns: 1fr; }
    .instruments { grid-template-columns: 1fr; }
    .container { padding: 16px; }
  }
</style>
</head>
<body>

<header>
  <div class="logo">MCX<span>·</span>AI<span>·</span>TRADER</div>
  <div class="status-badge">
    <div class="dot"></div>
    <span id="statusText">CONNECTING…</span>
    <div class="mode-badge" id="modeBadge">PAPER</div>
  </div>
</header>

<div class="container">

  <!-- Controls -->
  <div class="controls">
    <button class="btn btn-danger" onclick="closeAll()">⬛ CLOSE ALL POSITIONS</button>
    <button class="btn btn-warn"   onclick="stopAgent()">🛑 STOP AGENT</button>
  </div>

  <!-- Stats row -->
  <div class="grid-4">
    <div class="card">
      <div class="card-label">Available Capital</div>
      <div class="card-value" id="avail">₹—</div>
      <div class="card-sub">of ₹2,00,000 total</div>
    </div>
    <div class="card" id="pnl-card">
      <div class="card-label">Today's PnL</div>
      <div class="card-value" id="dailyPnl">₹—</div>
      <div class="card-sub" id="dailyWR">Win Rate: —%</div>
    </div>
    <div class="card blue">
      <div class="card-label">Open Positions</div>
      <div class="card-value blue" id="openPos">—</div>
      <div class="card-sub" id="totalTrades">Total trades: —</div>
    </div>
    <div class="card orange">
      <div class="card-label">All-Time PnL</div>
      <div class="card-value orange" id="allPnl">₹—</div>
      <div class="card-sub" id="winRate">Win rate: —%</div>
    </div>
  </div>

  <!-- Instruments -->
  <div class="instruments" id="instruments">
    <div class="instr-card">
      <div class="instr-name">GOLDPETAL</div>
      <div class="instr-price" id="gp-price">—</div>
      <div><span class="instr-signal sig-neutral" id="gp-sig">SCANNING</span></div>
    </div>
    <div class="instr-card">
      <div class="instr-name">CRUDEOILM</div>
      <div class="instr-price" id="co-price">—</div>
      <div><span class="instr-signal sig-neutral" id="co-sig">SCANNING</span></div>
    </div>
    <div class="instr-card">
      <div class="instr-name">NATGASMINI</div>
      <div class="instr-price" id="ng-price">—</div>
      <div><span class="instr-signal sig-neutral" id="ng-sig">SCANNING</span></div>
    </div>
  </div>

  <!-- Tables -->
  <div class="grid-2">
    <div class="table-card">
      <div class="table-header">Recent Trades</div>
      <table>
        <thead>
          <tr><th>Symbol</th><th>Dir</th><th>Strategy</th><th>PnL</th><th>Result</th></tr>
        </thead>
        <tbody id="tradesBody">
          <tr><td colspan="5" style="text-align:center;color:var(--dim)">Loading…</td></tr>
        </tbody>
      </table>
    </div>
    <div class="table-card">
      <div class="table-header">Open Positions</div>
      <table>
        <thead>
          <tr><th>Symbol</th><th>Dir</th><th>Entry</th><th>SL</th><th>Target</th></tr>
        </thead>
        <tbody id="posBody">
          <tr><td colspan="5" style="text-align:center;color:var(--dim)">No open positions</td></tr>
        </tbody>
      </table>
    </div>
  </div>

</div>

<script>
const fmt = n => '₹' + parseFloat(n||0).toLocaleString('en-IN', {maximumFractionDigits:2});
const pct = n => parseFloat(n||0).toFixed(1) + '%';

async function fetchStatus() {
  try {
    const r = await fetch('/api/status');
    if (!r.ok) return;
    const d = await r.json();

    document.getElementById('statusText').textContent = d.running ? 'LIVE' : 'STOPPED';
    document.getElementById('modeBadge').textContent = d.paper ? 'PAPER' : '🔴 LIVE';

    const risk = d.risk || {};
    document.getElementById('avail').textContent = fmt(risk.available);
    document.getElementById('openPos').textContent = risk.open_positions ?? '—';
    document.getElementById('totalTrades').textContent = `Daily trades: ${risk.daily_trades ?? 0}`;

    const pnl = risk.daily_pnl ?? 0;
    const pnlEl = document.getElementById('dailyPnl');
    pnlEl.textContent = fmt(pnl);
    pnlEl.className = 'card-value ' + (pnl >= 0 ? '' : 'red');

    const learn = d.learn || {};
    document.getElementById('dailyWR').textContent = `Win Rate: ${pct(learn.today_wr)}`;
    document.getElementById('allPnl').textContent = fmt(learn.total_pnl);
    document.getElementById('winRate').textContent = `Win rate: ${pct(learn.win_rate)}`;
    document.getElementById('totalTrades').textContent = `Total: ${learn.total_trades ?? 0}`;

    // Trades table
    const trades = d.trades || [];
    const tbody = document.getElementById('tradesBody');
    if (trades.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--dim)">No trades yet</td></tr>';
    } else {
      tbody.innerHTML = trades.map(t => {
        const pnlCls = parseFloat(t.pnl||0) >= 0 ? 'pnl-pos' : 'pnl-neg';
        const pnlStr = (parseFloat(t.pnl||0) >= 0 ? '+' : '') + fmt(t.pnl);
        const resCls = t.outcome === 'WIN' ? 'win' : (t.outcome === 'LOSS' ? 'loss' : '');
        return `<tr>
          <td>${t.symbol}</td>
          <td>${t.direction}</td>
          <td style="font-size:0.75rem">${t.strategy||'—'}</td>
          <td class="${pnlCls}">${pnlStr}</td>
          <td class="${resCls}">${t.outcome}</td>
        </tr>`;
      }).join('');
    }
  } catch(e) {
    document.getElementById('statusText').textContent = 'DISCONNECTED';
  }
}

async function closeAll() {
  if (!confirm('Close all open positions?')) return;
  await fetch('/api/close_all', {method:'POST'});
}

async function stopAgent() {
  if (!confirm('Stop the trading agent?')) return;
  await fetch('/api/stop', {method:'POST'});
}

// Auto-refresh
fetchStatus();
setInterval(fetchStatus, 5000);
</script>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    return DASHBOARD_HTML


def run_server(host: str = "0.0.0.0", port: int = 8000):
    uvicorn.run(app, host=host, port=port, log_level="warning")
