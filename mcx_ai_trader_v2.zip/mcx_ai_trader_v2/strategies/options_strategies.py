"""
Options Strategy Engine
Implements 15+ options strategies for MCX CrudeOilM & NatGasMini.
Selects the best strategy per market condition.
"""

import math
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple

logger = logging.getLogger("options")


# ─────────────────────────────────────────────────────────────────────────────
# Data models
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class OptionLeg:
    action:    str   # BUY | SELL
    opt_type:  str   # CE | PE
    strike:    int
    qty:       int
    expiry:    str   # e.g. JAN25
    premium:   float = 0.0

@dataclass
class OptionsStrategy:
    name:       str
    legs:       List[OptionLeg]
    max_profit: float = float("inf")
    max_loss:   float = float("inf")
    breakeven:  List[float] = field(default_factory=list)
    rationale:  str = ""


# ─────────────────────────────────────────────────────────────────────────────
# Black-Scholes for Greeks / fair value
# ─────────────────────────────────────────────────────────────────────────────

def _norm_cdf(x: float) -> float:
    return (1.0 + math.erf(x / math.sqrt(2.0))) / 2.0

def black_scholes(S: float, K: float, T: float, r: float,
                  sigma: float, opt_type: str = "CE") -> Tuple[float, Dict]:
    """Returns (price, greeks dict)."""
    if T <= 0 or sigma <= 0:
        intrinsic = max(0, S - K) if opt_type == "CE" else max(0, K - S)
        return intrinsic, {"delta": 0, "gamma": 0, "theta": 0, "vega": 0, "iv": sigma}

    d1 = (math.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    nd1 = _norm_cdf(d1)
    nd2 = _norm_cdf(d2)
    npd1 = math.exp(-0.5 * d1**2) / math.sqrt(2 * math.pi)

    if opt_type == "CE":
        price = S * nd1 - K * math.exp(-r * T) * nd2
        delta = nd1
    else:
        price = K * math.exp(-r * T) * _norm_cdf(-d2) - S * _norm_cdf(-d1)
        delta = nd1 - 1

    gamma  = npd1 / (S * sigma * math.sqrt(T))
    theta  = (-(S * npd1 * sigma) / (2 * math.sqrt(T))
              - r * K * math.exp(-r * T) * _norm_cdf(d2 if opt_type=="CE" else -d2)) / 365
    vega   = S * npd1 * math.sqrt(T) / 100

    return price, {"delta": delta, "gamma": gamma, "theta": theta, "vega": vega, "iv": sigma}


def implied_volatility(market_price: float, S: float, K: float, T: float,
                       r: float, opt_type: str = "CE") -> float:
    """Newton-Raphson IV solver."""
    sigma = 0.3
    for _ in range(100):
        price, greeks = black_scholes(S, K, T, r, sigma, opt_type)
        diff = price - market_price
        if abs(diff) < 1e-5:
            break
        vega = greeks["vega"] * 100  # convert back
        if vega < 1e-10:
            break
        sigma -= diff / vega
        sigma = max(0.001, min(sigma, 5.0))
    return sigma


# ─────────────────────────────────────────────────────────────────────────────
# Strategy constructor
# ─────────────────────────────────────────────────────────────────────────────

class OptionsStrategyEngine:
    """
    Given market conditions, selects and constructs the optimal options strategy.
    """

    STRATEGIES = [
        "long_call", "long_put", "covered_call", "protective_put",
        "bull_call_spread", "bear_put_spread", "bull_put_spread", "bear_call_spread",
        "long_straddle", "long_strangle", "short_straddle", "short_strangle",
        "iron_condor", "iron_butterfly",
        "call_ratio_spread", "put_ratio_spread",
        "calendar_spread", "diagonal_spread",
        "synthetic_long", "synthetic_short",
    ]

    def __init__(self, registry):
        self.registry = registry

    def select_strategy(self, symbol: str, signal: Dict,
                        ai_opinion: str, iv: float) -> Optional[OptionsStrategy]:
        """
        Select strategy based on direction + volatility environment.
        High IV → sell premium. Low IV → buy premium.
        """
        direction = signal.get("direction", "NEUTRAL")
        score     = signal.get("score", 0)
        atm       = signal.get("last_price", 0)

        if atm == 0:
            return None

        high_iv = iv > 0.35   # >35% IV = rich premium
        low_iv  = iv < 0.20   # <20% IV = cheap options

        # ── Strong directional ────────────────────────────────────────────
        if direction == "STRONG_BUY":
            if low_iv:
                return self.long_call(symbol, atm)
            else:
                return self.bull_call_spread(symbol, atm)

        if direction == "STRONG_SELL":
            if low_iv:
                return self.long_put(symbol, atm)
            else:
                return self.bear_put_spread(symbol, atm)

        if direction == "BUY":
            if high_iv:
                return self.bull_put_spread(symbol, atm)
            else:
                return self.bull_call_spread(symbol, atm)

        if direction == "SELL":
            if high_iv:
                return self.bear_call_spread(symbol, atm)
            else:
                return self.bear_put_spread(symbol, atm)

        # ── Neutral / range-bound ─────────────────────────────────────────
        if direction == "NEUTRAL":
            if high_iv:
                return self.iron_condor(symbol, atm)
            elif low_iv:
                return self.long_straddle(symbol, atm)
            else:
                return self.short_strangle(symbol, atm)

        return None

    # ── Strategy builders ─────────────────────────────────────────────────────

    def _round_strike(self, price: float, symbol: str) -> int:
        """Round to nearest valid MCX strike interval."""
        intervals = {
            "CRUDEOILM":  50,
            "NATGASMINI": 5,
        }
        step = intervals.get(symbol, 50)
        return int(round(price / step) * step)

    def _exp(self): return self.registry.near_expiry()

    def long_call(self, sym: str, atm: float) -> OptionsStrategy:
        k = self._round_strike(atm * 1.01, sym)
        leg = OptionLeg("BUY", "CE", k, 1, self._exp())
        return OptionsStrategy("Long Call", [leg],
            max_profit=float("inf"), max_loss=float("inf"),
            breakeven=[k],
            rationale="Strong bullish. Buy OTM CE for unlimited upside.")

    def long_put(self, sym: str, atm: float) -> OptionsStrategy:
        k = self._round_strike(atm * 0.99, sym)
        leg = OptionLeg("BUY", "PE", k, 1, self._exp())
        return OptionsStrategy("Long Put", [leg],
            max_profit=float("inf"), max_loss=float("inf"),
            breakeven=[k],
            rationale="Strong bearish. Buy OTM PE for downside exposure.")

    def bull_call_spread(self, sym: str, atm: float) -> OptionsStrategy:
        k1 = self._round_strike(atm, sym)
        step = {"CRUDEOILM": 100, "NATGASMINI": 10}.get(sym, 100)
        k2 = k1 + step
        legs = [
            OptionLeg("BUY",  "CE", k1, 1, self._exp()),
            OptionLeg("SELL", "CE", k2, 1, self._exp()),
        ]
        return OptionsStrategy("Bull Call Spread", legs,
            breakeven=[k1], rationale="Moderately bullish, capped risk.")

    def bear_put_spread(self, sym: str, atm: float) -> OptionsStrategy:
        k1 = self._round_strike(atm, sym)
        step = {"CRUDEOILM": 100, "NATGASMINI": 10}.get(sym, 100)
        k2 = k1 - step
        legs = [
            OptionLeg("BUY",  "PE", k1, 1, self._exp()),
            OptionLeg("SELL", "PE", k2, 1, self._exp()),
        ]
        return OptionsStrategy("Bear Put Spread", legs,
            breakeven=[k1], rationale="Moderately bearish, capped risk.")

    def bull_put_spread(self, sym: str, atm: float) -> OptionsStrategy:
        k_sell = self._round_strike(atm * 0.98, sym)
        step   = {"CRUDEOILM": 100, "NATGASMINI": 10}.get(sym, 100)
        k_buy  = k_sell - step
        legs = [
            OptionLeg("SELL", "PE", k_sell, 1, self._exp()),
            OptionLeg("BUY",  "PE", k_buy,  1, self._exp()),
        ]
        return OptionsStrategy("Bull Put Spread (Credit)", legs,
            rationale="Bullish credit spread. Collect premium if price stays above lower strike.")

    def bear_call_spread(self, sym: str, atm: float) -> OptionsStrategy:
        k_sell = self._round_strike(atm * 1.02, sym)
        step   = {"CRUDEOILM": 100, "NATGASMINI": 10}.get(sym, 100)
        k_buy  = k_sell + step
        legs = [
            OptionLeg("SELL", "CE", k_sell, 1, self._exp()),
            OptionLeg("BUY",  "CE", k_buy,  1, self._exp()),
        ]
        return OptionsStrategy("Bear Call Spread (Credit)", legs,
            rationale="Bearish credit spread. Collect premium if price stays below upper strike.")

    def long_straddle(self, sym: str, atm: float) -> OptionsStrategy:
        k = self._round_strike(atm, sym)
        legs = [
            OptionLeg("BUY", "CE", k, 1, self._exp()),
            OptionLeg("BUY", "PE", k, 1, self._exp()),
        ]
        return OptionsStrategy("Long Straddle", legs,
            rationale="Expecting big move but unsure of direction. Low IV environment.")

    def short_straddle(self, sym: str, atm: float) -> OptionsStrategy:
        k = self._round_strike(atm, sym)
        legs = [
            OptionLeg("SELL", "CE", k, 1, self._exp()),
            OptionLeg("SELL", "PE", k, 1, self._exp()),
        ]
        return OptionsStrategy("Short Straddle", legs,
            rationale="Range-bound. Collect maximum premium. High IV environment.")

    def long_strangle(self, sym: str, atm: float) -> OptionsStrategy:
        step = {"CRUDEOILM": 100, "NATGASMINI": 10}.get(sym, 100)
        kc = self._round_strike(atm + step, sym)
        kp = self._round_strike(atm - step, sym)
        legs = [
            OptionLeg("BUY", "CE", kc, 1, self._exp()),
            OptionLeg("BUY", "PE", kp, 1, self._exp()),
        ]
        return OptionsStrategy("Long Strangle", legs,
            rationale="Cheaper than straddle. Profits on large moves either way.")

    def short_strangle(self, sym: str, atm: float) -> OptionsStrategy:
        step = {"CRUDEOILM": 150, "NATGASMINI": 15}.get(sym, 150)
        kc = self._round_strike(atm + step, sym)
        kp = self._round_strike(atm - step, sym)
        legs = [
            OptionLeg("SELL", "CE", kc, 1, self._exp()),
            OptionLeg("SELL", "PE", kp, 1, self._exp()),
        ]
        return OptionsStrategy("Short Strangle", legs,
            rationale="Neutral. Wide wings collect premium. Moderate IV.")

    def iron_condor(self, sym: str, atm: float) -> OptionsStrategy:
        step = {"CRUDEOILM": 100, "NATGASMINI": 10}.get(sym, 100)
        kc_sell = self._round_strike(atm + step, sym)
        kc_buy  = kc_sell + step
        kp_sell = self._round_strike(atm - step, sym)
        kp_buy  = kp_sell - step
        legs = [
            OptionLeg("SELL", "CE", kc_sell, 1, self._exp()),
            OptionLeg("BUY",  "CE", kc_buy,  1, self._exp()),
            OptionLeg("SELL", "PE", kp_sell, 1, self._exp()),
            OptionLeg("BUY",  "PE", kp_buy,  1, self._exp()),
        ]
        return OptionsStrategy("Iron Condor", legs,
            rationale="Range-bound, high IV. Capped risk on both sides.")

    def iron_butterfly(self, sym: str, atm: float) -> OptionsStrategy:
        step = {"CRUDEOILM": 100, "NATGASMINI": 10}.get(sym, 100)
        k    = self._round_strike(atm, sym)
        legs = [
            OptionLeg("BUY",  "CE", k + step, 1, self._exp()),
            OptionLeg("SELL", "CE", k,         1, self._exp()),
            OptionLeg("SELL", "PE", k,         1, self._exp()),
            OptionLeg("BUY",  "PE", k - step, 1, self._exp()),
        ]
        return OptionsStrategy("Iron Butterfly", legs,
            rationale="ATM short straddle + OTM wings for protection. High premium collection.")

    def call_ratio_spread(self, sym: str, atm: float) -> OptionsStrategy:
        k1 = self._round_strike(atm, sym)
        step = {"CRUDEOILM": 100, "NATGASMINI": 10}.get(sym, 100)
        k2 = k1 + step
        legs = [
            OptionLeg("BUY",  "CE", k1, 1, self._exp()),
            OptionLeg("SELL", "CE", k2, 2, self._exp()),
        ]
        return OptionsStrategy("Call Ratio Spread (1:2)", legs,
            rationale="Mildly bullish. Profit from slow move up. Risk if sharp spike.")

    def put_ratio_spread(self, sym: str, atm: float) -> OptionsStrategy:
        k1 = self._round_strike(atm, sym)
        step = {"CRUDEOILM": 100, "NATGASMINI": 10}.get(sym, 100)
        k2 = k1 - step
        legs = [
            OptionLeg("BUY",  "PE", k1, 1, self._exp()),
            OptionLeg("SELL", "PE", k2, 2, self._exp()),
        ]
        return OptionsStrategy("Put Ratio Spread (1:2)", legs,
            rationale="Mildly bearish. Profit from slow decline. Risk if sharp crash.")

    def synthetic_long(self, sym: str, atm: float) -> OptionsStrategy:
        k = self._round_strike(atm, sym)
        legs = [
            OptionLeg("BUY",  "CE", k, 1, self._exp()),
            OptionLeg("SELL", "PE", k, 1, self._exp()),
        ]
        return OptionsStrategy("Synthetic Long", legs,
            rationale="Very bullish. Equivalent to long futures via options.")

    def synthetic_short(self, sym: str, atm: float) -> OptionsStrategy:
        k = self._round_strike(atm, sym)
        legs = [
            OptionLeg("SELL", "CE", k, 1, self._exp()),
            OptionLeg("BUY",  "PE", k, 1, self._exp()),
        ]
        return OptionsStrategy("Synthetic Short", legs,
            rationale="Very bearish. Equivalent to short futures via options.")
