"""
strategies/inventor.py — AI Strategy Inventor v2
Ported from FinanceAGI v17.2 commodity_strategy_manager.py + strategy_inventor.py.
Scoped to our 3 MCX symbols: GOLDPETAL, CRUDEOILM, NATGASMINI.

Capabilities:
  - Invent new strategies via Claude API based on trade performance
  - Track per-strategy win rate, PnL, drawdown
  - Promote / kill strategies automatically
  - Mutate existing high-performers
"""

import json
import logging
import math
import os
import random
import sqlite3
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, List, Optional

import requests

import config

logger = logging.getLogger("inventor")
IST  = timezone(timedelta(hours=5, minutes=30))
BASE = Path("data")
DB   = str(BASE / "learning.db")
STRAT_FILE = BASE / "invented_strategies.json"

# Thresholds
MIN_TRADES   = config.MIN_TRADES_TO_JUDGE
KILL_WR      = config.KILL_WIN_RATE
PROMOTE_WR   = config.PROMOTE_WIN_RATE
MAX_STRATS   = config.MAX_STRATEGIES
INVENT_EVERY = config.INVENT_EVERY_N_TRADES

KNOWN_ASSETS = config.FUTURES_SYMBOLS
SIGNAL_TYPES = list(config.STRATEGY_CATALOGUE.keys()) + ["CUSTOM_LLM"]


# ── DB setup ──────────────────────────────────────────────────────────────────

def _init_db():
    os.makedirs("data", exist_ok=True)
    con = sqlite3.connect(DB)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS invented_strategies (
        id          TEXT PRIMARY KEY,
        name        TEXT,
        description TEXT,
        params_json TEXT,
        status      TEXT DEFAULT 'active',
        source      TEXT DEFAULT 'invented',
        created_at  INTEGER,
        updated_at  INTEGER
    );
    CREATE TABLE IF NOT EXISTS invented_strat_trades (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        strategy_id TEXT,
        symbol      TEXT,
        won         INTEGER,
        gross_pnl   REAL,
        net_pnl     REAL,
        hold_min    REAL,
        ts          INTEGER
    );
    """)
    con.commit(); con.close()


# ── Claude API caller ─────────────────────────────────────────────────────────

def _call_claude(system: str, user: str, max_tokens: int = 1500) -> str:
    if not config.ANTHROPIC_API_KEY:
        logger.warning("[INVENTOR] No ANTHROPIC_API_KEY — skipping LLM call")
        return ""
    try:
        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            json={
                "model": config.CLAUDE_MODEL,
                "max_tokens": max_tokens,
                "system": system,
                "messages": [{"role": "user", "content": user}],
            },
            headers={
                "x-api-key": config.ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            timeout=30,
        )
        data = resp.json()
        return data.get("content", [{}])[0].get("text", "")
    except Exception as e:
        logger.error(f"[INVENTOR] Claude API error: {e}")
        return ""


# ── Performance tracker ───────────────────────────────────────────────────────

def _load_stats() -> Dict[str, Dict]:
    con  = sqlite3.connect(DB)
    rows = con.execute("""
        SELECT strategy_id, COUNT(*) t, SUM(won) w, SUM(net_pnl) pnl
        FROM invented_strat_trades GROUP BY strategy_id
    """).fetchall()
    con.close()
    result = {}
    for sid, t, w, pnl in rows:
        result[sid] = {
            "trades":   t or 0,
            "wins":     w or 0,
            "win_rate": round((w / t * 100) if t else 0, 1),
            "net_pnl":  round(pnl or 0, 2),
        }
    return result


def _load_strategies() -> List[Dict]:
    con  = sqlite3.connect(DB)
    rows = con.execute(
        "SELECT id,name,description,params_json,status,source FROM invented_strategies"
    ).fetchall()
    con.close()
    out = []
    for r in rows:
        sid, name, desc, pj, status, source = r
        try: params = json.loads(pj or "{}")
        except: params = {}
        out.append({"id": sid, "name": name, "description": desc,
                    "params": params, "status": status, "source": source})
    return out


def _save_strategy(strat_id: str, name: str, description: str, params: dict, source: str = "invented"):
    con = sqlite3.connect(DB)
    now = int(time.time())
    con.execute("""
        INSERT OR REPLACE INTO invented_strategies
            (id,name,description,params_json,status,source,created_at,updated_at)
        VALUES (?,?,?,?,'active',?,?,?)
    """, (strat_id, name, description, json.dumps(params), source, now, now))
    con.commit(); con.close()


# ── Strategy Inventor ─────────────────────────────────────────────────────────

class StrategyInventor:
    """
    Invents, tracks, promotes, and kills strategies for our 3 MCX symbols.
    Calls Claude API for invention; falls back to mutation if no API key.
    """

    def __init__(self):
        _init_db()
        self._closed_trades = 0
        self._load_file()

    def _load_file(self):
        """Load invented strategies from JSON file on disk."""
        try:
            if STRAT_FILE.exists():
                data = json.loads(STRAT_FILE.read_text())
                for s in data:
                    if s.get("active", True):
                        _save_strategy(
                            s["name"], s["name"], s.get("rationale", ""),
                            s, "file"
                        )
        except Exception as e:
            logger.debug(f"[INVENTOR] Strategy file load: {e}")

    # ── Public API ─────────────────────────────────────────────────────────────

    def record_trade(self, strategy_id: str, symbol: str,
                     won: bool, gross_pnl: float, net_pnl: float, hold_min: float):
        con = sqlite3.connect(DB)
        con.execute(
            "INSERT INTO invented_strat_trades (strategy_id,symbol,won,gross_pnl,net_pnl,hold_min,ts) "
            "VALUES (?,?,?,?,?,?,?)",
            (strategy_id, symbol, int(won), gross_pnl, net_pnl, hold_min, int(time.time()))
        )
        con.commit(); con.close()
        self._closed_trades += 1

        if self._closed_trades % INVENT_EVERY == 0:
            self.run_evolution()

    def run_evolution(self):
        """Kill losers, invent new, promote winners."""
        stats = _load_stats()
        self._kill_losers(stats)
        new_strats = self._invent(stats)
        for s in new_strats:
            _save_strategy(s["id"], s["name"], s.get("description", ""),
                           s, "invented")
        self._promote(stats)
        self._save_to_file()

    def _kill_losers(self, stats: Dict):
        strategies = _load_strategies()
        con = sqlite3.connect(DB)
        for s in strategies:
            sid = s["id"]
            st  = stats.get(sid, {})
            if st.get("trades", 0) >= MIN_TRADES and st.get("win_rate", 100) < KILL_WR:
                con.execute("UPDATE invented_strategies SET status='retired' WHERE id=?", (sid,))
                logger.info(f"[INVENTOR] Killed: {s['name']} WR={st.get('win_rate')}%")
        con.commit(); con.close()

    def _promote(self, stats: Dict):
        strategies = _load_strategies()
        con = sqlite3.connect(DB)
        for s in strategies:
            sid = s["id"]
            st  = stats.get(sid, {})
            if st.get("trades", 0) >= MIN_TRADES and st.get("win_rate", 0) >= PROMOTE_WR:
                if s["status"] == "active":
                    con.execute("UPDATE invented_strategies SET status='proven' WHERE id=?", (sid,))
                    logger.info(f"[INVENTOR] Promoted: {s['name']} WR={st.get('win_rate')}%")
        con.commit(); con.close()

    def _invent(self, stats: Dict) -> List[Dict]:
        """Invent new strategies via Claude. Falls back to mutation."""
        active = [s for s in _load_strategies() if s["status"] in ("active", "proven")]
        if len(active) >= MAX_STRATS:
            logger.info("[INVENTOR] Max strategies reached, skipping invention")
            return []

        perf_summary = "\n".join(
            f"  {sid}: {st['trades']}T WR={st['win_rate']}% PnL=₹{st['net_pnl']:.0f}"
            for sid, st in list(stats.items())[:8]
        ) or "  (no history yet)"

        system = (
            "You are an expert MCX commodity trading system designer. "
            "Respond ONLY with valid JSON — no markdown, no explanation."
        )
        user = f"""
Design 2 new futures trading strategies for these 3 MCX instruments:
  GOLDPETAL (Gold Petal, 10g/lot), CRUDEOILM (Crude Oil Mini, 10bbl/lot), NATGASMINI (NatGas Mini, 250mmBtu/lot)

Current strategy performance:
{perf_summary}

Available signal types: {', '.join(SIGNAL_TYPES)}

Return a JSON array of 2 strategy objects, each with:
{{
  "id": "unique_snake_case_id",
  "name": "Short strategy name",
  "description": "One sentence description",
  "symbols": ["GOLDPETAL"|"CRUDEOILM"|"NATGASMINI"|"ALL"],
  "signal_type": "<one of the signal types above>",
  "direction": "BUY"|"SELL"|"BOTH",
  "session": "both"|"morning"|"us",
  "target_pct": 0.5-2.5,
  "sl_pct": 0.3-1.5,
  "max_hold_min": 20-120,
  "min_score": 2-5,
  "rationale": "Why this edge exists for these commodities"
}}
"""
        text = _call_claude(system, user, max_tokens=1200)
        if not text:
            return self._mutate_best(active, stats)

        # Parse JSON
        try:
            text = text.strip()
            if text.startswith("```"):
                text = text.split("```")[1]
                if text.startswith("json"):
                    text = text[4:]
            new_strats = json.loads(text)
            if isinstance(new_strats, list):
                logger.info(f"[INVENTOR] Claude invented {len(new_strats)} new strategies")
                return new_strats
        except Exception as e:
            logger.warning(f"[INVENTOR] JSON parse failed: {e}")
        return self._mutate_best(active, stats)

    def _mutate_best(self, active: List[Dict], stats: Dict) -> List[Dict]:
        """Mutate the best performing strategy when no API key."""
        if not active: return []
        best = max(active, key=lambda s: stats.get(s["id"], {}).get("win_rate", 0))
        mutated = dict(best["params"])
        mutated["id"]        = f"mut_{best['id']}_{int(time.time())}"
        mutated["name"]      = f"{best['name']} v{random.randint(2, 9)}"
        mutated["target_pct"]= round(best["params"].get("target_pct", 1.0) * random.uniform(0.8, 1.3), 2)
        mutated["sl_pct"]    = round(best["params"].get("sl_pct", 0.6) * random.uniform(0.8, 1.2), 2)
        mutated["rationale"] = f"Mutation of {best['name']}"
        logger.info(f"[INVENTOR] Mutated: {mutated['name']}")
        return [mutated]

    def active_strategies(self) -> List[Dict]:
        return [s for s in _load_strategies() if s["status"] in ("active", "proven")]

    def performance_table(self) -> str:
        stats = _load_stats()
        lines = ["\n[INVENTOR] Strategy Performance:"]
        for s in _load_strategies():
            st   = stats.get(s["id"], {"trades": 0, "win_rate": 0, "net_pnl": 0})
            mark = "★" if s["status"] == "proven" else ("✗" if s["status"] == "retired" else " ")
            lines.append(f"  {mark} {s['name']:<30s} "
                         f"{st['trades']:>3}T  WR={st['win_rate']:>5.1f}%  "
                         f"PnL=₹{st['net_pnl']:>8.0f}")
        return "\n".join(lines)

    def _save_to_file(self):
        try:
            strats = _load_strategies()
            STRAT_FILE.write_text(json.dumps(strats, indent=2))
        except Exception: pass


# ── Singleton ──────────────────────────────────────────────────────────────────
inventor = StrategyInventor()
