#!/usr/bin/env python3
"""
command_centre.py — FreeAGI Control Dashboard (port 8001)
=========================================================
OAuth2 login for Upstox token + agent start/stop/status panel.

Run: python3 command_centre.py
Open: http://localhost:8001
"""

import asyncio, json, os, sqlite3, subprocess, sys, time
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.parse import urlencode, quote

import httpx

BASE = Path(__file__).resolve().parent
IST  = timezone(timedelta(hours=5, minutes=30))
DB   = str(BASE / "data" / "freeagi.db")
PORT = 8001

# Load .env
ENV = {}
_ef = BASE / ".env"
if _ef.exists():
    for _ln in _ef.read_text().splitlines():
        _ln = _ln.strip()
        if _ln and not _ln.startswith("#") and "=" in _ln:
            k, v = _ln.split("=", 1)
            ENV[k.strip()] = v.strip()

API_KEY  = ENV.get("UPSTOX_API_KEY", "")
API_SEC  = ENV.get("UPSTOX_API_SECRET", "")
REDIRECT = ENV.get("UPSTOX_REDIRECT_URI", f"http://localhost:{PORT}/callback")

def _db():
    Path(DB).parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def get_token() -> str:
    try:
        c = _db()
        c.execute("CREATE TABLE IF NOT EXISTS auth("
                  "id INTEGER PRIMARY KEY, provider TEXT, token TEXT)")
        c.commit()
        r = c.execute("SELECT token FROM auth WHERE provider='upstox' "
                      "ORDER BY id DESC LIMIT 1").fetchone()
        c.close()
        return r["token"] if r else ""
    except Exception:
        return ""

def save_token(token: str):
    c = _db()
    c.execute("CREATE TABLE IF NOT EXISTS auth("
              "id INTEGER PRIMARY KEY, provider TEXT, token TEXT)")
    c.execute("DELETE FROM auth WHERE provider='upstox'")
    c.execute("INSERT INTO auth(provider, token) VALUES('upstox', ?)", (token,))
    c.commit(); c.close()

async def exchange_code(code: str) -> str:
    """Exchange OAuth code for access token."""
    try:
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.post(
                "https://api.upstox.com/v2/login/authorization/token",
                headers={"Content-Type": "application/x-www-form-urlencoded",
                         "Accept": "application/json"},
                data={
                    "code": code,
                    "client_id": API_KEY,
                    "client_secret": API_SEC,
                    "redirect_uri": REDIRECT,
                    "grant_type": "authorization_code",
                },
            )
            data = r.json()
            return data.get("access_token", "")
    except Exception as e:
        return f"error: {e}"

def get_stats() -> dict:
    try:
        c = _db()
        c.execute("CREATE TABLE IF NOT EXISTS trades("
                  "id INTEGER PRIMARY KEY, won INTEGER, pnl REAL, net_pnl REAL)")
        r = c.execute("SELECT COUNT(*) t, COALESCE(SUM(won),0) w, "
                      "COALESCE(SUM(net_pnl),0) p FROM trades").fetchone()
        c.close()
        total = r["t"]; wins = int(r["w"]); pnl = round(r["p"], 2)
        return {"total": total, "wins": wins,
                "wr": round(wins / max(1, total) * 100, 1), "pnl": pnl}
    except Exception:
        return {"total": 0, "wins": 0, "wr": 0, "pnl": 0}

def agent_running() -> bool:
    try:
        import subprocess
        out = subprocess.check_output(["pgrep", "-f", "agent.py"], text=True)
        return bool(out.strip())
    except Exception:
        return False

HTML_TEMPLATE = """<!DOCTYPE html>
<html><head><title>FreeAGI Command Centre</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{{font-family:-apple-system,BlinkMacSystemFont,monospace;background:#0d1117;color:#e6edf3;
      padding:20px;max-width:700px;margin:0 auto}}
h1{{color:#58a6ff;margin-bottom:5px}}
.sub{{color:#8b949e;font-size:13px;margin-bottom:25px}}
.card{{background:#161b22;border:1px solid #21262d;border-radius:8px;padding:20px;margin:15px 0}}
.pill{{display:inline-block;padding:3px 10px;border-radius:12px;font-size:12px;font-weight:600}}
.live{{background:#238636;color:#fff}} .paper{{background:#1f6feb;color:#fff}}
.running{{background:#238636;color:#fff}} .stopped{{background:#b62324;color:#fff}}
.btn{{display:inline-block;padding:10px 20px;border-radius:6px;text-decoration:none;
      font-size:14px;font-weight:600;border:none;cursor:pointer;margin:5px}}
.btn-green{{background:#238636;color:#fff}} .btn-red{{background:#b62324;color:#fff}}
.btn-blue{{background:#1f6feb;color:#fff}} .btn-gray{{background:#21262d;color:#e6edf3}}
input{{background:#0d1117;border:1px solid #21262d;color:#e6edf3;padding:8px 12px;
       border-radius:6px;font-size:14px;width:100%;box-sizing:border-box;margin:5px 0}}
table{{width:100%;border-collapse:collapse;font-size:14px}}
th{{color:#8b949e;text-align:left;padding:8px;border-bottom:1px solid #21262d}}
td{{padding:8px;border-bottom:1px solid #161b22}}
.alert{{background:#1f3a1f;border:1px solid #238636;border-radius:6px;padding:10px;
        color:#56d364;margin:10px 0;font-size:13px}}
.error{{background:#3a1f1f;border:1px solid #b62324;border-radius:6px;padding:10px;
        color:#f85149;margin:10px 0;font-size:13px}}
</style></head>
<body>
<h1>⚡ FreeAGI</h1>
<div class="sub">MCX Commodity Futures — GOLDPETAL · CRUDEOILM · NATGASMINI</div>

{alert_html}

<div class="card">
<b>Agent Status</b><br><br>
<span class="pill {status_class}">{status_text}</span>
&nbsp;
<span class="pill {mode_class}">{mode_text}</span>
<br><br>
<a href="/start" class="btn btn-green">▶ Start Agent</a>
<a href="/stop"  class="btn btn-red">⏹ Stop Agent</a>
<a href="http://localhost:8080" target="_blank" class="btn btn-blue">📊 Live Dashboard</a>
<a href="/"      class="btn btn-gray">↻ Refresh</a>
</div>

<div class="card">
<b>Performance</b><br><br>
<table>
<tr><th>Trades</th><th>Wins</th><th>Win Rate</th><th>Net P&L</th></tr>
<tr><td>{total}</td><td>{wins}</td><td>{wr}%</td><td>₹{pnl:,.0f}</td></tr>
</table>
</div>

<div class="card">
<b>Upstox Login</b><br>
<small style="color:#8b949e">Token status: {token_status}</small><br><br>
<a href="{oauth_url}" class="btn btn-blue">🔑 Login with Upstox</a>
</div>

<div class="card">
<b>Quick Commands</b><br><br>
<a href="/reset_confirm" class="btn btn-gray">🗑 Reset All Data</a>
<a href="/logs"          class="btn btn-gray">📜 View Logs</a>
</div>

</body></html>"""

async def handle(reader, writer):
    try:
        data = await reader.read(4096)
        req  = data.decode("utf-8", errors="replace")
        path = req.split(" ")[1] if " " in req else "/"

        alert = ""
        code  = ""

        # ── Parse path ──
        if "?" in path:
            path, qs = path.split("?", 1)
            params = dict(p.split("=", 1) for p in qs.split("&") if "=" in p)
            code = params.get("code", "")

        # ── OAuth callback ──
        if path == "/callback" and code:
            token = await exchange_code(code)
            if token and not token.startswith("error"):
                save_token(token)
                alert = f'<div class="alert">✅ Login successful! Token saved. You can now start the agent.</div>'
            else:
                alert = f'<div class="error">❌ Login failed: {token}</div>'
            path = "/"

        if path == "/start":
            if not agent_running():
                subprocess.Popen(
                    [sys.executable, str(BASE / "agent.py")],
                    cwd=str(BASE),
                    stdout=open(BASE / "logs" / "agent.log", "a"),
                    stderr=subprocess.STDOUT,
                )
                time.sleep(1)
                alert = '<div class="alert">✅ Agent started.</div>'
            else:
                alert = '<div class="alert">Agent already running.</div>'
            path = "/"

        if path == "/stop":
            import subprocess as sp
            sp.run(["pkill", "-f", "agent.py"])
            time.sleep(1)
            alert = '<div class="alert">✅ Stop signal sent.</div>'
            path = "/"

        if path == "/logs":
            log_path = BASE / "logs" / "agent.log"
            try:
                lines = open(log_path).read().split("\n")[-100:]
                log_text = "\n".join(lines)
            except Exception:
                log_text = "No logs yet."
            html = (f"<html><head><title>Logs</title>"
                    f"<style>body{{background:#0d1117;color:#e6edf3;"
                    f"font-family:monospace;padding:20px}}</style></head>"
                    f"<body><pre>{log_text}</pre></body></html>")
            resp = (f"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n"
                    f"Content-Length: {len(html)}\r\n\r\n{html}")
            writer.write(resp.encode())
            await writer.drain(); writer.close(); return

        if path == "/reset_confirm":
            html = ("<html><head><title>Confirm Reset</title>"
                    "<style>body{background:#0d1117;color:#e6edf3;font-family:monospace;"
                    "padding:20px;max-width:500px;margin:0 auto}</style></head>"
                    "<body><h2>⚠️ Confirm Reset</h2>"
                    "<p>This will delete ALL trades, NN weights, RL data, and strategies.</p>"
                    "<a href='/reset_execute' style='background:#b62324;color:#fff;"
                    "padding:10px 20px;border-radius:6px;text-decoration:none'>Yes, reset everything</a>"
                    "&nbsp;<a href='/' style='background:#21262d;color:#e6edf3;"
                    "padding:10px 20px;border-radius:6px;text-decoration:none'>Cancel</a>"
                    "</body></html>")
            resp = (f"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n"
                    f"Content-Length: {len(html)}\r\n\r\n{html}")
            writer.write(resp.encode()); await writer.drain(); writer.close(); return

        if path == "/reset_execute":
            import subprocess as sp
            sp.run([sys.executable, str(BASE / "agent.py"), "reset"], cwd=str(BASE))
            alert = '<div class="alert">✅ All data reset.</div>'
            path = "/"

        # ── Main dashboard ──
        s       = get_stats()
        running = agent_running()
        token   = get_token()
        paper   = ENV.get("PAPER_TRADING", "true").lower() == "true"

        oauth_url = (
            f"https://api.upstox.com/v2/login/authorization/dialog?"
            f"response_type=code&client_id={API_KEY}"
            f"&redirect_uri={quote(REDIRECT)}"
        ) if API_KEY else "#"

        html = HTML_TEMPLATE.format(
            alert_html    = alert,
            status_class  = "running" if running else "stopped",
            status_text   = "RUNNING" if running else "STOPPED",
            mode_class    = "paper" if paper else "live",
            mode_text     = "PAPER" if paper else "LIVE",
            token_status  = f"✅ Set ({len(token)} chars)" if token else "❌ Not set",
            oauth_url     = oauth_url,
            total         = s["total"],
            wins          = s["wins"],
            wr            = s["wr"],
            pnl           = s["pnl"],
        )
        resp = (f"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n"
                f"Content-Length: {len(html)}\r\n\r\n{html}")
        writer.write(resp.encode())
        await writer.drain()
    except Exception as e:
        err = f"500 Error: {e}"
        resp = f"HTTP/1.1 500\r\nContent-Length: {len(err)}\r\n\r\n{err}"
        writer.write(resp.encode()); await writer.drain()
    finally:
        writer.close()

async def main():
    server = await asyncio.start_server(handle, "0.0.0.0", PORT)
    print(f"FreeAGI Command Centre → http://localhost:{PORT}")
    async with server:
        await server.serve_forever()

if __name__ == "__main__":
    asyncio.run(main())
