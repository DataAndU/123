#!/usr/bin/env python3
"""
FreeAGI v1.0 — MCX Commodity Futures Agent
==========================================
Focused MCX-only trading system for:
  - GOLDPETAL  (Gold Petal, 10g lot)
  - CRUDEOILM  (Crude Oil Mini, 10 bbl lot)
  - NATGASMINI (Nat Gas Mini, 250 mmBtu lot)

Key features (from FinanceAGI v17):
  - HMM regime detection (3-state: BULL/BEAR/CHOP)
  - Neural network + RL scoring (trade win prediction)
  - Strategy inventor via Anthropic Claude API
  - Multi-position: all 3 instruments simultaneously
  - Long AND short (direction-aware)
  - Kelly-based position sizing
  - Daily loss kill-switch
  - Telegram command listener (/stop, /status, /positions, /pnl)
  - Web dashboard on port 8080
  - Paper and live trading modes
  - GTT stop orders (live mode)
  - Graceful SIGTERM shutdown

Usage:
  python3 agent.py          # Start trading
  python3 agent.py stats    # View performance
  python3 agent.py reset    # Wipe memory + DB
  python3 agent.py paper    # Force paper mode for this run
"""

import asyncio, copy, gzip, hashlib, json, logging, math, os, pickle, random
import re, signal as _signal, sqlite3, sys, time
from collections import defaultdict, deque
from datetime import datetime, timezone, timedelta, time as dtime
from pathlib import Path

import numpy as np
import httpx

# ─────────────────────────── PATHS & IST ────────────────────────────────────

BASE = Path(__file__).resolve().parent
IST  = timezone(timedelta(hours=5, minutes=30))
DB   = str(BASE / "data" / "freeagi.db")
NN_F = str(BASE / "data" / "nn.pkl")
RL_F = str(BASE / "data" / "rl.pkl")
ST_F = str(BASE / "data" / "strategies.json")

for d in ["data", "logs"]:
    (BASE / d).mkdir(parents=True, exist_ok=True)

# ─────────────────────────── LOAD .env ──────────────────────────────────────

ENV = {}
_ef = BASE / ".env"
if _ef.exists():
    for _ln in _ef.read_text().splitlines():
        _ln = _ln.strip()
        if _ln and not _ln.startswith("#") and "=" in _ln:
            k, v = _ln.split("=", 1)
            ENV[k.strip()] = v.strip()
            os.environ.setdefault(k.strip(), v.strip())

# ─────────────────────────── LOGGING ────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(message)s",
    datefmt="%H:%M:%S",
    handlers=[logging.FileHandler(BASE / "logs" / "agent.log")],
)
if sys.stdout.isatty():
    logging.getLogger().addHandler(logging.StreamHandler())
log = logging.getLogger("freeagi")

# ═══════════════════════════════════════════════════════════════════
#  RUNTIME CONFIG
# ═══════════════════════════════════════════════════════════════════

VERSION   = "1.0"
PAPER     = ENV.get("PAPER_TRADING", "true").lower() == "true"
LIVE      = ENV.get("TRADING_ENABLED", "true").lower() == "true"
CAPITAL   = float(ENV.get("CAPITAL", "50000"))
MAX_DD    = float(ENV.get("MAX_DAILY_LOSS_PCT", "5.0"))   # daily loss kill-switch %
MAX_POSITIONS = 3  # one per instrument max
LOOP_INTERVAL = int(ENV.get("LOOP_INTERVAL", "20"))       # seconds between scan cycles

TG_TOKEN = ENV.get("TG_BOT_TOKEN", ENV.get("TELEGRAM_TOKEN", ""))
TG_CHAT  = ENV.get("TG_CHAT_ID",   ENV.get("TELEGRAM_CHAT_ID", ""))

API_KEY  = ENV.get("UPSTOX_API_KEY", "")
API_SEC  = ENV.get("UPSTOX_API_SECRET", "")
API_URL  = "https://api.upstox.com"
HFT_URL  = "https://api-hft.upstox.com"

ANTHROPIC_KEY = ENV.get("ANTHROPIC_API_KEY", "")

# ═══════════════════════════════════════════════════════════════════
#  INSTRUMENT DEFINITIONS  (3 instruments only)
# ═══════════════════════════════════════════════════════════════════

INSTRUMENTS = {
    "GOLDPETAL": {
        "name":        "Gold Petal",
        "lot_size":    10,
        "tick_size":   1.0,
        "min_capital": 6000,
        "volatility":  0.8,
        "target_pct":  0.6,
        "sl_pct":      0.35,
        "max_hold_min":60,
        "session":     "both",
        "strategies":  ["TREND_FOLLOW", "MEAN_REVERT", "VIX_SPIKE_GOLD", "GOLD_HEDGE"],
    },
    "CRUDEOILM": {
        "name":        "Crude Oil Mini",
        "lot_size":    10,
        "tick_size":   1.0,
        "min_capital": 7000,
        "volatility":  2.0,
        "target_pct":  1.0,
        "sl_pct":      0.55,
        "max_hold_min":45,
        "session":     "both",
        "strategies":  ["TREND_FOLLOW", "BREAKOUT_VOL", "US_MOMENTUM",
                        "INVENTORY_CRUDE", "VOLATILITY_CRUSH"],
    },
    "NATGASMINI": {
        "name":        "Nat Gas Mini",
        "lot_size":    250,
        "tick_size":   0.1,
        "min_capital": 3000,
        "volatility":  3.0,
        "target_pct":  1.5,
        "sl_pct":      0.8,
        "max_hold_min":40,
        "session":     "us",
        "strategies":  ["US_MOMENTUM", "SEASONAL_NATGAS", "VOLATILITY_CRUSH", "MEAN_REVERT"],
    },
}

MCX_OPEN     = dtime(9, 0)
MCX_CLOSE    = dtime(23, 25)
MCX_NO_ENTRY = dtime(23, 10)
US_SESSION   = dtime(18, 30)
ORB_END      = dtime(9, 30)
MIN_DTE      = 5
FORCE_EXIT_DTE = 3

NATGAS_SEASONAL = {1:+1,2:+1,3:-1,4:-1,5:0,6:+1,7:+1,8:+1,9:-1,10:0,11:+1,12:+1}

# ═══════════════════════════════════════════════════════════════════
#  TELEGRAM
# ═══════════════════════════════════════════════════════════════════

_tg_client: httpx.AsyncClient | None = None

async def tg(msg: str):
    if not TG_TOKEN or not TG_CHAT:
        return
    global _tg_client
    try:
        if _tg_client is None or _tg_client.is_closed:
            _tg_client = httpx.AsyncClient(timeout=6)
        await _tg_client.post(
            f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
            json={"chat_id": TG_CHAT, "text": msg, "parse_mode": "HTML"},
        )
    except Exception:
        pass

# ═══════════════════════════════════════════════════════════════════
#  BROKER (Upstox v2)
# ═══════════════════════════════════════════════════════════════════

class Broker:
    def __init__(self):
        self.token = ENV.get("UPSTOX_ACCESS_TOKEN", "")
        self._client: httpx.AsyncClient | None = None
        # Try loading token from DB
        try:
            c = sqlite3.connect(DB)
            r = c.execute("SELECT token FROM auth WHERE provider='upstox' "
                          "ORDER BY id DESC LIMIT 1").fetchone()
            if r and r[0]:
                self.token = r[0]
            c.close()
        except Exception:
            pass

    def _cli(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=12, limits=httpx.Limits(max_connections=10))
        return self._client

    @property
    def ok(self): return bool(self.token)

    @property
    def _h(self):
        return {
            "Accept": "application/json",
            "Authorization": f"Bearer {self.token}",
            "User-Agent": "FreeAGI/1.0",
        }

    def reload_token(self):
        try:
            c = sqlite3.connect(DB)
            r = c.execute("SELECT token FROM auth WHERE provider='upstox' "
                          "ORDER BY id DESC LIMIT 1").fetchone()
            if r and r[0] and r[0] != self.token:
                self.token = r[0]
                self._client = None
                log.info(f"  Broker: token refreshed")
            c.close()
        except Exception:
            pass

    async def get(self, path: str):
        r = await self._cli().get(f"{API_URL}{path}", headers=self._h)
        return r.json()

    async def post(self, path: str, body: dict):
        r = await self._cli().post(
            f"{HFT_URL}{path}",
            headers={**self._h, "Content-Type": "application/json"},
            json=body,
        )
        return r.json()

    async def cash(self) -> float:
        if PAPER:
            return max(CAPITAL, float(ENV.get("CAPITAL", str(CAPITAL))))
        try:
            d = await self.get("/v2/user/get-funds-and-margin")
            return d.get("data", {}).get("equity", {}).get("available_margin", 0)
        except Exception as e:
            log.warning(f"  cash(): {e}")
            return 0

    async def ltp(self, key: str) -> float:
        try:
            d = await self.get(f"/v2/market-quote/ltp?instrument_key={key}")
            for v in d.get("data", {}).values():
                p = v.get("last_price", 0)
                if p > 0: return p
        except Exception:
            pass
        return 0.0

    async def ohlc(self, key: str) -> dict:
        try:
            d = await self.get(f"/v2/market-quote/ohlc?instrument_key={key}&interval=1d")
            for v in d.get("data", {}).values():
                o = v.get("ohlc", {})
                if o: return o
        except Exception:
            pass
        return {}

    async def buy(self, key: str, qty: int, direction: str = "BUY") -> dict:
        if PAPER:
            return {"status": "success", "data": {"order_ids": [f"P-{int(time.time())}"]}}
        if not LIVE:
            return {"status": "error", "errors": [{"message": "Trading disabled"}]}
        return await self.post("/v3/order/place", {
            "quantity": qty, "product": "I", "validity": "DAY", "price": 0,
            "instrument_token": key, "order_type": "MARKET",
            "transaction_type": direction,
            "disclosed_quantity": 0, "trigger_price": 0,
            "is_amo": False, "slice": True,
        })

    async def sell(self, key: str, qty: int, entry_direction: str = "BUY") -> dict:
        exit_dir = "SELL" if entry_direction == "BUY" else "BUY"
        if PAPER:
            return {"status": "success", "data": {"order_ids": [f"P-X-{int(time.time())}"]}}
        if not LIVE:
            return {"status": "error"}
        return await self.post("/v3/order/place", {
            "quantity": qty, "product": "I", "validity": "DAY", "price": 0,
            "instrument_token": key, "order_type": "MARKET",
            "transaction_type": exit_dir,
            "disclosed_quantity": 0, "trigger_price": 0,
            "is_amo": False, "slice": True,
        })

broker = Broker()

# ═══════════════════════════════════════════════════════════════════
#  MCX INSTRUMENT KEY MANAGER
# ═══════════════════════════════════════════════════════════════════

MCX_INSTRUMENTS_URL = "https://assets.upstox.com/market-quote/instruments/exchange/MCX.json.gz"

class MCXInstruments:
    def __init__(self):
        self.keys: dict[str, str]      = {}
        self.expiry: dict[str, datetime] = {}
        self.dte: dict[str, int]       = {}
        self.lot: dict[str, int]       = {}
        self.last_refresh              = 0
        self._cache = BASE / "data" / "mcx_keys.json"

    async def refresh(self):
        now_ts = time.time()
        if now_ts - self.last_refresh < 3600 * 8:
            return
        try:
            async with httpx.AsyncClient(timeout=20) as c:
                r   = await c.get(MCX_INSTRUMENTS_URL,
                                  headers={"User-Agent": "Mozilla/5.0"})
                raw = gzip.decompress(r.content)
                data = json.loads(raw)
            self._cache.parent.mkdir(parents=True, exist_ok=True)
            json.dump(data, open(self._cache, "w"))
            log.info(f"  MCX: Downloaded {len(data)} instruments")
            self._parse(data)
            self.last_refresh = now_ts
        except Exception as e:
            log.error(f"  MCX instrument download failed: {e}")
            self._load_cache()

    def _load_cache(self):
        try:
            if self._cache.exists():
                self._parse(json.load(open(self._cache)))
                log.info("  MCX: Loaded instruments from cache")
        except Exception as e:
            log.error(f"  MCX cache load failed: {e}")

    def _parse(self, data: list):
        today     = datetime.now(IST).replace(hour=0, minute=0, second=0, microsecond=0)
        min_exp   = (today + timedelta(days=MIN_DTE)).timestamp() * 1000
        today_ms  = today.timestamp() * 1000
        by_sym: dict[str, list] = {}

        for inst in data:
            if inst.get("instrument_type") != "FUT": continue
            if inst.get("segment") != "MCX_FO": continue
            sym = inst.get("underlying_symbol", "")
            if sym not in INSTRUMENTS: continue
            if inst.get("expiry", 0) <= today_ms: continue
            by_sym.setdefault(sym, []).append(inst)

        for sym, contracts in by_sym.items():
            contracts.sort(key=lambda x: x["expiry"])
            eligible = [c for c in contracts if c["expiry"] > min_exp]
            if not eligible:
                log.warning(f"  MCX {sym}: No eligible contract (DTE>{MIN_DTE})")
                continue
            chosen = eligible[0]
            exp_dt = datetime.fromtimestamp(chosen["expiry"] / 1000, tz=IST)
            dte_d  = (exp_dt.date() - datetime.now(IST).date()).days
            # If very close to expiry and a next contract exists, pick next
            if dte_d <= MIN_DTE + 2 and len(eligible) >= 2:
                chosen = eligible[1]
                exp_dt = datetime.fromtimestamp(chosen["expiry"] / 1000, tz=IST)
                dte_d  = (exp_dt.date() - datetime.now(IST).date()).days
            self.keys[sym]   = chosen["instrument_key"]
            self.expiry[sym] = exp_dt
            self.dte[sym]    = dte_d
            self.lot[sym]    = chosen.get("lot_size", INSTRUMENTS[sym]["lot_size"])
            log.info(f"  MCX {sym}: {chosen.get('trading_symbol',sym)} DTE={dte_d}")

    def available(self) -> list[str]:
        return [s for s in INSTRUMENTS
                if s in self.keys and self.keys[s]
                and self.dte.get(s, 0) > FORCE_EXIT_DTE]

    def keys_loaded(self) -> bool:
        return len(self.keys) > 0

mcx_inst = MCXInstruments()

# ═══════════════════════════════════════════════════════════════════
#  CHARGES (MCX)
# ═══════════════════════════════════════════════════════════════════

class MCXCharges:
    @staticmethod
    def calculate(buy_price: float, sell_price: float, qty: int) -> dict:
        buy_val  = buy_price * qty
        sell_val = sell_price * qty
        turnover = buy_val + sell_val
        brokerage = 40
        ctt       = sell_val * 0.0001
        exchange  = turnover * 0.000026
        sebi      = turnover * 0.000001
        stamp     = buy_val  * 0.00002
        gst       = (brokerage + exchange + sebi) * 0.18
        total = brokerage + ctt + exchange + gst + sebi + stamp
        gross = (sell_price - buy_price) * qty
        return {
            "total":     round(total, 2),
            "gross_pnl": round(gross, 2),
            "net_pnl":   round(gross - total, 2),
            "be_pct":    round(total / max(1, buy_val) * 100, 3),
        }

    @staticmethod
    def be_pct(price: float, qty: int) -> float:
        val   = price * qty
        total = (40 + val * 0.0001 + val * 2 * 0.000026 + val * 0.00002
                 + (40 + val * 2 * 0.000026) * 0.18)
        return round(total / max(1, val) * 100, 3)

charges = MCXCharges()

# ═══════════════════════════════════════════════════════════════════
#  STRATEGY SIGNALS
# ═══════════════════════════════════════════════════════════════════

class Signals:

    @staticmethod
    def ema(series: list, period: int) -> float:
        if len(series) < 2: return series[-1] if series else 0.0
        k = 2.0 / (period + 1)
        e = series[0]
        for v in series[1:]:
            e = v * k + e * (1 - k)
        return e

    @staticmethod
    def rsi(closes: list, period: int = 14) -> float:
        if len(closes) < period + 1: return 50.0
        gains, losses = [], []
        for i in range(1, len(closes)):
            d = closes[i] - closes[i-1]
            gains.append(max(d, 0)); losses.append(max(-d, 0))
        ag = sum(gains[-period:]) / period
        al = sum(losses[-period:]) / period
        if al == 0: return 100.0
        return round(100 - (100 / (1 + ag / al)), 2)

    @staticmethod
    def bollinger(closes: list, period: int = 20) -> dict:
        if len(closes) < period:
            m = closes[-1] if closes else 0
            return {"upper": m * 1.01, "mid": m, "lower": m * 0.99}
        w = closes[-period:]
        m = sum(w) / period
        std = math.sqrt(sum((x - m) ** 2 for x in w) / period)
        return {"upper": m + 2 * std, "mid": m, "lower": m - 2 * std}

    @staticmethod
    def trend_follow(closes: list, day_chg: float) -> dict:
        if len(closes) < 20:
            # Fallback on day change alone
            if day_chg > 0.3: return {"dir": "BUY",  "strength": 1}
            if day_chg < -0.3: return {"dir": "SELL", "strength": 1}
            return {"dir": "SKIP", "strength": 0}
        e5  = Signals.ema(closes[-30:], 5)
        e20 = Signals.ema(closes[-30:], 20)
        sep = abs(e5 - e20) / max(e20, 1) * 100
        d = "BUY" if e5 > e20 else "SELL"
        s = 1 + (1 if sep > 0.3 else 0) + (1 if sep > 0.6 else 0)
        return {"dir": d, "strength": s}

    @staticmethod
    def mean_revert(closes: list) -> dict:
        if len(closes) < 14: return {"dir": "SKIP", "strength": 0}
        rsi_v = Signals.rsi(closes[-20:])
        bb    = Signals.bollinger(closes[-20:])
        ltp   = closes[-1]
        if rsi_v <= 25 and ltp <= bb["lower"] * 1.005:
            return {"dir": "BUY",  "strength": 3, "rsi": rsi_v}
        if rsi_v <= 30 and ltp <= bb["lower"] * 1.01:
            return {"dir": "BUY",  "strength": 2, "rsi": rsi_v}
        if rsi_v >= 75 and ltp >= bb["upper"] * 0.995:
            return {"dir": "SELL", "strength": 3, "rsi": rsi_v}
        if rsi_v >= 70 and ltp >= bb["upper"] * 0.99:
            return {"dir": "SELL", "strength": 2, "rsi": rsi_v}
        return {"dir": "SKIP", "strength": 0, "rsi": rsi_v}

    @staticmethod
    def breakout_vol(ltp: float, orb_high: float, orb_low: float,
                     vol: float, avg_vol: float) -> dict:
        vr = vol / max(avg_vol, 1)
        if ltp > orb_high and vr >= 1.5:
            return {"dir": "BUY",  "strength": min(3, int(vr))}
        if ltp < orb_low and vr >= 1.5:
            return {"dir": "SELL", "strength": min(3, int(vr))}
        return {"dir": "SKIP", "strength": 0}

    @staticmethod
    def us_momentum(closes: list) -> dict:
        now = datetime.now(IST)
        if not (dtime(18, 30) <= now.time() <= dtime(19, 0)):
            return {"dir": "SKIP", "strength": 0}
        if len(closes) < 5: return {"dir": "SKIP", "strength": 0}
        mom = (closes[-1] - closes[0]) / max(closes[0], 1) * 100
        if mom > 0.4:  return {"dir": "BUY",  "strength": 2 + (1 if mom > 0.8 else 0)}
        if mom < -0.4: return {"dir": "SELL", "strength": 2 + (1 if mom < -0.8 else 0)}
        return {"dir": "SKIP", "strength": 0}

    @staticmethod
    def gold_hedge(vix: float, usd_inr_chg: float) -> dict:
        score = (2 if vix > 18 else 1 if vix > 16 else 0) + \
                (2 if usd_inr_chg > 0.3 else 1 if usd_inr_chg > 0.1 else 0)
        if score >= 2: return {"dir": "BUY", "strength": min(score, 3)}
        return {"dir": "SKIP", "strength": 0}

    @staticmethod
    def seasonal_natgas() -> dict:
        month = datetime.now(IST).month
        bias  = NATGAS_SEASONAL.get(month, 0)
        if bias == 0: return {"dir": "SKIP", "strength": 0}
        return {"dir": "BUY" if bias > 0 else "SELL", "strength": 1}

    @staticmethod
    def inventory_crude(eia_draw: float) -> dict:
        now = datetime.now(IST)
        if now.weekday() != 2: return {"dir": "SKIP", "strength": 0}
        if not (dtime(20, 15) <= now.time() <= dtime(20, 45)):
            return {"dir": "SKIP", "strength": 0}
        if abs(eia_draw) < 1.0: return {"dir": "SKIP", "strength": 0}
        d = "BUY" if eia_draw > 0 else "SELL"
        return {"dir": d, "strength": 2 if abs(eia_draw) > 3 else 1}

    @staticmethod
    def vix_spike_gold(vix: float, prev_vix: float) -> dict:
        if vix > 18 and vix - prev_vix > 1.0:
            return {"dir": "BUY", "strength": 2 + (1 if vix > 22 else 0)}
        return {"dir": "SKIP", "strength": 0}

    @staticmethod
    def volatility_crush(closes: list) -> dict:
        if len(closes) < 3: return {"dir": "SKIP", "strength": 0}
        spike = (closes[-1] - closes[-2]) / max(closes[-2], 1) * 100
        if spike >= 2.0:  return {"dir": "SELL", "strength": 2}
        if spike <= -2.0: return {"dir": "BUY",  "strength": 2}
        return {"dir": "SKIP", "strength": 0}

sigs = Signals()

# ═══════════════════════════════════════════════════════════════════
#  HMM REGIME DETECTION (3-state: BULL/BEAR/CHOP)
# ═══════════════════════════════════════════════════════════════════

class RegimeDetector:
    STATES = {0: "BULL", 1: "BEAR", 2: "CHOP"}

    def __init__(self):
        self.current = "CHOP"
        self._returns: deque = deque(maxlen=50)
        self._history: list  = []
        self._hmmlearn: bool = False
        self._model = None
        try:
            from hmmlearn.hmm import GaussianHMM
            self._GaussianHMM = GaussianHMM
            self._hmmlearn = True
            log.info("  [REGIME] hmmlearn available — 3-state HMM active")
        except ImportError:
            log.info("  [REGIME] hmmlearn not found — using rule-based regime")

    def update(self, spot: float, prev_spot: float):
        if prev_spot <= 0 or spot <= 0: return
        r = math.log(spot / prev_spot)
        self._returns.append(r)
        rvol = float(np.std(list(self._returns)[-5:])) if len(self._returns) >= 5 else abs(r)
        self._history.append([r, rvol])

    def detect(self) -> str:
        if self._hmmlearn and len(self._history) >= 30:
            return self._hmm_detect()
        return self._rule_detect()

    def _hmm_detect(self) -> str:
        try:
            X = np.array(self._history[-100:])
            if self._model is None or len(self._history) % 20 == 0:
                m = self._GaussianHMM(n_components=3, covariance_type="diag",
                                      n_iter=50, random_state=42)
                m.fit(X)
                # Label states: BULL = highest mean return, BEAR = lowest
                means = m.means_[:, 0]
                state_map = {int(np.argmax(means)): "BULL",
                             int(np.argmin(means)): "BEAR"}
                for i in range(3):
                    if i not in state_map: state_map[i] = "CHOP"
                self._model = m
                self._state_map = state_map
            hidden = self._model.predict(X)
            self.current = self._state_map.get(int(hidden[-1]), "CHOP")
            return self.current
        except Exception:
            return self._rule_detect()

    def _rule_detect(self) -> str:
        if len(self._returns) < 5:
            self.current = "CHOP"; return "CHOP"
        recent = list(self._returns)[-10:]
        mean   = sum(recent) / len(recent)
        if mean > 0.0005:  self.current = "BULL"
        elif mean < -0.0005: self.current = "BEAR"
        else:              self.current = "CHOP"
        return self.current

regime = RegimeDetector()

# ═══════════════════════════════════════════════════════════════════
#  NEURAL NETWORK  (trade win predictor)
# ═══════════════════════════════════════════════════════════════════

# Feature vector: [day_chg, range_pct, range_pos, vol_ratio, direction, score,
#                  hour_sin, hour_cos, dte_norm, be_pct_norm]
FEAT_DIM = 10

class NN:
    def __init__(self, dims=None):
        dims = dims or (FEAT_DIM, 24, 12, 1)
        self.dims = list(dims); self.nl = len(dims) - 1
        self.W = [np.random.randn(dims[i], dims[i+1]) * np.sqrt(2/dims[i])
                  for i in range(self.nl)]
        self.b = [np.zeros((1, dims[i+1])) for i in range(self.nl)]
        self.mW = [np.zeros_like(w) for w in self.W]
        self.mb = [np.zeros_like(b) for b in self.b]
        self.vW = [np.zeros_like(w) for w in self.W]
        self.vb = [np.zeros_like(b) for b in self.b]
        self.lr = 0.001; self.b1 = 0.9; self.b2 = 0.999; self.step = 0
        self.mu = np.zeros(dims[0]); self.var = np.ones(dims[0]); self.cnt = 0

    def _norm(self, X):
        return (X - self.mu) / (np.sqrt(self.var) + 1e-8)

    def _update_stats(self, X):
        for x in X:
            self.cnt += 1
            d = x - self.mu
            self.mu += d / self.cnt
            self.var += (d * (x - self.mu) - self.var) / self.cnt

    def predict(self, f: np.ndarray) -> float:
        a = self._norm(f.reshape(1, -1))
        for i in range(self.nl):
            z = a @ self.W[i] + self.b[i]
            a = (np.maximum(0, z) if i < self.nl - 1
                 else 1 / (1 + np.exp(-np.clip(z, -500, 500))))
        return float(a[0, 0])

    def train(self, X: np.ndarray, y: np.ndarray, ep: int = 100):
        self._update_stats(X); Xn = self._norm(X); m = len(X)
        for _ in range(ep):
            a = Xn; acts = [Xn]; zs = []
            for i in range(self.nl):
                z = a @ self.W[i] + self.b[i]; zs.append(z)
                a = (np.maximum(0, z) if i < self.nl - 1
                     else 1 / (1 + np.exp(-np.clip(z, -500, 500))))
                acts.append(a)
            p = np.clip(acts[-1], 1e-7, 1 - 1e-7)
            d = p - y
            for i in range(self.nl - 1, -1, -1):
                dW = acts[i].T @ d / m; db = d.mean(0, keepdims=True)
                self.step += 1
                self.mW[i] = self.b1*self.mW[i] + (1-self.b1)*dW
                self.mb[i] = self.b1*self.mb[i] + (1-self.b1)*db
                self.vW[i] = self.b2*self.vW[i] + (1-self.b2)*dW**2
                self.vb[i] = self.b2*self.vb[i] + (1-self.b2)*db**2
                mh = self.mW[i]/(1-self.b1**self.step)
                bh = self.mb[i]/(1-self.b1**self.step)
                vh = self.vW[i]/(1-self.b2**self.step)
                vbh= self.vb[i]/(1-self.b2**self.step)
                self.W[i] -= self.lr * mh / (np.sqrt(vh) + 1e-8)
                self.b[i] -= self.lr * bh / (np.sqrt(vbh) + 1e-8)
                if i > 0: d = (d @ self.W[i].T) * (zs[i-1] > 0).astype(float)

    def train1(self, f: np.ndarray, outcome: float):
        self.train(f.reshape(1, -1), np.array([[outcome]]), ep=30)

    def save(self):
        pickle.dump({k: getattr(self, k) for k in
                     ["W","b","mW","mb","vW","vb","mu","var","cnt","step","dims"]},
                    open(NN_F, "wb"))

    def load(self) -> bool:
        if not os.path.exists(NN_F): return False
        try:
            d = pickle.load(open(NN_F, "rb"))
            if d.get("dims") != list(self.dims): return False
            for k, v in d.items(): setattr(self, k, v)
            self.nl = len(self.dims) - 1
            return True
        except Exception:
            return False

nn = NN()

def make_features(sym: str, ltp: float, day_chg: float, range_pct: float,
                  range_pos: float, direction: str, score: int,
                  dte: int, be_pct: float) -> np.ndarray:
    now  = datetime.now(IST)
    h    = now.hour + now.minute / 60
    return np.array([
        day_chg / 5.0,
        range_pct / 3.0,
        range_pos,
        1.0 if direction == "BUY" else -1.0,
        score / 10.0,
        math.sin(2 * math.pi * h / 24),
        math.cos(2 * math.pi * h / 24),
        min(dte / 30.0, 1.0),
        be_pct / 0.5,
        abs(day_chg) / 3.0,
    ], dtype=np.float64)[:FEAT_DIM]

# ═══════════════════════════════════════════════════════════════════
#  REINFORCEMENT LEARNING (Q-table)
# ═══════════════════════════════════════════════════════════════════

class RL:
    def __init__(self):
        self.Q: dict = defaultdict(lambda: np.zeros(6))
        self.ep = 0
        self.total_r = 0.0

    def state(self) -> str:
        reg = regime.current
        now = datetime.now(IST)
        h   = "O" if now.hour < 10 else "M" if now.hour < 15 else "E" if now.hour < 19 else "U"
        return f"{reg[0]}{h}"

    def act(self, s: str, n_actions: int, explore: bool = False) -> int:
        eps = max(0.05, 0.3 * 0.99 ** self.ep)
        if explore or random.random() < eps:
            return random.randint(0, n_actions - 1)
        q = self.Q[s][:n_actions]
        return int(np.argmax(q))

    def update(self, s: str, a: int, r: float, s2: str, n: int):
        best = float(np.max(self.Q[s2][:n])) if n > 0 else 0
        self.Q[s][a] += 0.15 * (r + 0.95 * best - self.Q[s][a])
        self.ep += 1; self.total_r += r

    def save(self):
        pickle.dump({"Q": dict(self.Q), "ep": self.ep, "r": self.total_r},
                    open(RL_F, "wb"))

    def load(self) -> bool:
        if not os.path.exists(RL_F): return False
        try:
            d = pickle.load(open(RL_F, "rb"))
            self.Q = defaultdict(lambda: np.zeros(6), d["Q"])
            self.ep = d.get("ep", 0); self.total_r = d.get("r", 0.0)
            return True
        except Exception:
            return False

rl = RL()

# ═══════════════════════════════════════════════════════════════════
#  DATABASE
# ═══════════════════════════════════════════════════════════════════

def _db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def init_db():
    c = _db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS trades(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, symbol TEXT, direction TEXT, strategy TEXT,
        entry_price REAL, exit_price REAL, qty INTEGER,
        pnl REAL, pnl_pct REAL, net_pnl REAL, charges REAL,
        won INTEGER, exit_reason TEXT, hold_sec INTEGER,
        score INTEGER, nn_prob REAL, regime TEXT,
        features_json TEXT, day_chg_pct REAL
    );
    CREATE TABLE IF NOT EXISTS auth(
        id INTEGER PRIMARY KEY, provider TEXT, token TEXT
    );
    CREATE TABLE IF NOT EXISTS daily(
        date TEXT PRIMARY KEY, trades INTEGER, wins INTEGER, pnl REAL
    );
    """)
    c.commit(); c.close()

def log_trade(t: dict):
    clean = {k: v for k, v in t.items() if not k.startswith("_")}
    c = _db()
    cols = ",".join(clean.keys())
    vals = ",".join(f":{k}" for k in clean.keys())
    try:
        c.execute(f"INSERT INTO trades({cols}) VALUES({vals})", clean)
        c.commit()
    except Exception as e:
        log.error(f"  DB log_trade: {e}")
    c.close()

def get_stats() -> dict:
    c = _db()
    r = c.execute("SELECT COUNT(*) t, COALESCE(SUM(won),0) w, "
                  "COALESCE(SUM(pnl),0) p FROM trades").fetchone()
    by_sym = c.execute("SELECT symbol, COUNT(*) t, SUM(won) w, SUM(net_pnl) p "
                       "FROM trades GROUP BY symbol").fetchall()
    c.close()
    total = r["t"]; wins = int(r["w"]); pnl = round(r["p"], 2)
    wr    = round(wins / max(1, total) * 100, 1)
    syms  = {row["symbol"]: {"t": row["t"], "w": row["w"] or 0,
                              "p": round(row["p"] or 0, 2)}
             for row in by_sym}
    return {"total": total, "wins": wins, "wr": wr, "pnl": pnl, "by_sym": syms}

def get_training_data():
    c = _db()
    rows = c.execute("SELECT features_json, won FROM trades "
                     "WHERE features_json IS NOT NULL").fetchall()
    c.close()
    if not rows: return None, None
    X, y = [], []
    for r in rows:
        try:
            f = json.loads(r["features_json"])
            if not isinstance(f, list) or len(f) == 0: continue
            if len(f) < FEAT_DIM: f += [0.0] * (FEAT_DIM - len(f))
            X.append(f[:FEAT_DIM]); y.append([r["won"]])
        except Exception:
            continue
    if not X: return None, None
    return np.array(X, dtype=np.float64), np.array(y, dtype=np.float64)

# ═══════════════════════════════════════════════════════════════════
#  STRATEGY INVENTOR  (Claude API)
# ═══════════════════════════════════════════════════════════════════

class StrategyInventor:
    """
    Uses Claude API to invent new MCX trading strategies based on
    recent performance data. Stores invented strategies in JSON.
    """
    STRAT_FILE = BASE / "data" / "invented_strategies.json"

    def __init__(self):
        self.strategies: list[dict] = []
        self.last_invent = 0
        self._load()

    def _load(self):
        try:
            if self.STRAT_FILE.exists():
                self.strategies = json.load(open(self.STRAT_FILE))
                log.info(f"  Inventor: loaded {len(self.strategies)} strategies")
        except Exception:
            self.strategies = []

    def _save(self):
        try:
            json.dump(self.strategies, open(self.STRAT_FILE, "w"), indent=2)
        except Exception:
            pass

    async def maybe_invent(self, market_ctx: dict, force: bool = False):
        """Invent a new strategy if enough time has passed (every 2h)."""
        if not ANTHROPIC_KEY:
            return
        if not force and time.time() - self.last_invent < 7200:
            return
        self.last_invent = time.time()
        try:
            await self._invent(market_ctx)
        except Exception as e:
            log.warning(f"  Inventor: {e}")

    async def _invent(self, ctx: dict):
        s = get_stats()
        prompt = f"""You are an expert MCX commodity futures quant.
Invent ONE new intraday trading strategy for one of: GOLDPETAL, CRUDEOILM, NATGASMINI.

Current context:
- Market regime: {regime.current}
- Recent P&L: ₹{s['pnl']} over {s['total']} trades, {s['wr']}% win rate
- Per-symbol: {json.dumps(s.get('by_sym', {}), indent=2)}
- Time: {datetime.now(IST).strftime('%H:%M IST')}

Respond ONLY with a JSON object (no markdown, no explanation):
{{
  "name": "STRATEGY_NAME",
  "symbol": "GOLDPETAL|CRUDEOILM|NATGASMINI",
  "direction_logic": "BUY when X, SELL when Y",
  "target_pct": 0.8,
  "sl_pct": 0.5,
  "max_hold_min": 45,
  "session": "both|morning|us",
  "rationale": "brief one-line reason"
}}"""

        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": ANTHROPIC_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": "claude-sonnet-4-20250514",
                    "max_tokens": 500,
                    "messages": [{"role": "user", "content": prompt}],
                },
            )
            data = r.json()
        text = ""
        for block in data.get("content", []):
            if block.get("type") == "text":
                text += block.get("text", "")
        # Parse JSON
        text = text.strip().lstrip("```json").rstrip("```").strip()
        strat = json.loads(text)
        strat["trades"] = 0; strat["wins"] = 0; strat["pnl"] = 0.0
        strat["invented_at"] = datetime.now(IST).isoformat()
        self.strategies.append(strat)
        self._save()
        log.info(f"  Inventor: new strategy '{strat['name']}' for {strat['symbol']}")
        await tg(f"🧠 New strategy invented: <b>{strat['name']}</b>\n"
                 f"Symbol: {strat['symbol']}\n"
                 f"Logic: {strat.get('rationale', '')}")

    def record_trade(self, strat_name: str, won: bool, pnl_pct: float):
        for s in self.strategies:
            if s["name"] == strat_name:
                s["trades"] += 1
                if won: s["wins"] += 1
                s["pnl"] = s.get("pnl", 0) + pnl_pct
                # Kill if < 30% WR after 8 trades
                if s["trades"] >= 8:
                    wr = s["wins"] / s["trades"]
                    if wr < 0.28:
                        self.strategies.remove(s)
                        log.info(f"  Inventor: killed '{strat_name}' WR={wr:.0%}")
                self._save()
                return

    def get_overrides(self, sym: str, direction: str) -> dict | None:
        """Return best matching invented strategy overrides for this symbol."""
        candidates = [s for s in self.strategies
                      if s.get("symbol") == sym
                      and s.get("trades", 0) < 30]  # keep fresh strategies
        if not candidates: return None
        # Best by win rate (min 3 trades), else newest
        qualified = [s for s in candidates if s.get("trades", 0) >= 3]
        if qualified:
            best = max(qualified, key=lambda x: x["wins"] / max(1, x["trades"]))
            return {"target_pct": best.get("target_pct"),
                    "sl_pct": best.get("sl_pct"),
                    "max_hold_min": best.get("max_hold_min"),
                    "strat_name": best["name"]}
        return None

inventor = StrategyInventor()

# ═══════════════════════════════════════════════════════════════════
#  KELLY POSITION SIZING
# ═══════════════════════════════════════════════════════════════════

def kelly_size(cash: float, margin_per_lot: float, win_rate: float = 0.5,
               avg_win: float = 1.0, avg_loss: float = 1.0) -> int:
    """Return number of lots to trade using fractional Kelly."""
    if avg_loss == 0 or win_rate == 0: return 1
    b = abs(avg_win / avg_loss)
    p = win_rate
    f = (b * p - (1 - p)) / b
    f = max(0.1, min(0.4, f * 0.25))  # quarter Kelly, cap 40%
    budget = cash * f
    lots   = max(1, int(budget / max(1, margin_per_lot)))
    return lots

# ═══════════════════════════════════════════════════════════════════
#  MCX SESSION HELPERS
# ═══════════════════════════════════════════════════════════════════

def mcx_is_open() -> bool:
    now = datetime.now(IST)
    return now.weekday() < 5 and MCX_OPEN <= now.time() <= MCX_CLOSE

def mcx_entry_allowed() -> bool:
    now = datetime.now(IST)
    return now.weekday() < 5 and MCX_OPEN <= now.time() < MCX_NO_ENTRY

def mcx_force_exit() -> bool:
    return datetime.now(IST).time() >= dtime(23, 20)

def us_session_active() -> bool:
    return datetime.now(IST).time() >= US_SESSION

def morning_session() -> bool:
    return datetime.now(IST).time() <= ORB_END

# ═══════════════════════════════════════════════════════════════════
#  SCANNER
# ═══════════════════════════════════════════════════════════════════

async def scan_instruments(cash: float,
                            prev_prices: dict[str, float],
                            vix: float = 14.0,
                            prev_vix: float = 14.0,
                            eia_draw: float = 0.0) -> list[dict]:
    """
    Scan GOLDPETAL, CRUDEOILM, NATGASMINI and return scored opportunities.
    """
    available = mcx_inst.available()
    if not available:
        log.warning("  Scanner: No MCX instruments loaded")
        return []

    now_us  = us_session_active()
    now_morn= morning_session()
    results = []

    for sym in available:
        key  = mcx_inst.keys.get(sym, "")
        if not key: continue
        meta = INSTRUMENTS[sym]
        lot  = mcx_inst.lot.get(sym, meta["lot_size"])
        dte  = mcx_inst.dte.get(sym, 99)

        if cash < meta["min_capital"]: continue

        try:
            ltp = await broker.ltp(key)
            if ltp <= 0: continue

            ohlc = await broker.ohlc(key)
            day_open  = ohlc.get("open",  ltp)
            day_high  = ohlc.get("high",  ltp)
            day_low   = ohlc.get("low",   ltp)
            day_vol   = ohlc.get("volume", 1000)
            day_range = max(day_high - day_low, 0.01)

            day_chg   = (ltp - day_open) / max(0.01, day_open) * 100
            range_pct = day_range / max(0.01, ltp) * 100
            range_pos = (ltp - day_low) / max(0.01, day_range)

            margin_one = ltp * lot * 0.12
            if cash * 0.35 < margin_one: continue  # need 35% of capital per trade max

            be = charges.be_pct(ltp, lot)
            if be > meta["volatility"] * 0.65: continue

            # Simulate candles from day OHLC (fallback - use limited signal set)
            closes_sim = [day_open, (day_open + day_high) / 2,
                          (day_open + day_low) / 2, ltp]

            prev_ltp = prev_prices.get(sym, ltp)
            regime.update(ltp, prev_ltp)

            # Evaluate all applicable strategies for this symbol
            best_dir = "SKIP"; best_score = 0; best_strat = "TREND_FOLLOW"

            for sid in meta["strategies"]:
                # Session gate
                if sid in ("US_MOMENTUM", "SEASONAL_NATGAS", "INVENTORY_CRUDE"):
                    if not now_us: continue
                if sid == "BREAKOUT_VOL":
                    if not now_morn: continue

                sig = {"dir": "SKIP", "strength": 0}
                if   sid == "TREND_FOLLOW":    sig = sigs.trend_follow(closes_sim, day_chg)
                elif sid == "MEAN_REVERT":     sig = sigs.mean_revert(closes_sim)
                elif sid == "BREAKOUT_VOL":    sig = sigs.breakout_vol(
                                                    ltp, day_high, day_low, day_vol, day_vol*0.7)
                elif sid == "US_MOMENTUM":     sig = sigs.us_momentum(closes_sim)
                elif sid == "GOLD_HEDGE":      sig = sigs.gold_hedge(vix, 0.0)
                elif sid == "SEASONAL_NATGAS": sig = sigs.seasonal_natgas()
                elif sid == "INVENTORY_CRUDE": sig = sigs.inventory_crude(eia_draw)
                elif sid == "VIX_SPIKE_GOLD":  sig = sigs.vix_spike_gold(vix, prev_vix)
                elif sid == "VOLATILITY_CRUSH":sig = sigs.volatility_crush(closes_sim)

                if sig["dir"] == "SKIP": continue
                if sig["strength"] > best_score:
                    best_score = sig["strength"]; best_strat = sid
                    best_dir   = sig["dir"]

            # Fallback heuristic
            if best_dir == "SKIP":
                if day_chg > 0.3 and range_pos < 0.70:   best_dir = "BUY"
                elif day_chg < -0.3 and range_pos > 0.30: best_dir = "SELL"
                elif range_pos < 0.35:                     best_dir = "BUY"
                elif range_pos > 0.65:                     best_dir = "SELL"
                else: continue  # truly no signal

            # Regime filter
            reg = regime.detect()
            if reg == "BULL" and best_dir == "SELL": continue
            if reg == "BEAR" and best_dir == "BUY":  continue

            # Boost score
            score = best_score
            if range_pct > 0.5: score += 1
            if abs(day_chg) > 0.3: score += 1
            if be < 0.15: score += 2
            if score < 2: continue

            # NN scoring
            f     = make_features(sym, ltp, day_chg, range_pct, range_pos,
                                   best_dir, score, dte, be)
            s_obj = get_stats()
            prob  = nn.predict(f) if nn.cnt >= 5 else 0.5 + score * 0.05
            if prob < 0.45 and nn.cnt >= 10: continue  # NN veto

            # Get target/sl from meta, potentially override by inventor
            tgt = meta["target_pct"]; sl = meta["sl_pct"]; mxh = meta["max_hold_min"]
            strat_name = best_strat
            overrides = inventor.get_overrides(sym, best_dir)
            if overrides:
                tgt  = overrides.get("target_pct", tgt)
                sl   = overrides.get("sl_pct",     sl)
                mxh  = overrides.get("max_hold_min",mxh)
                strat_name = overrides.get("strat_name", strat_name)

            # Kelly lot sizing
            wr = s_obj["wr"] / 100 if s_obj["total"] >= 5 else 0.5
            n_lots = kelly_size(cash * 0.30, margin_one, wr)
            qty    = n_lots * lot

            results.append({
                "symbol":     sym,
                "key":        key,
                "ltp":        ltp,
                "lot_size":   lot,
                "qty":        qty,
                "direction":  best_dir,
                "score":      score,
                "strategy":   strat_name,
                "target_pct": round(tgt, 3),
                "sl_pct":     round(sl,  3),
                "max_hold_min": mxh,
                "day_chg_pct": round(day_chg, 2),
                "range_pct":   round(range_pct, 2),
                "range_pos":   round(range_pos, 2),
                "margin_needed": round(margin_one, 2),
                "dte":         dte,
                "be_pct":      be,
                "nn_prob":     round(prob, 3),
                "regime":      reg,
                "_features":   f.tolist(),
            })

        except Exception as e:
            log.error(f"  scan {sym}: {e}")
        await asyncio.sleep(0.3)

    results.sort(key=lambda x: x["score"] * x["nn_prob"], reverse=True)
    return results

# ═══════════════════════════════════════════════════════════════════
#  TELEGRAM COMMAND LISTENER
# ═══════════════════════════════════════════════════════════════════

class TelegramCommands:
    def __init__(self):
        self._last_update_id = 0
        self._stop_requested = False
        self._positions_ref: dict = {}  # shared reference to live positions

    def link_positions(self, positions: dict):
        self._positions_ref = positions

    @property
    def stop_requested(self) -> bool:
        return self._stop_requested

    async def poll(self):
        """Poll Telegram for commands. Runs in background loop."""
        if not TG_TOKEN or not TG_CHAT:
            return
        try:
            async with httpx.AsyncClient(timeout=10) as c:
                r = await c.get(
                    f"https://api.telegram.org/bot{TG_TOKEN}/getUpdates",
                    params={"offset": self._last_update_id + 1, "timeout": 5},
                )
                data = r.json()
        except Exception:
            return

        for upd in data.get("result", []):
            self._last_update_id = upd["update_id"]
            msg = upd.get("message", {})
            text = msg.get("text", "").strip().lower()
            if not text: continue

            if "/stop" in text:
                self._stop_requested = True
                await tg("🛑 Stop command received. Closing positions and shutting down...")
                log.info("  [TG CMD] /stop received")

            elif "/status" in text:
                s = get_stats()
                open_pos = len(self._positions_ref)
                await tg(
                    f"📊 <b>FreeAGI Status</b>\n"
                    f"Mode: {'PAPER' if PAPER else 'LIVE'}\n"
                    f"Open positions: {open_pos}/3\n"
                    f"Today: {s['total']}T {s['wins']}W {s['wr']}%WR\n"
                    f"Net P&L: ₹{s['pnl']:,.0f}\n"
                    f"Regime: {regime.current}"
                )

            elif "/positions" in text:
                if not self._positions_ref:
                    await tg("No open positions.")
                else:
                    lines = ["📌 <b>Open Positions:</b>"]
                    for sym, pos in self._positions_ref.items():
                        ctx = pos["ctx"]
                        ep  = ctx.get("entry_price", 0)
                        dir_= ctx.get("direction", "?")
                        lines.append(f"• {sym} {dir_} @ ₹{ep:.1f}")
                    await tg("\n".join(lines))

            elif "/pnl" in text:
                s = get_stats()
                lines = [f"💰 <b>P&L by Symbol</b>"]
                for sym, d in s.get("by_sym", {}).items():
                    wr = round(d["w"] / max(1, d["t"]) * 100, 1)
                    lines.append(f"• {sym}: {d['t']}T {wr}%WR ₹{d['p']:,.0f}")
                await tg("\n".join(lines) if len(lines) > 1 else "No trades yet.")

            elif "/help" in text:
                await tg(
                    "📖 <b>FreeAGI Commands</b>\n"
                    "/status — agent status\n"
                    "/positions — open positions\n"
                    "/pnl — P&L breakdown\n"
                    "/stop — graceful shutdown"
                )

tg_cmds = TelegramCommands()

# ═══════════════════════════════════════════════════════════════════
#  WEB DASHBOARD  (port 8080)
# ═══════════════════════════════════════════════════════════════════

_dashboard_positions: dict = {}

async def dashboard_handler(reader, writer):
    """Minimal HTTP dashboard."""
    try:
        await reader.read(1024)  # consume request
        s = get_stats()
        pos_html = ""
        for sym, pos in _dashboard_positions.items():
            ctx = pos["ctx"]
            ep  = ctx.get("entry_price", 0)
            dir_= ctx.get("direction", "?")
            t0  = pos.get("t0")
            hld = round((datetime.now(IST) - t0).total_seconds() / 60, 1) if t0 else 0
            pos_html += (f"<tr><td>{sym}</td><td>{dir_}</td>"
                         f"<td>₹{ep:.1f}</td><td>{hld}m</td></tr>")

        sym_html = ""
        for sym, d in s.get("by_sym", {}).items():
            wr = round(d["w"] / max(1, d["t"]) * 100, 1)
            sym_html += (f"<tr><td>{sym}</td><td>{d['t']}</td>"
                         f"<td>{wr}%</td><td>₹{d['p']:,.0f}</td></tr>")

        mode = "PAPER" if PAPER else "LIVE"
        html = f"""<!DOCTYPE html>
<html><head><title>FreeAGI v{VERSION}</title>
<meta http-equiv="refresh" content="15">
<style>
  body{{font-family:monospace;background:#0d1117;color:#e6edf3;padding:20px}}
  h1{{color:#58a6ff}} h2{{color:#8b949e;font-size:14px}}
  table{{border-collapse:collapse;width:100%;margin:10px 0}}
  th{{background:#161b22;padding:8px;text-align:left;color:#58a6ff}}
  td{{padding:6px 8px;border-bottom:1px solid #21262d}}
  .pill{{display:inline-block;padding:2px 8px;border-radius:10px;font-size:12px}}
  .paper{{background:#1f6feb;}} .live{{background:#238636;}}
  .bull{{color:#3fb950}} .bear{{color:#f85149}} .chop{{color:#8b949e}}
</style></head>
<body>
<h1>⚡ FreeAGI v{VERSION}</h1>
<span class="pill {'paper' if PAPER else 'live'}">{mode}</span>
&nbsp;Capital: ₹{CAPITAL:,.0f}
&nbsp;Regime: <span class="{'bull' if regime.current=='BULL' else 'bear' if regime.current=='BEAR' else 'chop'}">{regime.current}</span>
<br><br>
<table><tr><th>Metric</th><th>Value</th></tr>
<tr><td>Total Trades</td><td>{s['total']}</td></tr>
<tr><td>Win Rate</td><td>{s['wr']}%</td></tr>
<tr><td>Net P&L</td><td>₹{s['pnl']:,.0f}</td></tr>
<tr><td>Open Positions</td><td>{len(_dashboard_positions)}/3</td></tr>
<tr><td>NN Samples</td><td>{nn.cnt}</td></tr>
<tr><td>RL Episodes</td><td>{rl.ep}</td></tr>
</table>
<h2>OPEN POSITIONS</h2>
<table><tr><th>Symbol</th><th>Direction</th><th>Entry</th><th>Held</th></tr>
{pos_html if pos_html else '<tr><td colspan=4>No open positions</td></tr>'}
</table>
<h2>PERFORMANCE BY SYMBOL</h2>
<table><tr><th>Symbol</th><th>Trades</th><th>WR</th><th>Net P&L</th></tr>
{sym_html if sym_html else '<tr><td colspan=4>No trades yet</td></tr>'}
</table>
<h2>INVENTED STRATEGIES: {len(inventor.strategies)}</h2>
<small>Auto-refreshes every 15s</small>
</body></html>"""
        resp = (f"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n"
                f"Content-Length: {len(html)}\r\n\r\n{html}")
        writer.write(resp.encode())
        await writer.drain()
    except Exception:
        pass
    finally:
        writer.close()

# ═══════════════════════════════════════════════════════════════════
#  MAIN TRADING LOOP
# ═══════════════════════════════════════════════════════════════════

async def run():
    global _dashboard_positions

    init_db()
    nn.load(); rl.load()

    # Retrain NN on existing trade history
    X, y = get_training_data()
    if X is not None and len(X) >= 5:
        nn.train(X, y, 200); nn.save()
        log.info(f"  NN pre-trained: {len(X)} trades")

    s    = get_stats()
    mode = "PAPER" if PAPER else "LIVE"
    log.info("=" * 60)
    log.info(f"  FreeAGI v{VERSION} | {mode} | Capital=₹{CAPITAL:,.0f}")
    log.info(f"  {s['total']}T {s['wr']}%WR ₹{s['pnl']:,.0f} | NN:{nn.cnt} RL:{rl.ep}ep")
    log.info(f"  Instruments: {list(INSTRUMENTS.keys())}")
    log.info(f"  TG: {'ON' if TG_TOKEN and TG_CHAT else 'OFF'}")
    log.info("=" * 60)

    await tg(
        f"🚀 <b>FreeAGI v{VERSION} started</b>\n"
        f"Mode: {mode} | Capital: ₹{CAPITAL:,.0f}\n"
        f"Instruments: GOLDPETAL, CRUDEOILM, NATGASMINI\n"
        f"Stats: {s['total']}T {s['wr']}%WR ₹{s['pnl']}"
    )

    # Start web dashboard
    try:
        server = await asyncio.start_server(dashboard_handler, "0.0.0.0", 8080)
        log.info("  Dashboard: http://localhost:8080")
    except Exception as e:
        log.warning(f"  Dashboard failed to start: {e}")
        server = None

    # Open positions: sym → {ctx, t0, peak}
    positions: dict[str, dict] = {}
    _dashboard_positions = positions
    tg_cmds.link_positions(positions)

    # Shared state
    prev_prices: dict[str, float] = {}
    day_pnl      = 0.0
    day_trades   = 0
    start_cash   = CAPITAL
    vix          = 14.0
    prev_vix     = 14.0
    last_day     = datetime.now(IST).date()
    halted       = False   # daily loss kill-switch
    _inst_loaded = False
    evo_ctr      = 0

    # Shutdown event
    _shutdown = asyncio.Event()

    def _sigterm(*_):
        log.info("  SIGTERM — graceful shutdown initiated")
        _shutdown.set()

    try:
        loop = asyncio.get_event_loop()
        loop.add_signal_handler(_signal.SIGTERM, _sigterm)
        loop.add_signal_handler(_signal.SIGINT,  _sigterm)
    except (NotImplementedError, RuntimeError):
        pass

    async def _tg_listener():
        while not _shutdown.is_set():
            await tg_cmds.poll()
            if tg_cmds.stop_requested:
                _shutdown.set()
            await asyncio.sleep(5)

    asyncio.ensure_future(_tg_listener())

    # ── MAIN LOOP ──────────────────────────────────────────────────
    while not _shutdown.is_set():
        try:
            now  = datetime.now(IST)
            today = now.date()

            # ── Daily reset ──
            if today != last_day:
                log.info(f"  New day | yesterday: {day_trades}T ₹{day_pnl:+.0f}")
                await tg(f"📅 Day ended | {day_trades}T ₹{day_pnl:+.0f}")
                day_pnl = 0.0; day_trades = 0; halted = False
                start_cash = await broker.cash()
                last_day = today

            # ── Sleep outside MCX hours ──
            if not mcx_is_open():
                await asyncio.sleep(60)
                continue

            broker.reload_token()
            if not broker.ok:
                log.info("  No Upstox token. Login via command_centre or set in .env")
                await asyncio.sleep(30)
                continue

            # ── Load MCX instruments (once, refresh every 8h) ──
            if not _inst_loaded:
                log.info("  Loading MCX instruments...")
                try:
                    await mcx_inst.refresh()
                    if mcx_inst.keys_loaded():
                        _inst_loaded = True
                        log.info(f"  MCX ready: {mcx_inst.available()}")
                    else:
                        log.warning("  MCX instruments empty after refresh")
                        await asyncio.sleep(30); continue
                except Exception as e:
                    log.error(f"  MCX refresh: {e}")
                    await asyncio.sleep(30); continue
            else:
                try:
                    await mcx_inst.refresh()
                except Exception:
                    pass

            # ── Daily loss kill-switch ──
            if halted:
                await asyncio.sleep(300)
                continue

            # ── Force-exit all if near close ──
            if mcx_force_exit() and positions:
                log.info(f"  MCX 23:20 — force-closing {len(positions)} position(s)")
                for sym in list(positions.keys()):
                    pos = positions[sym]
                    ctx = pos["ctx"]
                    r   = await broker.sell(ctx["key"], ctx["qty"], ctx["direction"])
                    if r.get("status") == "success":
                        ltp = await broker.ltp(ctx["key"]) or ctx["entry_price"]
                        _close_position(sym, positions, ltp, "MCX_CLOSE",
                                        day_pnl, day_trades)
                        day_pnl, day_trades = _update_day(sym, positions,
                                                           ctx, ltp, "MCX_CLOSE",
                                                           day_pnl, day_trades)
                        positions.pop(sym, None)
                        log.info(f"  Force-closed {sym}")
                    await asyncio.sleep(1)
                await asyncio.sleep(10)
                continue

            cash = await broker.cash()
            if PAPER: cash = max(cash, CAPITAL)

            # ── MONITOR open positions ──
            to_close = []
            for sym, pos in list(positions.items()):
                ctx   = pos["ctx"]
                t0    = pos["t0"]
                bp    = ctx["entry_price"]
                qty   = ctx["qty"]
                key   = ctx["key"]
                tgt   = ctx["target_pct"]
                sl    = ctx["sl_pct"]
                mxh   = ctx["max_hold_min"]
                direc = ctx["direction"]
                hld   = (now - t0).total_seconds() / 60 if t0 else 0

                ltp = await broker.ltp(key)
                if ltp <= 0: ltp = bp

                # P&L direction-aware
                if direc == "BUY":
                    pp = (ltp - bp) / max(0.01, bp) * 100
                    pr = (ltp - bp) * qty
                else:
                    pp = (bp - ltp) / max(0.01, bp) * 100
                    pr = (bp - ltp) * qty

                if pp > pos["peak"]: pos["peak"] = pp

                ex = None
                if pp >= tgt:                                       ex = "TARGET"
                elif pos["peak"] >= tgt * 0.5 and pp <= (pos["peak"] - tgt * 0.3): ex = "TRAIL_SL"
                elif pp <= -sl:                                     ex = "STOPLOSS"
                elif hld >= mxh:                                    ex = "TIMEOUT"

                if ex:
                    # Retry exit 3 times
                    result = {"status": "error"}
                    for attempt in range(3):
                        try:
                            result = await broker.sell(key, qty, direc)
                            if result.get("status") == "success": break
                            await asyncio.sleep(2)
                        except Exception as err:
                            log.error(f"  Exit attempt {attempt+1} {sym}: {err}")
                            await asyncio.sleep(2)

                    if result.get("status") == "success":
                        won   = pp > 0
                        ch    = charges.calculate(bp, ltp, qty) if direc == "BUY" \
                                else charges.calculate(ltp, bp, qty)
                        net   = ch["net_pnl"]
                        tc    = ch["total"]
                        hld_s = int((now - t0).total_seconds()) if t0 else 0

                        day_pnl   += pr
                        day_trades += 1
                        ic = "+" if pp > 0 else "-"
                        log.info(f"  {ic} {ex} {sym}({direc}) {bp:.1f}→{ltp:.1f} "
                                 f"{pp:+.3f}% ₹{pr:+.0f} net=₹{net:+.0f} "
                                 f"| Day:{day_trades}T ₹{day_pnl:+.0f}")

                        await tg(
                            f"{'✅ WIN' if won else '❌ LOSS'} MCX: {sym} ({direc})\n"
                            f"Entry: ₹{bp:.1f} → Exit: ₹{ltp:.1f}\n"
                            f"P&L: {pp:+.3f}% | ₹{pr:+.0f} | Net: ₹{net:+.0f}\n"
                            f"Reason: {ex} | Day: {day_trades}T ₹{day_pnl:+.0f}"
                        )

                        # Update NN & RL
                        f = np.array(ctx.get("_features", [0.0] * FEAT_DIM), dtype=np.float64)
                        if len(f) < FEAT_DIM:
                            f = np.concatenate([f, np.zeros(FEAT_DIM - len(f))])
                        nn.train1(f, 1.0 if won else 0.0)
                        evo_ctr += 1
                        if evo_ctr % 5 == 0:
                            Xt, yt = get_training_data()
                            if Xt is not None and len(Xt) >= 5:
                                nn.train(Xt, yt, 100)
                        nn.save()

                        s2 = rl.state()
                        rl.update(ctx.get("_rl_state", s2),
                                  ctx.get("_rl_action", 0),
                                  pp / 10 + (0.5 if won else -0.3),
                                  s2, len(mcx_inst.available()))
                        rl.save()

                        # Inventor feedback
                        inventor.record_trade(ctx["strategy"], won, pp)

                        # Log to DB
                        log_trade({
                            "ts": now.isoformat(),
                            "symbol": sym,
                            "direction": direc,
                            "strategy": ctx["strategy"],
                            "entry_price": bp,
                            "exit_price": ltp,
                            "qty": qty,
                            "pnl": round(pr, 2),
                            "pnl_pct": round(pp, 3),
                            "net_pnl": net,
                            "charges": tc,
                            "won": 1 if won else 0,
                            "exit_reason": ex,
                            "hold_sec": hld_s,
                            "score": ctx.get("score", 0),
                            "nn_prob": ctx.get("nn_prob", 0),
                            "regime": ctx.get("regime", "CHOP"),
                            "features_json": json.dumps(f.tolist()),
                            "day_chg_pct": ctx.get("day_chg_pct", 0),
                        })

                        # Daily loss kill-switch check
                        if start_cash > 0 and -day_pnl / start_cash * 100 >= MAX_DD:
                            halted = True
                            log.warning(f"  KILL-SWITCH: daily loss ₹{day_pnl:.0f} "
                                        f"= {-day_pnl/start_cash*100:.1f}% >= {MAX_DD}%")
                            await tg(
                                f"🚨 DAILY LOSS LIMIT HIT\n"
                                f"Loss: ₹{-day_pnl:,.0f} ({-day_pnl/start_cash*100:.1f}%)\n"
                                f"Trading HALTED for today."
                            )

                        to_close.append(sym)
                    else:
                        log.error(f"  ⚠ All exit attempts failed for {sym} — manual squareoff needed!")
                        await tg(f"⚠️ EXIT FAILED: {sym} ({direc}) | Manual squareoff needed!")
                    await asyncio.sleep(2)
                else:
                    prev_prices[sym] = ltp
                    log.info(f"  {sym}({direc}) {bp:.1f}→{ltp:.1f} {pp:+.3f}% "
                             f"₹{pr:+.0f} {hld:.0f}m")

            for sym in to_close:
                positions.pop(sym, None)

            if to_close: await asyncio.sleep(5); continue

            # ── ENTRY: scan for new opportunities ──
            if not mcx_entry_allowed():
                await asyncio.sleep(60)
                continue

            if halted:
                await asyncio.sleep(300)
                continue

            if len(positions) >= MAX_POSITIONS:
                await asyncio.sleep(LOOP_INTERVAL)
                continue

            # Periodically try to invent new strategies
            await inventor.maybe_invent({
                "regime": regime.current,
                "session": "us" if us_session_active() else "morning" if morning_session() else "day",
            })

            picks = await scan_instruments(
                cash, prev_prices,
                vix=vix, prev_vix=prev_vix,
            )

            if not picks:
                await asyncio.sleep(LOOP_INTERVAL)
                continue

            rl_state = rl.state()
            for pick in picks:
                sym = pick["symbol"]
                if sym in positions: continue  # already holding

                # RL action selection
                n_available = len(mcx_inst.available())
                ri = rl.act(rl_state, n_available)
                pick["_rl_state"]  = rl_state
                pick["_rl_action"] = ri

                result = await broker.buy(pick["key"], pick["qty"], pick["direction"])
                if result.get("status") == "success":
                    if not PAPER:
                        # Fetch actual fill price
                        try:
                            actual_ltp = await broker.ltp(pick["key"])
                            if actual_ltp > 0:
                                pick["ltp"] = actual_ltp
                        except Exception:
                            pass
                    pick["entry_price"] = pick["ltp"]
                    ctx = {**pick}
                    positions[sym] = {"ctx": ctx, "t0": now, "peak": 0.0}
                    prev_prices[sym] = pick["ltp"]
                    ep  = pick["entry_price"]
                    qty = pick["qty"]
                    log.info(
                        f"  ▶ {pick['direction']} {sym} qty={qty} @ ₹{ep:.1f} "
                        f"T:+{pick['target_pct']}% SL:-{pick['sl_pct']}% "
                        f"strat={pick['strategy']} nn={pick['nn_prob']:.0%}"
                    )
                    await tg(
                        f"🛒 MCX ENTRY: {sym} ({pick['direction']})\n"
                        f"Price: ₹{ep:.1f} | Qty: {qty}\n"
                        f"Target: +{pick['target_pct']}% | SL: -{pick['sl_pct']}%\n"
                        f"Strategy: {pick['strategy']} | Regime: {pick['regime']}\n"
                        f"{'📝 PAPER' if PAPER else '⚡ LIVE'}"
                    )
                else:
                    err = (result.get("errors") or [{}])[0].get("message", str(result))
                    log.error(f"  ✗ Entry failed {sym}: {err}")

                if len(positions) >= MAX_POSITIONS:
                    break

            await asyncio.sleep(LOOP_INTERVAL)

        except asyncio.CancelledError:
            break
        except Exception as e:
            log.error(f"  LOOP ERR: {e}")
            await asyncio.sleep(10)

    # ─────────────────────── SHUTDOWN ───────────────────────────────
    log.info("  Shutting down — closing all open positions...")
    await tg("⚠️ FreeAGI shutting down — closing all positions")

    for sym, pos in list(positions.items()):
        ctx  = pos["ctx"]
        key  = ctx["key"]
        qty  = ctx["qty"]
        direc= ctx["direction"]
        for attempt in range(3):
            try:
                r = await broker.sell(key, qty, direc)
                if r.get("status") == "success":
                    log.info(f"  Closed {sym} ({direc})")
                    await tg(f"🛑 CLOSED {sym} ({direc}) qty={qty} | shutdown")
                    break
                await asyncio.sleep(2)
            except Exception as e:
                log.error(f"  Shutdown exit attempt {attempt+1} {sym}: {e}")
                await asyncio.sleep(2)

    if server:
        server.close()

    await tg("✅ FreeAGI offline. All positions closed.")
    log.info("  FreeAGI offline.")

# ═══════════════════════════════════════════════════════════════════
#  CLI
# ═══════════════════════════════════════════════════════════════════

def cmd_stats():
    init_db(); nn.load(); rl.load()
    s = get_stats()
    print(f"\n{'='*60}")
    print(f"  FreeAGI v{VERSION} | {'PAPER' if PAPER else 'LIVE'}")
    print(f"  {s['total']}T {s['wins']}W {s['wr']}%WR ₹{s['pnl']:,.0f}")
    print(f"  NN: {nn.cnt} samples | RL: {rl.ep} episodes")
    print(f"  Invented strategies: {len(inventor.strategies)}")
    print(f"\n  By Symbol:")
    for sym, d in s.get("by_sym", {}).items():
        wr = round(d["w"] / max(1, d["t"]) * 100, 1)
        print(f"    {sym:12s} {d['t']}T {wr}%WR ₹{d['p']:,.0f}")
    print()

def cmd_reset():
    init_db()
    c = _db()
    c.execute("DELETE FROM trades")
    c.execute("DELETE FROM daily")
    c.commit(); c.close()
    for p in [NN_F, RL_F, ST_F]:
        if os.path.exists(p): os.remove(p)
    inv_f = BASE / "data" / "invented_strategies.json"
    if inv_f.exists(): inv_f.unlink()
    print("  Reset done. DB, NN, RL, strategies wiped.")

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "run"
    if cmd == "stats":
        cmd_stats()
    elif cmd == "reset":
        cmd_reset()
    elif cmd in ("run", "paper"):
        if cmd == "paper":
            os.environ["PAPER_TRADING"] = "true"
            PAPER = True
        try:
            import uvloop
            uvloop.run(run())
        except ImportError:
            asyncio.run(run())
    else:
        print(f"Usage: python3 agent.py [run|paper|stats|reset]")
