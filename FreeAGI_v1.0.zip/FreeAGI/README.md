# FreeAGI v1.0 — MCX Commodity Futures Agent

Focused MCX-only trading system built from FinanceAGI v17 core.

## Instruments
| Symbol | Name | Lot | Min Capital |
|---|---|---|---|
| GOLDPETAL | Gold Petal | 10g | ₹6,000 |
| CRUDEOILM | Crude Oil Mini | 10 bbl | ₹7,000 |
| NATGASMINI | Nat Gas Mini | 250 mmBtu | ₹3,000 |

## Key Features
- **HMM Regime Detection** — 3-state (BULL/BEAR/CHOP), gates trade direction
- **Neural Network** — trains on every trade, predicts win probability
- **RL Q-learning** — selects which instrument to prioritise
- **Strategy Inventor** — Claude API invents + kills strategies based on live WR
- **12 built-in signals** — EMA trend, RSI mean-revert, ORB breakout, US momentum, VIX-gold hedge, NatGas seasonal, EIA inventory, volatility crush
- **Kelly sizing** — quarter-Kelly, max 30% capital per instrument
- **Daily loss kill-switch** — halts trading if daily loss > MAX_DAILY_LOSS_PCT
- **Multi-position** — all 3 instruments simultaneously
- **Telegram commands** — /status /positions /pnl /stop /help
- **Web dashboard** — http://localhost:8080 (agent) + http://localhost:8001 (control)
- **Paper + Live modes** — set PAPER_TRADING=true/false

## Quick Start

```bash
# 1. Install dependencies
pip install httpx numpy --break-system-packages
pip install uvloop hmmlearn --break-system-packages   # optional

# 2. Configure
cp .env.example .env
# Edit .env — set UPSTOX_API_KEY, UPSTOX_API_SECRET, TG_BOT_TOKEN, etc.

# 3. Get Upstox token
python3 command_centre.py    # Open http://localhost:8001 → Login
# OR set UPSTOX_ACCESS_TOKEN directly in .env

# 4. Paper trade
python3 agent.py             # runs in paper mode (PAPER_TRADING=true)

# 5. Live trade (after testing)
# Edit .env: PAPER_TRADING=false
python3 agent.py

# PM2 (recommended on Termux/VPS)
pm2 start ecosystem.config.js
pm2 save
```

## CLI Commands
```bash
python3 agent.py           # Start trading
python3 agent.py paper     # Force paper mode
python3 agent.py stats     # View performance
python3 agent.py reset     # Wipe all data
```

## Telegram Commands
Send to your bot:
- `/status` — agent state, open positions, WR
- `/positions` — current open positions
- `/pnl` — P&L by instrument
- `/stop` — graceful shutdown + close all positions
- `/help` — command list

## Architecture

```
agent.py
├── MCXInstruments       — downloads/caches MCX futures instrument keys
├── Broker               — Upstox v2/v3 API (paper + live)
├── RegimeDetector       — HMM / rule-based regime (BULL/BEAR/CHOP)
├── Signals              — 9 signal types (EMA, RSI, ORB, US session, etc.)
├── NN                   — Adam-optimised neural net (win probability)
├── RL                   — Q-table (instrument selection)
├── StrategyInventor     — Claude API strategy invention + lifecycle
├── MCXCharges           — CTT + brokerage + GST charge calculator
├── TelegramCommands     — polling command listener
└── run()                — main async loop
    ├── MCX open/close gating
    ├── Position monitor (TARGET / TRAIL_SL / STOPLOSS / TIMEOUT / MCX_CLOSE)
    ├── Scanner → score → NN gate → Kelly size → entry
    ├── Daily kill-switch
    └── Graceful shutdown (SIGTERM, /stop)

command_centre.py
└── OAuth + start/stop panel (port 8001)
```

## Session Logic
| Time (IST) | Session | Active Instruments |
|---|---|---|
| 09:00–09:30 | Morning / ORB | GOLDPETAL, CRUDEOILM |
| 09:30–18:30 | Indian day session | GOLDPETAL, CRUDEOILM |
| 18:30–23:10 | US session | CRUDEOILM, NATGASMINI + GOLDPETAL |
| 23:10–23:20 | No new entries | — |
| 23:20–23:25 | Force exit | All |

## Data Files
```
data/
  freeagi.db           — SQLite: trades, auth tokens, daily stats
  nn.pkl               — Neural network weights
  rl.pkl               — RL Q-table
  strategies.json      — Invented strategies pool
  mcx_keys.json        — MCX instrument key cache
logs/
  agent.log            — Trading log
```
