"""
strategies/signals.py — MCX Strategy Signal Library v2
Full 9-strategy catalogue ported from FinanceAGI v17.2 StrategySignals.
Replaces mcx_ai_trader's single TA engine with named, context-aware strategies.
"""

import math
import logging
from datetime import datetime, timedelta, timezone, time as dtime
from typing import Dict, List

import config

logger = logging.getLogger("signals")
IST = timezone(timedelta(hours=5, minutes=30))

US_SESSION_START = dtime(18, 30)
ORB_WINDOW_END   = dtime(9, 30)


# ── Math helpers ──────────────────────────────────────────────────────────────

def _ema(series: List[float], period: int) -> float:
    if len(series) < period:
        return series[-1] if series else 0.0
    k = 2.0 / (period + 1)
    e = series[0]
    for v in series[1:]:
        e = v * k + e * (1 - k)
    return e

def _ema_series(series: List[float], period: int) -> List[float]:
    out = [float("nan")] * len(series)
    if len(series) < period:
        return out
    k = 2.0 / (period + 1)
    out[period - 1] = sum(series[:period]) / period
    for i in range(period, len(series)):
        out[i] = series[i] * k + out[i - 1] * (1 - k)
    return out

def _rsi(closes: List[float], period: int = 14) -> float:
    if len(closes) < period + 1:
        return 50.0
    gains, losses = [], []
    for i in range(1, len(closes)):
        d = closes[i] - closes[i - 1]
        gains.append(max(d, 0))
        losses.append(max(-d, 0))
    ag = sum(gains[-period:]) / period
    al = sum(losses[-period:]) / period
    if al == 0:
        return 100.0
    return round(100 - (100 / (1 + ag / al)), 2)

def _bollinger(closes: List[float], period: int = 20, mult: float = 2.0) -> Dict:
    if len(closes) < period:
        m = closes[-1]
        return {"upper": m * 1.01, "mid": m, "lower": m * 0.99}
    w = closes[-period:]
    m = sum(w) / period
    std = math.sqrt(sum((x - m) ** 2 for x in w) / period)
    return {"upper": m + mult * std, "mid": m, "lower": m - mult * std}

def _macd(closes: List[float], fast=12, slow=26, sig=9):
    ef = _ema_series(closes, fast)
    es = _ema_series(closes, slow)
    ml = [(f - s) if not (math.isnan(f) or math.isnan(s)) else float("nan")
          for f, s in zip(ef, es)]
    valid_ml = [x for x in ml if not math.isnan(x)]
    sl_raw = _ema_series(valid_ml, sig)
    offset = len(ml) - len(sl_raw)
    sl = [float("nan")] * offset + sl_raw
    hist = [(m - s) if not (math.isnan(m) or math.isnan(s)) else float("nan")
            for m, s in zip(ml, sl)]
    return ml[-1], sl[-1], hist[-1]

def _atr_series(candles: List, period: int = 14) -> List[float]:
    trs = [float("nan")]
    for i in range(1, len(candles)):
        h  = float(candles[i][2])
        l  = float(candles[i][3])
        pc = float(candles[i - 1][4])
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    result = []
    for i in range(len(trs)):
        if i < period - 1 or math.isnan(trs[i]):
            result.append(float("nan"))
        else:
            window = [x for x in trs[max(0, i - period + 1):i + 1] if not math.isnan(x)]
            result.append(sum(window) / len(window) if window else float("nan"))
    return result

def _supertrend(candles: List, period: int = 7, mult: float = 3.0):
    atr_vals = _atr_series(candles, period)
    n = len(candles)
    direction = [0] * n

    def mid(i): return (float(candles[i][2]) + float(candles[i][3])) / 2

    up_band = [float("nan")] * n
    dn_band = [float("nan")] * n
    for i in range(period, n):
        m = mid(i)
        a = atr_vals[i] if not math.isnan(atr_vals[i]) else 0
        up_band[i] = m + mult * a
        dn_band[i] = m - mult * a

    direction[period] = 1
    for i in range(period + 1, n):
        c  = float(candles[i][4])
        pc = float(candles[i - 1][4])
        prev_up = up_band[i - 1] if not math.isnan(up_band[i - 1]) else up_band[i]
        prev_dn = dn_band[i - 1] if not math.isnan(dn_band[i - 1]) else dn_band[i]
        up_band[i] = min(up_band[i], prev_up) if pc <= prev_up else up_band[i]
        dn_band[i] = max(dn_band[i], prev_dn) if pc >= prev_dn else dn_band[i]
        if direction[i - 1] == -1 and c > (up_band[i - 1] or 0):
            direction[i] = 1
        elif direction[i - 1] == 1 and c < (dn_band[i - 1] or 0):
            direction[i] = -1
        else:
            direction[i] = direction[i - 1]
    return direction[-1]


# ─────────────────────────────────────────────────────────────────────────────
# Strategy Signal Library (ported from v17 StrategySignals)
# ─────────────────────────────────────────────────────────────────────────────

def trend_follow_signal(candles: List) -> Dict:
    """EMA 5/20 crossover momentum."""
    if len(candles) < 20:
        return {"direction": "SKIP", "strength": 0}
    closes = [float(c[4]) for c in candles]
    e5  = _ema(closes[-30:], 5)
    e20 = _ema(closes[-30:], 20)
    sp  = abs(e5 - e20) / max(e20, 1) * 100
    direction = "BUY" if e5 > e20 else "SELL"
    strength  = 1 + (1 if sp > 0.3 else 0) + (1 if sp > 0.6 else 0)
    return {"direction": direction, "strength": strength, "ema5": e5, "ema20": e20}


def mean_revert_signal(candles: List) -> Dict:
    """RSI ≤25 + BB touch = BUY; RSI ≥75 + BB touch = SELL."""
    if len(candles) < 20:
        return {"direction": "SKIP", "strength": 0}
    closes  = [float(c[4]) for c in candles]
    rsi_val = _rsi(closes[-20:])
    bb      = _bollinger(closes[-20:])
    ltp     = closes[-1]
    if rsi_val <= 25 and ltp <= bb["lower"] * 1.005:
        return {"direction": "BUY",  "strength": 3, "rsi": rsi_val}
    if rsi_val <= 30 and ltp <= bb["lower"] * 1.01:
        return {"direction": "BUY",  "strength": 2, "rsi": rsi_val}
    if rsi_val >= 75 and ltp >= bb["upper"] * 0.995:
        return {"direction": "SELL", "strength": 3, "rsi": rsi_val}
    if rsi_val >= 70 and ltp >= bb["upper"] * 0.990:
        return {"direction": "SELL", "strength": 2, "rsi": rsi_val}
    return {"direction": "SKIP", "strength": 0, "rsi": rsi_val}


def breakout_vol_signal(candles: List, day_high: float, day_low: float,
                        current_vol: float, avg_vol: float) -> Dict:
    """Open Range Breakout with volume confirm."""
    if not candles:
        return {"direction": "SKIP", "strength": 0}
    ltp = float(candles[-1][4])
    if ltp <= 0 or day_high <= day_low:
        return {"direction": "SKIP", "strength": 0}
    vol_ratio = current_vol / max(avg_vol, 1)
    if ltp > day_high and vol_ratio >= 1.5:
        return {"direction": "BUY",  "strength": min(3, int(vol_ratio)), "vol_ratio": vol_ratio}
    if ltp < day_low  and vol_ratio >= 1.5:
        return {"direction": "SELL", "strength": min(3, int(vol_ratio)), "vol_ratio": vol_ratio}
    return {"direction": "SKIP", "strength": 0}


def us_momentum_signal(candles: List) -> Dict:
    """Directional trade in the first 30 min of US session."""
    now = datetime.now(IST)
    t   = now.time()
    if not (dtime(18, 30) <= t <= dtime(19, 0)):
        return {"direction": "SKIP", "strength": 0, "reason": "outside_us_window"}
    if len(candles) < 5:
        return {"direction": "SKIP", "strength": 0}
    closes = [float(c[4]) for c in candles[-10:]]
    mom    = (closes[-1] - closes[0]) / max(closes[0], 1) * 100
    if mom > 0.4:  return {"direction": "BUY",  "strength": 2 + (1 if mom > 0.8 else 0)}
    if mom < -0.4: return {"direction": "SELL", "strength": 2 + (1 if mom < -0.8 else 0)}
    return {"direction": "SKIP", "strength": 0}


def gold_hedge_signal(vix: float, usd_inr_chg_pct: float) -> Dict:
    """Long gold on VIX spike or USD/INR weakness."""
    score = 0
    if vix > 18:              score += 2
    elif vix > 16:            score += 1
    if usd_inr_chg_pct > 0.3: score += 2
    elif usd_inr_chg_pct > 0.1: score += 1
    if score >= 2:
        return {"direction": "BUY", "strength": min(score, 3)}
    return {"direction": "SKIP", "strength": 0}


def seasonal_natgas_signal() -> Dict:
    """Weather-driven calendar month bias for NatGasMini."""
    month = datetime.now(IST).month
    bias  = config.NATGAS_SEASONAL.get(month, 0)
    if bias == 0:
        return {"direction": "SKIP", "strength": 0}
    return {"direction": "BUY" if bias > 0 else "SELL", "strength": 1, "month": month}


def inventory_crude_signal(eia_draw_mmbbl: float = 0.0) -> Dict:
    """Wednesday EIA inventory release reversal."""
    now = datetime.now(IST)
    if now.weekday() != 2:
        return {"direction": "SKIP", "strength": 0, "reason": "not_wednesday"}
    t = now.time()
    if not (dtime(20, 15) <= t <= dtime(20, 45)):
        return {"direction": "SKIP", "strength": 0, "reason": "outside_eia_window"}
    if abs(eia_draw_mmbbl) < 1.0:
        return {"direction": "SKIP", "strength": 0, "reason": "small_surprise"}
    direction = "BUY" if eia_draw_mmbbl > 0 else "SELL"
    strength  = 2 if abs(eia_draw_mmbbl) > 3 else 1
    return {"direction": direction, "strength": strength, "eia_draw": eia_draw_mmbbl}


def vix_spike_gold_signal(vix: float, prev_vix: float = 0.0) -> Dict:
    """Long GOLDPETAL when VIX spikes above 18 intraday."""
    if prev_vix == 0:
        prev_vix = vix * 0.95
    if vix > 18 and vix - prev_vix > 1.0:
        return {"direction": "BUY", "strength": 2 + (1 if vix > 22 else 0)}
    return {"direction": "SKIP", "strength": 0}


def volatility_crush_signal(candles: List) -> Dict:
    """Mean-revert after ≥2% single-candle spike."""
    if len(candles) < 3:
        return {"direction": "SKIP", "strength": 0}
    pc = float(candles[-2][4])
    cc = float(candles[-1][4])
    spike_pct = (cc - pc) / max(pc, 1) * 100
    if spike_pct >= 2.0:  return {"direction": "SELL", "strength": 2, "spike_pct": spike_pct}
    if spike_pct <= -2.0: return {"direction": "BUY",  "strength": 2, "spike_pct": spike_pct}
    return {"direction": "SKIP", "strength": 0}


# ─────────────────────────────────────────────────────────────────────────────
# Multi-strategy scanner (v17 scan_commodities logic, sync version)
# ─────────────────────────────────────────────────────────────────────────────

def evaluate_strategies(
    symbol: str,
    candles: List,
    ltp: float,
    day_high: float,
    day_low: float,
    day_open: float,
    volume: float,
    vix: float = 14.0,
    usd_inr_chg: float = 0.0,
    eia_draw: float = 0.0,
    available_capital: float = 0.0,
) -> Dict:
    """
    Evaluate all applicable strategies for a symbol.
    Returns best strategy signal with composite score.
    Ported from v17 scan_commodities multi-strategy loop.
    """
    meta      = config.COMMODITY_META.get(symbol, {})
    now_ist   = datetime.now(IST)
    is_morning = now_ist.time() <= ORB_WINDOW_END
    is_us      = now_ist.time() >= US_SESSION_START

    day_chg_pct = (ltp - day_open) / max(0.01, day_open) * 100 if day_open else 0
    day_range   = day_high - day_low if day_high > day_low else 0.01
    range_pct   = day_range / max(0.01, ltp) * 100
    range_pos   = (ltp - day_low) / max(0.01, day_range)

    best_dir   = "SKIP"
    best_strat = "TREND_FOLLOW"
    best_score = 0
    best_sig   = {}

    for sid in meta.get("strategies", ["TREND_FOLLOW"]):
        strat = config.STRATEGY_CATALOGUE.get(sid, {})
        if available_capital < strat.get("min_capital", 3000):
            continue
        ss = strat.get("session", "both")
        if ss == "morning" and not is_morning: continue
        if ss == "us"      and not is_us:      continue

        sig = {"direction": "SKIP", "strength": 0}

        if   sid == "TREND_FOLLOW":    sig = trend_follow_signal(candles)
        elif sid == "MEAN_REVERT":     sig = mean_revert_signal(candles)
        elif sid == "BREAKOUT_VOL":    sig = breakout_vol_signal(candles, day_high, day_low,
                                                                  volume, volume * 0.7)
        elif sid == "US_MOMENTUM":     sig = us_momentum_signal(candles)
        elif sid == "GOLD_HEDGE":      sig = gold_hedge_signal(vix, usd_inr_chg)
        elif sid == "SEASONAL_NATGAS": sig = seasonal_natgas_signal()
        elif sid == "INVENTORY_CRUDE": sig = inventory_crude_signal(eia_draw)
        elif sid == "VIX_SPIKE_GOLD":  sig = vix_spike_gold_signal(vix)
        elif sid == "VOLATILITY_CRUSH":sig = volatility_crush_signal(candles)

        if sig["direction"] == "SKIP":
            continue
        ss_score = sig["strength"] + strat.get("score_bonus", 0)
        if ss_score > best_score:
            best_score, best_strat = ss_score, sid
            best_dir, best_sig = sig["direction"], sig

    # Heuristic fallback
    if best_dir == "SKIP":
        if day_chg_pct > 0.3 and range_pos < 0.70:  best_dir = "BUY"
        elif day_chg_pct < -0.3 and range_pos > 0.30: best_dir = "SELL"
        elif range_pos < 0.35: best_dir = "BUY"
        elif range_pos > 0.65: best_dir = "SELL"
        else: best_dir = "BUY"
        best_strat = "TREND_FOLLOW"

    # Composite score bonus
    if range_pct > 0.5:  best_score += 1
    if range_pct > 1.0:  best_score += 1
    if abs(day_chg_pct) > 0.3: best_score += 1

    strat_info = config.STRATEGY_CATALOGUE.get(best_strat, {})
    return {
        "symbol":        symbol,
        "direction":     best_dir,
        "score":         best_score,
        "strategy":      best_strat,
        "strategy_name": strat_info.get("name", best_strat),
        "signal_data":   best_sig,
        "day_change_pct":round(day_chg_pct, 2),
        "range_pct":     round(range_pct, 2),
        "range_position":round(range_pos, 2),
        "ltp":           ltp,
        "target_pct":    meta.get("target_pct", 1.0) * strat_info.get("target_mult", 1.0),
        "sl_pct":        meta.get("sl_pct", 0.6) * strat_info.get("sl_mult", 1.0),
        "max_hold_min":  strat_info.get("hold_min", meta.get("max_hold_min", 45)),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Legacy composite TA (kept for AI opinion input + learning features)
# ─────────────────────────────────────────────────────────────────────────────

def full_ta_summary(candles: List) -> Dict:
    """
    Composite TA score across 7 indicators.
    Used by AI opinion prompt and feature extraction for LightGBM.
    """
    if len(candles) < 10:
        return {"score": 0, "signals": {}, "summary": "insufficient data", "last_price": 0, "atr": 0}

    closes = [float(c[4]) for c in candles]
    last   = closes[-1]
    signals = {}
    score   = 0

    # EMA trend
    e9  = _ema(closes, 9)
    e21 = _ema(closes, 21)
    e50 = _ema(closes, 50) if len(closes) >= 50 else last
    signals["ema_trend"] = "BUY" if e9 > e21 > e50 else ("SELL" if e9 < e21 < e50 else "NEUTRAL")
    score += {"BUY": 2, "SELL": -2, "NEUTRAL": 0}[signals["ema_trend"]]

    # RSI
    r = _rsi(closes)
    if r < 30:   signals["rsi"] = "BUY";    score += 3
    elif r > 70: signals["rsi"] = "SELL";   score -= 3
    elif r < 45: signals["rsi"] = "WEAK_BUY"; score += 1
    elif r > 55: signals["rsi"] = "WEAK_SELL"; score -= 1
    else:        signals["rsi"] = "NEUTRAL"
    signals["rsi_val"] = round(r, 1)

    # MACD
    ml, sl, hl = _macd(closes)
    if not any(math.isnan(x) for x in [ml, sl, hl]):
        signals["macd"] = "BUY" if ml > sl and hl > 0 else ("SELL" if ml < sl and hl < 0 else "NEUTRAL")
        score += {"BUY": 2, "SELL": -2, "NEUTRAL": 0}[signals["macd"]]

    # Bollinger
    bb = _bollinger(closes)
    if last < bb["lower"]:  signals["bb"] = "BUY";  score += 2
    elif last > bb["upper"]:signals["bb"] = "SELL"; score -= 2
    else:                    signals["bb"] = "NEUTRAL"

    # Supertrend
    st_dir = _supertrend(candles)
    signals["supertrend"] = "BUY" if st_dir == 1 else "SELL"
    score += 3 if st_dir == 1 else -3

    # VWAP
    cum_tp_v = 0.0; cum_v = 0.0
    for c in candles:
        h, l, cl, v = float(c[2]), float(c[3]), float(c[4]), float(c[5])
        tp = (h + l + cl) / 3
        cum_tp_v += tp * v; cum_v += v
    vwap = cum_tp_v / cum_v if cum_v else last
    signals["vwap"] = "BUY" if last > vwap else "SELL"
    score += 1 if last > vwap else -1

    # ATR
    atr_val = _atr_series(candles)[-1]
    signals["atr"] = round(atr_val, 2) if not math.isnan(atr_val) else 0

    direction = "STRONG_BUY" if score >= 8 else \
                "BUY"        if score >= 3 else \
                "STRONG_SELL"if score <= -8 else \
                "SELL"       if score <= -3 else "NEUTRAL"

    return {
        "score":     score,
        "direction": direction,
        "signals":   signals,
        "last_price":last,
        "atr":       signals["atr"],
        "summary":   f"{direction}|score={score}|RSI={signals.get('rsi_val',50)}|MACD={signals.get('macd','?')}|ST={signals.get('supertrend','?')}",
    }
