"""
Upstox Broker Client
Handles OAuth2 login, order management, position tracking
"""

import logging
import time
import threading
import webbrowser
import urllib.parse
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Optional, Dict, List, Any

import requests

import config

logger = logging.getLogger("upstox")

# ─────────────────────────────────────────────────────────────────────────────
# OAuth callback server
# ─────────────────────────────────────────────────────────────────────────────

_auth_code: Optional[str] = None

class _CallbackHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        global _auth_code
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        if "code" in params:
            _auth_code = params["code"][0]
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"<h2>Login successful! You can close this tab.</h2>")
        else:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b"<h2>Auth failed - no code received.</h2>")
    def log_message(self, *_): pass  # silent


def _run_callback_server(port: int = 8000):
    server = HTTPServer(("0.0.0.0", port), _CallbackHandler)
    server.timeout = 120
    server.handle_request()   # single shot


# ─────────────────────────────────────────────────────────────────────────────
# UpstoxClient
# ─────────────────────────────────────────────────────────────────────────────

class UpstoxClient:
    BASE = "https://api.upstox.com/v2"

    def __init__(self):
        self.access_token: str = config.UPSTOX_ACCESS_TOKEN
        self._session = requests.Session()
        self._session.headers.update({"Accept": "application/json"})
        self._last_call = 0.0
        self._rate_limit = 0.2   # 200 ms between calls

    # ── Auth ─────────────────────────────────────────────────────────────────

    def login(self) -> bool:
        """
        Full OAuth login flow.
        1. Opens browser → user logs in → redirect to localhost:8000/callback
        2. Exchanges auth code for access token
        """
        if self.access_token and self._validate_token():
            logger.info("Existing token is valid – skipping login.")
            return True

        logger.info("Starting Upstox OAuth login …")
        port = int(urllib.parse.urlparse(config.UPSTOX_REDIRECT_URI).port or 8000)

        # Start callback server in background
        t = threading.Thread(target=_run_callback_server, args=(port,), daemon=True)
        t.start()

        auth_url = (
            f"https://api.upstox.com/v2/login/authorization/dialog"
            f"?response_type=code"
            f"&client_id={config.UPSTOX_API_KEY}"
            f"&redirect_uri={urllib.parse.quote(config.UPSTOX_REDIRECT_URI)}"
        )
        logger.info(f"Opening browser: {auth_url}")
        webbrowser.open(auth_url)

        # Wait up to 120 s for callback
        global _auth_code
        deadline = time.time() + 120
        while time.time() < deadline:
            if _auth_code:
                break
            time.sleep(0.5)

        if not _auth_code:
            logger.error("Timed out waiting for auth code.")
            return False

        token = self._exchange_code(_auth_code)
        if token:
            self.access_token = token
            logger.info("Login successful – access token obtained.")
            return True
        return False

    def _exchange_code(self, code: str) -> Optional[str]:
        url = "https://api.upstox.com/v2/login/authorization/token"
        data = {
            "code":          code,
            "client_id":     config.UPSTOX_API_KEY,
            "client_secret": config.UPSTOX_API_SECRET,
            "redirect_uri":  config.UPSTOX_REDIRECT_URI,
            "grant_type":    "authorization_code",
        }
        r = requests.post(url, data=data)
        if r.ok:
            return r.json().get("access_token")
        logger.error(f"Token exchange failed: {r.text}")
        return None

    def _validate_token(self) -> bool:
        try:
            r = self._get("/user/profile")
            return r.get("status") == "success"
        except Exception:
            return False

    # ── HTTP helpers ─────────────────────────────────────────────────────────

    def _throttle(self):
        elapsed = time.time() - self._last_call
        if elapsed < self._rate_limit:
            time.sleep(self._rate_limit - elapsed)
        self._last_call = time.time()

    def _headers(self):
        return {
            "Authorization": f"Bearer {self.access_token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def _get(self, path: str, params: Dict = None) -> Dict:
        self._throttle()
        r = self._session.get(f"{self.BASE}{path}", params=params, headers=self._headers())
        r.raise_for_status()
        return r.json()

    def _post(self, path: str, payload: Dict) -> Dict:
        self._throttle()
        r = self._session.post(f"{self.BASE}{path}", json=payload, headers=self._headers())
        r.raise_for_status()
        return r.json()

    def _delete(self, path: str, params: Dict = None) -> Dict:
        self._throttle()
        r = self._session.delete(f"{self.BASE}{path}", params=params, headers=self._headers())
        r.raise_for_status()
        return r.json()

    # ── Market data ──────────────────────────────────────────────────────────

    def get_ltp(self, instrument_key: str) -> Optional[float]:
        """Last traded price for an instrument key."""
        try:
            resp = self._get("/market-quote/ltp", {"instrument_key": instrument_key})
            data = resp.get("data", {})
            for v in data.values():
                return float(v.get("last_price", 0))
        except Exception as e:
            logger.warning(f"LTP fetch failed for {instrument_key}: {e}")
        return None

    def get_ohlc(self, instrument_key: str, interval: str = "5",
                 unit: str = "minutes") -> List[Dict]:
        """Historical candles using Upstox v3 intraday API."""
        try:
            encoded_key = urllib.parse.quote(instrument_key, safe="")
            url = f"https://api.upstox.com/v3/historical-candle/intraday/{encoded_key}/{unit}/{interval}"
            self._throttle()
            r = self._session.get(url, headers=self._headers())
            r.raise_for_status()
            return r.json().get("data", {}).get("candles", [])
        except Exception as e:
            logger.warning(f"OHLC fetch failed: {e}")
            return []

    def get_option_chain(self, instrument_key: str, expiry: str) -> Dict:
        """Fetch option chain for an underlying."""
        try:
            resp = self._get("/option/chain", {
                "instrument_key": instrument_key,
                "expiry_date": expiry,
            })
            return resp.get("data", {})
        except Exception as e:
            logger.warning(f"Option chain fetch failed: {e}")
            return {}

    def search_instruments(self, query: str) -> List[Dict]:
        """Search instruments by name."""
        try:
            resp = self._get("/market-quote/instruments/search", {"q": query})
            return resp.get("data", [])
        except Exception as e:
            logger.warning(f"Instrument search failed: {e}")
            return []

    # ── Order management ─────────────────────────────────────────────────────

    def place_order(self, instrument_key: str, qty: int,
                    side: str,          # "BUY" | "SELL"
                    order_type: str = "MARKET",
                    price: float = 0.0,
                    product: str = "D",  # D=delivery/NRML for F&O
                    tag: str = "MCX_AI") -> Optional[str]:
        """Place order; returns order_id or None on failure."""

        if config.PAPER_TRADING:
            oid = f"PAPER_{int(time.time()*1000)}"
            logger.info(f"[PAPER] {side} {qty} × {instrument_key} @ {order_type}={price} → {oid}")
            return oid

        payload = {
            "quantity":       qty,
            "product":        product,
            "validity":       "DAY",
            "price":          price,
            "tag":            tag,
            "instrument_token": instrument_key,
            "order_type":     order_type,
            "transaction_type": side,
            "disclosed_quantity": 0,
            "trigger_price":  0,
            "is_amo":         False,
        }
        try:
            resp = self._post("/order/place", payload)
            if resp.get("status") == "success":
                oid = resp["data"]["order_id"]
                logger.info(f"Order placed: {oid}  {side} {qty}×{instrument_key}")
                return oid
            logger.error(f"Order rejected: {resp}")
        except Exception as e:
            logger.error(f"Place order error: {e}")
        return None

    def cancel_order(self, order_id: str) -> bool:
        if config.PAPER_TRADING:
            logger.info(f"[PAPER] Cancel {order_id}")
            return True
        try:
            resp = self._delete("/order/cancel", {"order_id": order_id})
            return resp.get("status") == "success"
        except Exception as e:
            logger.warning(f"Cancel failed: {e}")
        return False

    def get_positions(self) -> List[Dict]:
        try:
            resp = self._get("/portfolio/short-term-positions")
            return resp.get("data", [])
        except Exception as e:
            logger.warning(f"Positions fetch failed: {e}")
            return []

    def get_orders(self) -> List[Dict]:
        try:
            resp = self._get("/order/retrieve-all")
            return resp.get("data", [])
        except Exception as e:
            logger.warning(f"Orders fetch failed: {e}")
            return []

    def get_funds(self) -> Dict:
        try:
            resp = self._get("/user/get-funds-and-margin")
            return resp.get("data", {})
        except Exception as e:
            logger.warning(f"Funds fetch failed: {e}")
            return {}
