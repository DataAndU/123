# CurrentPulse - Production Deployment Guide

## 📋 Table of Contents
1. [Prerequisites](#prerequisites)
2. [Local Setup](#local-setup)
3. [Environment Configuration](#environment-configuration)
4. [Database Setup](#database-setup)
5. [Hostinger VPS Deployment](#hostinger-vps-deployment)
6. [PM2 Management](#pm2-management)
7. [AI Engine Setup](#ai-engine-setup)
8. [Monitoring & Troubleshooting](#monitoring--troubleshooting)

---

## Prerequisites

### Required Software
- **Node.js**: v16 or higher
- **npm**: v7 or higher
- **Git**: For version control
- **SQLite3**: Included with Node.js packages

### API Keys
1. **OpenAI API Key** - Get from https://platform.openai.com/api-keys
2. **Claude API Key** - Get from https://console.anthropic.com

### Hostinger Account
- VPS with Ubuntu 20.04 LTS or higher
- SSH access to your server
- SSH key pair for authentication

---

## Local Setup

### Step 1: Clone/Initialize Project
```bash
# Navigate to project directory
cd CurrentPulse

# Initialize git (if not done)
git init

# Install dependencies
npm install
```

### Step 2: Create Environment File
```bash
# Copy example to .env
cp .env.example .env

# Edit .env with your credentials
nano .env
```

### Step 3: Update .env Values
```env
# Server
NODE_ENV=development
PORT=3000

# AI APIs
OPENAI_API_KEY=sk-your-openai-key
CLAUDE_API_KEY=sk-ant-your-claude-key

# JWT
JWT_SECRET=your-super-secret-key-here-change-in-production
JWT_EXPIRE=7d

# Database
DB_PATH=./database/currentpulse.db

# Admin
ADMIN_EMAIL=founder@currentpulse.in
ADMIN_PASSWORD_HASH=$2a$12$hashed-password-here

# Subscription
SUBSCRIPTION_PRICE=99
SUBSCRIPTION_CURRENCY=INR

# Scheduling (cron format)
DAILY_NEWS_FETCH_TIME=0 5 * * *
DAILY_STUDY_GEN_TIME=10 5 * * *
DAILY_QUIZ_GEN_TIME=20 5 * * *
DAILY_QUIZ_PUBLISH_TIME=0 6 * * *
WEEKLY_MOCK_TIME=0 0 ? * SUN

# Feature Flags
ENABLE_AI_AUTOMATION=true
PAUSE_AI_ENGINE=false
```

### Step 4: Generate Secure JWT Secret
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Step 5: Generate Admin Password Hash
```bash
# Create a Node script to generate bcrypt hash
node << 'EOF'
const bcrypt = require('bcryptjs');
const password = 'YourAdminPassword123!'; // Change this
const hash = bcrypt.hashSync(password, 10);
console.log('Hash:', hash);
EOF
```

### Step 6: Test Locally
```bash
# Development mode with auto-reload
npm run dev

# Production mode
npm start
```

Visit: http://localhost:3000

---

## Environment Configuration

### Required Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `NODE_ENV` | Environment type | `production` |
| `PORT` | Server port | `3000` |
| `OPENAI_API_KEY` | OpenAI API key | `sk-...` |
| `CLAUDE_API_KEY` | Claude API key | `sk-ant-...` |
| `JWT_SECRET` | JWT signing secret | 64-char hex string |
| `ADMIN_EMAIL` | Admin user email | `founder@currentpulse.in` |

### Optional Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `DB_PATH` | `./database/currentpulse.db` | SQLite database location |
| `LOG_LEVEL` | `info` | Logging level |
| `RATE_LIMIT_WINDOW_MS` | `900000` | Rate limit window (15 min) |
| `RATE_LIMIT_MAX_REQUESTS` | `100` | Max requests per window |
| `ENABLE_AI_AUTOMATION` | `true` | Enable AI scheduling |

---

## Database Setup

### Automatic Setup
The database is automatically created on first run with:
- ✓ All required tables
- ✓ Proper indexes for performance
- ✓ Default admin user

### Manual Database Reset
```bash
# Delete existing database
rm database/currentpulse.db

# Restart server to recreate
npm start
```

### Database Tables
```
- users (authentication)
- subscriptions (billing)
- articles (study material)
- questions (MCQs)
- tests (test collections)
- test_questions (mapping)
- attempts (user responses)
- doubts (Q&A)
- admin_logs (audit trail)
- system_health (monitoring)
```

---

## Hostinger VPS Deployment

### Step 1: Connect to VPS
```bash
# SSH into your Hostinger VPS
ssh root@your_vps_ip

# Update system packages
apt-get update
apt-get upgrade -y
```

### Step 2: Install Node.js and npm
```bash
# Install NodeSource repository
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -

# Install Node.js
apt-get install -y nodejs

# Verify installation
node --version
npm --version
```

### Step 3: Install PM2 Globally
```bash
npm install -g pm2

# Enable PM2 startup
pm2 startup
# Follow the command it outputs

# Save PM2 configuration
pm2 save
```

### Step 4: Setup Application Directory
```bash
# Create application directory
mkdir -p /var/www/currentpulse
cd /var/www/currentpulse

# Clone your repository (or upload files)
git clone https://your-repo.git .
# OR upload via SFTP/SCP

# Install dependencies
npm install --production
```

### Step 5: Configure Environment
```bash
# Create .env file
nano .env

# Paste your production environment variables
# Save with Ctrl+X, then Y, then Enter
```

### Step 6: Setup Nginx Reverse Proxy
```bash
# Install Nginx
apt-get install -y nginx

# Create Nginx configuration
nano /etc/nginx/sites-available/currentpulse
```

Paste the following configuration:
```nginx
upstream currentpulse {
  server 127.0.0.1:3000;
  keepalive 64;
}

server {
  listen 80;
  server_name currentpulse.in www.currentpulse.in;
  
  # Redirect HTTP to HTTPS
  return 301 https://$server_name$request_uri;
}

server {
  listen 443 ssl http2;
  server_name currentpulse.in www.currentpulse.in;

  # SSL Certificate (use Let's Encrypt)
  ssl_certificate /etc/letsencrypt/live/currentpulse.in/fullchain.pem;
  ssl_certificate_key /etc/letsencrypt/live/currentpulse.in/privkey.pem;

  # Security headers
  add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
  add_header X-Content-Type-Options "nosniff" always;
  add_header X-Frame-Options "DENY" always;

  # Gzip compression
  gzip on;
  gzip_types text/plain text/css application/json application/javascript;

  location / {
    proxy_pass http://currentpulse;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_cache_bypass $http_upgrade;
  }

  # Static files caching
  location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
  }
}
```

Enable the site:
```bash
ln -s /etc/nginx/sites-available/currentpulse /etc/nginx/sites-enabled/
rm /etc/nginx/sites-enabled/default

# Test Nginx configuration
nginx -t

# Restart Nginx
systemctl restart nginx
```

### Step 7: Setup SSL Certificate (Let's Encrypt)
```bash
# Install Certbot
apt-get install -y certbot python3-certbot-nginx

# Get SSL certificate
certbot certonly --nginx -d currentpulse.in -d www.currentpulse.in

# Auto-renew certificate
systemctl enable certbot.timer
systemctl start certbot.timer
```

### Step 8: Start Application with PM2
```bash
# Navigate to app directory
cd /var/www/currentpulse

# Start with PM2
pm2 start ecosystem.config.js --env production

# Verify it's running
pm2 status

# View logs
pm2 logs currentpulse

# Save PM2 configuration
pm2 save
```

---

## PM2 Management

### Start Application
```bash
# Start from ecosystem config
pm2 start ecosystem.config.js

# Start with custom name
pm2 start server.js --name currentpulse

# Start in cluster mode
pm2 start server.js -i max
```

### Monitor Application
```bash
# View status
pm2 status

# View real-time logs
pm2 logs currentpulse

# View specific error logs
pm2 logs currentpulse --err

# Monit dashboard
pm2 monit
```

### Manage Application
```bash
# Restart application
pm2 restart currentpulse

# Reload application (0-downtime)
pm2 reload currentpulse

# Stop application
pm2 stop currentpulse

# Delete application from PM2
pm2 delete currentpulse

# Resurrect application from ecosystem config
pm2 resurrect
```

### PM2 Configuration
The `ecosystem.config.js` file includes:
- ✓ Cluster mode (uses all CPU cores)
- ✓ Auto-restart on crash
- ✓ Max memory limit (500MB)
- ✓ Graceful shutdown
- ✓ Separate error/output logs

---

## AI Engine Setup

### Scheduler Configuration
The AI Engine runs on these schedules (all UTC):

| Task | Default Time | Function |
|------|--------------|----------|
| News Fetch | 5:00 AM | Fetch latest news from RSS |
| Study Material Gen | 5:10 AM | Convert news to study materials |
| MCQ Generation | 5:20 AM | Generate quiz questions |
| Quiz Publishing | 6:00 AM | Publish daily test |
| Doubt Processing | Every 2 hours | Answer student doubts |
| Daily Analysis | 7:00 PM | Analyze student performance |
| Daily Report | 8:00 PM | Generate founder report |
| Health Check | Every 6 hours | System monitoring |
| Weekly Mock | Sunday 12 AM | Generate 50-question mock test |

### Manual Task Execution
Access admin dashboard: `https://currentpulse.in/admin`

Or via API:
```bash
# Example: Manually run content agent
curl -X POST http://localhost:3000/api/admin/scheduler/run/content \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -H "Content-Type: application/json"
```

### Pause/Resume AI Engine
```bash
# Pause AI automation
curl -X POST http://localhost:3000/api/admin/ai-engine/pause \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"

# Resume AI automation
curl -X POST http://localhost:3000/api/admin/ai-engine/resume \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
```

### View Scheduler Status
```bash
# View all scheduled tasks
curl http://localhost:3000/api/admin/scheduler/tasks \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN"
```

---

## Monitoring & Troubleshooting

### Health Check Endpoints
```bash
# Basic health check
curl http://localhost:3000/api/health

# Detailed health check
curl http://localhost:3000/api/health/detailed
```

### View Application Logs
```bash
# PM2 logs
pm2 logs currentpulse

# System logs
tail -f ./logs/combined.log
tail -f ./logs/error.log
```

### Monitor System Resources
```bash
# View PM2 monitoring
pm2 monit

# Check system memory
free -h

# Check disk space
df -h
```

### Common Issues & Solutions

#### Issue: Database Lock Error
```bash
# Solution: Restart application
pm2 restart currentpulse
```

#### Issue: API Rate Limited
```
Error: 429 Too Many Requests

# Solution: Check rate limiting in .env
# Increase RATE_LIMIT_MAX_REQUESTS or RATE_LIMIT_WINDOW_MS
```

#### Issue: AI Keys Not Working
```bash
# Verify keys are set correctly
echo $OPENAI_API_KEY
echo $CLAUDE_API_KEY

# Test API connectivity
curl https://api.openai.com/v1/models \
  -H "Authorization: Bearer $OPENAI_API_KEY"
```

#### Issue: Scheduler Not Running
```bash
# Check if AI automation is enabled
grep ENABLE_AI_AUTOMATION .env

# Check PM2 logs for scheduler errors
pm2 logs currentpulse | grep -i scheduler
```

#### Issue: High Memory Usage
```bash
# Reduce max memory in ecosystem.config.js
# Check for memory leaks in logs
pm2 monit

# Restart if needed
pm2 restart currentpulse
```

---

## Backup & Maintenance

### Backup Database
```bash
# Create backup
cp database/currentpulse.db database/currentpulse.db.backup.$(date +%Y%m%d)

# Or use automated backup
0 2 * * * cp /var/www/currentpulse/database/currentpulse.db /backups/currentpulse.db.$(date +\%Y\%m\%d)
```

### Cleanup Old Logs
```bash
# Find logs older than 30 days and remove
find ./logs -name "*.log" -mtime +30 -delete
```

### Restart Application Periodically
```bash
# Restart every day at 3 AM
0 3 * * * cd /var/www/currentpulse && pm2 restart currentpulse

# Add to crontab
crontab -e
```

---

## Performance Optimization

### Database Optimization
```sql
-- Run periodically to optimize
VACUUM;
ANALYZE;
```

### Nginx Caching
- Static assets cached for 1 year
- Gzip compression enabled
- HTTP/2 enabled for faster loading

### Node.js Optimization
- Cluster mode enabled (uses all CPU cores)
- Connection pooling
- Graceful shutdown for updates

---

## Security Checklist

✓ Change admin password immediately
✓ Update JWT_SECRET to a random 64-char string
✓ Enable SSL/HTTPS with Let's Encrypt
✓ Configure firewall to allow only 80, 443, 22
✓ Regular database backups
✓ Monitor error logs for suspicious activity
✓ Rate limiting enabled
✓ CORS configured for frontend domain
✓ API keys stored securely in environment
✓ Database password hashing enabled

---

## Getting Help

### Check Application Status
```bash
curl http://localhost:3000/api/health
```

### View Error Logs
```bash
tail -100 ./logs/error.log
```

### Contact Support
- Email: support@currentpulse.in
- Docs: https://docs.currentpulse.in

---

**Last Updated**: 2024
**Version**: 1.0.0
