const axios = require('axios');
const logger = require('./logger');

const MAX_RETRIES = 3;
const INITIAL_DELAY = 1000; // 1 second
const MAX_DELAY = 10000; // 10 seconds

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const exponentialBackoff = (attempt) => {
  const delay = INITIAL_DELAY * Math.pow(2, attempt);
  return Math.min(delay, MAX_DELAY) + Math.random() * 1000;
};

const apiCall = async (fn, context = 'API Call') => {
  let lastError;
  
  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    try {
      logger.info(`${context} - Attempt ${attempt + 1}/${MAX_RETRIES}`);
      const result = await fn();
      return result;
    } catch (error) {
      lastError = error;
      
      // Check if error is retryable
      const isRetryable = 
        error.code === 'ECONNREFUSED' ||
        error.code === 'ETIMEDOUT' ||
        error.code === 'ENOTFOUND' ||
        (error.response && [429, 500, 502, 503, 504].includes(error.response.status));

      if (!isRetryable || attempt === MAX_RETRIES - 1) {
        logger.error(`${context} - Failed after ${attempt + 1} attempts:`, error.message);
        throw error;
      }

      const delay = exponentialBackoff(attempt);
      logger.warn(`${context} - Retry in ${Math.round(delay)}ms`);
      await sleep(delay);
    }
  }
  
  throw lastError;
};

const axiosWithRetry = async (config, context = 'Axios Call') => {
  return apiCall(() => axios(config), context);
};

module.exports = {
  apiCall,
  axiosWithRetry,
  sleep
};
