const express = require('express');
const router = express.Router();
const database = require('../database/init');
const { authMiddleware } = require('../utils/auth');
const logger = require('../utils/logger');

// ============== START DAILY TEST ==============
router.post('/start-daily', authMiddleware, async (req, res) => {
  try {
    const userId = req.user.userId;

    // Check if user already took today's test
    const existingTest = await database.get(
      `SELECT a.test_id FROM attempts a
       WHERE a.user_id = ? AND DATE(a.created_at) = DATE('now')
       LIMIT 1`,
      [userId]
    );

    if (existingTest) {
      // Return existing test
      const test = await database.get(
        'SELECT * FROM tests WHERE id = ?',
        [existingTest.test_id]
      );
      
      return res.json({
        success: true,
        message: 'You already started today\'s test',
        data: {
          testId: test.id,
          test_type: test.test_type,
          total_questions: test.total_questions,
          duration_minutes: test.duration_minutes
        }
      });
    }

    // Get today's daily test
    const test = await database.get(
      `SELECT * FROM tests 
       WHERE test_type = 'daily' AND DATE(created_at) = DATE('now')
       LIMIT 1`
    );

    if (!test) {
      return res.status(404).json({
        success: false,
        message: 'No daily test available today'
      });
    }

    const questions = await database.all(
      `SELECT tq.question_id, q.question, q.option_a, q.option_b, q.option_c, q.option_d
       FROM test_questions tq
       JOIN questions q ON tq.question_id = q.id
       WHERE tq.test_id = ?
       ORDER BY tq.sequence_order`,
      [test.id]
    );

    res.json({
      success: true,
      data: {
        testId: test.id,
        test_type: test.test_type,
        total_questions: test.total_questions,
        duration_minutes: test.duration_minutes,
        questions
      }
    });
  } catch (error) {
    logger.error('Start daily test error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to start daily test'
    });
  }
});

// ============== GET QUESTION EXPLANATION ==============
router.get('/question/:questionId/explanation', authMiddleware, async (req, res) => {
  try {
    const { questionId } = req.params;

    const question = await database.get(
      'SELECT question, correct_answer, explanation FROM questions WHERE id = ?',
      [questionId]
    );

    if (!question) {
      return res.status(404).json({
        success: false,
        message: 'Question not found'
      });
    }

    res.json({
      success: true,
      data: {
        question: question.question,
        correctAnswer: question.correct_answer,
        explanation: question.explanation || 'Explanation not available'
      }
    });
  } catch (error) {
    logger.error('Get explanation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch explanation'
    });
  }
});

// ============== GET SUBJECT PRACTICE TEST ==============
router.post('/practice/:subject', authMiddleware, async (req, res) => {
  try {
    const { subject } = req.params;

    // Get 10 questions from the subject
    const questions = await database.all(
      `SELECT id, question, option_a, option_b, option_c, option_d, difficulty_level
       FROM questions
       WHERE subject = ? AND is_approved = 1
       ORDER BY RANDOM()
       LIMIT 10`,
      [decodeURIComponent(subject)]
    );

    if (questions.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No practice questions available for this subject'
      });
    }

    // Create temporary test for practice
    const testResult = await database.run(
      `INSERT INTO tests (test_type, total_questions, duration_minutes, subject, created_at)
       VALUES (?, ?, ?, ?, datetime('now'))`,
      ['practice', questions.length, 30, subject]
    );

    const testId = testResult.id;

    // Assign questions
    for (let i = 0; i < questions.length; i++) {
      await database.run(
        `INSERT INTO test_questions (test_id, question_id, sequence_order)
         VALUES (?, ?, ?)`,
        [testId, questions[i].id, i + 1]
      );
    }

    res.json({
      success: true,
      data: {
        testId,
        subject,
        totalQuestions: questions.length,
        durationMinutes: 30,
        questions: questions.map(q => ({
          questionId: q.id,
          question: q.question,
          optionA: q.option_a,
          optionB: q.option_b,
          optionC: q.option_c,
          optionD: q.option_d,
          difficultyLevel: q.difficulty_level
        }))
      }
    });
  } catch (error) {
    logger.error('Practice test error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create practice test'
    });
  }
});

// ============== GET FULL MOCK TEST ==============
router.get('/full-mock', authMiddleware, async (req, res) => {
  try {
    // Get the latest full mock test
    const test = await database.get(
      `SELECT * FROM tests 
       WHERE test_type = 'full_mock'
       ORDER BY created_at DESC
       LIMIT 1`
    );

    if (!test) {
      return res.status(404).json({
        success: false,
        message: 'No full mock test available'
      });
    }

    const questions = await database.all(
      `SELECT tq.question_id, q.question, q.option_a, q.option_b, q.option_c, q.option_d, q.subject
       FROM test_questions tq
       JOIN questions q ON tq.question_id = q.id
       WHERE tq.test_id = ?
       ORDER BY tq.sequence_order`,
      [test.id]
    );

    res.json({
      success: true,
      data: {
        testId: test.id,
        totalQuestions: test.total_questions,
        durationMinutes: test.duration_minutes,
        questions: questions.map(q => ({
          questionId: q.question_id,
          question: q.question,
          optionA: q.option_a,
          optionB: q.option_b,
          optionC: q.option_c,
          optionD: q.option_d,
          subject: q.subject
        }))
      }
    });
  } catch (error) {
    logger.error('Full mock test error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch full mock test'
    });
  }
});

// ============== GET AVAILABLE SUBJECTS ==============
router.get('/subjects', authMiddleware, async (req, res) => {
  try {
    const subjects = await database.all(
      `SELECT DISTINCT subject, COUNT(*) as questionCount
       FROM questions
       WHERE is_approved = 1
       GROUP BY subject
       ORDER BY questionCount DESC`
    );

    res.json({
      success: true,
      data: subjects
    });
  } catch (error) {
    logger.error('Get subjects error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch subjects'
    });
  }
});

module.exports = router;
