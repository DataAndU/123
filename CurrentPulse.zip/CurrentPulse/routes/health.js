const express = require('express');
const router = express.Router();
const database = require('../database/init');
const logger = require('../utils/logger');

// ============== BASIC HEALTH CHECK ==============
router.get('/', async (req, res) => {
  try {
    // Test database connection
    const dbTest = await database.get('SELECT 1 as test');

    if (!dbTest) {
      return res.status(503).json({
        success: false,
        message: 'Database connection failed',
        timestamp: new Date().toISOString()
      });
    }

    res.json({
      success: true,
      message: 'Server is healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || 'development'
    });
  } catch (error) {
    logger.error('Health check failed:', error);
    res.status(503).json({
      success: false,
      message: 'Health check failed',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// ============== DETAILED HEALTH CHECK ==============
router.get('/detailed', async (req, res) => {
  try {
    const health = {
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV,
      memory: process.memoryUsage(),
      checks: {}
    };

    // Database check
    try {
      const dbTest = await database.get('SELECT COUNT(*) as count FROM users');
      health.checks.database = {
        status: 'healthy',
        users: dbTest.count
      };
    } catch (err) {
      health.checks.database = {
        status: 'error',
        error: err.message
      };
    }

    // API keys check
    health.checks.apis = {
      openai: !!process.env.OPENAI_API_KEY,
      claude: !!process.env.CLAUDE_API_KEY
    };

    res.json({
      success: true,
      data: health
    });
  } catch (error) {
    logger.error('Detailed health check error:', error);
    res.status(500).json({
      success: false,
      message: 'Health check failed'
    });
  }
});

module.exports = router;
