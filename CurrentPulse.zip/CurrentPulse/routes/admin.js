const express = require('express');
const router = express.Router();
const database = require('../database/init');
const { adminAuthMiddleware } = require('../utils/auth');
const monitorAgent = require('../ai-engine/agents/monitor-agent');
const scheduler = require('../ai-engine/scheduler');
const logger = require('../utils/logger');

// ============== GET ADMIN DASHBOARD ==============
router.get('/dashboard', adminAuthMiddleware, async (req, res) => {
  try {
    const dashboardData = await monitorAgent.getMonitoringDashboard();

    res.json({
      success: true,
      data: dashboardData
    });
  } catch (error) {
    logger.error('Admin dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to load admin dashboard'
    });
  }
});

// ============== GET SYSTEM STATISTICS ==============
router.get('/stats', adminAuthMiddleware, async (req, res) => {
  try {
    // Total users
    const totalUsers = await database.get(
      'SELECT COUNT(*) as count FROM users WHERE is_admin = 0'
    );

    // Active subscriptions
    const activeSubscriptions = await database.get(
      'SELECT COUNT(*) as count FROM subscriptions WHERE status = "active"'
    );

    // Total articles
    const totalArticles = await database.get(
      'SELECT COUNT(*) as count FROM articles'
    );

    // Total questions
    const totalQuestions = await database.get(
      'SELECT COUNT(*) as count FROM questions'
    );

    // Total tests taken
    const totalAttempts = await database.get(
      `SELECT COUNT(*) as count FROM (
        SELECT DISTINCT test_id FROM attempts
      )`
    );

    // Monthly revenue
    const monthlyRevenue = await database.get(
      `SELECT SUM(amount) as total FROM subscriptions 
       WHERE created_at > datetime('now', '-1 month')`
    );

    res.json({
      success: true,
      data: {
        totalUsers: totalUsers.count,
        activeSubscriptions: activeSubscriptions.count,
        totalArticles: totalArticles.count,
        totalQuestions: totalQuestions.count,
        totalTestsTaken: totalAttempts.count,
        monthlyRevenue: monthlyRevenue.total || 0
      }
    });
  } catch (error) {
    logger.error('Admin stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch statistics'
    });
  }
});

// ============== GET GENERATED CONTENT ==============
router.get('/content', adminAuthMiddleware, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const articles = await database.all(
      `SELECT id, title, source, category, difficulty_level, is_approved, created_at
       FROM articles
       ORDER BY created_at DESC
       LIMIT ? OFFSET ?`,
      [parseInt(limit), offset]
    );

    const total = await database.get('SELECT COUNT(*) as count FROM articles');

    res.json({
      success: true,
      data: {
        articles,
        pagination: {
          total: total.count,
          page: parseInt(page),
          limit: parseInt(limit),
          pages: Math.ceil(total.count / limit)
        }
      }
    });
  } catch (error) {
    logger.error('Get content error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch content'
    });
  }
});

// ============== APPROVE CONTENT ==============
router.put('/content/:contentId/approve', adminAuthMiddleware, async (req, res) => {
  try {
    const { contentId } = req.params;

    await database.run(
      'UPDATE articles SET is_approved = 1 WHERE id = ?',
      [contentId]
    );

    logger.info(`✓ Content approved: ${contentId}`);

    res.json({
      success: true,
      message: 'Content approved successfully'
    });
  } catch (error) {
    logger.error('Approve content error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to approve content'
    });
  }
});

// ============== DELETE CONTENT ==============
router.delete('/content/:contentId', adminAuthMiddleware, async (req, res) => {
  try {
    const { contentId } = req.params;

    // Delete related questions
    await database.run(
      'DELETE FROM questions WHERE article_id = ?',
      [contentId]
    );

    // Delete article
    await database.run(
      'DELETE FROM articles WHERE id = ?',
      [contentId]
    );

    logger.info(`✓ Content deleted: ${contentId}`);

    res.json({
      success: true,
      message: 'Content deleted successfully'
    });
  } catch (error) {
    logger.error('Delete content error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete content'
    });
  }
});

// ============== GET SCHEDULED TASKS ==============
router.get('/scheduler/tasks', adminAuthMiddleware, async (req, res) => {
  try {
    const tasks = scheduler.getScheduledTasks();

    res.json({
      success: true,
      data: tasks
    });
  } catch (error) {
    logger.error('Get scheduler tasks error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch scheduled tasks'
    });
  }
});

// ============== RUN TASK MANUALLY ==============
router.post('/scheduler/run/:taskName', adminAuthMiddleware, async (req, res) => {
  try {
    const { taskName } = req.params;

    logger.info(`Manual execution of task: ${taskName}`);

    const result = await scheduler.runTaskManually(taskName);

    res.json({
      success: true,
      message: `Task "${taskName}" executed`,
      data: result
    });
  } catch (error) {
    logger.error('Run task error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to execute task'
    });
  }
});

// ============== PAUSE/RESUME AI ENGINE ==============
router.post('/ai-engine/:action', adminAuthMiddleware, async (req, res) => {
  try {
    const { action } = req.params;

    if (action === 'pause') {
      process.env.PAUSE_AI_ENGINE = 'true';
      logger.warn('✓ AI Engine paused by admin');
      
      res.json({
        success: true,
        message: 'AI Engine paused successfully'
      });
    } else if (action === 'resume') {
      process.env.PAUSE_AI_ENGINE = 'false';
      logger.info('✓ AI Engine resumed by admin');
      
      res.json({
        success: true,
        message: 'AI Engine resumed successfully'
      });
    } else {
      res.status(400).json({
        success: false,
        message: 'Invalid action. Use "pause" or "resume"'
      });
    }
  } catch (error) {
    logger.error('AI engine control error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to control AI engine'
    });
  }
});

// ============== GET USER STATISTICS ==============
router.get('/users', adminAuthMiddleware, async (req, res) => {
  try {
    const users = await database.all(
      `SELECT u.id, u.name, u.email, u.subscription_status, u.created_at,
              (SELECT COUNT(*) FROM attempts WHERE user_id = u.id) as total_attempts,
              (SELECT COUNT(*) FROM doubts WHERE user_id = u.id) as total_doubts
       FROM users u
       WHERE u.is_admin = 0
       ORDER BY u.created_at DESC
       LIMIT 50`
    );

    res.json({
      success: true,
      data: users
    });
  } catch (error) {
    logger.error('Get users error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch users'
    });
  }
});

// ============== VIEW LOGS ==============
router.get('/logs', adminAuthMiddleware, async (req, res) => {
  try {
    const { action, limit = 50 } = req.query;

    let query = 'SELECT action, description, created_at FROM admin_logs';
    let params = [];

    if (action) {
      query += ' WHERE action = ?';
      params.push(action);
    }

    query += ' ORDER BY created_at DESC LIMIT ?';
    params.push(parseInt(limit));

    const logs = await database.all(query, params);

    res.json({
      success: true,
      data: logs
    });
  } catch (error) {
    logger.error('Get logs error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch logs'
    });
  }
});

// ============== SYSTEM HEALTH CHECK ==============
router.get('/health', adminAuthMiddleware, async (req, res) => {
  try {
    const health = await monitorAgent.generateSystemHealthCheck();

    res.json({
      success: true,
      data: health
    });
  } catch (error) {
    logger.error('Health check error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to perform health check'
    });
  }
});

module.exports = router;
