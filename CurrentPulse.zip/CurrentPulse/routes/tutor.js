const express = require('express');
const router = express.Router();
const database = require('../database/init');
const { authMiddleware } = require('../utils/auth');
const tutorAgent = require('../ai-engine/agents/tutor-agent');
const logger = require('../utils/logger');

// ============== ASK A DOUBT ==============
router.post('/ask-doubt', authMiddleware, async (req, res) => {
  try {
    const { question, subject, topic } = req.body;

    if (!question) {
      return res.status(400).json({
        success: false,
        message: 'Question is required'
      });
    }

    const result = await database.run(
      `INSERT INTO doubts (user_id, question, subject, topic)
       VALUES (?, ?, ?, ?)`,
      [req.user.userId, question, subject || 'General', topic || 'General']
    );

    logger.info(`✓ New doubt created: ${result.id}`);

    res.status(201).json({
      success: true,
      message: 'Your doubt has been submitted',
      data: {
        doubtId: result.id,
        message: 'Our expert will provide an explanation shortly'
      }
    });
  } catch (error) {
    logger.error('Ask doubt error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit doubt'
    });
  }
});

// ============== GET DOUBT ANSWER ==============
router.get('/doubt/:doubtId', authMiddleware, async (req, res) => {
  try {
    const { doubtId } = req.params;

    const doubt = await database.get(
      'SELECT * FROM doubts WHERE id = ? AND user_id = ?',
      [doubtId, req.user.userId]
    );

    if (!doubt) {
      return res.status(404).json({
        success: false,
        message: 'Doubt not found'
      });
    }

    // If not answered, try to generate answer
    if (doubt.is_answered === 0) {
      const result = await tutorAgent.answerDoubt(doubtId);
      
      if (result.success) {
        doubt.answer = result.explanation;
        doubt.is_answered = 1;
        doubt.answered_at = new Date().toISOString();
      }
    }

    res.json({
      success: true,
      data: {
        doubtId: doubt.id,
        question: doubt.question,
        answer: doubt.answer || 'Generating explanation...',
        subject: doubt.subject,
        topic: doubt.topic,
        isAnswered: doubt.is_answered === 1,
        answeredAt: doubt.answered_at
      }
    });
  } catch (error) {
    logger.error('Get doubt error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch doubt'
    });
  }
});

// ============== GET ALL DOUBTS ==============
router.get('/my-doubts', authMiddleware, async (req, res) => {
  try {
    const doubts = await database.all(
      `SELECT id, question, subject, topic, is_answered, answered_at, created_at
       FROM doubts
       WHERE user_id = ?
       ORDER BY created_at DESC
       LIMIT 50`,
      [req.user.userId]
    );

    res.json({
      success: true,
      data: doubts.map(d => ({
        doubtId: d.id,
        question: d.question,
        subject: d.subject,
        topic: d.topic,
        isAnswered: d.is_answered === 1,
        askedAt: d.created_at,
        answeredAt: d.answered_at
      }))
    });
  } catch (error) {
    logger.error('Get doubts error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch doubts'
    });
  }
});

// ============== GET EXPLANATION BY TOPIC ==============
router.post('/explain', authMiddleware, async (req, res) => {
  try {
    const { topic, subject } = req.body;

    if (!topic) {
      return res.status(400).json({
        success: false,
        message: 'Topic is required'
      });
    }

    const explanation = await tutorAgent.generateExplanation(
      topic,
      subject || 'General',
      topic
    );

    res.json({
      success: true,
      data: {
        topic,
        subject: subject || 'General',
        explanation
      }
    });
  } catch (error) {
    logger.error('Explain error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate explanation'
    });
  }
});

// ============== GET FREQUENTLY ASKED DOUBTS ==============
router.get('/faq', authMiddleware, async (req, res) => {
  try {
    const faqs = await database.all(
      `SELECT DISTINCT question, answer, subject, topic
       FROM doubts
       WHERE is_answered = 1 AND answer IS NOT NULL
       ORDER BY created_at DESC
       LIMIT 20`
    );

    res.json({
      success: true,
      data: faqs.map(faq => ({
        question: faq.question,
        answer: faq.answer,
        subject: faq.subject,
        topic: faq.topic
      }))
    });
  } catch (error) {
    logger.error('Get FAQ error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch FAQ'
    });
  }
});

module.exports = router;
