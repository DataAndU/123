const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const database = require('../database/init');
const { generateToken, authMiddleware } = require('../utils/auth');
const logger = require('../utils/logger');

// ============== REGISTER ==============
router.post('/register', async (req, res) => {
  try {
    const { email, password, name, phone } = req.body;

    // Validation
    if (!email || !password || !name) {
      return res.status(400).json({
        success: false,
        message: 'Email, password, and name are required'
      });
    }

    if (password.length < 8) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 8 characters'
      });
    }

    // Check if user exists
    const existingUser = await database.get(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );

    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: 'Email already registered'
      });
    }

    // Hash password
    const hashedPassword = bcrypt.hashSync(password, 10);

    // Create user
    const result = await database.run(
      `INSERT INTO users (email, password_hash, name, phone, subscription_status)
       VALUES (?, ?, ?, ?, ?)`,
      [email, hashedPassword, name, phone || null, 'trial']
    );

    // Set trial subscription (7 days)
    const trialEndDate = new Date();
    trialEndDate.setDate(trialEndDate.getDate() + 7);

    await database.run(
      `INSERT INTO subscriptions (user_id, plan, amount, status, start_date, end_date)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [result.id, 'trial', 0, 'active', new Date().toISOString(), trialEndDate.toISOString()]
    );

    // Generate token
    const token = generateToken(result.id, email, false);

    logger.info(`✓ New user registered: ${email}`);

    res.status(201).json({
      success: true,
      message: 'Registration successful',
      data: {
        userId: result.id,
        email,
        name,
        token
      }
    });
  } catch (error) {
    logger.error('Registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Registration failed'
    });
  }
});

// ============== LOGIN ==============
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Email and password are required'
      });
    }

    const user = await database.get(
      'SELECT id, password_hash, name, subscription_status, is_admin FROM users WHERE email = ?',
      [email]
    );

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    const passwordMatch = bcrypt.compareSync(password, user.password_hash);

    if (!passwordMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    const token = generateToken(user.id, email, user.is_admin === 1);

    logger.info(`✓ User logged in: ${email}`);

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        userId: user.id,
        email,
        name: user.name,
        subscriptionStatus: user.subscription_status,
        isAdmin: user.is_admin === 1,
        token
      }
    });
  } catch (error) {
    logger.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Login failed'
    });
  }
});

// ============== GET CURRENT USER ==============
router.get('/me', authMiddleware, async (req, res) => {
  try {
    const user = await database.get(
      'SELECT id, email, name, phone, subscription_status, is_admin FROM users WHERE id = ?',
      [req.user.userId]
    );

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    const subscription = await database.get(
      'SELECT * FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC LIMIT 1',
      [req.user.userId]
    );

    res.json({
      success: true,
      data: {
        ...user,
        isAdmin: user.is_admin === 1,
        subscription
      }
    });
  } catch (error) {
    logger.error('Get user error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch user data'
    });
  }
});

// ============== UPDATE PROFILE ==============
router.put('/profile', authMiddleware, async (req, res) => {
  try {
    const { name, phone } = req.body;

    await database.run(
      'UPDATE users SET name = ?, phone = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [name || null, phone || null, req.user.userId]
    );

    logger.info(`✓ Profile updated for user ${req.user.userId}`);

    res.json({
      success: true,
      message: 'Profile updated successfully'
    });
  } catch (error) {
    logger.error('Profile update error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update profile'
    });
  }
});

// ============== CHANGE PASSWORD ==============
router.post('/change-password', authMiddleware, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Current and new password are required'
      });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({
        success: false,
        message: 'New password must be at least 8 characters'
      });
    }

    const user = await database.get(
      'SELECT password_hash FROM users WHERE id = ?',
      [req.user.userId]
    );

    if (!bcrypt.compareSync(currentPassword, user.password_hash)) {
      return res.status(401).json({
        success: false,
        message: 'Current password is incorrect'
      });
    }

    const hashedPassword = bcrypt.hashSync(newPassword, 10);

    await database.run(
      'UPDATE users SET password_hash = ? WHERE id = ?',
      [hashedPassword, req.user.userId]
    );

    logger.info(`✓ Password changed for user ${req.user.userId}`);

    res.json({
      success: true,
      message: 'Password changed successfully'
    });
  } catch (error) {
    logger.error('Password change error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to change password'
    });
  }
});

module.exports = router;
