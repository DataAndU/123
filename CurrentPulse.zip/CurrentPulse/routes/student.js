const express = require('express');
const router = express.Router();
const database = require('../database/init');
const { authMiddleware } = require('../utils/auth');
const logger = require('../utils/logger');

// ============== GET DASHBOARD ==============
router.get('/dashboard', authMiddleware, async (req, res) => {
  try {
    const userId = req.user.userId;

    // Get user subscription status
    const user = await database.get(
      'SELECT subscription_status FROM users WHERE id = ?',
      [userId]
    );

    // Get total tests taken
    const testStats = await database.get(
      `SELECT COUNT(*) as total FROM (
        SELECT DISTINCT test_id FROM attempts WHERE user_id = ?
      )`,
      [userId]
    );

    // Get overall accuracy
    const accuracyStats = await database.get(
      `SELECT COUNT(*) as total, 
              SUM(CASE WHEN is_correct = 1 THEN 1 ELSE 0 END) as correct
       FROM attempts WHERE user_id = ?`,
      [userId]
    );

    const overallAccuracy = accuracyStats.total > 0 
      ? Math.round((accuracyStats.correct / accuracyStats.total) * 100) 
      : 0;

    // Get subject-wise accuracy
    const subjectAccuracy = await database.all(
      `SELECT q.subject, COUNT(*) as total,
              SUM(CASE WHEN a.is_correct = 1 THEN 1 ELSE 0 END) as correct
       FROM attempts a
       JOIN questions q ON a.question_id = q.id
       WHERE a.user_id = ?
       GROUP BY q.subject
       ORDER BY correct DESC`,
      [userId]
    );

    // Get streak (consecutive days with attempts)
    const streak = await database.get(
      `SELECT COUNT(DISTINCT DATE(created_at)) as streak
       FROM attempts
       WHERE user_id = ? AND created_at > datetime('now', '-30 days')`,
      [userId]
    );

    // Get today's test status
    const todayTest = await database.get(
      `SELECT t.id, COUNT(DISTINCT a.question_id) as answered
       FROM tests t
       LEFT JOIN attempts a ON t.id = a.test_id AND a.user_id = ?
       WHERE DATE(t.created_at) = DATE('now') AND t.test_type = 'daily'
       LIMIT 1`,
      [userId]
    );

    res.json({
      success: true,
      data: {
        subscriptionStatus: user.subscription_status,
        stats: {
          totalTestsTaken: testStats.total,
          overallAccuracy,
          streak: streak.streak || 0
        },
        subjectAccuracy: subjectAccuracy.map(s => ({
          subject: s.subject,
          total: s.total,
          correct: s.correct,
          accuracy: Math.round((s.correct / s.total) * 100)
        })),
        todayTest: todayTest ? {
          testId: todayTest.id,
          answered: todayTest.answered,
          status: todayTest.answered ? 'in-progress' : 'not-started'
        } : {
          status: 'no-test-today'
        }
      }
    });
  } catch (error) {
    logger.error('Dashboard error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to load dashboard'
    });
  }
});

// ============== GET AVAILABLE TESTS ==============
router.get('/tests', authMiddleware, async (req, res) => {
  try {
    const tests = await database.all(
      `SELECT t.*, 
              COUNT(tq.question_id) as total_questions,
              (SELECT COUNT(*) FROM attempts a WHERE a.test_id = t.id AND a.user_id = ?) as attempted
       FROM tests t
       LEFT JOIN test_questions tq ON t.id = tq.test_id
       GROUP BY t.id
       ORDER BY t.created_at DESC`,
      [req.user.userId]
    );

    res.json({
      success: true,
      data: tests
    });
  } catch (error) {
    logger.error('Get tests error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch tests'
    });
  }
});

// ============== GET TEST DETAILS ==============
router.get('/test/:testId', authMiddleware, async (req, res) => {
  try {
    const { testId } = req.params;

    const test = await database.get(
      'SELECT * FROM tests WHERE id = ?',
      [testId]
    );

    if (!test) {
      return res.status(404).json({
        success: false,
        message: 'Test not found'
      });
    }

    const questions = await database.all(
      `SELECT tq.*, q.question, q.subject FROM test_questions tq
       JOIN questions q ON tq.question_id = q.id
       WHERE tq.test_id = ?
       ORDER BY tq.sequence_order`,
      [testId]
    );

    res.json({
      success: true,
      data: {
        ...test,
        questions
      }
    });
  } catch (error) {
    logger.error('Get test details error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch test details'
    });
  }
});

// ============== SUBMIT ANSWER ==============
router.post('/answer', authMiddleware, async (req, res) => {
  try {
    const { testId, questionId, selectedAnswer, timeSpent } = req.body;

    if (!testId || !questionId || !selectedAnswer) {
      return res.status(400).json({
        success: false,
        message: 'Test ID, question ID, and selected answer are required'
      });
    }

    const question = await database.get(
      'SELECT correct_answer FROM questions WHERE id = ?',
      [questionId]
    );

    if (!question) {
      return res.status(404).json({
        success: false,
        message: 'Question not found'
      });
    }

    const isCorrect = selectedAnswer.toLowerCase() === question.correct_answer.toLowerCase() ? 1 : 0;

    await database.run(
      `INSERT INTO attempts (user_id, test_id, question_id, selected_answer, is_correct, time_spent_seconds)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [req.user.userId, testId, questionId, selectedAnswer, isCorrect, timeSpent || 0]
    );

    res.json({
      success: true,
      data: {
        isCorrect: isCorrect === 1,
        correctAnswer: question.correct_answer
      }
    });
  } catch (error) {
    logger.error('Submit answer error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to submit answer'
    });
  }
});

// ============== GET TEST RESULTS ==============
router.get('/test/:testId/results', authMiddleware, async (req, res) => {
  try {
    const { testId } = req.params;
    const userId = req.user.userId;

    const results = await database.all(
      `SELECT a.*, q.question, q.correct_answer, q.explanation, q.subject, q.difficulty_level
       FROM attempts a
       JOIN questions q ON a.question_id = q.id
       WHERE a.test_id = ? AND a.user_id = ?
       ORDER BY a.created_at`,
      [testId, userId]
    );

    const stats = await database.get(
      `SELECT COUNT(*) as total,
              SUM(CASE WHEN is_correct = 1 THEN 1 ELSE 0 END) as correct
       FROM attempts
       WHERE test_id = ? AND user_id = ?`,
      [testId, userId]
    );

    const accuracy = stats.total > 0 
      ? Math.round((stats.correct / stats.total) * 100) 
      : 0;

    res.json({
      success: true,
      data: {
        totalQuestions: stats.total,
        correctAnswers: stats.correct,
        accuracy,
        results
      }
    });
  } catch (error) {
    logger.error('Get results error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch results'
    });
  }
});

// ============== GET ATTEMPT HISTORY ==============
router.get('/history', authMiddleware, async (req, res) => {
  try {
    const history = await database.all(
      `SELECT DISTINCT DATE(a.created_at) as date, 
              COUNT(*) as attempts,
              SUM(CASE WHEN a.is_correct = 1 THEN 1 ELSE 0 END) as correct
       FROM attempts a
       WHERE a.user_id = ?
       GROUP BY DATE(a.created_at)
       ORDER BY date DESC
       LIMIT 30`,
      [req.user.userId]
    );

    res.json({
      success: true,
      data: history
    });
  } catch (error) {
    logger.error('Get history error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch history'
    });
  }
});

module.exports = router;
