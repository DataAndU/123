# CurrentPulse - Quick Start Guide

## 🚀 Get Running in 5 Minutes

### 1. Install Dependencies
```bash
npm install
```

### 2. Setup Environment
```bash
# Copy example environment file
cp .env.example .env

# Edit with your API keys
nano .env  # or use your favorite editor
```

**Required API Keys:**
- Get OpenAI API Key: https://platform.openai.com/api-keys
- Get Claude API Key: https://console.anthropic.com

### 3. Start Development Server
```bash
npm run dev
```

Server will start on `http://localhost:3000`

### 4. Access the Platform

#### Student Users
- **URL**: http://localhost:3000
- **Create Account**: Click "Get Started Free"
- **Dashboard**: http://localhost:3000/dashboard
- **Features**: Daily tests, practice, doubt solving

#### Admin/Founder
- **URL**: http://localhost:3000/admin
- **Default Email**: `founder@currentpulse.in`
- **Default Password**: `ChangeMe@123` (change this!)
- **Features**: Monitor AI, manage content, view reports

---

## 📝 Default Admin Account

**Email**: `founder@currentpulse.in`
**Password**: `ChangeMe@123`

⚠️ **IMPORTANT**: Change this password immediately in production!

---

## 🤖 AI Agents in Action

### What Happens Automatically

**Every Day at 5:00 AM**
- AI fetches latest news from government sources
- Converts news into study materials
- Generates 15 multiple-choice questions
- Publishes daily quiz at 6:00 AM

**Every 2 Hours**
- AI processes student doubts
- Generates personalized explanations

**Daily at 7:00 PM**
- AI analyzes student performance
- Identifies weak topics
- Recommends study improvements

**Daily at 8:00 PM**
- Generates daily report for founder

**Every Sunday**
- AI creates 50-question full mock test

### Manual Task Execution

Go to Admin Dashboard → Scheduler tab to manually run any task:
- Run Content Agent
- Generate Daily Quiz
- Create Mock Test
- Process Doubts
- Run Student Analysis
- Generate Report
- System Health Check

---

## 📊 Key Features

### For Students
✓ **Daily Test** - 15 questions every morning
✓ **Subject Practice** - Choose subject, practice 10 questions
✓ **Full Mock Test** - 50-question exam simulation
✓ **Doubt Solving** - Ask any concept question
✓ **Progress Tracking** - See accuracy by subject
✓ **Explanations** - Instant answer explanations

### For Founder (Admin)
✓ **Content Approval** - Review AI-generated questions
✓ **Pause/Resume AI** - Control automation
✓ **Run Tasks Manually** - Test agents anytime
✓ **View Reports** - Daily performance metrics
✓ **Monitor System** - Health checks, logs
✓ **User Analytics** - Track student engagement
✓ **Revenue Dashboard** - Subscription metrics

---

## 📁 Project Structure

```
CurrentPulse/
├── server.js                 # Main server file
├── package.json              # Dependencies
├── .env.example              # Environment template
├── ecosystem.config.js       # PM2 configuration
├── DEPLOYMENT.md             # Full deployment guide
│
├── routes/                   # API endpoints
│   ├── auth.js              # Login/Register
│   ├── student.js           # Student dashboard
│   ├── quiz.js              # Tests & quizzes
│   ├── tutor.js             # Doubt solving
│   ├── admin.js             # Admin functions
│   └── health.js            # Health checks
│
├── ai-engine/               # AI Automation
│   ├── scheduler.js         # Task scheduling
│   ├── agents/
│   │   ├── content-agent.js    # News → Study Material
│   │   ├── quiz-agent.js       # Questions generation
│   │   ├── tutor-agent.js      # Doubt solving
│   │   ├── improvement-agent.js # Performance analysis
│   │   └── monitor-agent.js    # Reporting
│
├── database/
│   └── init.js              # Database setup
│
├── utils/
│   ├── logger.js            # Logging
│   ├── auth.js              # JWT handling
│   └── retry.js             # API retry logic
│
└── public/                  # Frontend
    ├── index.html           # Landing page
    ├── dashboard.html       # Student dashboard
    └── admin.html           # Admin panel
```

---

## 🔌 API Endpoints

### Authentication
```
POST   /api/auth/register      - Create account
POST   /api/auth/login         - Login
GET    /api/auth/me            - Current user
PUT    /api/auth/profile       - Update profile
POST   /api/auth/change-password - Change password
```

### Student
```
GET    /api/student/dashboard          - Dashboard stats
GET    /api/student/tests              - Available tests
GET    /api/student/test/:testId       - Test questions
POST   /api/student/answer             - Submit answer
GET    /api/student/test/:testId/results - Test results
GET    /api/student/history            - Attempt history
```

### Quiz
```
POST   /api/quiz/start-daily           - Start daily test
POST   /api/quiz/practice/:subject     - Subject practice
GET    /api/quiz/full-mock             - Full mock test
GET    /api/quiz/subjects              - Available subjects
GET    /api/quiz/question/:id/explanation - Get explanation
```

### Tutor
```
POST   /api/tutor/ask-doubt            - Ask question
GET    /api/tutor/doubt/:doubtId       - Get answer
GET    /api/tutor/my-doubts            - All doubts
POST   /api/tutor/explain              - Get topic explanation
GET    /api/tutor/faq                  - Frequently asked questions
```

### Admin
```
GET    /api/admin/dashboard            - Dashboard
GET    /api/admin/stats                - Statistics
GET    /api/admin/content              - View content
GET    /api/admin/users                - View users
GET    /api/admin/logs                 - System logs
POST   /api/admin/ai-engine/pause      - Pause AI
POST   /api/admin/ai-engine/resume     - Resume AI
```

---

## 🧪 Testing the System

### Test User Registration
```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "student@test.com",
    "password": "TestPass123",
    "name": "Test Student"
  }'
```

### Test Daily Quiz Generation
Go to Admin Dashboard → Scheduler → Click "Run Quiz Agent"

### Test Doubt Solving
1. Go to Student Dashboard
2. Click "Ask Doubt"
3. Type a question like "What is compound interest?"
4. Go to Admin → Scheduler → Click "Process Doubts"
5. Refresh and see the answer

---

## 📊 Database Schema

### Users Table
- id, email, password_hash, name, subscription_status, created_at

### Questions Table
- id, question, options (a,b,c,d), correct_answer, explanation, subject, difficulty_level

### Tests Table
- id, test_type (daily/practice/full_mock), total_questions, duration_minutes

### Attempts Table
- id, user_id, test_id, question_id, selected_answer, is_correct, time_spent_seconds

### Doubts Table
- id, user_id, question, answer, is_answered, subject, topic

---

## 🔑 Environment Variables

```env
# Server
NODE_ENV=development
PORT=3000

# AI APIs (GET THESE FROM PROVIDERS)
OPENAI_API_KEY=sk-xxxxx
CLAUDE_API_KEY=sk-ant-xxxxx

# Security
JWT_SECRET=your-secret-key
JWT_EXPIRE=7d

# Database
DB_PATH=./database/currentpulse.db

# Admin
ADMIN_EMAIL=founder@currentpulse.in
ADMIN_PASSWORD_HASH=bcrypt-hash

# Features
ENABLE_AI_AUTOMATION=true
PAUSE_AI_ENGINE=false
```

---

## 🚀 Production Deployment

For full deployment instructions including:
- Hostinger VPS setup
- Nginx configuration
- SSL/HTTPS setup
- PM2 process management
- Database backups
- Monitoring

See **DEPLOYMENT.md**

---

## 📞 Getting Help

### Check if everything is working
```bash
curl http://localhost:3000/api/health
```

### View logs
```bash
npm run dev  # Shows logs in console
# OR
tail -f logs/combined.log
```

### Reset everything
```bash
# Delete database
rm database/currentpulse.db

# Restart server
npm run dev
```

---

## 💡 Next Steps

1. **Set Admin Password**: Go to admin.html, change password
2. **Configure AI**: Add OpenAI and Claude API keys
3. **Test Agents**: Run tasks manually from admin panel
4. **Monitor**: Watch logs as AI generates content
5. **Deploy**: Follow DEPLOYMENT.md for production setup

---

## 📚 Features NOT Showing "AI Powered"

The frontend NEVER mentions AI, automation, or that content is generated. Students see:

```
✓ "15 curated questions every morning"
✓ "Questions aligned with latest news"
✓ "Instant explanations from experts"
✓ "Personalized study recommendations"

NOT:
✗ "AI-powered questions"
✗ "Generated by artificial intelligence"
✗ "Automated system"
```

---

**Start building! 🚀**
