require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const database = require('./database/init');
const logger = require('./utils/logger');
const { startScheduler } = require('./ai-engine/scheduler');

const app = express();
const PORT = process.env.PORT || 3000;

// ============== MIDDLEWARE ==============
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ============== LOGGING MIDDLEWARE ==============
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    logger.info(`${req.method} ${req.path} ${res.statusCode} ${duration}ms`);
  });
  next();
});

// ============== DATABASE INITIALIZATION ==============
database.init().then(() => {
  logger.info('✓ Database initialized successfully');
}).catch(err => {
  logger.error('✗ Database initialization failed:', err);
  process.exit(1);
});

// ============== ROUTES ==============
app.use('/api/auth', require('./routes/auth'));
app.use('/api/student', require('./routes/student'));
app.use('/api/quiz', require('./routes/quiz'));
app.use('/api/tutor', require('./routes/tutor'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/health', require('./routes/health'));

// ============== SERVE FRONTEND ==============
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/dashboard.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/admin.html'));
});

// ============== ERROR HANDLING ==============
app.use((err, req, res, next) => {
  logger.error('Unhandled error:', err);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// ============== 404 HANDLER ==============
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Route not found' });
});

// ============== START SERVER ==============
const server = app.listen(PORT, () => {
  logger.info(`✓ CurrentPulse Server running on port ${PORT}`);
  logger.info(`✓ Environment: ${process.env.NODE_ENV || 'development'}`);
});

// ============== START AI SCHEDULER ==============
startScheduler();

// ============== GRACEFUL SHUTDOWN ==============
process.on('SIGTERM', () => {
  logger.info('SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('SIGINT received. Shutting down gracefully...');
  server.close(() => {
    logger.info('Server closed');
    process.exit(0);
  });
});

process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception:', err);
  process.exit(1);
});

module.exports = app;
