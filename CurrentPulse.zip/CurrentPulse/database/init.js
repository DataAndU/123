const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');
const logger = require('../utils/logger');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'currentpulse.db');

// Ensure database directory exists
const dbDir = path.dirname(DB_PATH);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

let db = null;

const init = async () => {
  return new Promise((resolve, reject) => {
    db = new sqlite3.Database(DB_PATH, (err) => {
      if (err) {
        logger.error('Database connection failed:', err);
        reject(err);
      } else {
        logger.info('Database connected:', DB_PATH);
        createTables()
          .then(resolve)
          .catch(reject);
      }
    });
  });
};

const createTables = async () => {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      // ============== USERS TABLE ==============
      db.run(`
        CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          email TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL,
          name TEXT NOT NULL,
          phone TEXT,
          subscription_status TEXT DEFAULT 'trial',
          subscription_end_date DATETIME,
          is_admin INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `, (err) => {
        if (err) logger.error('Error creating users table:', err);
      });

      // ============== SUBSCRIPTIONS TABLE ==============
      db.run(`
        CREATE TABLE IF NOT EXISTS subscriptions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          plan TEXT NOT NULL,
          amount REAL NOT NULL,
          status TEXT DEFAULT 'active',
          start_date DATETIME DEFAULT CURRENT_TIMESTAMP,
          end_date DATETIME,
          payment_id TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id)
        )
      `, (err) => {
        if (err) logger.error('Error creating subscriptions table:', err);
      });

      // ============== ARTICLES TABLE ==============
      db.run(`
        CREATE TABLE IF NOT EXISTS articles (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          source TEXT,
          source_url TEXT,
          key_facts TEXT,
          important_numbers TEXT,
          government_schemes TEXT,
          exam_relevance TEXT,
          category TEXT,
          difficulty_level TEXT,
          is_approved INTEGER DEFAULT 0,
          is_published INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          published_at DATETIME
        )
      `, (err) => {
        if (err) logger.error('Error creating articles table:', err);
      });

      // ============== QUESTIONS TABLE ==============
      db.run(`
        CREATE TABLE IF NOT EXISTS questions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          article_id INTEGER,
          question TEXT NOT NULL,
          option_a TEXT NOT NULL,
          option_b TEXT NOT NULL,
          option_c TEXT NOT NULL,
          option_d TEXT NOT NULL,
          correct_answer TEXT NOT NULL,
          explanation TEXT,
          subject TEXT NOT NULL,
          difficulty_level TEXT,
          category TEXT,
          is_approved INTEGER DEFAULT 0,
          is_published INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          published_at DATETIME,
          FOREIGN KEY (article_id) REFERENCES articles(id)
        )
      `, (err) => {
        if (err) logger.error('Error creating questions table:', err);
      });

      // ============== TESTS TABLE ==============
      db.run(`
        CREATE TABLE IF NOT EXISTS tests (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          test_type TEXT NOT NULL,
          total_questions INTEGER,
          duration_minutes INTEGER,
          subject TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `, (err) => {
        if (err) logger.error('Error creating tests table:', err);
      });

      // ============== TEST QUESTIONS MAPPING ==============
      db.run(`
        CREATE TABLE IF NOT EXISTS test_questions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          test_id INTEGER NOT NULL,
          question_id INTEGER NOT NULL,
          sequence_order INTEGER,
          FOREIGN KEY (test_id) REFERENCES tests(id),
          FOREIGN KEY (question_id) REFERENCES questions(id)
        )
      `, (err) => {
        if (err) logger.error('Error creating test_questions table:', err);
      });

      // ============== ATTEMPTS TABLE ==============
      db.run(`
        CREATE TABLE IF NOT EXISTS attempts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          test_id INTEGER NOT NULL,
          question_id INTEGER NOT NULL,
          selected_answer TEXT,
          is_correct INTEGER,
          time_spent_seconds INTEGER,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (user_id) REFERENCES users(id),
          FOREIGN KEY (test_id) REFERENCES tests(id),
          FOREIGN KEY (question_id) REFERENCES questions(id)
        )
      `, (err) => {
        if (err) logger.error('Error creating attempts table:', err);
      });

      // ============== DOUBTS TABLE ==============
      db.run(`
        CREATE TABLE IF NOT EXISTS doubts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          question TEXT NOT NULL,
          answer TEXT,
          subject TEXT,
          topic TEXT,
          is_answered INTEGER DEFAULT 0,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          answered_at DATETIME,
          FOREIGN KEY (user_id) REFERENCES users(id)
        )
      `, (err) => {
        if (err) logger.error('Error creating doubts table:', err);
      });

      // ============== ADMIN LOGS TABLE ==============
      db.run(`
        CREATE TABLE IF NOT EXISTS admin_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          action TEXT NOT NULL,
          description TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `, (err) => {
        if (err) logger.error('Error creating admin_logs table:', err);
      });

      // ============== SYSTEM HEALTH TABLE ==============
      db.run(`
        CREATE TABLE IF NOT EXISTS system_health (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          metric_name TEXT NOT NULL,
          metric_value TEXT,
          status TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `, (err) => {
        if (err) logger.error('Error creating system_health table:', err);
      });

      // Create indexes for better performance
      db.run('CREATE INDEX IF NOT EXISTS idx_user_email ON users(email)', (err) => {
        if (err) logger.error('Error creating index:', err);
      });

      db.run('CREATE INDEX IF NOT EXISTS idx_question_subject ON questions(subject)', (err) => {
        if (err) logger.error('Error creating index:', err);
      });

      db.run('CREATE INDEX IF NOT EXISTS idx_attempt_user ON attempts(user_id)', (err) => {
        if (err) logger.error('Error creating index:', err);
      });

      db.run('CREATE INDEX IF NOT EXISTS idx_article_category ON articles(category)', (err) => {
        if (err) logger.error('Error creating index:', err);
      });

      // Seed admin user if not exists (CHANGE THIS IN PRODUCTION)
      const seedAdminUser = () => {
        const bcrypt = require('bcryptjs');
        const adminEmail = process.env.ADMIN_EMAIL || 'founder@currentpulse.in';
        const adminPassword = 'ChangeMe@123'; // CHANGE THIS

        db.get('SELECT id FROM users WHERE email = ?', [adminEmail], (err, row) => {
          if (!row) {
            const hash = bcrypt.hashSync(adminPassword, 10);
            db.run(
              'INSERT INTO users (email, password_hash, name, is_admin) VALUES (?, ?, ?, ?)',
              [adminEmail, hash, 'Founder', 1],
              (err) => {
                if (err) {
                  logger.error('Error seeding admin user:', err);
                } else {
                  logger.info('✓ Admin user seeded successfully');
                }
              }
            );
          }
        });
      };

      // Run seed after tables are created
      setTimeout(seedAdminUser, 500);

      resolve();
    });
  });
};

const getDB = () => {
  if (!db) {
    throw new Error('Database not initialized');
  }
  return db;
};

const run = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) {
        logger.error('Database error:', err);
        reject(err);
      } else {
        resolve({ id: this.lastID, changes: this.changes });
      }
    });
  });
};

const get = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) {
        logger.error('Database error:', err);
        reject(err);
      } else {
        resolve(row);
      }
    });
  });
};

const all = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) {
        logger.error('Database error:', err);
        reject(err);
      } else {
        resolve(rows || []);
      }
    });
  });
};

module.exports = {
  init,
  getDB,
  run,
  get,
  all
};
