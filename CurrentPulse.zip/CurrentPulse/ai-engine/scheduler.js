const cron = require('node-cron');
const logger = require('../utils/logger');
const contentAgent = require('./agents/content-agent');
const quizAgent = require('./agents/quiz-agent');
const tutorAgent = require('./agents/tutor-agent');
const improvementAgent = require('./agents/improvement-agent');
const monitorAgent = require('./agents/monitor-agent');

let scheduledTasks = [];

const startScheduler = () => {
  try {
    logger.info('🚀 Starting AI Scheduler');

    // ============== DAILY CONTENT FETCH (5:00 AM) ==============
    const dailyContentTask = cron.schedule(process.env.DAILY_NEWS_FETCH_TIME || '0 5 * * *', async () => {
      logger.info('⏰ [SCHEDULED] Daily content fetch started');
      try {
        const result = await contentAgent.fetchAndGenerateContent();
        logger.info('✓ Daily content fetch completed:', result);
      } catch (error) {
        logger.error('✗ Daily content fetch failed:', error);
      }
    });
    scheduledTasks.push({ name: 'Daily Content Fetch', task: dailyContentTask });

    // ============== DAILY STUDY MATERIAL GENERATION (5:10 AM) ==============
    const dailyStudyTask = cron.schedule(process.env.DAILY_STUDY_GEN_TIME || '10 5 * * *', async () => {
      logger.info('⏰ [SCHEDULED] Daily study material generation started');
      // Content is generated during fetch, this can be used for additional processing
    });
    scheduledTasks.push({ name: 'Daily Study Generation', task: dailyStudyTask });

    // ============== DAILY MCQ GENERATION (5:20 AM) ==============
    const dailyQuizTask = cron.schedule(process.env.DAILY_QUIZ_GEN_TIME || '20 5 * * *', async () => {
      logger.info('⏰ [SCHEDULED] Daily quiz generation started');
      try {
        const result = await quizAgent.generateDailyQuiz();
        logger.info('✓ Daily quiz generation completed:', result);
      } catch (error) {
        logger.error('✗ Daily quiz generation failed:', error);
      }
    });
    scheduledTasks.push({ name: 'Daily Quiz Generation', task: dailyQuizTask });

    // ============== PUBLISH DAILY QUIZ (6:00 AM) ==============
    const publishQuizTask = cron.schedule(process.env.DAILY_QUIZ_PUBLISH_TIME || '0 6 * * *', async () => {
      logger.info('⏰ [SCHEDULED] Daily quiz publishing started');
      try {
        // Quiz is already published during generation, this is a confirmation step
        logger.info('✓ Daily quiz published');
      } catch (error) {
        logger.error('✗ Daily quiz publishing failed:', error);
      }
    });
    scheduledTasks.push({ name: 'Daily Quiz Publishing', task: publishQuizTask });

    // ============== PROCESS DOUBTS (Every 2 hours) ==============
    const processDoubtsTask = cron.schedule('0 */2 * * *', async () => {
      logger.info('⏰ [SCHEDULED] Processing unanswered doubts');
      try {
        const result = await tutorAgent.handleUnansweredDoubts();
        logger.info('✓ Doubts processing completed:', result);
      } catch (error) {
        logger.error('✗ Doubts processing failed:', error);
      }
    });
    scheduledTasks.push({ name: 'Process Doubts', task: processDoubtsTask });

    // ============== DAILY STUDENT ANALYSIS (7:00 PM) ==============
    const dailyAnalysisTask = cron.schedule('0 19 * * *', async () => {
      logger.info('⏰ [SCHEDULED] Daily student analysis started');
      try {
        const result = await improvementAgent.analyzeAndImprove();
        logger.info('✓ Daily analysis completed:', result);
      } catch (error) {
        logger.error('✗ Daily analysis failed:', error);
      }
    });
    scheduledTasks.push({ name: 'Daily Student Analysis', task: dailyAnalysisTask });

    // ============== DAILY REPORT GENERATION (8:00 PM) ==============
    const dailyReportTask = cron.schedule('0 20 * * *', async () => {
      logger.info('⏰ [SCHEDULED] Daily report generation started');
      try {
        const report = await monitorAgent.generateDailyReport();
        logger.info('✓ Daily report generated');
      } catch (error) {
        logger.error('✗ Daily report generation failed:', error);
      }
    });
    scheduledTasks.push({ name: 'Daily Report', task: dailyReportTask });

    // ============== SYSTEM HEALTH CHECK (Every 6 hours) ==============
    const healthCheckTask = cron.schedule('0 */6 * * *', async () => {
      logger.info('⏰ [SCHEDULED] System health check started');
      try {
        const health = await monitorAgent.generateSystemHealthCheck();
        logger.info('✓ System health check completed');
      } catch (error) {
        logger.error('✗ System health check failed:', error);
      }
    });
    scheduledTasks.push({ name: 'System Health Check', task: healthCheckTask });

    // ============== WEEKLY MOCK TEST GENERATION (Sunday 12:00 AM) ==============
    const weeklyMockTask = cron.schedule(process.env.WEEKLY_MOCK_TIME || '0 0 ? * SUN', async () => {
      logger.info('⏰ [SCHEDULED] Weekly mock test generation started');
      try {
        const result = await quizAgent.generateFullMockTest();
        logger.info('✓ Weekly mock test generated:', result);
      } catch (error) {
        logger.error('✗ Weekly mock test generation failed:', error);
      }
    });
    scheduledTasks.push({ name: 'Weekly Mock Test', task: weeklyMockTask });

    logger.info(`✓ AI Scheduler started with ${scheduledTasks.length} scheduled tasks`);
    
    // Log all scheduled tasks
    scheduledTasks.forEach(task => {
      logger.info(`  - ${task.name}`);
    });

  } catch (error) {
    logger.error('Failed to start scheduler:', error);
    throw error;
  }
};

const stopScheduler = () => {
  logger.info('Stopping AI Scheduler...');
  scheduledTasks.forEach(task => {
    task.task.stop();
  });
  scheduledTasks = [];
  logger.info('✓ AI Scheduler stopped');
};

const getScheduledTasks = () => {
  return scheduledTasks.map(task => ({
    name: task.name,
    nextDate: task.task.nextDate().toString()
  }));
};

const runTaskManually = async (taskName) => {
  logger.info(`Manual trigger: ${taskName}`);
  
  try {
    switch (taskName) {
      case 'content':
        return await contentAgent.fetchAndGenerateContent();
      case 'quiz':
        return await quizAgent.generateDailyQuiz();
      case 'mock':
        return await quizAgent.generateFullMockTest();
      case 'doubts':
        return await tutorAgent.handleUnansweredDoubts();
      case 'analysis':
        return await improvementAgent.analyzeAndImprove();
      case 'report':
        return await monitorAgent.generateDailyReport();
      case 'health':
        return await monitorAgent.generateSystemHealthCheck();
      default:
        return { error: 'Unknown task' };
    }
  } catch (error) {
    logger.error(`Manual task execution failed: ${taskName}`, error);
    return { error: error.message };
  }
};

module.exports = {
  startScheduler,
  stopScheduler,
  getScheduledTasks,
  runTaskManually
};
