const axios = require('axios');
const Anthropic = require('@anthropic-ai/sdk');
const parser = require('xml2js').parseString;
const database = require('../database/init');
const logger = require('../utils/logger');
const { apiCall } = require('../utils/retry');

const client = new Anthropic({
  apiKey: process.env.CLAUDE_API_KEY
});

const NEWS_SOURCES = {
  PIB: 'https://pib.gov.in/PressReleaseIframePage.aspx?PRID=1900000',
  GOV_INDIA: 'https://www.india.gov.in/official-website-india/government-india',
};

const fetchNewsFromRSS = async (feedUrl) => {
  try {
    logger.info(`Fetching news from RSS: ${feedUrl}`);
    
    const response = await apiCall(async () => {
      return axios.get(feedUrl, {
        timeout: 10000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });
    }, `RSS Feed Fetch: ${feedUrl}`);

    return response.data;
  } catch (error) {
    logger.error(`Error fetching RSS feed ${feedUrl}:`, error.message);
    return null;
  }
};

const parseRSSFeed = async (xmlData) => {
  return new Promise((resolve, reject) => {
    parser(xmlData, (err, result) => {
      if (err) {
        logger.error('RSS parsing error:', err);
        reject(err);
      } else {
        const items = result?.rss?.channel?.[0]?.item || [];
        resolve(items.map(item => ({
          title: item.title?.[0] || 'No title',
          description: item.description?.[0] || '',
          link: item.link?.[0] || '',
          pubDate: item.pubDate?.[0] || new Date().toISOString(),
          source: 'PIB'
        })));
      }
    });
  });
};

const generateStudyMaterial = async (newsItem) => {
  try {
    logger.info(`Generating study material for: ${newsItem.title}`);

    const prompt = `You are an expert exam coach. Convert the following news article into study material for SSC and Banking exams.

Article Title: ${newsItem.title}
Article Content: ${newsItem.description}

Generate a JSON response with the following structure:
{
  "title": "Descriptive title for exam relevance",
  "key_facts": "Array of 3-5 important facts in bullet format",
  "important_numbers": "Any important statistics or figures mentioned",
  "government_schemes": "If any government schemes are mentioned, describe them",
  "exam_relevance": "Why this news is important for SSC/Banking exams",
  "category": "General Awareness or Current Affairs",
  "difficulty_level": "easy|medium|hard"
}

Generate ONLY valid JSON, no other text.`;

    const message = await apiCall(async () => {
      return client.messages.create({
        model: 'claude-opus-4-20250805',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      });
    }, 'Claude API - Study Material Generation');

    const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
    
    // Extract JSON from response
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No JSON found in response');
    }

    const studyMaterial = JSON.parse(jsonMatch[0]);

    // Store in database
    const result = await database.run(
      `INSERT INTO articles (
        title, source, source_url, key_facts, important_numbers, 
        government_schemes, exam_relevance, category, difficulty_level, is_approved
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        studyMaterial.title || newsItem.title,
        newsItem.source,
        newsItem.link,
        studyMaterial.key_facts || '',
        studyMaterial.important_numbers || '',
        studyMaterial.government_schemes || '',
        studyMaterial.exam_relevance || '',
        studyMaterial.category || 'General Awareness',
        studyMaterial.difficulty_level || 'medium',
        1 // Auto-approve for now
      ]
    );

    logger.info(`✓ Study material created with ID: ${result.id}`);
    return result.id;
  } catch (error) {
    logger.error('Error generating study material:', error.message);
    return null;
  }
};

const fetchAndGenerateContent = async () => {
  try {
    logger.info('🔄 Content Agent: Starting news fetch and study material generation');

    // Fetch PIB news (using mock data for now)
    const newsItems = [
      {
        title: 'New Government Scheme Launched for Digital Payment',
        description: 'The government has launched a new scheme to promote digital payments with benefits including reduced transaction charges and cashback rewards.',
        link: 'https://pib.gov.in/example',
        source: 'PIB',
        pubDate: new Date().toISOString()
      },
      {
        title: 'RBI Announces New Policy on Inflation Control',
        description: 'The Reserve Bank of India has announced new policy measures to control inflation and stabilize the rupee value in the international market.',
        link: 'https://rbi.org.in/example',
        source: 'RBI',
        pubDate: new Date().toISOString()
      }
    ];

    let generatedCount = 0;

    for (const newsItem of newsItems) {
      const articleId = await generateStudyMaterial(newsItem);
      if (articleId) {
        generatedCount++;
      }
    }

    logger.info(`✓ Content Agent: Generated ${generatedCount} study materials`);

    // Log the activity
    await database.run(
      'INSERT INTO admin_logs (action, description) VALUES (?, ?)',
      ['CONTENT_GENERATION', `Generated ${generatedCount} study materials`]
    );

    return {
      success: true,
      articlesGenerated: generatedCount
    };
  } catch (error) {
    logger.error('Content Agent error:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

module.exports = {
  fetchAndGenerateContent,
  generateStudyMaterial,
  fetchNewsFromRSS,
  parseRSSFeed
};
