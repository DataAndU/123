const Anthropic = require('@anthropic-ai/sdk');
const database = require('../database/init');
const logger = require('../utils/logger');
const { apiCall } = require('../utils/retry');

const client = new Anthropic({
  apiKey: process.env.CLAUDE_API_KEY
});

const generateExplanation = async (userQuestion, subject = 'General', topic = 'General') => {
  try {
    logger.info(`Tutor Agent: Generating explanation for: ${userQuestion}`);

    const prompt = `You are an expert exam coach specialized in SSC and Banking exam preparation.

A student is asking: "${userQuestion}"
Subject: ${subject}
Topic: ${topic}

Provide a clear, exam-focused explanation that:
1. Explains the concept clearly
2. Provides exam tips
3. Gives example questions if relevant
4. Mentions related important topics

Keep the explanation concise but comprehensive (200-300 words).`;

    const message = await apiCall(async () => {
      return client.messages.create({
        model: 'claude-opus-4-20250805',
        max_tokens: 800,
        messages: [{ role: 'user', content: prompt }]
      });
    }, 'Claude API - Doubt Explanation');

    const explanation = message.content[0].type === 'text' ? message.content[0].text : '';
    return explanation;
  } catch (error) {
    logger.error('Error generating explanation:', error.message);
    return 'Unable to generate explanation. Please try again later.';
  }
};

const answerDoubt = async (doubtId) => {
  try {
    const doubt = await database.get(
      'SELECT * FROM doubts WHERE id = ?',
      [doubtId]
    );

    if (!doubt) {
      logger.warn(`Doubt ID ${doubtId} not found`);
      return { success: false, message: 'Doubt not found' };
    }

    logger.info(`Answering doubt: ${doubt.question}`);

    const explanation = await generateExplanation(
      doubt.question,
      doubt.subject || 'General',
      doubt.topic || 'General'
    );

    await database.run(
      `UPDATE doubts SET answer = ?, is_answered = 1, answered_at = datetime('now')
       WHERE id = ?`,
      [explanation, doubtId]
    );

    logger.info(`✓ Doubt ${doubtId} answered`);

    return {
      success: true,
      doubtId,
      explanation
    };
  } catch (error) {
    logger.error('Error answering doubt:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

const handleUnansweredDoubts = async () => {
  try {
    logger.info('🔄 Tutor Agent: Processing unanswered doubts');

    const unansweredDoubts = await database.all(
      'SELECT id FROM doubts WHERE is_answered = 0 ORDER BY created_at ASC LIMIT 10'
    );

    if (unansweredDoubts.length === 0) {
      logger.info('No unanswered doubts found');
      return { success: true, answeredCount: 0 };
    }

    let answeredCount = 0;

    for (const doubt of unansweredDoubts) {
      const result = await answerDoubt(doubt.id);
      if (result.success) {
        answeredCount++;
      }
    }

    logger.info(`✓ Tutor Agent: Answered ${answeredCount} doubts`);

    await database.run(
      'INSERT INTO admin_logs (action, description) VALUES (?, ?)',
      ['DOUBTS_ANSWERED', `Total doubts answered: ${answeredCount}`]
    );

    return {
      success: true,
      answeredCount
    };
  } catch (error) {
    logger.error('Tutor Agent error:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

module.exports = {
  generateExplanation,
  answerDoubt,
  handleUnansweredDoubts
};
