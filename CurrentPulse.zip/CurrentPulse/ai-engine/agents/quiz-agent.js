const OpenAI = require('openai');
const database = require('../database/init');
const logger = require('../utils/logger');
const { apiCall } = require('../utils/retry');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

const SUBJECTS = ['Quantitative Aptitude', 'Reasoning', 'English', 'General Awareness', 'Current Affairs'];

const generateMCQsFromArticle = async (articleId, articleData) => {
  try {
    logger.info(`Generating MCQs for article ${articleId}`);

    const prompt = `You are an expert exam question setter for SSC and Banking exams. 
Create multiple choice questions based on the following study material.

Title: ${articleData.title}
Key Facts: ${articleData.key_facts}
Important Numbers: ${articleData.important_numbers}
Government Schemes: ${articleData.government_schemes}

Generate 3 MCQs in JSON format. Each question must have:
{
  "questions": [
    {
      "question": "Question text here?",
      "option_a": "Option A",
      "option_b": "Option B",
      "option_c": "Option C",
      "option_d": "Option D",
      "correct_answer": "a|b|c|d",
      "explanation": "Detailed explanation of the correct answer",
      "difficulty_level": "easy|medium|hard",
      "subject": "${articleData.category || 'General Awareness'}"
    }
  ]
}

Generate ONLY valid JSON, no other text.`;

    const message = await apiCall(async () => {
      return openai.chat.completions.create({
        model: 'gpt-4o-mini',
        max_tokens: 1500,
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7
      });
    }, 'OpenAI API - MCQ Generation');

    const responseText = message.choices[0].message.content;
    
    // Extract JSON
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No JSON found in OpenAI response');
    }

    const questionsData = JSON.parse(jsonMatch[0]);
    let questionsCreated = 0;

    for (const q of questionsData.questions) {
      await database.run(
        `INSERT INTO questions (
          article_id, question, option_a, option_b, option_c, option_d,
          correct_answer, explanation, subject, difficulty_level, category, is_approved
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          articleId,
          q.question,
          q.option_a,
          q.option_b,
          q.option_c,
          q.option_d,
          q.correct_answer,
          q.explanation,
          q.subject || 'General Awareness',
          q.difficulty_level || 'medium',
          'Practice',
          1 // Auto-approve
        ]
      );
      questionsCreated++;
    }

    logger.info(`✓ Created ${questionsCreated} MCQs for article ${articleId}`);
    return questionsCreated;
  } catch (error) {
    logger.error(`Error generating MCQs for article ${articleId}:`, error.message);
    return 0;
  }
};

const generateDailyQuiz = async () => {
  try {
    logger.info('🔄 Quiz Agent: Generating daily quiz');

    // Get latest unpublished articles
    const articles = await database.all(
      `SELECT id, title, key_facts, important_numbers, government_schemes, category 
       FROM articles 
       WHERE is_published = 0 AND is_approved = 1
       LIMIT 3`
    );

    if (articles.length === 0) {
      logger.warn('No unpublished articles found for quiz generation');
      return { success: false, message: 'No articles available' };
    }

    let totalQuestions = 0;

    // Generate questions from each article
    for (const article of articles) {
      const count = await generateMCQsFromArticle(article.id, article);
      totalQuestions += count;
    }

    // Create daily test
    const testResult = await database.run(
      `INSERT INTO tests (test_type, total_questions, duration_minutes, subject, created_at)
       VALUES (?, ?, ?, ?, datetime('now'))`,
      ['daily', 15, 20, 'Mixed']
    );

    const testId = testResult.id;

    // Assign 15 questions to the test (mix of difficulties)
    const easyQuestions = await database.all(
      `SELECT id FROM questions WHERE is_published = 0 AND is_approved = 1 
       AND difficulty_level = 'easy' LIMIT 5`
    );

    const mediumQuestions = await database.all(
      `SELECT id FROM questions WHERE is_published = 0 AND is_approved = 1 
       AND difficulty_level = 'medium' LIMIT 5`
    );

    const hardQuestions = await database.all(
      `SELECT id FROM questions WHERE is_published = 0 AND is_approved = 1 
       AND difficulty_level = 'hard' LIMIT 5`
    );

    const allQuestions = [...easyQuestions, ...mediumQuestions, ...hardQuestions];
    
    for (let i = 0; i < allQuestions.length; i++) {
      await database.run(
        `INSERT INTO test_questions (test_id, question_id, sequence_order)
         VALUES (?, ?, ?)`,
        [testId, allQuestions[i].id, i + 1]
      );
    }

    // Mark questions as published
    await database.run(
      `UPDATE questions SET is_published = 1, published_at = datetime('now')
       WHERE id IN (SELECT question_id FROM test_questions WHERE test_id = ?)`,
      [testId]
    );

    logger.info(`✓ Quiz Agent: Daily quiz created with ${totalQuestions} questions`);

    await database.run(
      'INSERT INTO admin_logs (action, description) VALUES (?, ?)',
      ['DAILY_QUIZ_CREATED', `Test ID: ${testId}, Questions: ${totalQuestions}`]
    );

    return {
      success: true,
      testId,
      questionsGenerated: totalQuestions
    };
  } catch (error) {
    logger.error('Quiz Agent error:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

const generateFullMockTest = async () => {
  try {
    logger.info('🔄 Quiz Agent: Generating full mock test (50 questions)');

    // Get mix of questions from all subjects
    const questions = await database.all(
      `SELECT id, difficulty_level FROM questions 
       WHERE is_approved = 1
       ORDER BY RANDOM()
       LIMIT 50`
    );

    if (questions.length < 50) {
      logger.warn('Not enough questions for full mock test');
      return { success: false, message: 'Insufficient questions' };
    }

    const testResult = await database.run(
      `INSERT INTO tests (test_type, total_questions, duration_minutes, subject, created_at)
       VALUES (?, ?, ?, ?, datetime('now'))`,
      ['full_mock', 50, 120, 'Mixed (All Subjects)']
    );

    const testId = testResult.id;

    for (let i = 0; i < questions.length; i++) {
      await database.run(
        `INSERT INTO test_questions (test_id, question_id, sequence_order)
         VALUES (?, ?, ?)`,
        [testId, questions[i].id, i + 1]
      );
    }

    logger.info(`✓ Full mock test created with ID: ${testId}`);

    await database.run(
      'INSERT INTO admin_logs (action, description) VALUES (?, ?)',
      ['WEEKLY_MOCK_TEST', `Test ID: ${testId}`]
    );

    return {
      success: true,
      testId,
      questionsGenerated: 50
    };
  } catch (error) {
    logger.error('Mock test generation error:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

module.exports = {
  generateDailyQuiz,
  generateFullMockTest,
  generateMCQsFromArticle
};
