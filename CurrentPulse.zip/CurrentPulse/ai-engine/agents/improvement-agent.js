const Anthropic = require('@anthropic-ai/sdk');
const database = require('../database/init');
const logger = require('../utils/logger');
const { apiCall } = require('../utils/retry');

const client = new Anthropic({
  apiKey: process.env.CLAUDE_API_KEY
});

const SUBJECTS = ['Quantitative Aptitude', 'Reasoning', 'English', 'General Awareness', 'Current Affairs'];

const calculateSubjectAccuracy = async (userId) => {
  try {
    const subjectAccuracy = {};

    for (const subject of SUBJECTS) {
      const stats = await database.get(
        `SELECT 
           COUNT(*) as total,
           SUM(CASE WHEN is_correct = 1 THEN 1 ELSE 0 END) as correct
         FROM attempts a
         JOIN questions q ON a.question_id = q.id
         WHERE a.user_id = ? AND q.subject = ?`,
        [userId, subject]
      );

      const total = stats?.total || 0;
      const correct = stats?.correct || 0;
      const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;

      subjectAccuracy[subject] = {
        total,
        correct,
        accuracy
      };
    }

    return subjectAccuracy;
  } catch (error) {
    logger.error('Error calculating subject accuracy:', error);
    return {};
  }
};

const identifyWeakAreas = async (userId) => {
  try {
    const weakTopics = await database.all(
      `SELECT q.topic, q.subject, COUNT(*) as attempts, 
              SUM(CASE WHEN a.is_correct = 1 THEN 1 ELSE 0 END) as correct
       FROM attempts a
       JOIN questions q ON a.question_id = q.id
       WHERE a.user_id = ? AND a.is_correct = 0
       GROUP BY q.topic, q.subject
       ORDER BY attempts DESC
       LIMIT 10`,
      [userId]
    );

    return weakTopics.map(topic => ({
      subject: topic.subject,
      topic: topic.topic,
      attempts: topic.attempts,
      correct: topic.correct,
      accuracy: Math.round((topic.correct / topic.attempts) * 100)
    }));
  } catch (error) {
    logger.error('Error identifying weak areas:', error);
    return [];
  }
};

const generatePersonalizedRecommendations = async (userId) => {
  try {
    logger.info(`Generating personalized recommendations for user ${userId}`);

    const user = await database.get('SELECT * FROM users WHERE id = ?', [userId]);
    if (!user) {
      throw new Error('User not found');
    }

    const subjectAccuracy = await calculateSubjectAccuracy(userId);
    const weakAreas = await identifyWeakAreas(userId);

    const accuracySummary = Object.entries(subjectAccuracy)
      .map(([subject, data]) => `${subject}: ${data.accuracy}% (${data.correct}/${data.total})`)
      .join('\n');

    const weakAreasSummary = weakAreas
      .slice(0, 5)
      .map(area => `${area.subject} - ${area.topic}: ${area.accuracy}% accuracy`)
      .join('\n');

    const prompt = `You are a dedicated exam coaching expert. Analyze this student's performance and provide personalized improvement recommendations.

Student Performance Analysis:
${accuracySummary}

Weak Areas:
${weakAreasSummary || 'No specific weak areas identified yet'}

Generate a personalized improvement plan with:
1. Key strength areas to maintain
2. Specific weak areas to focus on
3. Daily practice recommendations
4. Study strategy suggestions
5. Timeline for improvement

Make it motivational and actionable.`;

    const message = await apiCall(async () => {
      return client.messages.create({
        model: 'claude-opus-4-20250805',
        max_tokens: 1200,
        messages: [{ role: 'user', content: prompt }]
      });
    }, 'Claude API - Personalized Recommendations');

    const recommendations = message.content[0].type === 'text' ? message.content[0].text : '';

    return {
      userId,
      subjectAccuracy,
      weakAreas,
      recommendations,
      generatedAt: new Date().toISOString()
    };
  } catch (error) {
    logger.error('Error generating recommendations:', error);
    return null;
  }
};

const analyzeAndImprove = async () => {
  try {
    logger.info('🔄 Improvement Agent: Starting daily analysis');

    // Get all active users with recent attempts
    const activeUsers = await database.all(
      `SELECT DISTINCT user_id FROM attempts 
       WHERE created_at > datetime('now', '-7 days')
       ORDER BY user_id DESC
       LIMIT 20`
    );

    if (activeUsers.length === 0) {
      logger.info('No active users to analyze');
      return { success: true, analyzedUsers: 0 };
    }

    let analyzedCount = 0;
    const recommendations = [];

    for (const userRecord of activeUsers) {
      const rec = await generatePersonalizedRecommendations(userRecord.user_id);
      if (rec) {
        recommendations.push(rec);
        analyzedCount++;
      }
    }

    logger.info(`✓ Improvement Agent: Analyzed ${analyzedCount} users`);

    await database.run(
      'INSERT INTO admin_logs (action, description) VALUES (?, ?)',
      ['DAILY_ANALYSIS', `Analyzed ${analyzedCount} users for performance improvements`]
    );

    return {
      success: true,
      analyzedUsers: analyzedCount,
      recommendations
    };
  } catch (error) {
    logger.error('Improvement Agent error:', error);
    return {
      success: false,
      error: error.message
    };
  }
};

module.exports = {
  calculateSubjectAccuracy,
  identifyWeakAreas,
  generatePersonalizedRecommendations,
  analyzeAndImprove
};
