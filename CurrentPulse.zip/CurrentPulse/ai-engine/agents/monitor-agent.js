const database = require('../database/init');
const logger = require('../utils/logger');

const generateDailyReport = async () => {
  try {
    logger.info('🔄 Monitor Agent: Generating daily report');

    // Collect metrics
    const metrics = {
      timestamp: new Date().toISOString(),
      articlesGenerated: 0,
      questionsGenerated: 0,
      testsCreated: 0,
      activeUsers: 0,
      newUsers: 0,
      doubtsSolved: 0,
      systemErrors: 0,
      performanceSummary: {}
    };

    // Articles generated today
    const articleStats = await database.get(
      `SELECT COUNT(*) as count FROM articles 
       WHERE created_at > datetime('now', '-1 day')`
    );
    metrics.articlesGenerated = articleStats?.count || 0;

    // Questions generated today
    const questionStats = await database.get(
      `SELECT COUNT(*) as count FROM questions 
       WHERE created_at > datetime('now', '-1 day')`
    );
    metrics.questionsGenerated = questionStats?.count || 0;

    // Tests created today
    const testStats = await database.get(
      `SELECT COUNT(*) as count FROM tests 
       WHERE created_at > datetime('now', '-1 day')`
    );
    metrics.testsCreated = testStats?.count || 0;

    // Active users
    const activeUserStats = await database.get(
      `SELECT COUNT(*) as count FROM users 
       WHERE subscription_status = 'active'`
    );
    metrics.activeUsers = activeUserStats?.count || 0;

    // New users today
    const newUserStats = await database.get(
      `SELECT COUNT(*) as count FROM users 
       WHERE created_at > datetime('now', '-1 day')`
    );
    metrics.newUsers = newUserStats?.count || 0;

    // Doubts solved today
    const doubtStats = await database.get(
      `SELECT COUNT(*) as count FROM doubts 
       WHERE answered_at > datetime('now', '-1 day')`
    );
    metrics.doubtsSolved = doubtStats?.count || 0;

    // Performance by subject
    const performanceBySubject = await database.all(
      `SELECT q.subject, COUNT(*) as total, 
              SUM(CASE WHEN a.is_correct = 1 THEN 1 ELSE 0 END) as correct
       FROM attempts a
       JOIN questions q ON a.question_id = q.id
       WHERE a.created_at > datetime('now', '-1 day')
       GROUP BY q.subject`
    );

    performanceBySubject.forEach(subject => {
      const accuracy = subject.total > 0 
        ? Math.round((subject.correct / subject.total) * 100) 
        : 0;
      metrics.performanceSummary[subject.subject] = {
        totalAttempts: subject.total,
        correct: subject.correct,
        accuracy: accuracy
      };
    });

    // Top performing topics
    const topTopics = await database.all(
      `SELECT q.topic, COUNT(*) as attempts, 
              SUM(CASE WHEN a.is_correct = 1 THEN 1 ELSE 0 END) as correct
       FROM attempts a
       JOIN questions q ON a.question_id = q.id
       WHERE a.created_at > datetime('now', '-1 day')
       GROUP BY q.topic
       ORDER BY correct DESC
       LIMIT 5`
    );

    metrics.topTopics = topTopics.map(topic => ({
      topic: topic.topic,
      attempts: topic.attempts,
      correct: topic.correct,
      accuracy: Math.round((topic.correct / topic.attempts) * 100)
    }));

    // Store report
    const reportJson = JSON.stringify(metrics);
    await database.run(
      `INSERT INTO admin_logs (action, description) VALUES (?, ?)`,
      ['DAILY_REPORT', reportJson]
    );

    logger.info('✓ Daily report generated');
    logger.info('Daily Report:', JSON.stringify(metrics, null, 2));

    return metrics;
  } catch (error) {
    logger.error('Monitor Agent error:', error);
    return null;
  }
};

const generateSystemHealthCheck = async () => {
  try {
    logger.info('🔄 Monitor Agent: Running system health check');

    const healthChecks = {};

    // Database check
    try {
      const dbTest = await database.get('SELECT 1 as test');
      healthChecks.database = {
        status: dbTest ? 'healthy' : 'warning',
        timestamp: new Date().toISOString()
      };
    } catch (err) {
      healthChecks.database = {
        status: 'error',
        error: err.message,
        timestamp: new Date().toISOString()
      };
    }

    // API connectivity check (placeholder)
    healthChecks.apis = {
      openai: 'configured',
      claude: 'configured',
      timestamp: new Date().toISOString()
    };

    // Storage check
    const storageStats = await database.get(
      `SELECT 
        (SELECT COUNT(*) FROM articles) as articles,
        (SELECT COUNT(*) FROM questions) as questions,
        (SELECT COUNT(*) FROM attempts) as attempts
      `
    );

    healthChecks.storage = {
      articles: storageStats?.articles || 0,
      questions: storageStats?.questions || 0,
      attempts: storageStats?.attempts || 0,
      timestamp: new Date().toISOString()
    };

    // Store health check
    await database.run(
      `INSERT INTO system_health (metric_name, metric_value, status) VALUES (?, ?, ?)`,
      ['daily_health_check', JSON.stringify(healthChecks), 'ok']
    );

    logger.info('✓ System health check completed');
    logger.info('Health Status:', JSON.stringify(healthChecks, null, 2));

    return healthChecks;
  } catch (error) {
    logger.error('System health check error:', error);
    return { status: 'error', error: error.message };
  }
};

const getMonitoringDashboard = async () => {
  try {
    const latestReport = await database.get(
      `SELECT description FROM admin_logs 
       WHERE action = 'DAILY_REPORT'
       ORDER BY created_at DESC
       LIMIT 1`
    );

    const latestHealth = await database.get(
      `SELECT metric_value FROM system_health 
       ORDER BY created_at DESC
       LIMIT 1`
    );

    const recentLogs = await database.all(
      `SELECT action, description, created_at FROM admin_logs 
       ORDER BY created_at DESC
       LIMIT 20`
    );

    return {
      latestReport: latestReport?.description ? JSON.parse(latestReport.description) : null,
      latestHealth: latestHealth?.metric_value ? JSON.parse(latestHealth.metric_value) : null,
      recentLogs
    };
  } catch (error) {
    logger.error('Error getting monitoring dashboard:', error);
    return null;
  }
};

module.exports = {
  generateDailyReport,
  generateSystemHealthCheck,
  getMonitoringDashboard
};
